# Calculation example
The handler accepts a and b and returns a result.
