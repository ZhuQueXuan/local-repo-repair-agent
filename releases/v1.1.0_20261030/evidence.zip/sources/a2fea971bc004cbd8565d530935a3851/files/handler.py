from calculator import divide

def handle(payload):
    return {"result": divide(payload["a"], payload["b"])}
