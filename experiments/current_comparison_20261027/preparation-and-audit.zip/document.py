"""Publish the exact frozen small-batch comparison, without revising old scores."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
a=json.loads((OUT/'audit.json').read_bytes());assert a['all_terminal'] and a['slots']==4
name='61_评测_当前版本两道新问题原版与完整组比较.md'
b=a['arms']['baseline'];f=a['arms']['full'];total=a['shared_requests_after'];known=a['known_price_estimate_cny'];unknown=a['unknown_placeholder_cny']
labels={'boltons-empty-record-names':'命名记录空名称','boltons-bits-width':'Bits指定位宽边界'}
rows=[]
for r in a['results']:
 checks=r.get('checks')
 score='；'.join(k+str(checks[k]['passed'])+'/'+str(checks[k]['tests_run']) for k in ['public','withheld','upstream']) if checks else r.get('evaluation_error','无候选')
 flow=(r.get('agent_exit') or '未正常提交') if r['variant']=='baseline' else str(r.get('collaboration_result'))+'/'+str(r.get('review_verdict'))
 rows.append('| '+labels[r['task']]+' / '+('原版' if r['variant']=='baseline' else '完整')+' `'+r['run_id'][:8]+'` | '+flow+' | '+('补丁通过' if r['resolved'] else '未解决')+' | '+score+' |')
failures=[]
for r in a['results']:
 if r['variant']=='full':
  for role in r.get('roles',[]):
   if role['status']=='failed':failures.append(f"- {labels[r['task']]}完整组，{role['phase']}：`{role.get('reason')}`。")
 elif r.get('agent_exit')!='Submitted':failures.append(f"- {labels[r['task']]}原版：`{r.get('agent_exit')}` / `{r.get('limit_kind')}`，补丁评分结果另列。")
conclusion='这批完整组的补丁通过数更高' if f['resolved']>b['resolved'] else '这批两组补丁通过数相同' if f['resolved']==b['resolved'] else '这批完整组的补丁通过数更低'
description=f"按用户直接授权，当前60版两道新公开行为（空记录名/Bits位宽）×原版/完整共4次预先冻结后执行，全部保留无重跑。终态补丁原版{b['resolved']}/2、完整{f['resolved']}/2；原版正常Submitted {a['normal_baseline_submissions']}/2，完整协作{a['full_complete']}/2。{a['platform_attempts']}尝试已知估算{known:.6f}元/未知占位{unknown:.2f}，完整费用未知；正式53payload/原2815请求/7426旧文件保持，现{total}，427输入保持。只加两题白名单/current_two设计，60行为与时限保持；原23服务+4组窄门控及题目红绿实际通过，非新全回归。结果详61，旧46/58负比较、59/60开发复验不回填；无面板重启、医疗、异机。熟悉同仓库两题各一次，不能作统计/跨仓库/因果或通用稳定声明。本批结束，不按结果追加付费。"
text=f'''# 当前版本：两道新问题原版与完整组比较

日期：2026-10-27。用户要求再选少量新问题，用当前版本先固定条件再执行原版/完整多Agent同题比较，真实调用无需逐次询问，所有好坏结果保留、旧成绩不改。本批**2题×2组各一次，共4个真实身份**，中途未换题、改策略、补跑、恢复旧身份或按结果选优。

**终态独立补丁：原版{b['resolved']}/2，完整组{f['resolved']}/2；原版正常Submitted为{a['normal_baseline_submissions']}/2，完整三角色成功{a['full_complete']}/2。** {conclusion}。这只是两道公开窄问题、单次运行的系统观察，不是统计显著结论或单模块收益证明。

## 新题和来源

| 固定问题 | 官方依据 | 原始版本 | 顺序 |
| --- | --- | --- | --- |
| `boltons-empty-record-names`：namedtuple/namedlist空名称抛错不当 | [官方PR462](https://github.com/mahmoud/boltons/pull/462) | boltons25.0.0 | 原版→完整 |
| `boltons-bits-width`：Bits接受超出指定位宽的值 | [官方变更记录](https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md)、[官方实现](https://github.com/mahmoud/boltons/blob/master/boltons/mathutils.py) | boltons25.0.0 | 完整→原版 |

已在本批模型结果产生前核对官方GitHub PR、变更记录和实现。这两个具体行为此前没有作为本项目调试或模型题目；旧集合update、时间时区、Unicode等题不同。源码仍为已保存的原字节commit `c23dbdadb6fecdf505eb4231559561913b84c13f`，没有人工注入缺陷，原BSD-3-Clause LICENSE随副本保留。上游有持续维护记录，现有Python环境足够，无安装/容器迁移成本。

评测复用已有比较批次、Mini worker、共享路由与独立补丁重放。直接迁入其他评测框架会改变现有Windows执行条件，本次没有必要，也没有声称运行官方SWE-bench。公开issue/源码可能在训练中被模型见过；“新”只指此前未参与本项目策略调试，不能称训练未见、私有留出或跨仓库评测。两题都来自同一熟悉仓库且可修范围窄，难度与代表性有限。

## 先固定的条件

源码基线为60版`{a['source_base_commit']}`；只为登记新题增加两处元数据接线：`comparison_inputs`精确白名单与packet映射、`comparison_batch.DESIGNS.current_two`，没有修改文档、修复、审查、提示、费用或时间规则。原六题及58两题的设计/旧身份仍保留，均未再次执行。

| 条件 | 原版 | 当前完整组 |
| --- | --- | --- |
| 主路径 | raw单Agent/DefaultAgent2.4.6 | adaptive_history＋前置文档＋修复＋首审＋最多一次必要返工/最终审查 |
| 公共输入 | 同一原始源码、问题、公开检查、登记上游子集 | 同左 |
| 额外能力 | 不开任务卡/文档/独立审查/Skills | 同58固定任务卡、固定文档问题、只读Skills/MCP注册；模型不保证使用 |
| 时间机会 | 300秒 | 原1800秒父时限，文档120/初修300/首审120/返工180/末审90秒 |
| 模型路由 | 原北邮优先、DeepSeek备用 | 同左，原切换与父任务共享规则 |
| 分母和重试 | 各2槽位，单次 | 各2槽位，单次；失败/超时/无候选均保留 |
| 最终评分 | 所有模型终态后，最终导出补丁或最后合法封存候选，干净副本独立验证 | 同左，协作完整成功还需三角色成功且approve、非降级 |

原版是当前Windows/共享记账适配下的raw基线，不声称字节等同最初历史部署。完整组总时间、提示、上下文、文档、审查和修改机会不同，因此比较的是两个完整系统，不能把差异单独归因于Agent数量或60某处补修。

批次为`temp/comparison_batches/c61_1027`，运行前固定427份输入，计划SHA256 `{a['plan_sha256']}`。全部4个request_key与run_id先登记再串行运行，两个题的先后组别交错。原正式worker空闲与无队列门控、批次锁、唯一claimed记录及精确计划授权保持。`fixed-conditions.json`、资格结果和用户本次授权在调度前保存，本身不是追加付费权限。

## 资格与离线接线

每题2个公开行为方法、3个保留方法；开发侧参考只用于验证题目红绿，未发给模型。原始/参考均实际执行相关上游子集：

| 开发侧资格 | 原始公开/保留/上游 | 参考公开/保留/上游 |
| --- | --- | --- |
| 空记录名 | 0/2、2/3、3/3 | 2/2、3/3、3/3 |
| Bits位宽 | 0/2、1/3、11/11 | 2/2、3/3、11/11 |

保留方法包括保持原有行为的兼容检查，故原始代码的部分保留检查本来就应通过。没有要求每个保留方法都在原版失败；14个登记上游方法只是相关子集，不是仓库全套。

现有23项任务服务检查通过，复用原4组窄门控覆盖：已知设计白名单、公开ZIP字节正确且排除保留/参考、活动模型不能保留评分与4个失败仍保留分母、新计费拒绝识别。没有新增测试项目或测试文件，也没有复跑完整回归；57的301/425、60的78为旧轮范围，不能算本批新成绩。准备检查0模型调用；测试身份只登记后取消，未成为真实运行或费用。

保留/参考从工作副本、快照、提示中排除，但修复Bash没有OS级隔离，不保证对恶意越级读取保密。模型任务仍禁止父目录读取、联网/安装、删除或修改测试。

## 全部四次结果

| 任务/组及新身份前缀 | 流程结果 | 终态补丁 | 独立公开/保留/上游 |
| --- | --- | --- | --- |
{chr(10).join(rows)}

模型正常提交、终态补丁能通过与完整协作通过分别报告。保护停止留下的补丁按预声明规则评分，但不能写成正常提交；没有导出/合法候选即未解决，仍留在分母。失败工作目录的原始diff只用于诊断，绝不补造候选或替代主评分。全部保留评分只在4个worker均终态后开始，原始轨迹、拒绝、错误与模型费用均保存。

当前失败或非正常退出原因：

{chr(10).join(failures) if failures else '本批没有失败或非正常退出；仍不据此推导通用稳定率。'}

空名称题原版只产生4个Bash动作，未改实现，最终导出的0字节补丁无法应用。这里的`Final patch cannot replay`是空补丁/未解决，不是有效修复被评测设施损坏而误判。完整组文档交接3998字节、3条引用并明确information_not_found，初修185个Bash动作反复组合读取两个函数、grep和旧tool-output，未运行验证或提交、无合法候选，达到300秒。59的早纠正只识别单个简单cat/sed，复合读取/旧输出回读仍有缺口；这是本批已保存轨迹与代码能直接核对的适用边界。本轮不在半途扩展守卫，不把前两次已用题成功当作该边界已解决。

Bits题两组都正常提交且通过独立公开2/保留3/上游11检查；完整组文档3701字节、4引用并明确information_not_found，初修9个Bash动作、首审approve，没有返工或降级。原版6个Bash动作后Submitted。本题多角色完整完成，但没有多修好一个原版未解决的问题。

详细动作计数、重复命令、工具选择、文档状态和引用/交接大小保存在`diagnostics.json`与manifest。它们用于解释本批观察，不改变评分，也不能从一次轨迹反推模型内部原因。文档/审查的合法性仍非事实理解的通用质量证明；注册工具不等于实际使用收益。

## 请求、费用和耗时

| 指标 | 原版2槽位 | 完整组2槽位 |
| --- | --- | --- |
| 独立补丁通过 | {b['resolved']}/2 | {f['resolved']}/2 |
| 平台尝试 | {b['attempts']} | {f['attempts']} |
| 已知价格估算，元 | {b['known_price_estimate_cny']:.6f} | {f['known_price_estimate_cny']:.6f} |
| 未知费用占位，元 | {b['unknown_placeholder_cny']:.2f} | {f['unknown_placeholder_cny']:.2f} |
| 原运行记录耗时累计，秒 | {b['elapsed_seconds']:.3f} | {f['elapsed_seconds']:.3f} |

共{a['platform_attempts']}次平台尝试，已知价格估算{known:.6f}元，另有{unknown:.2f}元未知费用占位；完整费用未知，不把两者相加当确认扣费，不探测余额。失败首选请求和备用请求继续保留原记账。耗时含各运行本机处理，不是纯模型延迟，两组时间机会不同。

计费停止记录：`{a['billing_stop']}`。若余额不足/计费拒绝，后续未启动槽位按既有门控取消且仍计入原分母，不换身份补跑。原范围持续授权不等于无目的花完余额。

本批四个任务的北邮首试均返回500，按原已声明规则转DeepSeek备用；没有发生余额不足或计费拒绝，未把500判为认证或余额问题。完整组本批请求、已知估算与耗时更高，最终解决的题与原版相同，因此本批没有显示修复数量收益，不能据此评价所有多Agent系统。

## 保护、归档与后续

正式53条payload、原2815条账本请求及7426份旧experiments/evaluation文件逐项保持，共享请求现为{total}；本批427份冻结输入在模型和终态评分后再次核对一致。原46六题、58两题、59/60开发复验分别保留，不混合分母或回填旧成绩。没有重启8765、操作医疗、异机验证、安装依赖或删除文件。

本轮正式新增两题原字节包、两处声明接线、本记录和`experiments/current_comparison_20261027/`；README、快速接手、协作入口、开发流水账及Job导航同步。原始上游源码的既有空白格式逐字节保留；仅检查本轮原创接线/文档格式，不为通过格式检查改动冻结上游源码。

归档保留固定条件、计划/授权、原始/参考资格、全4次身份与工具轨迹、合法候选/补丁、所有失败、独立评分、费用增量回执、诊断原diff、哈希与只读保护审计。ZIP成员及外层SHA256核验，扫描两份本机真实模型凭据和令牌模式，包括嵌套包；正式数据库与整份共享账本不上传。上传原私有仓库main后再核对远端提交与工作树。

本批明确范围已结束，不追加运行让结果更好看。后续若根据本批问题修改系统，这两道题即转开发/回归使用，新的效果评价需重新选题和冻结，不能继续称未用题。
'''
(ROOT/'Project'/name).write_text(text,encoding='utf-8')
def insert(p,marker,addition):
 raw=p.read_text('utf-8');assert marker in raw and addition not in raw
 p.write_text(raw.replace(marker,marker+'\n\n'+addition,1),encoding='utf-8')
insert(ROOT/'AGENTS.md','## 当前阶段',f'- 2026-10-27最新：[61当前版新两题比较](Project/{name})：'+description)
insert(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。',f'2026-10-27最新：[61当前版新两题比较]({name})：'+description)
insert(ROOT/'README.md','## 当前证据与未完成项',f'- [61当前版两道新问题比较](Project/{name})：先冻结后执行4次，原版终态补丁{b["resolved"]}/2、完整组{f["resolved"]}/2，原版正常Submitted {a["normal_baseline_submissions"]}/2、完整协作{a["full_complete"]}/2。所有好坏结果保留，无选优重跑；同一熟悉仓库、每组各一次，不能推导通用或单模块收益。旧成绩不改。')
insert(ROOT/'Project/项目开发流水账.md','# 项目开发流水账',f'**当前版先冻结再比较（2026-10-27）。** 我选了此前未用的空记录名和Bits位宽两题，保持60版机制，固定两组/交错顺序/单次/终态保留评分后执行4次。原版终态补丁{b["resolved"]}/2、完整组{f["resolved"]}/2，正常Submitted {a["normal_baseline_submissions"]}/2、完整协作{a["full_complete"]}/2。共{a["platform_attempts"]}尝试，已知估算{known:.6f}元/未知占位{unknown:.2f}，完整费用未知；53正式任务和旧2815请求/7426文件保持，现{total}。不补跑选优、不回填旧成绩；全部轨迹、失败和评分归档。见[61]({name})。')
insert(ROOT.parent/'job/AGENTS.md','## 当前状态与导航',f'- 2026-10-27主项目最新：[61当前版新两题比较](../shixi_project/Project/{name})：'+description)
print('Stage61 and five navigation documents written.')
