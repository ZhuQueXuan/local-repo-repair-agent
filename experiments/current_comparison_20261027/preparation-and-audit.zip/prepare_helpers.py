"""Reuse stage58 audit/archive helpers, with this batch's exact identities."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
old=ROOT/'temp/fresh_comparison_20261027'
for name in ['audit.py','diagnose.py','seal.py']:
 source=(old/name).read_text('utf-8')
 for before,after in [('f2_1027','c61_1027'),("'stage':58","'stage':61"),('2477','2815'),
   ('fresh_comparison_20261027','current_comparison_20261027')]:
  source=source.replace(before,after)
 if name=='seal.py':
  source=source.replace("'scripts/comparison_inputs.py','scripts/comparison_batch.py','scripts/task_service_worker.py'", "'scripts/comparison_inputs.py','scripts/comparison_batch.py'")
  source=source.replace("'task_service_worker.py-before',",'')
  source=source.replace("'baseline.json','authorization-record.json'", "'baseline.json','fixed-conditions.json','authorize.py','prepare_helpers.py','service-tests.txt','authorization-record.json'")
 target=OUT/name;assert not target.exists();target.write_text(source,encoding='utf-8')
print('Current-batch audit, diagnostics and archive helpers prepared; no model calls.')
