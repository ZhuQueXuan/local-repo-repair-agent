"""Two new-to-project public behaviors on unchanged boltons 25.0.0."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts')]
from collaboration_protocol import canonical_bytes
SOURCE=ROOT/'evaluation/multi_agent_20261025/public/boltons-query-encoding'
DEST=ROOT/'evaluation/current_comparison_20261027';assert not DEST.exists()
base=json.loads((SOURCE/'manifest.json').read_bytes())
specs={
'boltons-empty-record-names':{
 'target':'tests/test_namedutils.py','problem':'https://github.com/mahmoud/boltons/pull/462',
 'issue':'''# Record factories raise IndexError for empty names

The namedtuple and namedlist factories leak IndexError when a type name is empty or an empty string appears in an explicit field-name iterable. These are invalid names and should raise ValueError, consistently with other invalid-name inputs.

Apply the behavior to both factories. Preserve valid record creation, positional/keyword access, the existing field-name string syntax, and rename=True replacement of invalid or duplicate field names. rename=True must not make an empty type name valid. Empty field lists remain valid zero-field records. Do not require a particular error message. Change implementation only, leaving tests and metadata untouched.
''',
 'public':'''import unittest
from boltons.namedutils import namedtuple, namedlist
class Cases(unittest.TestCase):
 def test_empty_type(self):
  for factory in (namedtuple,namedlist):
   with self.subTest(factory=factory.__name__),self.assertRaises(ValueError): factory('', ['x'])
 def test_empty_field(self):
  for factory in (namedtuple,namedlist):
   with self.subTest(factory=factory.__name__),self.assertRaises(ValueError): factory('Point',['x',''])
''',
 'withheld':'''import unittest
from boltons.namedutils import namedtuple, namedlist
class Cases(unittest.TestCase):
 def test_empty_type_is_not_renamable(self):
  for factory in (namedtuple,namedlist):
   for fields in ([],['x'],['','x']):
    with self.subTest(factory=factory.__name__,fields=fields),self.assertRaises(ValueError): factory('',fields,rename=True)
 def test_rename_preserves_values_and_fields(self):
  for factory in (namedtuple,namedlist):
   with self.subTest(factory=factory.__name__):
    record=factory('Sample',['x','','x','class'],rename=True)
    self.assertEqual(record._fields,('x','_1','_2','_3'))
    self.assertEqual(tuple(record(1,2,3,4)),(1,2,3,4))
 def test_valid_zero_fields_and_existing_invalid_names(self):
  for factory in (namedtuple,namedlist):
   with self.subTest(factory=factory.__name__):
    self.assertEqual(tuple(factory('Empty',[])()),())
    value=factory('Point','x, y')(x=3,y=4); self.assertEqual((value.x,value.y),(3,4))
    for fields in (['x-y'],['x','x'],['_hidden']):
     with self.assertRaises(ValueError): factory('Bad',fields)
''',
 'edits':[{'path':'boltons/namedutils.py',
  'old':"    for name in [typename] + field_names:\n        if not all(c.isalnum() or c == '_' for c in name):",
  'new':"    for name in [typename] + field_names:\n        if not name or not all(c.isalnum() or c == '_' for c in name):",'expected_occurrences':2}]},
'boltons-bits-width':{
 'target':'tests/test_mathutils.py','problem':'https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md',
 'issue':'''# Bits accepts an integer that does not fit its explicit width

Bits(8, 3) is accepted even though eight cannot fit into three binary digits. Bits.from_int has the same problem. It can create an object whose binary representation is longer than its declared length.

Reject nonnegative values outside the representable range of an explicitly requested nonnegative integer width with ValueError. This also applies when a binary or hexadecimal string is converted by the constructor with an explicit width. Keep zero and the highest fitting value valid, preserve padding, inferred widths and existing conversions, and retain rejection of negative values. Width zero may represent zero only. Negative or non-integer widths and unrelated slicing/formatting edge cases are outside this task. Change implementation only; do not edit tests or metadata.
''',
 'public':'''import unittest
from boltons.mathutils import Bits
class Cases(unittest.TestCase):
 def test_constructor_width_boundary(self):
  with self.assertRaises(ValueError): Bits(8,3)
  self.assertEqual(Bits(7,3).as_bin(),'111')
 def test_from_int_width_boundary(self):
  with self.assertRaises(ValueError): Bits.from_int(16,4)
  self.assertEqual(Bits.from_int(0,4).as_bin(),'0000')
''',
 'withheld':'''import unittest
from boltons.mathutils import Bits
class Cases(unittest.TestCase):
 def test_powers_of_two_and_fitting_neighbors(self):
  for width in (1,2,5,13,64):
   for factory in (Bits,Bits.from_int):
    with self.subTest(width=width,factory=factory):
     with self.assertRaises(ValueError): factory(1<<width,width)
     value=factory((1<<width)-1,width); self.assertEqual(len(value),width);self.assertEqual(len(value.as_bin()),width)
 def test_converted_strings_and_zero_width(self):
  for text in ('1000','0x8'):
   with self.subTest(text=text),self.assertRaises(ValueError): Bits(text,3)
  with self.assertRaises(ValueError): Bits(1,0)
  self.assertEqual(Bits(0,0).as_int(),0);self.assertEqual(len(Bits(0,0)),0)
 def test_padding_inference_and_negative_value(self):
  self.assertEqual(Bits(3,8).as_bin(),'00000011')
  self.assertEqual(Bits(8).as_bin(),'1000')
  self.assertEqual(Bits('0011').as_bin(),'0011')
  self.assertEqual(Bits.from_hex('0F').as_int(),15)
  with self.assertRaises(ValueError): Bits(-1,4)
''',
 'edits':[{'path':'boltons/mathutils.py','old':'        if val > 2 ** len_:',
  'new':'        if val >= 2 ** len_:','expected_occurrences':1}]}}
for task,s in specs.items():
 public=DEST/'public'/task;authority=DEST/'evaluator'/task
 public.mkdir(parents=True);authority.mkdir(parents=True)
 for n,h in base['source_files_sha256'].items():
  raw=(SOURCE/'repo'/n).read_bytes();assert hashlib.sha256(raw).hexdigest()==h
  p=public/'repo'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 (public/'checks').mkdir();(public/'issue.md').write_bytes(s['issue'].encode());(public/'checks/test_behavior.py').write_bytes(s['public'].encode())
 (authority/'test_behavior.py').write_bytes(s['withheld'].encode())
 (authority/'reference.json').write_bytes(canonical_bytes({'edits':s['edits'],'scope':'Trusted developer qualification only; excluded from model inputs'}))
 source={'problem_url':s['problem'],'corroboration':'https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md',
  'base_tag':base['base_tag'],'base_commit':base['base_commit'],'license':'BSD-3-Clause; original LICENSE retained',
  'previous_project_model_use_of_this_issue':False,'selection':'Two concrete behaviors absent from previous project task ids and issue descriptions. Selected before model outcomes; familiar repository, not training-unseen or cross-repository evidence.'}
 if task.endswith('bits-width'):source['fixed_source_url']='https://github.com/mahmoud/boltons/blob/master/boltons/mathutils.py'
 (authority/'source.json').write_bytes(canonical_bytes(source))
 manifest={**base,'task_id':task,'problem_url':s['problem'],'upstream_target':[s['target']],'full_target':[s['target']],
  'agent_test_command':'python -B -m pytest '+s['target']+' -q -p no:cacheprovider',
  'task_files_sha256':{n:hashlib.sha256((public/n).read_bytes()).hexdigest() for n in ('issue.md','checks/test_behavior.py')}}
 (public/'manifest.json').write_bytes(canonical_bytes(manifest))
(DEST/'README.md').write_bytes(b'# Current-version two-task comparison inputs\n\nTwo previously unused public behaviors: empty record names (PR462), Bits explicit-width boundary (official changelog/source). Unchanged boltons25.0.0 source, BSD-3-Clause LICENSE retained. Four predeclared slots, baseline/full once each. Qualification precedes all model outcomes; evaluator/reference never enter public workspaces. Familiar repository; no OS sandbox, training-unseen, cross-repository or official benchmark claim.\n')
print('Created 2 unchanged baselines, 4 public and 6 retained test methods; 0 model calls.')
