"""Bind direct human approval to the final exact four-slot plan."""
import hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c61_1027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from comparison_batch import verify
from collaboration_protocol import canonical_bytes
p=verify(HOME);assert p['design']=='current_two' and len(p['slots'])==4
assert p['tasks']==['boltons-empty-record-names','boltons-bits-width']
assert not (HOME/'dispatched.json').exists() and not (HOME/'authorization.json').exists()
log=(OUT/'service-tests.txt').read_text('utf-8-sig');assert 'Ran 23 tests in ' in log and log.rstrip().endswith('OK')
import re
offline=json.loads((OUT/'offline-checks.json').read_bytes())
offline['existing_task_service_tests']['seconds']=float(re.search(r'Ran 23 tests in ([\d.]+)s',log)[1])
offline['implementation_changes']='Only two task IDs/packet mapping and a current_two predeclared design; repair/document/review behavior remains stage60.'
(OUT/'offline-checks.json').write_bytes(canonical_bytes(offline))
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==json.loads((OUT/'formal-before.json').read_bytes())
assert json.loads((ROOT/'data/deepseek_budget.json').read_bytes())==json.loads((OUT/'ledger-before.json').read_bytes())
history=json.loads((OUT/'historical-before.json').read_bytes())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in history.items())
digest=hashlib.sha256((HOME/'plan.json').read_bytes()).hexdigest()
(HOME/'authorization.json').open('xb').write(canonical_bytes({'approved':True,'plan_sha256':digest,'maximum_runs':4}))
(OUT/'authorization-record.json').write_bytes(canonical_bytes({'human_instruction':json.loads((OUT/'baseline.json').read_bytes())['authorization'],
 'plan_sha256':digest,'maximum_runs':4,'no_selection_reruns':True,'old_results_unchanged':True,'balance_not_probed':True}))
conditions={'design':'current_two','tasks':p['tasks'],'slots':p['slots'],'source_base_commit':json.loads((OUT/'baseline.json').read_bytes())['source_commit'],
 'plan_sha256':digest,'frozen_input_files':len(p['files_sha256']),
 'arms':{k:p[k] for k in ['baseline','full']},'confounds':p['confounds'],'visibility':p['visibility'],
 'scoring':p['scoring'],'failure_policy':p['failure_policy'],'destinations':p['destinations'],'accounting':p['accounting'],
 'qualification_before_any_model':True,'public_sources':['https://github.com/mahmoud/boltons/pull/462','https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md',
 'https://github.com/mahmoud/boltons/blob/master/boltons/mathutils.py'],
 'limits':'Two issues from one familiar repository, narrow behaviors, one repetition; no cross-repository, training-unseen, official benchmark or module-causal claim.'}
(OUT/'fixed-conditions.json').write_bytes(canonical_bytes(conditions))
print(json.dumps({'plan_sha256':digest,'frozen_files':len(p['files_sha256']),'maximum_runs':4,'old_requests_unchanged':2815,
 'order':[(s['task'],s['variant']) for s in p['slots']]}))
