"""Narrow offline checks for the new two-task design, using existing components."""
import json,sys,uuid,zipfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
import comparison_batch as b
from comparison_inputs import TASKS,CURRENT_TASKS,public_task
from collaboration_store import CollaborationStore
from task_service_worker import freeze_inputs
from collaboration_protocol import canonical_bytes

checks=[]
assert len(TASKS)==6 and len(CURRENT_TASKS)==2 and b.design_tasks({})==TASKS
assert b.design_tasks({'design':'current_two'})==CURRENT_TASKS
try:b.design_tasks({'design':'arbitrary'})
except ValueError:pass
else:raise AssertionError('Unknown design accepted')
checks.append('old six/default and new two exact allowlists; arbitrary design rejected')
for task in CURRENT_TASKS:
 home=OUT/'snapshot'/task;home.mkdir(parents=True)
 listing=freeze_inputs(task,home)
 with zipfile.ZipFile(home/'frozen_public_inputs.zip') as z:
  assert all('/public/'+task+'/' in n and '/evaluator/' not in n for n in z.namelist())
  assert all(b.sha(z.read(n))==listing[n] for n in z.namelist())
 assert not any('/evaluator/' in n for n in listing)
checks.append('new public snapshots preserve exact bytes and omit evaluator/reference')
home=ROOT/'temp/comparison_batches'/('gate-'+uuid.uuid4().hex[:6]);home.mkdir(parents=True)
store=CollaborationStore(home/'store');slots=[]
for task in CURRENT_TASKS:
 for variant in ('baseline','full'):
  key=uuid.uuid4().hex;row=store.create(task,'raw','live',key,model_profile='legacy_deepseek_v1')
  slots.append({'task':task,'variant':variant,'request_key':key,'repetition':1,'run_id':row['id']})
try:b.score(home,store,slots)
except ValueError:pass
else:raise AssertionError('Nonterminal scoring accepted')
for s in slots:store.cancel(s['run_id'])
report=b.score(home,store,slots)
assert report['slots']==4 and len(report['results'])==4 and report['resolved']=={'baseline':0,'full':0}
assert all('No exported' in r['evaluation_error'] for r in report['results'])
checks.append('active-worker scoring rejected; all four no-candidate failures stay in denominator')
assert b.billing_failure({'requests':{'old':{'failure':{'kind':'insufficient_balance'}}}},{'old'}) is None
assert b.billing_failure({'requests':{'new':{'failure':{'kind':'connection_failed'}}}},set()) is None
assert b.billing_failure({'requests':{'new':{'failure':{'kind':'insufficient_balance','status_code':402}}}},set())['status_code']==402
checks.append('new explicit billing rejection stops; historical failures and unknown balance do not')
(OUT/'offline-checks.json').write_bytes(canonical_bytes({'checks':checks,'groups_passed':len(checks),
 'existing_task_service_tests':{'tests_run':23,'passed':23,'seconds':0,'command':['.venv/Scripts/python.exe','-B','-m','unittest','discover','-s','scripts','-p','test_task_service.py','-v']},'model_calls':0}))
print(json.dumps({'narrow_check_groups':len(checks),'original_service_tests_passed':23,'model_calls':0}))
