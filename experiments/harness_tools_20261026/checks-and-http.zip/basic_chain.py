import json
import os
from pathlib import Path
import sys
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent_demo import exercise
store,runner,summary,wires=exercise(allow_capabilities=True)
row=summary['run']
registries={p.stem:json.loads(p.read_bytes()) for p in runner.output.glob('*-tool-registry.json')}
result={'store_home':str(store.home),'run_id':summary['run_id'],'counts':summary['counts'],
        'status':row['status'],'repair_result':row['repair_result'],'review_verdict':row['review_verdict'],
        'receipt_counts':{k:len(v['receipts']) for k,v in registries.items()},'external_model_calls':0}
(OUT/'basic-chain.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
assert row['status']=='finished' and row['repair_result']=='passed' and row['review_verdict']=='approve'
assert set(summary['counts'])=={'consulting','repairing','reviewing','revising','final_review'}
for name,registry in registries.items():
    assert any(r['tool']=='read_skill' and r['outcome']=='finished' for r in registry['receipts']),name
    if name!='consulting-tool-registry':
        receipts=[r for r in registry['receipts'] if r['tool']=='read_change_summary']
        assert len(receipts)==1 and receipts[0]['outcome']=='finished'
        assert [x['method'] for x in receipts[0]['mcp']['exchanges']]==['initialize','tools/list','tools/call']
        assert receipts[0]['mcp']['transport']=='stdio'
assert all('read_skill' not in w['tool_names'] and 'read_change_summary' not in w['tool_names']
           for w in wires if w['phase'] in {'repairing','revising'})
assert all('bash' not in w['tool_names'] for w in wires if w['phase'] in {'consulting','reviewing','final_review'})
