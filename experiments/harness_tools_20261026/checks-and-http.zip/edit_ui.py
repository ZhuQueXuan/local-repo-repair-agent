from pathlib import Path
root=Path(__file__).resolve().parents[2]
path=root/'scripts/task_panel.html'
text=path.read_text(encoding='utf-8')
old='<button id="start" class="primary">'
assert text.count(old)==1
text=text.replace(old,'<label><input id="allowCapabilities" type="checkbox" disabled>启用只读工具与Skills扩展（实验）</label><p class="hint">仅用于新建普通双/三角色；增加按需工作方法与本地MCP变更概览，不增加写入或执行权限。</p>'+old)
old="if($('allowPause').checked)request.allow_pause=true;"
assert text.count(old)==1
text=text.replace(old,old+"if($('allowCapabilities').checked)request.allow_capabilities=true;")
old='<script src="/checkpoint-panel.js"></script>'
assert text.count(old)==1
text=text.replace(old,old+'<script src="/capability-panel.js"></script>')
old='<div id="notice" role="status"></div>'
assert text.count(old)==1
text=text.replace(old,old+'<p id="capabilityRunState" class="hint" hidden></p>')
path.write_text(text,encoding='utf-8')
