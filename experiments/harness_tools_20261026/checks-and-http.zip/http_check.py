import json
import os
from pathlib import Path
import sys
import threading
import urllib.request
import urllib.error
import uuid
from http.server import ThreadingHTTPServer
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_store import CollaborationStore
from task_service import make_handler
store=CollaborationStore(OUT/'http-store')
server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(store,'offline-capabilities-check',0))
port=server.server_port
server.RequestHandlerClass=make_handler(store,'offline-capabilities-check',port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base='http://127.0.0.1:'+str(port)
def api(path,body=None,token='offline-capabilities-check',raw=False):
    req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),
        headers={'X-Task-Token':token,'Content-Type':'application/json','Origin':base})
    with urllib.request.urlopen(req,timeout=5) as r:
        data=r.read();return r.status,data if raw else json.loads(data)
try:
    html=api('/',raw=True)[1]
    assert b'allowCapabilities' in html and b'/capability-panel.js' in html
    assert b'capabilityChoices' in api('/capability-panel.js',raw=True,token='')[1]
    body={'task':'split-after-boundary','profile':'adaptive_history','mode':'live','request_key':uuid.uuid4().hex,
          'collaboration_mode':'dual_review','policy_version':1,'allow_capabilities':True}
    try:api('/api/runs',body,token='bad')
    except urllib.error.HTTPError as e:assert e.code==403
    else:raise AssertionError('Authentication bypass')
    status,row=api('/api/runs',body)
    assert status==201 and row['status']=='queued' and row['harness_capabilities_version']==1
    assert api('/api/runs',body)[1]['id']==row['id']
    try:api('/api/runs',dict(body,allow_capabilities=False))
    except urllib.error.HTTPError as e:assert e.code==409
    else:raise AssertionError('Configuration changed under same key')
    assert api('/api/runs/'+row['id']+'/collaboration')[1]['harness_capabilities']['version']==1
    api('/api/runs/'+row['id']+'/cancel',{})
    _,legacy=api('/api/runs',dict(body,request_key=uuid.uuid4().hex,allow_capabilities=False))
    assert 'harness_capabilities_version' not in legacy
    api('/api/runs/'+legacy['id']+'/cancel',{})
    for bad in ['yes',1]:
        try:api('/api/runs',dict(body,request_key=uuid.uuid4().hex,allow_capabilities=bad))
        except urllib.error.HTTPError as e:assert e.code==400
        else:raise AssertionError('Non-boolean option accepted')
    try:api('/api/runs',dict(body,request_key=uuid.uuid4().hex,collaboration_mode='single'))
    except urllib.error.HTTPError as e:assert e.code==400
    else:raise AssertionError('Unsupported mode enabled')
finally:
    server.shutdown();server.server_close();thread.join(timeout=2)
result={'checks':['HTML/assets','authenticated creation','explicit opt-in','same-key idempotence',
    'configuration conflict','read-only capability view','default off','boolean validation','unsupported mode rejection'],
    'workers_started':0,'external_model_calls':0,'browser_clicks_verified':False,'store_home':str(store.home)}
(OUT/'http-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
