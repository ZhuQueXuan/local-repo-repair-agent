import json
import os
from pathlib import Path
import sys
import uuid
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent_demo import exercise
from harness_checkpoints import request_pause,continue_checkpoint,checkpoint_view
from task_cards import card_view
from collaboration_panel import usage_view
card={'goal':'保留扩展配置与已完成查阅','steps':[{'id':'repair','title':'修复并审查','status':'pending'}]}
def boundary(name,role,runner):
    if name=='after_role_completion' and role['phase']=='consulting':request_pause(runner.store,runner.run_id)
store,first,summary,wires=exercise(scenario='approve',task_card=card,allow_pause=True,allow_capabilities=True,checkpoint=boundary)
source=summary['run'];assert source['status']=='paused',source
before=store.get(source['id']);view=checkpoint_view(store,source['id'])
child=continue_checkpoint(store,source['id'],{'request_key':'capability-'+uuid.uuid4().hex,'checkpoint_sha256':view['checkpoint_sha256'],
    'task_card':card_view(store,source['id'])['card']})
assert child['harness_capabilities_version']==1
store,second,final,new_wires=exercise(scenario='approve',continuation={'home':str(store.home),'run_id':child['id']})
assert final['run']['status']=='finished' and final['run']['repair_result']=='passed' and final['run']['review_verdict']=='approve',final['run']
assert store.get(source['id'])==before
assert {w['phase'] for w in new_wires}=={'repairing','reviewing'}
registry=json.loads((second.output/'reviewing-tool-registry.json').read_bytes())
assert any(r['tool']=='read_change_summary' and r['outcome']=='finished' for r in registry['receipts'])
usage=usage_view(store,store.get(child['id']))
assert usage['lineage']['attempts']==len(wires)+len(new_wires)
result={'store_home':str(store.home),'source':source['id'],'child':child['id'],'source_unchanged':True,
    'configuration_inherited':True,'completed_document_role_not_repeated':True,'repair_result':'passed','review_verdict':'approve',
    'lineage_usage':usage['lineage'],'external_model_calls':0}
(OUT/'continuation-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
