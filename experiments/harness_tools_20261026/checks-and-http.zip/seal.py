import hashlib
import json
from pathlib import Path
import zipfile
from dotenv import dotenv_values

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_tools_20261026'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Do not overwrite an archive'
basic=json.loads((OUT/'basic-chain.json').read_bytes())
continued=json.loads((OUT/'continuation-check.json').read_bytes())
boundary=json.loads((OUT/'boundary-checks.json').read_bytes())
http=json.loads((OUT/'http-check.json').read_bytes())
protect=json.loads((OUT/'protection-check.json').read_bytes())
ui=json.loads((OUT/'ui-check.json').read_bytes())
assert basic['status']=='finished' and basic['repair_result']=='passed'
assert continued['source_unchanged'] and continued['configuration_inherited']
assert 'Ran 6 tests' in (OUT/'compatibility.log').read_text(encoding='utf-8')
assert (OUT/'compatibility.log').read_text(encoding='utf-8').rstrip().endswith('OK')
sources=['harness_tool_registry.py','harness_capabilities.py','harness_skills.py','harness_mcp_server.py',
    'harness_mcp_client.py','capability_panel.js','collaboration_live.py','collaboration_store.py',
    'collaboration_panel.py','harness_checkpoints.py','review_model.py','document_agent_demo.py',
    'task_service.py','task_service_worker.py','task_panel.html']
documents=[ROOT/'Project/39_过程_Harness只读工具注册与Skills扩展.md',ROOT/'Project/00_项目现状与快速接手.md',
    ROOT/'Project/项目开发流水账.md',ROOT/'AGENTS.md',ROOT/'README.md',ROOT.parent/'job/AGENTS.md']
secrets=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(secrets)>=2
DEST.mkdir();outer={};scanned=0;counts={}
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,label in entries:
            if not path.is_file() or path.name in {'.env','server.lock','worker.lock'} or '__pycache__' in path.parts:continue
            raw=path.read_bytes()
            assert not any(secret in raw for secret in secrets),'Credential scan rejected archive'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(k))==v for k,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes());outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
    counts[name]=len(members)
pack('source-and-documents.zip',[(ROOT/'scripts'/n,'scripts/'+n) for n in sources]+
    [(p,p.relative_to(ROOT).as_posix()) for p in (ROOT/'skills').glob('*/SKILL.md')]+
    [(p,p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else 'job/AGENTS.md') for p in documents])
pack('checks-and-http.zip',[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.rglob('*')) if p.name not in {'panel.log','panel-error.log'}])
for name,path in [('final-scripted-chain.zip',basic['store_home']),('continuation-scripted-chain.zip',continued['store_home']),
    ('first-restricted-failure.zip',ROOT/'temp/document_agent_demo/b5fb500a902647649a3d0fdbc94b96f9')]:
    path=Path(path);pack(name,[(p,p.relative_to(path).as_posix()) for p in sorted(path.rglob('*'))])
result={**protect,'scope':'Opt-in readonly tool registry, approved method skills, fixed local MCP tool subset. Scripted model replies; local processes/checks actually executed.',
    'basic_chain':basic,'continuation_before_source_pinning':continued,'boundary_checks':boundary,'http':http,'ui':ui,
    'existing_compatibility_checks_passed':6,'full_regression_run':False,'new_formal_test_files':0,'browser_clicks_verified':False,
    'panel':json.loads((OUT/'panel-restored.json').read_bytes()),'archive_members':counts,
    'credential_scan':{'keys_checked':len(secrets),'files_scanned':scanned,'matches':0},
    'pending':['Real model tool/skill selection and quality','Browser clicks','General external MCP interoperability',
               'Execution backend and Python/Node environment interfaces','Model capability adaptation','Consolidated system acceptance']}
write(DEST/'verification.json',result);outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'protected_files':protect['protected_old_files_hash_verified'],
    'formal_payloads':protect['formal_payloads_unchanged'],'ledger_requests':protect['shared_ledger_requests']},ensure_ascii=False))
