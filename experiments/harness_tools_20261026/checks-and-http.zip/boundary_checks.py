import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_protocol import ProtocolError, canonical_bytes, sha256
from harness_capabilities import CapabilityBroker
from harness_mcp_client import change_overview
from harness_mcp_server import overview
from review_tools import ReviewCancelled
from test_collaboration_protocol import StageAFixture

f=StageAFixture();events=[]
context=SimpleNamespace(identity=f.reviewer,role={'phase':'reviewing'},deadline=time.monotonic()+10,
    check=lambda:None,store=SimpleNamespace(event=lambda *a:events.append(a)))
broker=CapabilityBroker(f.broker,context,OUT/'boundary-registry.json')
catalog=broker.prompt_catalog();assert 'body' not in catalog['skills'][0]
before={p:sha256(p.read_bytes()) for p in f.snapshot.directory.rglob('*') if p.is_file()}
def reject(name,args,reason):
    try:broker.dispatch(f.reviewer,name,args)
    except ProtocolError as error:assert str(error)==reason,(reason,str(error))
    else:raise AssertionError('Forbidden invocation accepted')
reject('bash',{'command':'echo forbidden'},'tool_not_registered_for_role')
reject('read_change_summary',{'candidate_id':'other'},'candidate_identity_mismatch')
reject('read_skill',{'skill':'document-consultation','sha256':'0'*64},'skill_not_allowed_for_role')
reject('read_skill',{'skill':'evidence-review','sha256':'0'*64},'skill_version_changed')
result=broker.dispatch(f.reviewer,'read_change_summary',{'candidate_id':f.snapshot.candidate.candidate_id})
assert result['changed_files']==1 and result['added']==1 and result['removed']==1
assert not f.broker.evidence and 'evidence' not in result
assert before=={p:sha256(p.read_bytes()) for p in f.snapshot.directory.rglob('*') if p.is_file()}
f.broker.cancelled=lambda:True
try:broker.dispatch(f.reviewer,'read_change_summary',{'candidate_id':f.snapshot.candidate.candidate_id})
except ReviewCancelled:pass
else:raise AssertionError('Cancelled tool accepted')

# Header-looking lines INSIDE a hunk count as source, not another file header.
patch='--- a/x.py\n+++ b/x.py\n@@ -1,2 +1,2 @@\n--- a/trick\n+++ b/trick\n keep\n'
arguments={'candidate_id':'c','source_tree_digest':'0'*64,'patch_sha256':sha256(patch.encode()),'patch':patch}
summary,trace=change_overview(arguments,lambda:None,time.monotonic()+5)
assert summary['changed_files']==1 and summary['files'][0]['path']=='x.py'
assert summary['added']==summary['removed']==1
try:overview(dict(arguments,patch_sha256='f'*64))
except ValueError:pass
else:raise AssertionError('Tampered patch accepted')

calls=[]
def cancel_after_launch():
    calls.append(True)
    if len(calls)>=3:raise ReviewCancelled('Synthetic cancellation during MCP handshake')
try:change_overview(arguments,cancel_after_launch,time.monotonic()+5)
except ReviewCancelled:pass
else:raise AssertionError('MCP cancellation ignored')
report={'checks':['role tool restriction','candidate binding','skill role restriction','skill hash binding',
    'real MCP lifecycle and diff counts','no new issued evidence','snapshot bytes preserved',
    'cancel before dispatch','hunk header ambiguity','tampered patch rejected','cancel during MCP handshake'],
    'mcp_exchanges':trace['exchanges'],'external_model_calls':0}
(OUT/'boundary-checks.json').write_bytes(canonical_bytes(report));print(json.dumps(report))
