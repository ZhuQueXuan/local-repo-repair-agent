"""Document specialist reuses the existing provider, guards and shared ledger."""
from collaboration_runtime import ProtectedReviewModel
from document_agent import DOCUMENT_SCHEMAS
import json
from collaboration_protocol import canonical_bytes, sha256
from context_budget import message_bytes


class ProtectedDocumentModel(ProtectedReviewModel):
    tool_schemas = DOCUMENT_SCHEMAS

    def _prepare_messages_for_api(self, messages):
        prepared = super()._prepare_messages_for_api(messages)
        if message_bytes(prepared) <= 12288:
            return prepared
        pairs = [i for i in range(1, len(prepared)) if prepared[i].get("role") == "tool"
            and prepared[i-1].get("role") == "assistant" and len(prepared[i-1].get("tool_calls", [])) == 1
            and prepared[i-1]["tool_calls"][0]["id"] == prepared[i].get("tool_call_id")]
        # Remove only completed assistant/tool pairs together. The raw messages
        # remain in the durable trajectory; no synthetic tool receipt is added.
        for keep in (3, 2, 1):
            archived = pairs[:-keep]
            if not archived:
                continue
            omitted = {index for i in archived for index in (i-1, i)}
            evidence_ids = []
            excerpts, requests = {}, {}
            for i in archived:
                raw = json.loads(messages[i]["content"])
                evidence_ids.extend([raw["evidence"]["evidence_id"]] if raw.get("evidence") else [])
                evidence_ids.extend(hit["evidence"]["evidence_id"] for hit in raw.get("hits", []))
                for hit in ([raw] if raw.get("evidence") else raw.get("hits", [])):
                    ref=hit["evidence"]
                    excerpts[ref["evidence_id"]]={"evidence_id":ref["evidence_id"],"document_id":ref.get("document_id"),
                        "start_line":ref.get("start_line"),"end_line":ref.get("end_line"),
                        "exact_prefix":hit.get("content","")[:180],"prefix_is_full_quote":len(hit.get("content",""))<=180}
                call=messages[i-1]["tool_calls"][0]["function"]
                requests[call["name"]+call["arguments"]]={"tool":call["name"],"arguments":json.loads(call["arguments"])}
            note = {"completed_document_exchanges_archived": len(archived),
                "archive_sha256": sha256(canonical_bytes([messages[i-1:i+1] for i in archived])),
                "recent_issued_evidence_ids": list(dict.fromkeys(evidence_ids))[-20:],
                "recent_unique_requests": list(requests.values())[-6:],
                "issued_quote_prefixes": list(excerpts.values())[-6:],
                "scope": "API view only. Full messages/quotes remain in the trajectory. Re-read registered IDs for exact text; do not infer missing quotations."}
            projected = [m for i,m in enumerate(prepared) if i not in omitted]
            projected.insert(2, {"role": "user", "content": canonical_bytes(note).decode()})
            if keep == 1:
                # Historic receipts may predate the complete-envelope limit.
                # Preserve the newest real receipt; shrink optional previews
                # before allowing the unchanged hard guard to decide.
                while message_bytes(projected) > 12288 and note["issued_quote_prefixes"]:
                    note["issued_quote_prefixes"].pop(0)
                    projected[2] = {"role":"user","content":canonical_bytes(note).decode()}
            if not hasattr(self, "document_projection_events"):
                self.document_projection_events = []
            if message_bytes(projected) <= 12288 or keep == 1:
                self.document_projection_events.append({"before_bytes": message_bytes(prepared), "after_bytes": message_bytes(projected),
                    "archived_pairs": len(archived), "sha256": note["archive_sha256"]})
                return projected
        return prepared  # The original 16KiB guard still rejects irreducible input.
