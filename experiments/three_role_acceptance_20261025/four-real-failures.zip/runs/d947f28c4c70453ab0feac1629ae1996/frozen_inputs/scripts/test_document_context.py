"""Regression for the actual document receipt/context failure; no live API."""
from copy import deepcopy
import json
import os
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
import unittest
from unittest.mock import patch
import uuid

from collaboration_protocol import canonical_bytes, sha256
from context_budget import message_bytes
from document_agent import DocumentBroker, freeze_documents
from document_model import ProtectedDocumentModel
import test_document_agent as document_fixture
import test_collaboration_runtime as runtime_fixture


class DocumentContextTests(unittest.TestCase):
    def fixture(self, raw):
        # Reuse the file fixture without importing its TestCase into discovery.
        f=document_fixture.DocumentTests();f.setUp()
        path=f.f.baseline/'docs/rules.md';path.write_bytes(raw)
        manifest=deepcopy(f.f.manifest);manifest['source_files_sha256']['docs/rules.md']=sha256(raw)
        snapshot=freeze_documents(manifest,f.f.baseline,f.f.issue,f.f.root/'context-docs',f.identity,'Locate documented split boundary requirements.')
        return f,DocumentBroker(snapshot,f.identity)

    def test_search_bounds_complete_citation_envelopes_and_revokes_unreturned_ids(self):
        f,broker=self.fixture((('split_after ' + 'x'*60+'\n')*40).encode())
        result=broker.dispatch(f.identity,'search_text',{'snapshot_id':broker.snapshot.grant.snapshot_id,'query':'split'})
        self.assertLessEqual(len(canonical_bytes(result)),4096)
        self.assertTrue(result['truncated'])
        self.assertLess(len(result['hits']),20)
        self.assertEqual(set(broker.evidence),{h['evidence']['evidence_id'] for h in result['hits']})

    def test_read_accounts_for_json_escaping_and_returns_real_continuation(self):
        f,broker=self.fixture(('"\\'*600+'\n'+('more text '*10+'\n')*30).encode())
        doc=broker.snapshot.grant.documents[0]
        result=broker.dispatch(f.identity,'read_lines',{'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':1,'end':31})
        self.assertLessEqual(len(canonical_bytes(result)),4096)
        self.assertTrue(result['truncated'])
        self.assertEqual(result['next_line'],result['evidence']['end_line']+1)
        self.assertEqual(sha256(result['content'].encode()),result['evidence']['span_sha256'])

    def test_long_actual_receipt_history_projects_complete_pairs_without_mutation(self):
        f,broker=self.fixture(('split '+ 'x'*160+'\n') .encode()*40)
        doc=broker.snapshot.grant.documents[0]
        messages=[{'role':'system','content':'Read-only document task.'},{'role':'user','content':'ORIGINAL_QUESTION_AND_REGISTERED_IDS'}]
        for i in range(12):
            args={'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':i+1,'end':i+15}
            receipt=broker.dispatch(f.identity,'read_lines',args)
            messages.extend([{'role':'assistant','content':'Unverified interpretation '+str(i),'tool_calls':[{'id':'call-'+str(i),'type':'function',
                'function':{'name':'read_lines','arguments':json.dumps(args)}}]},
                {'role':'tool','tool_call_id':'call-'+str(i),'content':canonical_bytes(receipt).decode()}])
        before=canonical_bytes(messages)
        fixture=runtime_fixture.RuntimeTests();fixture.setUp()
        model=fixture.model(cls=ProtectedDocumentModel)
        prepared=model._prepare_messages_for_api(messages)
        self.assertGreater(message_bytes(messages),16384)
        self.assertLessEqual(message_bytes(prepared),12288)
        self.assertEqual(canonical_bytes(messages),before)
        self.assertEqual(prepared[:2],messages[:2])
        self.assertEqual(prepared[-1]['tool_call_id'],messages[-1]['tool_call_id'])
        for i,m in enumerate(prepared):
            if m['role']=='tool':self.assertEqual(prepared[i-1]['tool_calls'][0]['id'],m['tool_call_id'])
        self.assertTrue(model.document_projection_events)


if __name__=='__main__':unittest.main()
