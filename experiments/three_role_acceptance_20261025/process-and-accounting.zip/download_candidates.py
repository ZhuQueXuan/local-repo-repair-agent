"""Fetch fixed public source bytes only; do not install or execute packages."""
import base64,hashlib,io,json,tarfile,urllib.request
from pathlib import Path
OUT=Path(__file__).parent/'candidate_downloads';OUT.mkdir(exist_ok=True)
def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'local-agent-task-preparation'})
    with urllib.request.urlopen(req,timeout=30) as response:
        raw=response.read(2*1024*1024+1)
    assert len(raw)<=2*1024*1024
    return raw
meta=json.loads(fetch('https://registry.npmjs.org/fast-deep-equal/3.1.3'))
raw=fetch(meta['dist']['tarball'])
assert 'sha512-'+base64.b64encode(hashlib.sha512(raw).digest()).decode()==meta['dist']['integrity']
(OUT/'fast-deep-equal-3.1.3.tgz').write_bytes(raw)
(OUT/'npm-metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    for name in ('index.js','README.md','LICENSE','package.json','index.d.ts'):
        item=archive.getmember('package/'+name)
        assert item.isfile() and item.size<=262144
        (OUT/name).write_bytes(archive.extractfile(item).read())
for number in (134,142):
    issue=json.loads(fetch('https://api.github.com/repos/epoberezkin/fast-deep-equal/pulls/'+str(number)))
    (OUT/('pull-'+str(number)+'.json')).write_text(json.dumps(issue,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'downloaded':'fast-deep-equal@3.1.3','integrity_verified':True,'license':meta.get('license'),'git_head':meta.get('gitHead'),'executed_package_code':False}))
