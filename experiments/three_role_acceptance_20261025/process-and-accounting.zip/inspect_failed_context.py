import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
RUN='de35b7ada1df4de2b2fea7a480f49b14'
base=ROOT/'data/task_service/runs'/RUN
trajectory=json.loads((base/'consulting-trajectory.json').read_bytes())
messages=trajectory['messages']
summaries=[]
for i,m in enumerate(messages):
    entry={'index':i,'role':m.get('role'),'content_bytes':len(str(m.get('content','')).encode()),'extra_keys':list(m.get('extra',{}))}
    if m.get('role')=='assistant':
        for call in m.get('tool_calls',[]):entry['tool']=call['function']['name'];entry['arguments']=json.loads(call['function']['arguments'])
    summaries.append(entry)
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
before=json.loads((OUT/'before-real-ledger.json').read_bytes())
assert all(ledger['requests'][k]==v for k,v in before['requests'].items())
record=json.loads((OUT/'acceptance-result.json').read_bytes())
result={'run_id':RUN,'status':record['status'],'reason':record.get('reason'),'metrics':record.get('metrics'),
    'messages':summaries,'trajectory_bytes':len((base/'consulting-trajectory.json').read_bytes()),
    'old_ledger_requests_unchanged':len(before['requests']),'new_ledger_requests':len(ledger['requests'])-len(before['requests'])}
(OUT/'failed-context-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
