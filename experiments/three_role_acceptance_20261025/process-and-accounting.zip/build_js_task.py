"""Prepare one dependency-free JavaScript repair task with a Python/Node bridge.

Only writes fixed public source and developer-authored checks. No model calls.
"""
import hashlib,json,shutil,sys,subprocess,textwrap,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DOWNLOAD=OUT/'candidate_downloads'
TASK=ROOT/'tasks/fast-deep-equal-property-methods'
POOL=ROOT/'evaluation/task_pool_20261025'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def put(path,text):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(textwrap.dedent(text).lstrip('\n'),encoding='utf-8')
assert not TASK.exists(),'Never replace an existing task'
TASK.mkdir();(TASK/'temp').mkdir();(POOL/'temp').mkdir(parents=True,exist_ok=True)
for name in ('README.md','LICENSE'):
    dest=TASK/'repo'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(DOWNLOAD/name,dest)
(TASK/'repo/lib').mkdir()
shutil.copyfile(DOWNLOAD/'index.js',TASK/'repo/lib/equal.js')
put(TASK/'repo/fixture_bridge/__init__.py',r'''
"""Trusted task-only bridge. The implementation under repair is JavaScript."""
import json,shutil,subprocess
from pathlib import Path
REPO=Path(__file__).resolve().parents[1]
NODE=shutil.which('node')
if not NODE:raise RuntimeError('This task requires the declared Node.js runtime')
probe=subprocess.run([NODE,'-e',"console.log(require.resolve('./lib/equal.js'))"],cwd=REPO,capture_output=True,text=True,check=True,timeout=10)
if Path(probe.stdout.strip()).resolve()!=(REPO/'lib/equal.js').resolve():raise RuntimeError('JavaScript import escaped task')
PROGRAM=r"""
const fs=require('node:fs');
const equal=require('./lib/equal.js');
function decode(v){
 if(Array.isArray(v))return v.map(decode);
 if(v!==null&&typeof v==='object'){
  if(v.__fixture_kind__==='null-prototype')return Object.assign(Object.create(null),decode(v.values));
  if(v.__fixture_kind__==='date')return new Date(v.value);
  if(v.__fixture_kind__==='number-object')return new Number(v.value);
  if(v.__fixture_kind__==='nan')return NaN;
  if(v.__fixture_kind__==='regexp')return new RegExp(v.source,v.flags);
  return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,decode(x)]));
 }
 return v;
}
const p=JSON.parse(fs.readFileSync(0,'utf8'));
process.stdout.write(JSON.stringify(equal(decode(p.left),decode(p.right))));
"""
def evaluate(left,right):
    result=subprocess.run([NODE,'-e',PROGRAM],cwd=REPO,input=json.dumps({'left':left,'right':right}),capture_output=True,text=True,timeout=10)
    if result.returncode:raise RuntimeError('JavaScript implementation failed: '+result.stderr[-1800:])
    value=json.loads(result.stdout)
    if type(value) is not bool:raise RuntimeError('Comparator did not return a boolean')
    return value
''')
put(TASK/'repo/tests/__init__.py','')
put(TASK/'repo/tests/test_regression.py','''
import unittest
from fixture_bridge import evaluate
class Regression(unittest.TestCase):
    def test_plain_and_nested(self):
        self.assertTrue(evaluate({'a':[1,{'b':2}]},{'a':[1,{'b':2}]}))
        self.assertFalse(evaluate({'a':1},{'a':2}))
    def test_array_length_and_order(self):
        self.assertFalse(evaluate([1,2],[2,1]))
        self.assertFalse(evaluate([1],[1,2]))
    def test_dates_and_number_objects(self):
        for kind in ('date','number-object'):
            self.assertTrue(evaluate({'__fixture_kind__':kind,'value':123},{'__fixture_kind__':kind,'value':123}))
            self.assertFalse(evaluate({'__fixture_kind__':kind,'value':123},{'__fixture_kind__':kind,'value':124}))
    def test_regexp_and_nan(self):
        self.assertTrue(evaluate({'__fixture_kind__':'nan'},{'__fixture_kind__':'nan'}))
        self.assertFalse(evaluate({'__fixture_kind__':'regexp','source':'x','flags':'i'},{'__fixture_kind__':'regexp','source':'x','flags':''}))
''')
put(TASK/'checks/test_behavior.py','''
import unittest
from fixture_bridge import evaluate
class Behavior(unittest.TestCase):
    def test_ordinary_valueof_data_field(self):
        self.assertTrue(evaluate({'valueOf':7,'x':1},{'valueOf':7,'x':1}))
        self.assertFalse(evaluate({'valueOf':7,'x':1},{'valueOf':7,'x':2}))
    def test_null_prototype_maps(self):
        left={'__fixture_kind__':'null-prototype','values':{'x':1}}
        self.assertTrue(evaluate(left,left))
        self.assertFalse(evaluate(left,{'__fixture_kind__':'null-prototype','values':{'x':2}}))
''')
put(POOL/'evaluator/fast-deep-equal-property-methods/test_behavior.py','''
import unittest
from fixture_bridge import evaluate
class WithheldBehavior(unittest.TestCase):
    def test_tostring_data_fields(self):
        self.assertTrue(evaluate({'toString':'label','n':1},{'toString':'label','n':1}))
        self.assertFalse(evaluate({'toString':'label','n':1},{'toString':'other','n':1}))
    def test_nested_null_prototype_maps(self):
        a={'wrap':[{'__fixture_kind__':'null-prototype','values':{'a':1,'b':[2]}}]}
        self.assertTrue(evaluate(a,a))
        self.assertFalse(evaluate(a,{'wrap':[{'__fixture_kind__':'null-prototype','values':{'a':2,'b':[2]}}]}))
    def test_method_named_nested_array_values(self):
        self.assertTrue(evaluate([{'valueOf':0,'toString':False}],[{'valueOf':0,'toString':False}]))
        self.assertFalse(evaluate([{'valueOf':0}],[{'valueOf':1}]))
    def test_null_maps_with_null_method_data(self):
        a={'__fixture_kind__':'null-prototype','values':{'valueOf':None,'toString':'data','key':'x'}}
        self.assertTrue(evaluate(a,a))
''')
put(TASK/'issue.md','''
# Compare dictionary-like objects without calling non-function data properties

The comparator throws for ordinary objects whose `valueOf` or `toString` fields contain data, and for maps constructed with a null prototype. Such objects should be compared structurally, returning a boolean for equal and unequal contents. Preserve existing array, nested object, Date, RegExp, boxed-number and NaN behavior.

This task uses the unmodified CommonJS implementation distributed in fast-deep-equal 3.1.3, relocated from index.js to lib/equal.js. Edit that existing JavaScript file directly; its generated-source comment refers to a source template not included in this release fixture. Do not edit the Python bridge, tests, description or metadata. No dependencies need installing. The Python checks call the real local Node.js runtime against lib/equal.js.
''')
meta=json.loads((DOWNLOAD/'npm-metadata.json').read_bytes())
manifest={'task_id':'fast-deep-equal-nonfunction-properties-134-142','language':'javascript','package':'fixture_bridge','import_root':'.','source_prefix':'lib/',
    'upstream_runner':'unittest','upstream_target':'tests.test_regression','full_target':'tests',
    'agent_test_command':'python -B -m unittest discover -s tests -v','agent_issue_command':'python -B -m unittest discover -s task_checks -v',
    'scope':'Adapted public JavaScript release-source repair fixture with a protected Python-to-Node test bridge; not SWE-bench or an official upstream suite.',
    'origin':{'package':'fast-deep-equal','version':'3.1.3','git_head':meta.get('gitHead'),'npm_integrity':meta['dist']['integrity'],
        'license':'MIT','source_urls':['https://github.com/epoberezkin/fast-deep-equal/pull/134','https://github.com/epoberezkin/fast-deep-equal/pull/142'],
        'layout_adaptation':'npm index.js bytes preserved as lib/equal.js; original README/LICENSE preserved; bridge and regression checks are developer-authored'},
    'source_files_sha256':{p.relative_to(TASK/'repo').as_posix():sha(p.read_bytes()) for p in sorted((TASK/'repo').rglob('*')) if p.is_file()},
    'task_files_sha256':{p:sha((TASK/p).read_bytes()) for p in ('issue.md','checks/test_behavior.py')}}
(TASK/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
reference={'task':'fast-deep-equal-property-methods','edits':[]}
for name in ('valueOf','toString'):
    old='if (a.'+name+' !== Object.prototype.'+name+')'
    new="if (typeof a."+name+" === 'function' && typeof b."+name+" === 'function' && a."+name+' !== Object.prototype.'+name+')'
    assert (TASK/'repo/lib/equal.js').read_text().count(old)==1
    reference['edits'].append({'file':'lib/equal.js','old':old,'new':new,'count':1})
(POOL/'evaluator/fast-deep-equal-property-methods/reference.json').write_text(json.dumps(reference,indent=2),encoding='utf-8')
shutil.copyfile(DOWNLOAD/'npm-metadata.json',POOL/'npm-source-metadata.json')
print(json.dumps({'task':str(TASK),'language':'javascript','target_implementation':'lib/equal.js','native_runtime':'Node.js','model_calls':0}))
