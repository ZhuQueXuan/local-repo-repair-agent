from pathlib import Path
import subprocess,sys
OUT=Path(__file__).parent
source=(OUT/'real_acceptance.py').read_text(encoding='utf-8')
source=source.replace("OUT=Path(__file__).parent","OUT=Path(__file__).parent/'fixed_context_v1'\nOUT.mkdir(exist_ok=True)")
source=source.replace('One real three-role integration acceptance','One new-version real three-role context-fix acceptance')
target=OUT/'real_acceptance_fixed.py'
assert not target.exists()
target.write_text(source,encoding='utf-8')
raise SystemExit(subprocess.run([sys.executable,'-B',str(target)]).returncode)
