import argparse,hashlib,json,os,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'scripts'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--hidden-child',type=Path);parser.add_argument('--repo',type=Path);args=parser.parse_args()
    if args.hidden_child:
        import importlib.util,unittest
        from check_task import run_suite
        sys.path.insert(0,str(args.repo));os.chdir(args.repo)
        spec=importlib.util.spec_from_file_location('held_out_node_checks',args.hidden_child)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        print(json.dumps(run_suite(unittest.TestLoader().loadTestsFromModule(module))))
        return
    from task_workspace import prepare_task,load_task
    task='fast-deep-equal-property-methods';source,manifest=load_task(task)
    pool=ROOT/'evaluation/task_pool_20261025'
    reference=json.loads((pool/'evaluator'/task/'reference.json').read_bytes())
    directory=OUT/('js-qualification-'+uuid.uuid4().hex);directory.mkdir()
    results={}
    for phase in ('baseline','reference'):
        repo,_=prepare_task(task)
        if phase=='reference':
            for edit in reference['edits']:
                path=repo/edit['file'];raw=path.read_text(encoding='utf-8');assert raw.count(edit['old'])==edit['count']
                path.write_text(raw.replace(edit['old'],edit['new']),encoding='utf-8')
        output=directory/(phase+'.json')
        command=[sys.executable,'-B',str(ROOT/'scripts/check_task.py'),'--task',task,'--repo',str(repo),'--output',str(output),'--full-suite']
        completed=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=90)
        (directory/(phase+'-console.log')).write_text(completed.stdout+completed.stderr,encoding='utf-8')
        report=json.loads(output.read_bytes());assert completed.returncode==(0 if report['task_tests_passed'] else 1)
        hidden=subprocess.run([sys.executable,'-B','-I',str(Path(__file__).resolve()),'--hidden-child',str(pool/'evaluator'/task/'test_behavior.py'),'--repo',str(repo)],
            cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=60)
        assert hidden.returncode==0,hidden.stderr
        held=json.loads(hidden.stdout)
        assert report['upstream_targeted']['successful'] and report['full_upstream_suite']['successful']
        assert report['protected_tests_unchanged']
        assert report['issue_checks']['successful']==(phase=='reference')
        assert held['successful']==(phase=='reference')
        for p,h in manifest['source_files_sha256'].items():
            if phase=='baseline' or not p.startswith(manifest['source_prefix']):assert sha((repo/p).read_bytes())==h
        results[phase]={'repo':str(repo),'public':report,'withheld':held}
    results['native_node_version']=subprocess.run(['node','--version'],capture_output=True,text=True,check=True).stdout.strip()
    results['scope']='Adapted JavaScript release fixture and developer-authored native-Node regression checks, not an upstream Mocha suite or model result.'
    (directory/'qualification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'js-qualification-selected.json').write_text(json.dumps({'directory':str(directory),'task':task},indent=2),encoding='utf-8')
    print(json.dumps({'directory':str(directory),'baseline_public_passed':results['baseline']['public']['issue_checks']['passed'],
        'reference_public_passed':results['reference']['public']['issue_checks']['passed'],'baseline_withheld_passed':results['baseline']['withheld']['passed'],
        'reference_withheld_passed':results['reference']['withheld']['passed'],'reference_regression_passed':results['reference']['public']['full_upstream_suite']['passed'],
        'node':results['native_node_version'],'model_calls':0}))
if __name__=='__main__':main()
