"""Offline regression only; stop an idle panel normally and restore it hidden."""
import json
import re
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
BASE = 'http://127.0.0.1:8765'


def main():
    with sqlite3.connect((ROOT / 'data/task_service/runs.sqlite3').as_uri() + '?mode=ro', uri=True) as db:
        rows = [json.loads(raw) for (raw,) in db.execute('SELECT payload FROM runs')]
    assert not any(r['status'] in {'queued', 'running', 'cancel_requested'} for r in rows), 'Panel has pending work'
    restore = False
    try:
        with urllib.request.urlopen(BASE + '/', timeout=5) as response:
            html = response.read().decode()
        token = re.search(r"const token='([^']+)'", html).group(1)
        request = urllib.request.Request(BASE + '/api/shutdown', data=b'{}', headers={
            'X-Task-Token': token, 'Content-Type': 'application/json', 'Origin': BASE}, method='POST')
        with urllib.request.urlopen(request, timeout=5) as response:
            assert json.loads(response.read())['status'] == 'stopping'
        restore = True
        for _ in range(30):
            try:
                with urllib.request.urlopen(BASE + '/', timeout=1):
                    pass
            except OSError:
                break
            time.sleep(0.3)
        else:
            raise RuntimeError('Panel did not stop; do not force termination')
        results = []
        for suffix in ([], ['--scope', 'upstream', '--upstream-profile', 'adapter']):
            command = [sys.executable, '-B', str(ROOT / 'scripts/run_regression.py'), *suffix]
            result = subprocess.run(command, cwd=ROOT, check=False)
            results.append({'arguments': suffix, 'exit_code': result.returncode})
        (OUT / 'offline-finalize-results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    finally:
        if restore:
            with (OUT / 'restored-panel.log').open('ab') as log:
                process = subprocess.Popen([sys.executable, '-B', str(ROOT / 'scripts/task_service.py')], cwd=ROOT,
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)
            (OUT / 'restored-panel.json').write_text(json.dumps({'pid': process.pid, 'url': BASE}), encoding='utf-8')
            print('Idle panel restored hidden; no model task dispatched.', flush=True)


if __name__ == '__main__':
    main()
