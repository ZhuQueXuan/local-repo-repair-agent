import os
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
import sys,json
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from document_agent import DocumentGrant,DocumentSnapshot,DocumentBroker
from collaboration_protocol import RoleIdentity,ProtocolError,canonical_bytes
from collaboration_runtime import run_document_consultation
from review_model import ReviewModel
run_id='d947f28c4c70453ab0feac1629ae1996'
path=ROOT/'data/task_service/runs'/run_id/'consulting-trajectory.json'
raw=path.read_bytes()
messages=json.loads(raw)['messages']
directory=next((ROOT/'data/task_service/document_snapshots'/run_id).iterdir())
grant=DocumentGrant.parse(json.loads((directory/'grant.json').read_bytes()))
identity=RoleIdentity(run_id=run_id,role_run_id=grant.role_run_id,session_id='offline-replay',role='document_reader')
broker=DocumentBroker(DocumentSnapshot(directory,grant),identity)
actions=iter(m for m in messages if m['role']=='assistant')
calls=[]
def query(history):
    value=next(actions);calls.append(value['extra']['actions'][0]['tool']);return value
model=SimpleNamespace(query=query,usage={},contains_credentials=lambda value:False)
model.format_observation_messages=lambda message,outputs:ReviewModel.format_observation_messages(model,message,outputs)
context=SimpleNamespace(check=lambda:None,identity=identity)
try:run_document_consultation(model,broker,context,Path(__file__).parent/'cycle-replay-trajectory.json','Replay actual recorded actions; zero model calls')
except ProtocolError as error:
    assert str(error)=='document_repeated_evidence_limit'
else:raise AssertionError('Recorded no-progress cycle must stop')
assert len(calls)<20 and path.read_bytes()==raw
result={'run_id':run_id,'original_attempts':104,'replayed_tool_actions_before_stop':len(calls),
    'reason':'document_repeated_evidence_limit','old_trajectory_unchanged':True,'external_model_calls':0}
(Path(__file__).parent/'cycle-replay-result.json').write_bytes(canonical_bytes(result))
print(json.dumps(result))
