import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'data/task_service/runs/c30617e5d664484ea58f7c8a565f1cd3/consulting-trajectory.json'
v=json.loads(p.read_bytes())
result=[]
for m in v['messages']:
    if m.get('extra',{}).get('review_rejection'):
        r=m['extra']['review_rejection'];result.append({'reason':r['reason'],'calls':r['calls']})
print(json.dumps(result,ensure_ascii=False))
(Path(__file__).parent/'submission-errors.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
