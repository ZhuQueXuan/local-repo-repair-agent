import os
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
import json,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from context_budget import message_bytes
import test_collaboration_runtime as fixture
p=ROOT/'data/task_service/runs/6b3068c4e13c40bd8e9358dcc72d3e1b/reviewing-trajectory.json'
raw=p.read_bytes();messages=json.loads(raw)['messages']
f=fixture.RuntimeTests();f.setUp();model=f.model()
model.review_projection_windows=(3,)
old=model._prepare_messages_for_api(messages)
model.review_projection_windows=(3,2,1)
new=model._prepare_messages_for_api(messages)
assert message_bytes(old)>16384
assert message_bytes(new)<=16384
assert p.read_bytes()==raw
assert new[0]==old[0] and new[1]==old[1] and new[-1]==old[-1]
result={'run_id':'6b3068c4e13c40bd8e9358dcc72d3e1b','old_api_bytes':message_bytes(old),'new_api_bytes':message_bytes(new),
    'guard_unchanged':16384,'original_task_and_latest_receipt_unchanged':True,'old_trajectory_unchanged':True,'external_model_calls':0}
(Path(__file__).parent/'review-failure-replay.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
