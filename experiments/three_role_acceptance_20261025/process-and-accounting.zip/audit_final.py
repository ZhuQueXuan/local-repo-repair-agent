"""Read-only audit of retained real failures and offline task qualification."""
import hashlib
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent


def read(path):
    return json.loads(path.read_bytes())


before = read(OUT / 'before-real-payloads.json')
with sqlite3.connect((ROOT / 'data/task_service/runs.sqlite3').as_uri() + '?mode=ro', uri=True) as db:
    after = dict(db.execute('SELECT id,payload FROM runs'))
assert all(after.get(key) == raw for key, raw in before.items())
old_ledger = read(OUT / 'before-real-ledger.json')
ledger = read(ROOT / 'data/deepseek_budget.json')
assert all(ledger['requests'].get(key) == raw for key, raw in old_ledger['requests'].items())
assert all(ledger.get(key) == raw for key, raw in old_ledger.items() if key != 'requests')
new_ids = set(after) - set(before)
audit = read(OUT / 'acceptance-final-audit.json')
assert new_ids == {row['id'] for row in audit}
assert not any(json.loads(raw)['status'] in {'queued', 'running', 'cancel_requested'} for raw in after.values())
assert all(row['live_receipts_digest'] for row in audit)
result = {
    'old_payloads_byte_identical': len(before), 'current_formal_rows': len(after),
    'old_ledger_requests_unchanged': len(old_ledger['requests']),
    'new_ledger_requests': len(ledger['requests']) - len(old_ledger['requests']),
    'attempts': sum(r['metrics']['attempts'] for r in audit),
    'logical_requests': sum(r['metrics']['logical_requests'] for r in audit),
    'known_price_estimate_cny': round(sum(r['metrics']['known_price_estimate_cny'] for r in audit), 6),
    'unknown_cost_attempts': sum(r['metrics']['unknown_cost_attempts'] for r in audit),
    'unknown_placeholder_cny': round(sum(r['metrics']['unknown_placeholder_cny'] for r in audit), 6),
    'complete_cost_estimate_cny': None, 'all_new_run_ids': sorted(new_ids),
    'all_new_runs_terminal': True, 'three_role_live_acceptance_passed': False,
    'new_comparison_runs': 0, 'browser_clicks_verified': False,
    'final_review_context_fix_live_verified': False,
    'next_real_dispatch_block': 'Automatic approval review could not complete due to account usage limit; no v4 identity dispatched.',
}
task = ROOT / 'tasks/fast-deep-equal-property-methods'
manifest = read(task / 'manifest.json')
for name, expected in manifest['source_files_sha256'].items():
    assert hashlib.sha256((task / 'repo' / name).read_bytes()).hexdigest() == expected
for name, expected in manifest['task_files_sha256'].items():
    assert hashlib.sha256((task / name).read_bytes()).hexdigest() == expected
qualification_path = OUT / 'js-qualification-7e2574c1258d46edb367b4d27f80968a/qualification.json'
q = read(qualification_path)
result['javascript_qualification'] = {
    key: {'public_passed': q[key]['public']['issue_checks']['passed'],
          'public_total': q[key]['public']['issue_checks']['tests_run'],
          'developer_regression_passed': q[key]['public']['upstream_targeted']['passed'],
          'developer_regression_total': q[key]['public']['upstream_targeted']['tests_run'],
          'withheld_passed': q[key]['withheld']['passed'],
          'withheld_total': q[key]['withheld']['tests_run']}
    for key in ('baseline', 'reference')}
result['javascript_qualification']['node_version'] = q['native_node_version']
result['javascript_qualification']['scope'] = q['scope']
result['offline_failure_replays'] = {name: read(OUT / name) for name in (
    'document-failure-replay.json', 'cycle-replay-result.json', 'review-failure-replay.json')}
native_dir = ROOT / 'temp/regression/20261025_211130_dd197ba2'
adapter_dir = ROOT / 'temp/regression/20261025_211556_14c0b9e7'
native = read(native_dir / 'summary.json')
adapter_summary = read(adapter_dir / 'summary.json')
adapter = read(adapter_dir / 'adapter/upstream_results.json')
old_adapter = read(ROOT / 'temp/regression/20261025_181222_8c3a755f/adapter/upstream_results.json')
failed = lambda value: sorted(r['nodeid'] for r in value['reports'] if r['outcome'] == 'failed')
assert failed(adapter) == failed(old_adapter)
assert not native['changed_protected_files'] and not adapter_summary['changed_protected_files']
assert native['jobs'][0]['counts'] == {'passed': 301}
assert native['jobs'][1]['exit_code'] == 0 and native['jobs'][1]['tests_run'] == 401
result['final_regression'] = {'default_directory': str(native_dir.relative_to(ROOT)),
    'native_passed': 301, 'project_tests_run': 401, 'project_passed': 400, 'project_skipped': 1,
    'project_seconds': 246.342, 'protected_files_unchanged': True,
    'adapter_directory': str(adapter_dir.relative_to(ROOT)), 'adapter_counts': adapter['counts'],
    'adapter_same_six_failures': failed(adapter), 'adapter_guard_violations': adapter['guard_violations']}
frozen_counts = {}
for run_id in new_ids:
    run = ROOT / 'data/task_service/runs' / run_id
    frozen = read(run / 'inputs.json')['files_sha256']
    for name, expected in frozen.items():
        assert hashlib.sha256((run / 'frozen_inputs' / name).read_bytes()).hexdigest() == expected, (run_id, name)
    frozen_counts[run_id] = len(frozen)
result['real_run_frozen_input_files_verified'] = frozen_counts
(OUT / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
