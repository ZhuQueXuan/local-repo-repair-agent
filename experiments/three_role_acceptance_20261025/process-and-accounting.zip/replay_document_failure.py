import os
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from document_model import ProtectedDocumentModel
from collaboration_runtime import ProtectedReviewModel
from context_budget import message_bytes
from collaboration_protocol import canonical_bytes
import test_collaboration_runtime as fixture
p=ROOT/'data/task_service/runs/de35b7ada1df4de2b2fea7a480f49b14/consulting-trajectory.json'
before=hashlib.sha256(p.read_bytes()).hexdigest()
raw=json.loads(p.read_bytes())['messages']
f=fixture.RuntimeTests();f.setUp();model=f.model(cls=ProtectedDocumentModel)
old=ProtectedReviewModel._prepare_messages_for_api(model,raw)
new=model._prepare_messages_for_api(raw)
assert message_bytes(old)>16384
assert message_bytes(new)<=16384
assert hashlib.sha256(p.read_bytes()).hexdigest()==before
for i,m in enumerate(new):
    if m['role']=='tool':assert new[i-1]['tool_calls'][0]['id']==m['tool_call_id']
result={'run_id':'de35b7ada1df4de2b2fea7a480f49b14','old_api_bytes':message_bytes(old),'new_api_bytes':message_bytes(new),
    'guard_bytes_unchanged':16384,'original_trajectory_unchanged':True,'external_model_calls':0,'projections':model.document_projection_events}
(Path(__file__).parent/'document-failure-replay.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
