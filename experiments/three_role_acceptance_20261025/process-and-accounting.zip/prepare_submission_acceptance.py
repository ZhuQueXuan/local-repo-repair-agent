from pathlib import Path
import subprocess,sys
OUT=Path(__file__).parent
source=(OUT/'real_acceptance.py').read_text(encoding='utf-8')
source=source.replace("OUT=Path(__file__).parent","OUT=Path(__file__).parent/'submission_context_v2'\nOUT.mkdir(exist_ok=True)")
source=source.replace('One real three-role integration acceptance','One new-version real three-role cited-submission acceptance')
source=source.replace('Locate documentation about split_after and maxsplit in the frozen repository. Explain documented input/termination requirements, cite exact lines, and explicitly mark any boundary behavior that these documents do not specify. Do not invent requirements.',
    'Find the frozen changelog entries mentioning split_after or maxsplit. Cite the exact entries, state only what they establish, and list the input or boundary behavior they do not specify. A changelog is not a complete API contract; submit explicit unknowns rather than searching unrelated release history.')
target=OUT/'real_acceptance_submission.py';assert not target.exists()
target.write_text(source,encoding='utf-8')
raise SystemExit(subprocess.run([sys.executable,'-B',str(target)]).returncode)
