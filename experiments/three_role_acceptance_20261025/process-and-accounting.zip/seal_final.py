"""Seal current implementation, all four failures, and offline qualification."""
import hashlib
import json
from pathlib import Path
import sqlite3
import stat
import zipfile
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
DEST = ROOT / 'experiments/three_role_acceptance_20261025'
assert not DEST.exists(), 'Do not overwrite formal evidence'
verification = json.loads((OUT / 'verification.json').read_bytes())
finalize = json.loads((OUT / 'offline-finalize-results.json').read_bytes())
assert finalize[0]['exit_code'] == 0, 'Read failed regression before sealing'
assert all(json.loads((ROOT / 'data/task_service/runs' / rid / 'summary.json').read_bytes())
           for rid in verification['all_new_run_ids'])
with sqlite3.connect((ROOT / 'data/task_service/runs.sqlite3').as_uri() + '?mode=ro', uri=True) as source:
    with sqlite3.connect(OUT / 'final-formal-store.sqlite3') as target:
        source.backup(target)
(OUT / 'final-shared-ledger.json').write_bytes((ROOT / 'data/deepseek_budget.json').read_bytes())
secrets = [v.encode() for k, v in dotenv_values(ROOT / '.env', interpolate=False).items() if 'KEY' in k and v]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def files(base, skip_temp=False):
    result = []
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if not stat.S_ISREG(path.lstat().st_mode) or any(p in {'.git', '__pycache__'} for p in relative.parts):
            continue
        if path.name.startswith('.env') or path.name.endswith('.lock') or (skip_temp and 'temp' in relative.parts):
            continue
        result.append((path, relative.as_posix()))
    return result


def pack(name, entries):
    listing = {}
    with zipfile.ZipFile(DEST / name, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path, relative in entries:
            assert relative not in listing and not Path(relative).is_absolute() and '..' not in Path(relative).parts
            raw = path.read_bytes()
            assert not any(secret in raw for secret in secrets), 'Private credential detected; do not seal'
            archive.writestr(relative, raw)
            listing[relative] = sha(raw)
    (DEST / (name + '.sha256.json')).write_text(json.dumps(listing, indent=2), encoding='utf-8')
    with zipfile.ZipFile(DEST / name) as archive:
        assert set(archive.namelist()) == set(listing)
        assert all(sha(archive.read(relative)) == expected for relative, expected in listing.items())
    return len(listing)


DEST.mkdir()
code = [(p, p.relative_to(ROOT).as_posix()) for p in sorted((ROOT / 'scripts').iterdir())
        if p.is_file() and p.suffix in {'.py', '.html', '.js'}]
code += [(p, p.relative_to(ROOT).as_posix()) for p in sorted((ROOT / 'configs').glob('*.json'))]
counts = {'runtime-code.zip': pack('runtime-code.zip', code)}
evidence = []
for run_id in verification['all_new_run_ids']:
    for folder in ('runs', 'snapshots', 'document_snapshots'):
        base = ROOT / 'data/task_service' / folder / run_id
        if base.exists():
            evidence += [(path, folder + '/' + run_id + '/' + rel) for path, rel in files(base)]
counts['four-real-failures.zip'] = pack('four-real-failures.zip', evidence)
counts['process-and-accounting.zip'] = pack('process-and-accounting.zip', files(OUT))
task = ROOT / 'tasks/fast-deep-equal-property-methods'
entries = [(path, 'tasks/fast-deep-equal-property-methods/' + rel) for path, rel in files(task, True)]
entries += [(path, 'evaluation/task_pool_20261025/' + rel)
            for path, rel in files(ROOT / 'evaluation/task_pool_20261025', True)]
counts['javascript-task.zip'] = pack('javascript-task.zip', entries)
regressions = []
for path in (ROOT / 'temp/regression').glob('*/summary.json'):
    if path.parent.name >= '20261025_211130':
        summary = json.loads(path.read_bytes())
        regressions.append((path.parent, summary))
assert len(regressions) == 2, 'Expected exactly the final native/project and adapter runs'
for directory, summary in regressions:
    label = 'adapter' if summary['scope'] == 'upstream' else 'default'
    counts[label + '-regression.zip'] = pack(label + '-regression.zip', files(directory))
docs = ['Project/33_过程_三角色真实接入诊断与多语言扩题准备.md', 'Project/00_项目现状与快速接手.md',
        'Project/32_过程_双角色快照修复与第三文档角色离线接入.md', 'Project/项目开发流水账.md',
        'README.md', 'AGENTS.md', 'tasks/README.md']
counts['documentation.zip'] = pack('documentation.zip', [(ROOT / rel, 'shixi_project/' + rel) for rel in docs]
    + [(ROOT.parent / 'job/AGENTS.md', 'job/AGENTS.md')])
(DEST / 'verification.json').write_bytes((OUT / 'verification.json').read_bytes())
(DEST / 'README.json').write_text(json.dumps({
    'scope': 'Retained real integration failures and offline fixes; no completed three-role acceptance or effect comparison.',
    'live_acceptance_passed': False, 'browser_clicks_verified': False, 'new_effect_comparison_runs': 0,
    'known_price_estimate_cny': verification['known_price_estimate_cny'],
    'unknown_placeholder_cny': verification['unknown_placeholder_cny'], 'complete_cost_estimate_cny': None,
    'archive_member_counts': counts, 'regressions': [str(p.relative_to(ROOT)) for p, _ in regressions],
    'next_real_dispatch': 'Not started: automatic approval review usage failure. Do not bypass approval.'
}, ensure_ascii=False, indent=2), encoding='utf-8')
outer = {p.name: sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()}
assert all(not any(secret in (DEST / name).read_bytes() for secret in secrets) for name in outer)
(DEST / 'artifact_sha256.json').write_text(json.dumps(outer, indent=2), encoding='utf-8')
print(json.dumps({'archive': str(DEST), 'outer_entries': len(outer), 'verified_zip_members': sum(counts.values()),
                  'secret_matches': 0}, ensure_ascii=False))
