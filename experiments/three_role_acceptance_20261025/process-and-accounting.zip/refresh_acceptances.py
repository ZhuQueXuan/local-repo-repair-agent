import json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
ids=['de35b7ada1df4de2b2fea7a480f49b14','d947f28c4c70453ab0feac1629ae1996','c30617e5d664484ea58f7c8a565f1cd3','6b3068c4e13c40bd8e9358dcc72d3e1b']
result=[]
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    for run_id in ids:
        row=json.loads(db.execute('SELECT payload FROM runs WHERE id=?',(run_id,)).fetchone()[0])
        (OUT/(run_id+'-final-parent.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
        result.append({k:row.get(k) for k in ('id','status','reason','repair_result','collaboration_result','live_receipts_digest','metrics')})
(OUT/'acceptance-final-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='metrics'}|{'attempts':r['metrics'].get('attempts'),'known_price_estimate_cny':r['metrics'].get('known_price_estimate_cny')} for r in result],ensure_ascii=False))
