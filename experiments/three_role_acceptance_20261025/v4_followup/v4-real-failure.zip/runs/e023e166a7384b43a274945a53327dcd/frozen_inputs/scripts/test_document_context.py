"""Regression for the actual document receipt/context failure; no live API."""
from copy import deepcopy
import json
import os
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
import unittest
from unittest.mock import patch
import uuid
from types import SimpleNamespace

from collaboration_protocol import canonical_bytes, sha256
from context_budget import message_bytes
from document_agent import DocumentBroker, freeze_documents
from document_model import ProtectedDocumentModel
from collaboration_runtime import run_document_consultation
from collaboration_protocol import ProtocolError
from review_model import ReviewModel
from minisweagent.exceptions import FormatError
from review_tools import ReviewCancelled, ReviewEvidenceBroker
from test_collaboration_protocol import StageAFixture
import test_document_agent as document_fixture
import test_collaboration_runtime as runtime_fixture


class DocumentContextTests(unittest.TestCase):
    def response_batch(self, calls):
        response=runtime_fixture.response(calls[0][0],calls[0][1])
        template=response.choices[0].message.tool_calls[0]
        response.choices[0].message.tool_calls=[template.model_copy(deep=True) for _ in calls]
        for i,(tool,args) in enumerate(calls):
            response.choices[0].message.tool_calls[i].id='batch-call-'+str(i)
            response.choices[0].message.tool_calls[i].function.name=tool
            response.choices[0].message.tool_calls[i].function.arguments=json.dumps(args)
        return response

    def fixture(self, raw):
        # Reuse the file fixture without importing its TestCase into discovery.
        f=document_fixture.DocumentTests();f.setUp()
        path=f.f.baseline/'docs/rules.md';path.write_bytes(raw)
        manifest=deepcopy(f.f.manifest);manifest['source_files_sha256']['docs/rules.md']=sha256(raw)
        snapshot=freeze_documents(manifest,f.f.baseline,f.f.issue,f.f.root/'context-docs',f.identity,'Locate documented split boundary requirements.')
        return f,DocumentBroker(snapshot,f.identity)

    def test_search_bounds_complete_citation_envelopes_and_revokes_unreturned_ids(self):
        f,broker=self.fixture((('split_after ' + 'x'*60+'\n')*40).encode())
        result=broker.dispatch(f.identity,'search_text',{'snapshot_id':broker.snapshot.grant.snapshot_id,'query':'split'})
        self.assertLessEqual(len(canonical_bytes(result)),4096)
        self.assertTrue(result['truncated'])
        self.assertLess(len(result['hits']),20)
        self.assertEqual(set(broker.evidence),{h['evidence']['evidence_id'] for h in result['hits']})

    def test_read_accounts_for_json_escaping_and_returns_real_continuation(self):
        f,broker=self.fixture(('"\\'*600+'\n'+('more text '*10+'\n')*30).encode())
        doc=broker.snapshot.grant.documents[0]
        result=broker.dispatch(f.identity,'read_lines',{'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':1,'end':31})
        self.assertLessEqual(len(canonical_bytes(result)),4096)
        self.assertTrue(result['truncated'])
        self.assertEqual(result['next_line'],result['evidence']['end_line']+1)
        self.assertEqual(sha256(result['content'].encode()),result['evidence']['span_sha256'])

    def test_long_actual_receipt_history_projects_complete_pairs_without_mutation(self):
        f,broker=self.fixture(('split '+ 'x'*160+'\n') .encode()*40)
        doc=broker.snapshot.grant.documents[0]
        messages=[{'role':'system','content':'Read-only document task.'},{'role':'user','content':'ORIGINAL_QUESTION_AND_REGISTERED_IDS'}]
        for i in range(12):
            args={'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':i+1,'end':i+15}
            receipt=broker.dispatch(f.identity,'read_lines',args)
            messages.extend([{'role':'assistant','content':'Unverified interpretation '+str(i),'tool_calls':[{'id':'call-'+str(i),'type':'function',
                'function':{'name':'read_lines','arguments':json.dumps(args)}}]},
                {'role':'tool','tool_call_id':'call-'+str(i),'content':canonical_bytes(receipt).decode()}])
        before=canonical_bytes(messages)
        fixture=runtime_fixture.RuntimeTests();fixture.setUp()
        model=fixture.model(cls=ProtectedDocumentModel)
        prepared=model._prepare_messages_for_api(messages)
        self.assertGreater(message_bytes(messages),16384)
        self.assertLessEqual(message_bytes(prepared),12288)
        self.assertEqual(canonical_bytes(messages),before)
        self.assertEqual(prepared[:2],messages[:2])
        self.assertEqual(prepared[-1]['tool_call_id'],messages[-1]['tool_call_id'])
        for i,m in enumerate(prepared):
            if m['role']=='tool':self.assertEqual(prepared[i-1]['tool_calls'][0]['id'],m['tool_call_id'])
        self.assertTrue(model.document_projection_events)

    def test_rotating_unchanged_queries_stop_without_a_global_request_cap(self):
        f,broker=self.fixture(('split behavior\n'*12).encode())
        doc=broker.snapshot.grant.documents[0]
        requests=[('read_lines',{'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':1,'end':1}),
            ('search_text',{'snapshot_id':broker.snapshot.grant.snapshot_id,'query':'split'})]
        observed=[]
        def query(messages):
            tool,args=requests[len(observed)%2];observed.append(deepcopy(messages))
            call_id='cycle-'+str(len(observed))
            return {'role':'assistant','content':'','tool_calls':[{'id':call_id,'type':'function','function':{'name':tool,'arguments':json.dumps(args)}}],
                'extra':{'actions':[{'tool':tool,'arguments':args,'tool_call_id':call_id}]}}
        model=SimpleNamespace(query=query,usage={},contains_credentials=lambda text:False)
        model.format_observation_messages=lambda message,outputs:ReviewModel.format_observation_messages(model,message,outputs)
        context=SimpleNamespace(check=lambda:None,identity=f.identity)
        with self.assertRaisesRegex(ProtocolError,'document_repeated_evidence_limit'):
            run_document_consultation(model,broker,context,f.f.root/'cycle-trajectory.json','One question')
        self.assertLessEqual(len(observed),8)
        self.assertTrue(any('progress_warning' in m.get('content','') for sample in observed for m in sample))

    def test_two_read_calls_parse_but_original_reviewer_stays_single_call(self):
        fixture=runtime_fixture.RuntimeTests();fixture.setUp()
        model=fixture.model(cls=ProtectedDocumentModel)
        response=self.response_batch([('search_text',{'snapshot_id':'docs-1','query':'split_after'}),('search_text',{'snapshot_id':'docs-1','query':'maxsplit'})])
        before=canonical_bytes(response.model_dump())
        self.assertEqual(len(model._parse_actions(response)),2)
        self.assertEqual(canonical_bytes(response.model_dump()),before)
        with self.assertRaises(FormatError):fixture.model()._parse_actions(response)

    def test_mixed_submission_duplicate_ids_and_executable_batches_reject(self):
        fixture=runtime_fixture.RuntimeTests();fixture.setUp();model=fixture.model(cls=ProtectedDocumentModel)
        valid=('search_text',{'snapshot_id':'docs-1','query':'split'})
        for second in [('bash',{'command':'echo forbidden'}),('submit_consultation',{})]:
            with self.subTest(second=second[0]),self.assertRaises(FormatError):model._parse_actions(self.response_batch([valid,second]))
        duplicate=self.response_batch([valid,valid]);duplicate.choices[0].message.tool_calls[1].id=duplicate.choices[0].message.tool_calls[0].id
        with self.assertRaises(FormatError):model._parse_actions(duplicate)
        with self.assertRaises(FormatError):model._parse_actions(self.response_batch([valid,valid,valid]))

    def test_two_reads_execute_serially_with_both_receipts_before_submission(self):
        f,broker=self.fixture(b'split behavior\nsecond line\n')
        doc=broker.snapshot.grant.documents[0]
        first=[('read_lines',{'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':1,'end':1}),
            ('search_text',{'snapshot_id':broker.snapshot.grant.snapshot_id,'query':'second'})]
        fixture=runtime_fixture.RuntimeTests();fixture.setUp();parser=fixture.model(cls=ProtectedDocumentModel)
        observed=[]
        def query(messages):
            observed.append(deepcopy(messages))
            calls=first if len(observed)==1 else [('submit_consultation',{'advice':document_fixture.advice_for(broker).model_dump(mode='json')})]
            response=self.response_batch(calls)
            return response.choices[0].message.model_dump()|{'extra':{'actions':parser._parse_actions(response)}}
        model=SimpleNamespace(query=query,usage={},contains_credentials=lambda value:False)
        model.format_observation_messages=lambda message,outputs:ReviewModel.format_observation_messages(model,message,outputs)
        result=run_document_consultation(model,broker,SimpleNamespace(check=lambda:None,identity=f.identity),f.f.root/'batch-trajectory.json','One question')
        self.assertEqual(result.status,'answered')
        self.assertEqual(len(observed),2)
        self.assertEqual([m['tool_call_id'] for m in observed[1] if m['role']=='tool'],['batch-call-0','batch-call-1'])
        self.assertEqual([e.get('tool') for e in broker.events],['read_lines','search_text','submit_consultation'])

    def test_cancel_between_serial_reads_does_not_execute_second(self):
        f,broker=self.fixture(b'split behavior\nsecond line\n');doc=broker.snapshot.grant.documents[0]
        fixture=runtime_fixture.RuntimeTests();fixture.setUp();parser=fixture.model(cls=ProtectedDocumentModel)
        response=self.response_batch([('read_lines',{'snapshot_id':broker.snapshot.grant.snapshot_id,'document_id':doc.document_id,'start':1,'end':1}),
            ('search_text',{'snapshot_id':broker.snapshot.grant.snapshot_id,'query':'second'})])
        def check():
            if broker.events:raise ReviewCancelled('cancel-between-reads')
        message=response.choices[0].message.model_dump()|{'extra':{'actions':parser._parse_actions(response)}}
        model=SimpleNamespace(query=lambda messages:message,usage={},contains_credentials=lambda value:False)
        model.format_observation_messages=lambda m,outputs:ReviewModel.format_observation_messages(model,m,outputs)
        output=f.f.root/'cancel-batch.json'
        with self.assertRaises(ReviewCancelled):run_document_consultation(model,broker,SimpleNamespace(check=check,identity=f.identity),output,'One question')
        self.assertEqual(len(broker.events),1)
        tools=[m for m in json.loads(output.read_bytes())['messages'] if m['role']=='tool']
        self.assertEqual(len(tools),2)
        self.assertEqual(json.loads(tools[1]['content'])['status'],'not_executed')

    def test_review_can_project_three_large_receipts_with_document_context(self):
        f=StageAFixture()
        f.write(('def total(values):\n'+('# documented context '+'x'*75+'\n')*125).encode())
        f.snapshot=f.seal('large-review-source')
        broker=ReviewEvidenceBroker(f.snapshot,f.reviewer,f.make_handoff(report_ids=()))
        doc=f.doc()
        messages=[{'role':'system','content':'Original reviewer instructions.'},{'role':'user','content':'Original task and version-bound document context '+ 'Q'*6500}]
        for i,start in enumerate((2,42,82)):
            args={'snapshot_id':f.snapshot.candidate.snapshot_id,'document_id':doc.document_id,'start':start,'end':start+39}
            receipt=broker.dispatch(f.reviewer,'read_lines',args)
            messages.extend([{'role':'assistant','content':'','tool_calls':[{'id':'review-call-'+str(i),'type':'function','function':{'name':'read_lines','arguments':json.dumps(args)}}]},
                {'role':'tool','tool_call_id':'review-call-'+str(i),'content':canonical_bytes(receipt).decode()}])
        raw=canonical_bytes(messages)
        fixture=runtime_fixture.RuntimeTests();fixture.setUp();model=fixture.model()
        model.review_projection_windows=(3,)
        old=model._prepare_messages_for_api(messages)
        model.review_projection_windows=(3,2,1)
        new=model._prepare_messages_for_api(messages)
        self.assertGreater(message_bytes(old),16384)
        self.assertLessEqual(message_bytes(new),16384)
        self.assertEqual(new[:2],messages[:2]);self.assertEqual(new[-1],messages[-1])
        self.assertEqual(canonical_bytes(messages),raw)
        self.assertTrue(model.review_projection_events)


if __name__=='__main__':unittest.main()
