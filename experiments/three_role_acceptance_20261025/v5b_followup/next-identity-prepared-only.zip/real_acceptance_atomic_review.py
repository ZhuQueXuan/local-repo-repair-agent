"""One declared public three-role acceptance via the existing task service."""
import argparse,hashlib,json,re,sqlite3,time,urllib.request,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent/'atomic_review_v6'
OUT.mkdir(exist_ok=True)
PLAN=OUT/'three-role-acceptance-plan.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def api(base,token,path,body=None):
    req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),
        headers={'X-Task-Token':token,'Content-Type':'application/json','Origin':base},method='GET' if body is None else 'POST')
    with urllib.request.urlopen(req,timeout=20) as response:return json.loads(response.read())
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    if not args.execute:
        assert not PLAN.exists(),'Do not replace a declared identity'
        source=ROOT/'tasks/split-after-boundary'
        paths=list((ROOT/'scripts').glob('*.py'))+[ROOT/'scripts/task_panel.html',ROOT/'scripts/collaboration_panel.js']
        paths+=list((ROOT/'configs').glob('*.json'))+[source/'manifest.json',source/'issue.md',source/'checks/test_behavior.py']
        manifest=json.loads((source/'manifest.json').read_bytes())
        paths += [source/'repo'/p for p in manifest['source_files_sha256']]
        frozen={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(set(paths))}
        plan={'schema_version':1,'purpose':'One new-version real three-role atomic-review history acceptance on a known public development issue; no effectiveness claim',
            'request':{'task':'split-after-boundary','profile':'adaptive_history','mode':'live','collaboration_mode':'document_review','policy_version':1,
                'document_question':'Find the frozen changelog entries mentioning split_after or maxsplit. Cite the exact entries, state only what they establish, and list the input or boundary behavior they do not specify. A changelog is not a complete API contract; submit explicit unknowns rather than searching unrelated release history.',
                'request_key':'three-role-acceptance-'+uuid.uuid4().hex},
            'destinations':['https://myai.bupt.edu.cn/llm-gw/v1','https://api.deepseek.com'],
            'external_content':['public task source','patches','test results','role conversations'],
            'accounting':'existing shared data/deepseek_budget.json; preserve historical receipts',
            'parent_seconds':1800,'feedback_windows':1,'no_selection_reruns':True,'files_sha256':frozen}
        write(PLAN,plan);print(json.dumps({'prepared':str(PLAN),'files':len(frozen),'external_model_calls':0}));return
    plan=json.loads(PLAN.read_bytes())
    assert not (OUT/'acceptance-dispatched.json').exists(),'Do not dispatch a second identity'
    for p,h in plan['files_sha256'].items():assert sha((ROOT/p).read_bytes())==h,p
    with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
        rows={run_id:raw for run_id,raw in db.execute('SELECT id,payload FROM runs')}
        assert not any(json.loads(raw)['status'] in {'queued','running','cancel_requested'} for raw in rows.values())
        with sqlite3.connect(OUT/'before-real-acceptance.sqlite3') as target:db.backup(target)
    write(OUT/'before-real-payloads.json',rows)
    write(OUT/'before-real-ledger.json',json.loads((ROOT/'data/deepseek_budget.json').read_bytes()))
    base='http://127.0.0.1:8765'
    with urllib.request.urlopen(base+'/',timeout=10) as response:html=response.read().decode()
    token=re.search(r"const token='([^']+)'",html).group(1)
    # Persistent request key makes an uncertain POST recoverable without a new task.
    write(OUT/'acceptance-dispatched.json',{'request_key':plan['request']['request_key'],'plan_sha256':sha(PLAN.read_bytes()),'state':'dispatching'})
    parent=api(base,token,'/api/runs',plan['request'])
    write(OUT/'acceptance-parent.json',parent)
    print(json.dumps({'run_id':parent['id'],'purpose':plan['purpose']},ensure_ascii=False),flush=True)
    until=time.monotonic()+1860
    last=None
    while time.monotonic()<until:
        current=api(base,token,'/api/runs/'+parent['id'])
        marker=(current['status'],current.get('stage'))
        if marker!=last:print(json.dumps({'run_id':parent['id'],'status':marker[0],'stage':marker[1]},ensure_ascii=False),flush=True);last=marker
        if current['status'] not in {'queued','running','cancel_requested'} and current.get('live_receipts_digest'):
            write(OUT/'acceptance-result.json',current)
            write(OUT/'acceptance-collaboration.json',api(base,token,'/api/runs/'+parent['id']+'/collaboration'))
            return
        time.sleep(2)
    write(OUT/'acceptance-wait-limit.json',{'run_id':parent['id'],'note':'Observer wait expired; inspect original identity, never dispatch a replacement'})
if __name__=='__main__':main()
