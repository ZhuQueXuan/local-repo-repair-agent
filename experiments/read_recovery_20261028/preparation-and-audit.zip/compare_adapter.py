import json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
driver=(OUT/'regression-driver.log').read_text('utf-8-sig')
folder=Path(next(l.split('; log: ',1)[1] for l in driver.splitlines() if l.startswith('Running adapter;'))).parent
current=json.loads((folder/'adapter/upstream_results.json').read_bytes())
with zipfile.ZipFile(ROOT/'experiments/final_regression_20261027/offline-reports.zip') as z:
 reference=json.loads(z.read('reference/adapter-upstream_results.json'))
def outcomes(value,outcome):return sorted((r['nodeid'],r['phase']) for r in value['reports'] if r['outcome']==outcome)
assert current['counts']==reference['counts']=={'passed':169,'failed':6,'skipped':1}
assert not current['guard_violations']
for outcome in ['failed','skipped']:assert outcomes(current,outcome)==outcomes(reference,outcome)
record={'same_failures_and_skips':True,'counts':current['counts'],'failed':outcomes(current,'failed'),
 'skipped':outcomes(current,'skipped'),'guard_violations':0,'reference':'experiments/final_regression_20261027/offline-reports.zip/reference/adapter-upstream_results.json',
 'current':str(folder/'adapter/upstream_results.json')}
(OUT/'adapter-comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'adapter-reference.json').write_text(json.dumps(reference,ensure_ascii=False),encoding='utf-8')
print(json.dumps(record))
