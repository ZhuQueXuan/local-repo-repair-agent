"""Combine all three outcomes, retaining the initial failed frozen version."""
from decimal import Decimal
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
first=read(OUT/'first-audit.json');second=read(OUT/'second-audit.json')
assert first['all_terminal'] and second['all_terminal'] and first['slots']==2 and second['slots']==1
results=[r|{'version':'initial'} for r in first['results']]+[r|{'version':'formatter_corrected'} for r in second['results']]
assert len({r['run_id'] for r in results})==3
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json')
assert len(before['requests'])==4104 and len(after['requests'])==4177
assert all(after['requests'][k]==v for k,v in before['requests'].items())
assert {k:v for k,v in before.items() if k!='requests'}=={k:v for k,v in after.items() if k!='requests'}
history=read(OUT/'history-before.json');assert len(history)==8447 and all(sha(ROOT/n)==h for n,h in history.items())
plan1=read(ROOT/'temp/comparison_batches/c66_1028/plan.json');plan2=read(ROOT/'temp/comparison_batches/c66b_1028/plan.json')
changed=[n for n,h in plan1['inputs'].items() if sha(ROOT/n)!=h]
assert sorted(changed)==plan2['changed_since_initial_batch']
for n in changed:assert sha(OUT/'snapshots/click-resource-exceptions/frozen_inputs'/n)==plan1['inputs'][n]
assert all(sha(ROOT/n)==h for n,h in plan2['inputs'].items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
unknown=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']!='settled'),Decimal(0))
assert len(new)==sum(r['attempts'] for r in results)
assert abs(float(known)-sum(r['known_price_estimate_cny'] for r in results))<0.000003
assert sum(r['resolved'] for r in results)==0
assert results[-1]['execution_evidence']['archive_continuations']>=1
assert results[-1]['execution_evidence']['archive_recoveries']>=1
assert results[-1]['status']=='finished' and results[-1]['agent_exit']=='NoProgress'
diags=read(OUT/'diagnostics.json');write(OUT/'first-diagnostics.json',diags)
diags+=read(OUT/'formatter-diagnostics.json');assert len(diags)==3;write(OUT/'diagnostics.json',diags)
diagnostic=ROOT/'temp/task_service/65653a3f56614963837b0719286c3ed1/diagnostic.txt'
(OUT/'formatter-initial-diagnostic.txt').write_bytes(diagnostic.read_bytes())
audit={'stage':66,'slots':3,'all_terminal':True,'resolved':0,'normal_submissions':0,'full_complete':0,
 'source_base_commit':first['source_base_commit'],'results':results,'selection_reruns':0,
 'initial_two_run_plan_sha256':first['plan_sha256'],'formatter_one_run_plan_sha256':second['plan_sha256'],
 'initial_frozen_inputs':len(plan1['inputs']),'initial_inputs_changed_after_terminal':changed,
 'initial_changed_inputs_preserved_in_original_snapshot':True,'current_frozen_inputs_verified':len(plan2['inputs']),
 'extra_acceptance_reason':plan2['reason'],'platform_attempts':len(new),'known_price_estimate_cny':float(known),
 'unknown_placeholder_cny':float(unknown),'complete_cost_estimate_cny':None,
 'formal_payloads_unchanged':53,'shared_requests_before':4104,'shared_requests_after':len(after['requests']),
 'historical_files_unchanged':len(history),'actual_worker_seconds':round(sum(r['elapsed_seconds'] for r in results),3),
 'balance_probed':False,'maximum_total_runs':3,
 'scope':'Two predeclared known-task development acceptances, then exactly one new single identity after a concrete formatter contract bug. All failures retained; not a matched comparison, new benchmark, or stable solve-rate claim.'}
write(OUT/'audit.json',audit);write(OUT/'new-request-receipts.json',new);write(OUT/'ledger-after.json',after)
print(json.dumps({k:audit[k] for k in ['slots','resolved','platform_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after','actual_worker_seconds']}))
