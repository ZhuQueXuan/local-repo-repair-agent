"""Two predeclared development acceptances; fixed source, one identity each."""
import hashlib,json,os,sqlite3,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c66_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_store import CollaborationStore
from collaboration_panel import public_policy
from task_service_store import worker_lock,TERMINAL,policy
from task_service_worker import freeze_inputs
from comparison_batch import score,billing_failure

def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def verify(plan):
 assert all(sha(ROOT/n)==h for n,h in plan['inputs'].items()),'Frozen input changed'
 with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
 assert formal==read(OUT/'formal-before.json')
 assert all(sha(ROOT/n)==h for n,h in read(OUT/'history-before.json').items())

if sys.argv[1]=='prepare':
 assert not HOME.exists()
 log=(OUT/'targeted-final.log').read_text('utf-8-sig');assert 'Ran 130 tests' in log and log.rstrip().endswith('OK')
 lines=(OUT/'regression-driver.log').read_text('utf-8-sig').splitlines()
 regression=Path(next(l.removeprefix('Summary: ') for l in lines if l.startswith('Summary: ')))
 summary=read(regression);assert not summary['changed_protected_files']
 native=next(j for j in summary['jobs'] if j['scope']=='native');project=next(j for j in summary['jobs'] if j['scope']=='project');adapter=next(j for j in summary['jobs'] if j['scope']=='adapter')
 assert native['exit_code']==project['exit_code']==0 and adapter['exit_code']==1
 assert read(OUT/'adapter-comparison.json')['same_failures_and_skips']
 replay=read(OUT/'replay.json');assert replay['all_checks_passed'] and replay['model_calls']==0
 assert read(ROOT/'data/deepseek_budget.json')==read(OUT/'ledger-before.json')
 HOME.mkdir();slots=[];inputs={str(Path(__file__).relative_to(ROOT).as_posix()):sha(Path(__file__))}
 for task,variant in [('click-resource-exceptions','improved'),('boltons-table-text','full')]:
  target=OUT/'snapshots'/task;target.mkdir(parents=True)
  inputs.update(freeze_inputs(task,target))
  slots.append({'task':task,'variant':variant,'repetition':1,'request_key':'development66-'+uuid.uuid4().hex})
 plan={'kind':'Stage66 known-task development acceptance, not a new comparison or benchmark','maximum_runs':2,
  'base':read(OUT/'baseline.json')['commit'],'slots':slots,'inputs':inputs,'model_profile':'legacy_deepseek_v1',
  'configuration':policy('adaptive_history'),'full_policy':public_policy(documents=True,question='Find only relevant public documentation on the issue behavior and constraints. State information_not_found when the documentation does not establish the requested boundary.'),
  'regression':str(regression),'replay':replay,'failure_policy':'One new identity per slot, all outcomes preserved. No automatic paid rerun; explicit billing failure stops remaining. Score only after all terminal. Raw/failing/degraded outcomes separate from independent patch acceptance.',
  'changes':'Read-only output continuation with immutable hashes; once-per-origin/current-revision recovery of observations omitted from API view; context grep and compound pagination; real declared public reproduction before initial model run. Existing request/fee/time/security guards, eight-action advisory/24-action stop and role times unchanged.',
  'route':['bupt_gateway/deepseek-v4-flash','deepseek_official/deepseek-flash'],'unknown_balance_probe':False,'source_and_test_changes_during_live':False,
  'authorization':read(OUT/'baseline.json')['authorization']}
 verify(plan);write(HOME/'plan.json',plan);write(HOME/'plan-sha256.json',{'sha256':sha(HOME/'plan.json')})
 write(OUT/'fixed-conditions.json',plan);print(json.dumps({'prepared':2,'inputs':len(inputs),'plan_sha256':sha(HOME/'plan.json'),'model_calls':0}))
elif sys.argv[1]=='execute':
 plan=read(HOME/'plan.json');assert sha(HOME/'plan.json')==read(HOME/'plan-sha256.json')['sha256']
 assert not (HOME/'dispatched.json').exists();verify(plan)
 with worker_lock(HOME,'batch.lock') as owned:
  assert owned
  with worker_lock(ROOT/'data/task_service') as idle:
   assert idle
   with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    assert all(json.loads(v)['status'] not in {'queued','running','cancel_requested','preparing_continuation'} for v, in db.execute('SELECT payload FROM runs'))
   store=CollaborationStore(HOME/'store');write(HOME/'dispatched.json',{'plan_sha256':sha(HOME/'plan.json')})
   slots=[]
   for s in plan['slots']:
    if s['variant']=='improved':row=store.create(s['task'],'adaptive_history','live',s['request_key'],model_profile=plan['model_profile'])
    else:row=store.create_collaboration(s['task'],'adaptive_history',s['request_key'],plan['full_policy'],execution='live',model_profile=plan['model_profile'],allow_capabilities=True,
     task_card={'goal':'Repair the original issue under existing constraints; independent checks/review determine outcomes.',
      'steps':[{'id':'repair','title':'Repair, validate and submit','status':'pending'}],
      'instruction':'Known-task development acceptance. Retain uncertainty/failure; one possible revision, no looping until success.'})
    slots.append(s|{'run_id':row['id']})
   write(HOME/'slots.json',slots)
   for s in slots:
    verify(plan)
    with (HOME/(s['request_key']+'.claimed')).open('x') as f:f.write(s['run_id'])
    command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--home',str(store.home),'--run-id',s['run_id']]
    if s['variant']=='full':command.append('--collaboration')
    print(json.dumps({'starting':s}),flush=True)
    with (HOME/(s['request_key']+'.log')).open('xb') as log:
     p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
     try:p.wait(timeout=1860)
     except subprocess.TimeoutExpired:
      from execution_backend import terminate_owned_process
      terminate_owned_process(p);p.wait(timeout=10)
      store.update(s['run_id'],status='failed',stage='done',reason='Owned development worker exceeded deadline; preserve, no rerun')
    row=store.get(s['run_id'])
    if row['status'] not in TERMINAL:store.update(s['run_id'],status='failed',stage='done',reason='Worker exited without terminal status; no rerun')
    print(json.dumps({'ended':s['run_id'],'status':store.get(s['run_id'])['status']}),flush=True)
    stopped=billing_failure(read(ROOT/'data/deepseek_budget.json'),read(OUT/'ledger-before.json')['requests'])
    if stopped:
     write(HOME/'billing-stop.json',stopped)
     for pending in slots:
      if store.get(pending['run_id'])['status']=='queued':store.cancel(pending['run_id'])
     break
   verify(plan);report=score(HOME,store,slots)
   print(json.dumps({'development_resolved':report['resolved'],'slots':2}),flush=True)
else:raise ValueError('prepare or execute only')
