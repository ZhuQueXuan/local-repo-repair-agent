"""Old Click output continuation and partial-table recovery, no model transport."""
import hashlib,json,sys,time,uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from run_task_batch import StatefulTaskEnvironment,StatefulModel
from collaboration_runtime import RepairEnvironment
from execution_runtime import bash_executable
from context_budget import ContextBudget,message_bytes
from minisweagent.models.litellm_model import LitellmModelConfig
from task_workspace import load_task

records=json.loads((ROOT/'temp/execution_closure_20261028/diagnostics.json').read_bytes())
results=[];uid=uuid.uuid4().hex[:8]
for record in records:
 old=Path(record['work']);_,manifest=load_task(record['task'])
 work=OUT/'replay'/uid/record['task'];work.mkdir(parents=True)
 for name in manifest['source_files_sha256']:
  path=work/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((old/name).read_bytes())
 options={'source_files':list(manifest['source_files_sha256']),'max_output_bytes':1024,
  'state_policy':{'guard_enabled':True,'implementation_prefix':manifest['source_prefix'],
   'progress_policy':{'stagnation_actions':8},'validation_commands':{
    'targeted':manifest['agent_test_command'],'issue':manifest.get('agent_issue_command','python -B -m unittest discover -s task_checks -v')}}}
 if record['task'].startswith('click'):
  events=[json.loads(l) for l in (old/'temp/tool-output/events.jsonl').read_text('utf-8').splitlines()]
  oldevent=next(e for e in events if e['sequence']==15)
  original=(old/oldevent['full_output_path']).read_bytes()
  env=StatefulTaskEnvironment(work,bash_executable(),**options)
  env.backend.run_shell=Mock(return_value={'output':original.decode('utf-8'),'returncode':0})
  pages=[]
  while True:
   response=env.execute({'command':oldevent['command']})
   e=response['extra']['tool_output'];pages.append(e)
   assert len(response['output'].encode())<=1024
   if not e['page_next_line']:break
   assert len(pages)<24
  assert env.backend.run_shell.call_count==1
  assert all(a['page_next_line']==b['page_start_line'] for a,b in zip(pages,pages[1:]))
  assert (work/pages[0]['page_origin']).read_bytes()==original
  assert env.execute({'command':oldevent['command']})['returncode']==-1
  assert not env.task_state.progress.first_change
  results.append({'task':record['task'],'old_run':record['run_id'],'old_action_sequence':15,
   'old_bytes':len(original),'old_output_sha256':hashlib.sha256(original).hexdigest(),
   'contiguous_pages':len(pages),'backend_invocations':env.backend.run_shell.call_count,
   'no_gaps':True,'full_raw_preserved':True,'eof_repeat_blocked':True,
   'scope':'Exact old tool command/output replay with mocked local shell result; no old Shell executed or model called.'})
 else:
  context=SimpleNamespace(check=lambda:None,deadline=time.monotonic()+60,store=SimpleNamespace(event=Mock()),
   identity=SimpleNamespace(run_id='recovery-replay',role_run_id='repairer-1'))
  env=RepairEnvironment(work,bash_executable(),context=context,**options)
  env.model=SimpleNamespace(contains_credentials=lambda _:False)
  name='boltons/tableutils.py';lines=(work/name).read_text('utf-8').splitlines(keepends=True)
  observed=''.join(lines[554:600])
  env.backend.run_shell=Mock(return_value={'output':observed,'returncode':0})
  source=env.execute({'command':"sed -n '555,600p' boltons/tableutils.py"})
  messages=[{'role':'system','content':'repair'},{'role':'user','content':'original public issue'}]
  for index in range(3):
   result=source if index==0 else env._process_output({'output':'logged check output\n'+'x'*800,'returncode':1},command='python temp/diagnostic.py')
   call={'id':f'c-{index}','type':'function','function':{'name':'bash','arguments':'{}'}}
   messages.extend([{'role':'assistant','content':None,'tool_calls':[call]},
    {'role':'tool','tool_call_id':call['id'],'content':result['output'],'extra':result['extra']}])
  model=StatefulModel.__new__(StatefulModel);model.task_state=env.task_state;model.repository_retrieval=None
  model.config=LitellmModelConfig(model_name='deepseek/deepseek-flash')
  model.context_budget=ContextBudget(target_bytes=2500,keep_recent_tool_outputs=1,compact_completed_exchanges=True,retained_audit_entries=1)
  before=json.dumps(messages);view=model._prepare_messages_for_api(messages)
  assert source['extra']['tool_output']['full_output_path'] not in env.task_state.visible_outputs
  assert before==json.dumps(messages)
  env.task_state.progress.since_progress=9  # Reconstruct the old stalled contract state.
  recovered=env.execute({'command':"cd \"$(git rev-parse --show-toplevel)\" && sed -n '560,590p' boltons/tableutils.py"})
  receipt=recovered['extra']['tool_output']
  assert receipt['execution_kind']=='archived_recovery' and recovered['returncode']==0
  assert env.backend.run_shell.call_count==1 and len(recovered['output'].encode())<=1024
  assert receipt['delivered_source_span'][1]==560
  assert not env.task_state.progress.first_change
  results.append({'task':record['task'],'old_run':record['run_id'],'partial_source_sha256':hashlib.sha256((work/name).read_bytes()).hexdigest(),
   'current_api_bytes':message_bytes(view),'raw_history_preserved':True,'source_omitted_by_actual_projection':True,
   'requested_original_source_lines':[560,590],'recovered_source_lines':receipt['delivered_source_span'],
   'execution_kind':receipt['execution_kind'],'backend_invocations':env.backend.run_shell.call_count,
   'no_source_or_test_progress_claimed':True,
   'scope':'Old final partial source in a new isolated directory; actual request projection plus reconstructed nine-action stagnation, mocked source read. Not full old-session/model replay.'})
value={'all_checks_passed':True,'results':results,'model_calls':0,'old_scores_changed':False,
 'scope':'Mechanism replays only. Actual edit, two checks and standalone submission covered separately by existing RuntimeTests with real local Bash and no model API.'}
(OUT/'replay.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(value,ensure_ascii=False))
