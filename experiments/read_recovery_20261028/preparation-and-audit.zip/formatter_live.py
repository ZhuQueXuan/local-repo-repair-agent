"""One predeclared integration acceptance after the concrete output-contract fix.

Initial two outcomes stay closed and unchanged. This is not a success search.
"""
import hashlib,json,os,sqlite3,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c66b_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_service_worker import freeze_inputs
from collaboration_store import CollaborationStore
from task_service_store import worker_lock,TERMINAL
from comparison_batch import score,billing_failure
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def protections():
 with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
  rows=dict(db.execute('SELECT id,payload FROM runs'))
 assert rows==read(OUT/'formal-before.json')
 assert all(sha(ROOT/n)==h for n,h in read(OUT/'history-before.json').items())
old=read(OUT/'first-audit.json');assert old['all_terminal'] and old['slots']==2
assert 'UndefinedError' in old['results'][0]['reason']
assert not HOME.exists() and read(ROOT/'data/deepseek_budget.json')==read(OUT/'first-ledger-after.json')
log=(OUT/'formatter-correction-tests.log').read_text('utf-8-sig');assert 'Ran 130 tests' in log and log.rstrip().endswith('OK')
initial=read(ROOT/'temp/comparison_batches/c66_1028/plan.json')
changed=[n for n,h in initial['inputs'].items() if sha(ROOT/n)!=h]
assert sorted(changed)==['scripts/run_task_batch.py','scripts/test_collaboration_runtime.py'],changed
assert billing_failure(read(ROOT/'data/deepseek_budget.json'),read(OUT/'ledger-before.json')['requests']) is None
protections();HOME.mkdir()
target=OUT/'formatter-snapshot';target.mkdir()
inputs=freeze_inputs('click-resource-exceptions',target)
inputs[Path(__file__).relative_to(ROOT).as_posix()]=sha(Path(__file__))
slot={'task':'click-resource-exceptions','variant':'improved','repetition':1,'request_key':'formatter66-'+uuid.uuid4().hex}
plan={'maximum_runs':1,'maximum_total_stage_runs':3,'slots':[slot],'inputs':inputs,'base':read(OUT/'baseline.json')['commit'],
 'reason':'The initial Click run failed in real StrictUndefined observation formatting: cached output lacked exception_info. After fixing that one return field and adding the actual formatter assertion, perform one new single-agent integration acceptance. Keep every outcome; no more paid attempts regardless of result.',
 'original_closed_batch':str(ROOT/'temp/comparison_batches/c66_1028'),'changed_since_initial_batch':changed,
 'correction_patch_sha256':sha(OUT/'formatter-correction.patch'),'targeted_checks':130,
 'conditions':'Same old Click task, model route, public/retained checks, state/time/byte/fee guards. No new full-group attempt. No real requests before this freeze.',
 'authorization':read(OUT/'baseline.json')['authorization']}
write(HOME/'plan.json',plan);write(HOME/'plan-sha256.json',{'sha256':sha(HOME/'plan.json')});write(OUT/'formatter-fixed-conditions.json',plan)
with worker_lock(HOME,'batch.lock') as owned:
 assert owned
 with worker_lock(ROOT/'data/task_service') as idle:
  assert idle
  with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
   assert all(json.loads(v)['status'] not in {'queued','running','cancel_requested','preparing_continuation'} for v, in db.execute('SELECT payload FROM runs'))
  store=CollaborationStore(HOME/'store')
  row=store.create(slot['task'],'adaptive_history','live',slot['request_key'],model_profile='legacy_deepseek_v1')
  slot|={'run_id':row['id']};write(HOME/'slots.json',[slot])
  with (HOME/(slot['request_key']+'.claimed')).open('x') as f:f.write(row['id'])
  assert all(sha(ROOT/n)==h for n,h in inputs.items());write(HOME/'dispatched.json',{'plan_sha256':sha(HOME/'plan.json')})
  print(json.dumps({'starting':slot,'frozen_inputs':len(inputs),'maximum_total_stage_runs':3}),flush=True)
  command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--home',str(store.home),'--run-id',row['id']]
  with (HOME/(slot['request_key']+'.log')).open('xb') as log:
   p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
   try:p.wait(timeout=420)
   except subprocess.TimeoutExpired:
    from execution_backend import terminate_owned_process
    terminate_owned_process(p);p.wait(timeout=10)
    store.update(row['id'],status='failed',stage='done',reason='Owned formatter acceptance exceeded deadline; no rerun')
  row=store.get(row['id'])
  if row['status'] not in TERMINAL:store.update(row['id'],status='failed',stage='done',reason='Worker ended without terminal status; no rerun')
  protections();assert all(sha(ROOT/n)==h for n,h in inputs.items())
  report=score(HOME,store,[slot]);write(OUT/'formatter-result.json',report)
  print(json.dumps({'ended':row['id'],'status':row['status'],'resolved':report['resolved']}),flush=True)
