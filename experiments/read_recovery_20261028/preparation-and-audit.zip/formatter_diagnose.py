"""Preserve local tool evidence for each terminal run without synthesizing candidates."""
import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c66b_1028'
def read(p):return json.loads(p.read_bytes())
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows=[json.loads(v) for v, in db.execute('SELECT payload FROM runs')]
assert len(rows)==1 and all(r['status'] in {'finished','failed','cancelled','interrupted'} for r in rows)
result=[]
for row in rows:
 if not row.get('workspace'):
  result.append({'run_id':row['id'],'task':row['task'],'work':None,'evidence':[],
   'scope':'No initialized workspace; slot remains in final denominator.'})
  continue
 work=Path(row['workspace']).resolve();assert work.is_relative_to(ROOT/'temp/comparison_tasks'/row['task'])
 entries=[]
 for directory in ['tool-output','task-state','context-history']:
  for p in sorted((work/'temp'/directory).rglob('*')):
   if p.is_file():entries.append({'path':p.relative_to(ROOT).as_posix(),'member':row['id']+'/'+p.relative_to(work).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 # Any unsealed raw work diff is diagnostic only; final patch selection is unchanged.
 raw=subprocess.check_output(['git','-C',str(work),'diff','--binary','--',('src/click/' if row['task'].startswith('click-') else 'boltons/')])
 target=OUT/'diagnostics'/row['id']/'unsealed-working.diff';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 result.append({'run_id':row['id'],'task':row['task'],'work':str(work),'evidence':entries,'diagnostic_diff_sha256':hashlib.sha256(raw).hexdigest(),
  'scope':'Local evidence and work diff for audit only; never replace exported or legally sealed candidate, never change final score.'})
(OUT/'formatter-diagnostics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'terminal_runs':1,'evidence_files':sum(len(r['evidence']) for r in result),'model_calls':0}))
