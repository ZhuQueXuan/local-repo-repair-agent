"""Read only terminal trajectories; no model calls, no scoring or changes."""
from collections import Counter
import json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/u68_1028'
records=[]
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows={r['id']:r for v, in db.execute('SELECT payload FROM runs') for r in [json.loads(v)]}
for s in json.loads((HOME/'slots.json').read_bytes()):
 row=rows[s['run_id']];assert row['status'] in {'finished','failed','cancelled','interrupted'}
 run=HOME/'store/runs'/s['run_id'];record=s|{'trajectories':{}}
 for p in sorted(run.glob('*trajectory.json')):
  data=json.loads(p.read_bytes());messages=data.get('messages',[])
  actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
  record['trajectories'][p.name]={'action_count':len(actions),'all_model_actions':actions,
   'last_tool_outputs':[m.get('content','') for m in messages if m.get('role')=='tool'][-4:],
   'end_info':{k:data.get('info',{}).get(k) for k in ('exit_status','submission','reason')}}
 work=Path(row['workspace']) if row.get('workspace') else None
 if work:
  outputs=work/'temp/tool-output/events.jsonl'
  values=[json.loads(l) for l in outputs.read_text('utf-8').splitlines()] if outputs.is_file() else []
  record['truncated_outputs_by_kind']=dict(Counter(e.get('execution_kind','shell') for e in values if e['truncated']))
  record['all_outputs_by_kind']=dict(Counter(e.get('execution_kind','shell') for e in values))
 records.append(record)
(OUT/'diagnostics.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'variant':r['variant'],'trace_actions':{k:v['action_count'] for k,v in r['trajectories'].items()},
 'output_kinds':r.get('all_outputs_by_kind')} for r in records]))
