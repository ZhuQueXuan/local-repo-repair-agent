"""Facts from terminal traces, including API timing limitations; no model calls."""
from collections import Counter
import json
from pathlib import Path
OUT=Path(__file__).parent;ROOT=OUT.parents[1]
a=json.loads((OUT/'audit.json').read_bytes());records=[]
for r in a['results']:
 run=ROOT/'temp/comparison_batches/u68_1028/store/runs'/r['run_id']
 data=json.loads((run/'trajectory.json').read_bytes());messages=data['messages']
 stamps=[m['extra']['timestamp'] for m in messages if m.get('extra',{}).get('timestamp')]
 actions=[act for m in messages for act in m.get('extra',{}).get('actions',[])]
 kinds=Counter(e['decision_event'] for e in r.get('decision_events',[]))
 commands=[act.get('command','') for act in actions]
 error=json.loads((run/'request_error.json').read_bytes()) if (run/'request_error.json').exists() else None
 record={'variant':r['variant'],'checks':r.get('checks'), 'agent_exit':r['agent_exit'],'decision_events':dict(kinds),
  'actions':len(actions),'tool_calls':dict(Counter(act.get('tool','bash') for act in actions)),
  'max_recorded_message_gap_seconds':round(max([0]+[b-a for a,b in zip(stamps,stamps[1:])]),3),
  'recorded_message_span_seconds':round(max(stamps)-min(stamps),3) if stamps else None,
  'repeated_commands':[{'command':c[:180],'count':n} for c,n in Counter(commands).most_common(5) if n>1],
  'provider_failure':error.get('provider_failure') if error else None}
 records.append(record)
(OUT/'findings.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(records,ensure_ascii=False))
