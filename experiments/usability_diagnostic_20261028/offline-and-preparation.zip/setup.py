"""Prepare an isolated, exactly two-run usability comparison, not a benchmark."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;OLD=ROOT/'temp/edit_decision_20261028'
b=json.loads((OUT/'baseline.json').read_bytes())
b.update(authorization='好的，按你的方式继续吧。承接已提方案：同一道已有表格题、同一模型与预算，当前严格流程与简化流程各一次，先离线后真实，好坏保留，旧成绩不改。',
 live_selection='Existing boltons-table-text only; adaptive_history single agent strict and simple diagnostic once each, exactly two fresh identities, no reruns.',live_limit=2)
(OUT/'baseline.json').write_text(json.dumps(b,ensure_ascii=False,indent=2),encoding='utf-8')
text=(OLD/'live.py').read_text('utf-8').replace('c67_1028','u68_1028').replace('development67-','usability68-')
text=text.replace('Stage67','Stage68').replace('targeted-compat.log','targeted-final.log').replace('Ran 137 tests','Ran 139 tests')
text=text.replace('regression-final-driver.log','regression-driver.log')
text=text.replace(" native=next(j for j in summary['jobs'] if j['scope']=='native');project=next(j for j in summary['jobs'] if j['scope']=='project');adapter=next(j for j in summary['jobs'] if j['scope']=='adapter')", " project=next(j for j in summary['jobs'] if j['scope']=='project')")
text=text.replace(" assert native['exit_code']==project['exit_code']==0 and adapter['exit_code']==1", " assert project['exit_code']==0")
text=text.replace(" assert read(OUT/'adapter-comparison.json')['same_failures_and_skips']", " # Underlying upstream implementation unchanged; project regression is new.")
text=text.replace(" analysis=read(OUT/'analysis.json');assert len(analysis['records'])==2", " assert read(OUT/'baseline.json')['live_limit']==2")
text=text.replace("[('click-resource-exceptions','improved'),('boltons-table-text','full')]", "[('boltons-table-text','strict'),('boltons-table-text','simple')]")
text=text.replace("target=OUT/'snapshots'/task", "target=OUT/'snapshots'/variant/task")
text=text.replace("'targeted_tests':137,'new_tests':4", "'targeted_tests':139,'new_tests':1")
text=text.replace("'changes':'Initial evidence-to-edit checkpoint", "'changes':'Simple arm: stable bash/edit/read/locate/abandon tools from first call; exact 512-byte pages with explicit next_start and actual file end; no two-evidence quota, no three-argument-rejection or 24-action read stop; original 300-second/16KB/1024-byte display/model/fee/file and check constraints retained. Strict arm: unchanged phase67 controller. Both adaptive_history SINGLE agents; no extra document/review/card/retrieval/skills. Implementation/check/submit unchanged. Original prior policy detail for strict: Initial evidence-to-edit checkpoint")
text=text.replace("'kind':'Stage68 known-task development acceptance, not a new comparison or benchmark'", "'kind':'Stage68 same-old-task single-agent strict/simple usability diagnostic; one per arm, not a new benchmark or causal proof'")
text=text.replace("    if s['variant']=='improved':row=store.create(s['task'],'adaptive_history','live',s['request_key'],model_profile=plan['model_profile'])\n    else:row=store.create_collaboration", "    if s['variant'] in {'strict','simple'}:row=store.create(s['task'],'adaptive_history','live',s['request_key'],model_profile=plan['model_profile'])\n    else:row=store.create_collaboration")
text=text.replace("    if s['variant']=='full':command.append('--collaboration')", "    if s['variant']=='simple':command.extend(['--diagnostic-variant','simple'])")
text=text.replace("   verify(plan);report=score(HOME,store,slots)", "   verify(plan)\n   # Existing scorer's improved tag is an execution-path selector only; preserve original arm names alongside.\n   report=score(HOME,store,[s|{'variant':'improved'} for s in slots])\n   write(HOME/'arm-mapping.json',{s['run_id']:s['variant'] for s in slots})")
# Both rows carry the same immutable source/config snapshot. Only the trusted CLI flag differs.
(OUT/'live.py').write_text(text,encoding='utf-8')
text=(OLD/'audit.py').read_text('utf-8').replace('c67_1028','u68_1028').replace('4177','4230').replace('8455','8463').replace("'stage':67","'stage':68")
text=text.replace("[('click-resource-exceptions','improved'),('boltons-table-text','full')]", "[('boltons-table-text','strict'),('boltons-table-text','simple')]")
text=text.replace("for v in ('improved','full')", "for v in ('strict','simple')")
text=text.replace("for result in report['results']:\n", "for original_result in report['results']:\n result=original_result|{'variant':next(s['variant'] for s in slots if s['run_id']==original_result['run_id'])}\n")
text=text.replace("Two known-task development acceptances, one single Click and one full table. Not a matched comparison, new benchmark, statistical rate or mechanism-causal effect.", "Same old table task, strict/simple adaptive_history single agents once each. Tests/route/time/model/context/file protection same; multiple usability controls changed as one bundle. One pair is a diagnostic, not causal/stable/benchmark evidence. No extra paid attempts.")
(OUT/'audit.py').write_text(text,encoding='utf-8')
text=(OLD/'monitor.py').read_text('utf-8').replace('c67_1028','u68_1028');(OUT/'monitor.py').write_text(text,encoding='utf-8')
print('Prepared two fixed single-agent arms; no new model calls.')
