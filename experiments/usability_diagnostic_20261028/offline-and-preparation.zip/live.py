"""Two predeclared development acceptances; fixed source, one identity each."""
import hashlib,json,os,sqlite3,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/u68_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_store import CollaborationStore
from collaboration_panel import public_policy
from task_service_store import worker_lock,TERMINAL,policy
from task_service_worker import freeze_inputs
from comparison_batch import score,billing_failure

def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def verify(plan):
 assert all(sha(ROOT/n)==h for n,h in plan['inputs'].items()),'Frozen input changed'
 with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
 assert formal==read(OUT/'formal-before.json')
 assert all(sha(ROOT/n)==h for n,h in read(OUT/'history-before.json').items())

if sys.argv[1]=='prepare':
 assert not HOME.exists()
 log=(OUT/'targeted-final.log').read_text('utf-8-sig');assert 'Ran 139 tests' in log and log.rstrip().endswith('OK')
 lines=(OUT/'regression-driver.log').read_text('utf-8-sig').splitlines()
 regression=Path(next(l.removeprefix('Summary: ') for l in lines if l.startswith('Summary: ')))
 summary=read(regression);assert not summary['changed_protected_files']
 project=next(j for j in summary['jobs'] if j['scope']=='project')
 assert project['exit_code']==0
 # Underlying upstream implementation unchanged; project regression is new.
 assert read(OUT/'baseline.json')['live_limit']==2
 replay=read(OUT/'replay.json');assert replay['model_calls']==0 and replay['same_three_original_invalid_ranges']
 assert read(ROOT/'data/deepseek_budget.json')==read(OUT/'ledger-before.json')
 HOME.mkdir();slots=[];inputs={str(Path(__file__).relative_to(ROOT).as_posix()):sha(Path(__file__))}
 for task,variant in [('boltons-table-text','strict'),('boltons-table-text','simple')]:
  target=OUT/'snapshots'/variant/task;target.mkdir(parents=True)
  inputs.update(freeze_inputs(task,target))
  slots.append({'task':task,'variant':variant,'repetition':1,'request_key':'usability68-'+uuid.uuid4().hex})
 plan={'kind':'Stage68 same-old-task single-agent strict/simple usability diagnostic; one per arm, not a new benchmark or causal proof','maximum_runs':2,
  'base':read(OUT/'baseline.json')['commit'],'slots':slots,'inputs':inputs,'model_profile':'legacy_deepseek_v1',
  'configuration':policy('adaptive_history'),'single_agents_only':True,
  'regression':str(regression),'offline_evidence':{'targeted_tests':139,'new_tests':1},'failure_policy':'One new identity per slot, all outcomes preserved. No automatic paid rerun; explicit billing failure stops remaining. Score only after all terminal. Raw/failing/degraded outcomes separate from independent patch acceptance.',
  'changes':'Simple arm: stable bash/edit/read/locate/abandon tools from first call; exact 512-byte pages with explicit next_start and actual file end; no two-evidence quota, no three-argument-rejection or 24-action read stop; original 300-second/16KB/1024-byte display/model/fee/file and check constraints retained. Strict arm: unchanged phase67 controller. Both adaptive_history SINGLE agents; no extra document/review/card/retrieval/skills. Implementation/check/submit unchanged. Original prior policy detail for strict: Initial evidence-to-edit checkpoint after eight actions without source/new-check progress; latest program message after task card, exact model-authored edit or at most two short evidence requests per revision, honest abandonment and three rejection stop. Actual registered checks automatically execute after any source edit; current passing revision permits one final diff and actual standalone model submission. Shared compact instructions, unchanged raw group, request/fee/time/security and role bounds; review revisions retain existing protocol. No seeded patch or automatic submit.',
  'route':['bupt_gateway/deepseek-v4-flash','deepseek_official/deepseek-flash'],'unknown_balance_probe':False,'source_and_test_changes_during_live':False,
  'authorization':read(OUT/'baseline.json')['authorization']}
 verify(plan);write(HOME/'plan.json',plan);write(HOME/'plan-sha256.json',{'sha256':sha(HOME/'plan.json')})
 write(OUT/'fixed-conditions.json',plan);print(json.dumps({'prepared':2,'inputs':len(inputs),'plan_sha256':sha(HOME/'plan.json'),'model_calls':0}))
elif sys.argv[1]=='execute':
 plan=read(HOME/'plan.json');assert sha(HOME/'plan.json')==read(HOME/'plan-sha256.json')['sha256']
 assert not (HOME/'dispatched.json').exists();verify(plan)
 with worker_lock(HOME,'batch.lock') as owned:
  assert owned
  with worker_lock(ROOT/'data/task_service') as idle:
   assert idle
   with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    assert all(json.loads(v)['status'] not in {'queued','running','cancel_requested','preparing_continuation'} for v, in db.execute('SELECT payload FROM runs'))
   store=CollaborationStore(HOME/'store');write(HOME/'dispatched.json',{'plan_sha256':sha(HOME/'plan.json')})
   slots=[]
   for s in plan['slots']:
    assert s['variant'] in {'strict','simple'}
    row=store.create(s['task'],'adaptive_history','live',s['request_key'],model_profile=plan['model_profile'])
    write(HOME/(row['id']+'-diagnostic-arm.json'),{'arm':s['variant'],'cli_flag':['--diagnostic-variant','simple'] if s['variant']=='simple' else [],'plan_sha256':sha(HOME/'plan.json')})
    slots.append(s|{'run_id':row['id']})
   write(HOME/'slots.json',slots)
   for s in slots:
    verify(plan)
    with (HOME/(s['request_key']+'.claimed')).open('x') as f:f.write(s['run_id'])
    command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--home',str(store.home),'--run-id',s['run_id']]
    if s['variant']=='simple':command.extend(['--diagnostic-variant','simple'])
    print(json.dumps({'starting':s}),flush=True)
    with (HOME/(s['request_key']+'.log')).open('xb') as log:
     p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
     try:p.wait(timeout=1860)
     except subprocess.TimeoutExpired:
      from execution_backend import terminate_owned_process
      terminate_owned_process(p);p.wait(timeout=10)
      store.update(s['run_id'],status='failed',stage='done',reason='Owned development worker exceeded deadline; preserve, no rerun')
    row=store.get(s['run_id'])
    if row['status'] not in TERMINAL:store.update(s['run_id'],status='failed',stage='done',reason='Worker exited without terminal status; no rerun')
    print(json.dumps({'ended':s['run_id'],'status':store.get(s['run_id'])['status']}),flush=True)
    stopped=billing_failure(read(ROOT/'data/deepseek_budget.json'),read(OUT/'ledger-before.json')['requests'])
    if stopped:
     write(HOME/'billing-stop.json',stopped)
     for pending in slots:
      if store.get(pending['run_id'])['status']=='queued':store.cancel(pending['run_id'])
     break
   verify(plan)
   report=score(HOME,store,slots)
   print(json.dumps({'development_resolved':report['resolved'],'slots':2}),flush=True)
else:raise ValueError('prepare or execute only')
