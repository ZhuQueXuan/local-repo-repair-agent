"""Replay the third phase67 invalid ranges against strict/simple; zero models."""
import hashlib,json,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_state import TaskState
from edit_decision import DecisionRejected
source=ROOT/'evaluation/medium_comparison_20261028/public/boltons-table-text/repo/boltons/tableutils.py'
raw=source.read_bytes();manifest=json.loads((source.parents[2]/'manifest.json').read_bytes())
assert hashlib.sha256(raw).hexdigest()==manifest['source_files_sha256']['boltons/tableutils.py']
work=OUT/'paging-replay'/uuid.uuid4().hex;(work/'boltons').mkdir(parents=True)
(work/'boltons/tableutils.py').write_bytes(raw)
records={}
for arm in ('strict','simple'):
 state=TaskState(work,['boltons/tableutils.py'],implementation_prefix='boltons/',progress_policy={'stagnation_actions':8},
  validation_commands={'issue':'python -B -m unittest discover -s task_checks -v'},
  decision_policy={'mode':'simple_diagnostic_v1' if arm=='simple' else 'evidence_to_edit_v1'})
 results=[]
 for start,end in ((560,600),(520,583),(520,560)):
  value={'source_revision':state.revision,'path':'boltons/tableutils.py','start':start,'end':end,'question':'Exact current method body?'}
  try:
   pages=[]
   while True:
    page=state.decision.evidence(value);pages.append(page)
    if not page.get('next_start'):break
    value=value|{'start':page['next_start']}
   content=''.join(p['content'] for p in pages)
   assert content==''.join(raw.decode().splitlines(keepends=True)[start-1:min(end,583)])
   results.append({'requested':[start,end],'pages':len(pages),'original_bytes_verified':True,'status':'read'})
  except DecisionRejected as e:results.append({'requested':[start,end],'status':'rejected','reason':str(e)})
 records[arm]=results
assert all(r['status']=='rejected' for r in records['strict'])
assert all(r['status']=='read' for r in records['simple'])
result={'same_three_original_invalid_ranges':True,'strict_and_simple':records,'model_calls':0,'no_source_edit':True}
(OUT/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'strict_rejected':3,'simple_exact_paginated':3,'model_calls':0}))
