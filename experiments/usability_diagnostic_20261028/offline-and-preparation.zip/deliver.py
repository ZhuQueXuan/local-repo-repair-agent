"""Outcome-specific report, navigation, immutable archives and upload scan."""
import hashlib,io,json,re,sqlite3,subprocess,sys,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/u68_1028';DEST=ROOT/'experiments/usability_diagnostic_20261028'
def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
a=read(OUT/'audit.json');plan=read(OUT/'fixed-conditions.json');assert a['all_terminal'] and a['slots']==2
findings=read(OUT/'findings.json')
summary=read(Path(plan['regression']));project=next(j for j in summary['jobs'] if j['scope']=='project')
passed=project['tests_run']-project['skipped'];name='68_诊断_严格与简化单Agent操作流程同题比较.md'
resultlines=[]
for r in a['results']:
 checks='；'.join(f"{k} {v['passed']}/{v['tests_run']}" for k,v in r.get('checks',{}).items()) or '无可评分补丁'
 resultlines.append(f"| {r['variant']} | `{r['run_id']}` | {r.get('agent_exit')} | {checks} | {r['attempts']} | {r['elapsed_seconds']} |")
body=f'''# 68：严格与简化操作流程的同题诊断

2026-10-28。用户认可67后的方案：保持正确性标准，先做可用性诊断，不加题。基线 `{plan['base']}`，{len(plan['inputs'])}输入先冻结，已有boltons表格题两个adaptive_history单Agent身份各一次。无文档、任务卡、独立审查、Skills/MCP或检索差异；这不是完整多Agent收益比较。全部终态后才执行保留评分，无选优或按结果重跑。

本次实际结果：严格组正常Submitted且公开3/3、保留5/5、登记上游3/3通过；简化组未提交，公开2/3、保留5/5、上游3/3，最后ProviderUnavailable。该结果没有支持“只要放宽流程便更好”，也不能凭一对运行证明严格规则是成功原因。旧67的3次失败保持，不能回填成成功。

## 为什么做这一轮

67中关键代码曾完整出现在模型请求里，仍只读不改；随后明确决策下Click确实改了代码但破坏兼容，Table仅打印修改JSON，换成真实工具后又三次请求非法范围而停止。因此要区分：补丁错误（正确性问题）、工具操作负担（可用性问题）和模型能力；不能看到0通过就一律放宽测试，也不能把程序离线检查通过等同于模型能用好。

## 固定条件和唯一实验范围

| 条件 | strict当前严格组 | simple简化诊断组 |
| --- | --- | --- |
| 任务/公开、保留、上游测试 | 同一旧表格题，同一输入哈希 | 相同，不放宽测试 |
| 模型/路由/输出 | 北邮优先/官方备用，原Flash配置、温度0、2048输出上限 | 相同 |
| 请求/展示/配置时限 | 16KB请求、1024B单回执展示、配置300秒Agent、共享费用守卫 | 相同；实际调用/费用可能不同；请求失败存在时长异常，见后文 |
| 工具 | 8动作停滞后切换成编辑/证据工具 | 开始到结束稳定提供bash、编辑、定位、读取、放弃 |
| 读取 | 原512B拒绝/2次证据配额 | 512B原文分页、next_start/实际文件末行明确，无逐版本2次配额 |
| 停止 | 原3连续非法决定/24无进展动作停止 | 参数错误可改，无此两项提前停止；原总时限/上下文/费用/格式保护保持 |
| 修改/验证/提交 | 模型提供精确修改；实际两项检查，模型真实提交 | 同样实现、检查和提交，不代写或代交 |
| 文件权限/测试保护 | 原有实现范围/测试与任务不可改 | 相同 |

简化组通过仅隔离批次可用的 `--diagnostic-variant simple` 开启，不改默认配置，不用于正式面板或多Agent；默认严格路径保持。该开关同时调整工具稳定性、分页与提前停止，是一个可用性方案整体比较，不是单因素消融。时间上限相同不代表实际token或花费相同；固定严格→简化顺序且只有一次，没有随机化/重复，所以不能声称因果或统计收益。

开源先核对[Mini SWE Agent当前工具解析源码](https://github.com/SWE-agent/mini-swe-agent/blob/main/src/minisweagent/models/utils/actions_toolcall.py)，沿用本地固定2.4.6、已有MIT底座与同一记账/调用链。其简单工具循环适合此次减负；当前公开源码可读但不据此保证未来维护。未引入另一个框架或依赖，沿用已有精确编辑、状态与检查实现，集成成本限制在诊断分支。GitHub的LICENSE无后缀链接本次连接器未取回；许可依据本地保留的上游LICENSE，不从失败结果猜许可。

## 代码与离线验证

`scripts/edit_decision.py`增加明确的简化策略：稳定工具、逐原文页回执、可纠正参数、保留精确写入约束；`scripts/run_task_batch.py`只对该策略提供稳定API工具集且不触发3拒绝停止；`scripts/task_service_worker.py`增加隔离CLI入口/说明，保持默认策略；`scripts/task_state.py`显示无逐版本配额。原 `scripts/test_collaboration_runtime.py`只加1项端到端回归：3错误仍可恢复、多页无漏重、真实错改→两项失败→定位→正确修改→两项通过→显式提交。离线回复是脚本，不是模型成绩。

首次139检查有1个冻结错误：测试尚运行时我修改了状态显示字段，五阶段流程正确拒绝变化；原失败日志保留。停止改源码后139项定向全通过，新的集中项目回归{passed}通过/1原权限跳过。上游原样301与适配169/6旧失败/1跳过是67已逐名核对的历史结果，此次不重跑也不冒称新成绩；未改上游或底层执行环境。

另对67末次三份真实非法参数（560—600、520—583、520—560）做固定原源码重放：严格组三份均拒绝，简化组三份均分页提供请求与实际文件交集、逐原始内容无漏重。只读重放模型调用0，没有给模型提供修补答案，不能称其纠错成功。

## 两次真实结果

| 组别 | 身份 | Agent终态 | 独立检查 | 平台尝试 | worker秒数 |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(resultlines)}

严格组：正常提交 {a['arms']['strict']['normal_submissions']}/1、独立补丁 {a['arms']['strict']['resolved']}/1。简化组：正常提交 {a['arms']['simple']['normal_submissions']}/1、独立补丁 {a['arms']['simple']['resolved']}/1。实际编辑、证据、拒绝及检查次数见manifest每个身份；时间采用worker实际总时长，不含排队或事后评分。最终总结只依据这两个身份，不能用旧不同配置运行充当对照。

严格组32个工具动作，实际6次编辑；过程中7次决定拒绝、9次有效证据（分散在多个源码版本，每版本仍有原配额），没有连续三拒绝终止，最终查看一次diff再独立提交。说明当前严格流程这一次确实能改错后继续修，不应把以前失败解释成它必然无法使用。

简化组150个工具动作，149个bash、1个repair_edit，未调用repair_need_evidence或repair_locate。首次修改后公开2/3，上游相关检查通过，随后反复sed/grep，没有第二次修改。例如同一公开失败方法搜索9次、一段源码读取8次。独立评分余项是短表头不能丢掉数据的公开用例；保留项通过不能抵消公开失败。新分页接口虽然可用，但本次真实模型未选择，不能宣称已验证它帮助模型理解源码。

时间与归因限制必须保留：两组配置都是300秒，严格worker约70秒；简化worker约1515秒，末次官方API返回500/连接失败。简化模型已记录消息跨度约207秒、相邻已完成消息最大间隔约2.951秒，最后失败不产生正常模型回复；多出的长等待没有可核实的单一原因（可能与连接等待或宿主暂停有关），不能断言是正常推理耗时、超时停止或故意给简化组更多预算。本轮耗时不可作公平效率比较，也不能推断若无连接失败它必定失败；截至已记录150个动作它仍只改过一次、公开失败未解决的事实保持。

另有实现局限：简化组实际取消了24动作停滞停止，但原ExecutionProgress的通用停滞提示仍保留“24动作停止”的文字；它可能增加提示冲突，因此该方案还不是彻底清理提示后的最简底座。原提示/源码全部保留，本轮不在运行后改条件追成功。这也是不能把单对差异归因于某条规则或模型能力的原因。简化组仍为隔离诊断开关，不提升默认。

本批共{a['platform_attempts']}平台尝试，已知价格部分估算{a['known_price_estimate_cny']:.6f}元、未知占位{a['unknown_placeholder_cny']:.2f}元，完整费用未知；无余额探测。原53正式payload、4230共享请求及8463旧成果文件逐项保持，新增后{a['shared_requests_after']}请求。没有新题、面板重启、医疗、异机或追加身份。

下一步：保持正确性门槛和当前默认，承认严格组已在这一道已用题取得真实闭环；先离线聚焦“首次修改失败后，为何反复读而不提出第二次修订”，同时清理诊断组提示冲突和核查请求超时边界。可只对确切重复输出做有界纠正，保留有新信息的读取；不能一律恢复任意读取，也不应再靠不断收紧字节/次数求成功。本批关闭，不扩题或继续付费，原多Agent效果仍未得到证明。

## 证据

`experiments/usability_diagnostic_20261028/manifest.json`含全部终态、费用和保护审计；`two-runs.zip`保存冻结输入、原轨迹和本机执行原文；`offline-and-preparation.zip`保存各轮检查、驱动/审计脚本及源码补丁。内外层SHA256核对，递归扫描两套真实密钥和常见令牌；不打包完整正式数据库/共享账本。旧46—67结果及负成绩不覆盖。
'''
(ROOT/'Project'/name).write_text(body,encoding='utf-8')
nav=(f"2026-10-28最新：[68严格与简化流程诊断]({name})：保持测试，用同一旧表格题两单Agent比较严格/简化流程；稳定工具/原文分页/可纠错为隔离开关，不改默认。139定向及项目{passed}通过/1原跳过，首次运行中改源码冻结错误留证。{len(plan['inputs'])}输入先冻结，各1次：严格提交{a['arms']['strict']['normal_submissions']}/1、补丁{a['arms']['strict']['resolved']}/1；简化提交{a['arms']['simple']['normal_submissions']}/1、补丁{a['arms']['simple']['resolved']}/1。{a['platform_attempts']}尝试已知{a['known_price_estimate_cny']:.6f}元/未知占位{a['unknown_placeholder_cny']:.2f}，完整费用未知。53正式payload/原4230请求/8463旧文件保持，现{a['shared_requests_after']}；旧成绩不改，不作单因素或稳定率结论，无追加题/重跑/面板重启/医疗。")
def insert(path,text):
 value=path.read_text('utf-8');assert '[68严格与简化流程诊断]' not in value
 first,rest=value.split('\n',1);path.write_text(first+'\n\n'+text+'\n'+rest,encoding='utf-8')
insert(ROOT/'README.md',nav.replace('](','](Project/'))
insert(ROOT/'Project/00_项目现状与快速接手.md',nav)
p=ROOT/'AGENTS.md';text=p.read_text('utf-8');assert '[68严格与简化流程诊断]' not in text
p.write_text(text.replace('## 当前阶段\n','## 当前阶段\n\n- '+nav.replace('](','](Project/')+'\n',1),encoding='utf-8')
insert(ROOT.parent/'job/AGENTS.md',nav.replace('](','](../shixi_project/Project/'))
insert(ROOT/'Project/项目开发流水账.md',f"我把正确性检查和操作约束分开，保留全部测试，为同一旧表格题做严格/简化两个单Agent各一次诊断。简化组稳定工具、原文分页并容许参数纠错，仍受原时限/上下文/费用/文件保护约束。139定向及项目{passed}通过/1原跳过后冻结运行，严格提交{a['arms']['strict']['normal_submissions']}/1、补丁{a['arms']['strict']['resolved']}/1；简化提交{a['arms']['simple']['normal_submissions']}/1、补丁{a['arms']['simple']['resolved']}/1。两次好坏都保留，不改旧成绩；这是整体可用性诊断，不能归因单个规则或称稳定收益。[68严格与简化流程诊断]({name})。")
# Keep exact raw state/output files too, which live outside store/runs.
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
 global scanned
 scanned+=1;assert depth<=7 and not any(k in raw for k in keys),'Credential detected; value withheld'
 assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(z.read(n),depth+1)
assert not DEST.exists();DEST.mkdir();outer={};counts={}
def pack(name,entries):
 members={}
 with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p,n in entries:
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock' or p.name.endswith(('-wal','-shm')):continue
   assert not p.name.startswith('.env') and n not in members
   raw=p.read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
 with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
 write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
 for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
entries=[(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.rglob('*')) if p.is_file()]
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows=[json.loads(v) for v, in db.execute('SELECT payload FROM runs')]
for row in rows:
 work=Path(row['workspace']);assert work.resolve().is_relative_to((ROOT/'temp').resolve())
 for folder in ('temp/task-state','temp/tool-output'):
  entries.extend((p,'local-execution/'+row['id']+'/'+p.relative_to(work).as_posix()) for p in sorted((work/folder).rglob('*')) if p.is_file())
pack('two-runs.zip',entries)
(OUT/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','scripts'],cwd=ROOT))
entries=[(p,p.name) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.log','.patch'}
 and p.name not in {'formal-before.json','ledger-before.json','ledger-after.json','history-before.json','commit-inventory.json'}]
folder=Path(plan['regression']).parent
entries.extend((p,'regression/'+p.relative_to(folder).as_posix()) for p in sorted(folder.rglob('*')) if p.is_file()
 and p.suffix in {'.log','.json','.xml'} and p.name not in {'protected_before.json','protected_after.json'})
pack('offline-and-preparation.zip',entries)
write(DEST/'manifest.json',dict(a,archive_members=counts,credential_scan={'keys_checked':2,'objects_including_nested':scanned,'matches':0},formal_database_and_whole_shared_ledger_uploaded=False))
outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan_objects':scanned,'matches':0,'document':name}))
