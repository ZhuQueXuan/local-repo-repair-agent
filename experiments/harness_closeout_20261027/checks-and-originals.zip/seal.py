import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_closeout_20261027'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Do not overwrite sealed evidence'
reports={name:json.loads((OUT/(name+'.json')).read_bytes()) for name in ['panel-check','scope-check','http-check','live-resources','protection-check']}
assert reports['panel-check']['previous_fast_response_availability_failure_reproduced']
assert reports['panel-check']['previous_task_card_pause_stale_reproduced']
assert reports['panel-check']['fast_and_normal_load_order_passed'] and reports['scope-check']['acceptance_layers']==5
assert reports['http-check']['new_task_rows']==0 and reports['live-resources']['service_restarted'] is False
before={}
for name,source in [('README.before.md','README.md'),('task_panel.before.html','scripts/task_panel.html'),('checkpoint_panel.before.js','scripts/checkpoint_panel.js')]:
    raw=(OUT/name).read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+source],cwd=ROOT),name
    before[name]=sha(raw)
old=ROOT/'experiments/harness_models_20261027';old_hashes=json.loads((old/'artifact_sha256.json').read_bytes())
assert all(sha((old/name).read_bytes())==value for name,value in old_hashes.items())
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(keys)==2
DEST.mkdir();outer={};counts={};scanned=0
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p,label in entries:
            if not p.is_file() or p.name in {'.env','server.lock','worker.lock'} or '__pycache__' in p.parts:continue
            raw=p.read_bytes();assert not any(k in raw for k in keys),'Credential scan rejected archive'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(k))==v for k,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes());outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
    counts[name]=len(members)
documents=[ROOT/'README.md',ROOT/'GITHUB_SETUP.md',ROOT/'AGENTS.md',ROOT/'Project/00_项目现状与快速接手.md',
    ROOT/'Project/项目开发流水账.md',ROOT/'Project/42_过程_统一使用入口与整体验收范围.md',ROOT.parent/'job/AGENTS.md']
pack('source-and-documents.zip',[(ROOT/name,name) for name in ['scripts/task_panel.html','scripts/checkpoint_panel.js','configs/final_acceptance_scope_v1.json']]+
    [(p,p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else 'job/AGENTS.md') for p in documents])
pack('checks-and-originals.zip',[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.rglob('*'))])
result={**reports['protection-check'],'scope':'Consolidated use and scope-only acceptance preparation with two frontend wiring fixes; not full regression, real-model or browser acceptance.',
    'reports':reports,'original_files_verified_against_base_commit':before,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'old_model_delivery_files_verified':len(old_hashes),'archive_member_counts':counts,'credential_scan':{'keys_checked':2,'files_scanned':scanned,'matches':0},
    'new_formal_test_files':0,'full_regression_run':False,'real_model_acceptance_run':False,'browser_clicks_verified':False,'environment_probes_started':0,
    'pending':['Consolidated current-code engineering regression and adapter differences','Real original-route integrated acceptance after explicit final scope',
        'Browser clicks','Fresh-machine setup','Terminal retained scoring and comparison batch gate','New same-task original-baseline versus full-workflow comparison','New-vendor live transport']}
write(DEST/'verification.json',result);outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'original_files_verified':len(before),'old_model_delivery_files_verified':len(old_hashes),
    'protected_files':result['protected_old_files_hash_verified'],'formal_rows':result['formal_payloads_unchanged'],'ledger_requests':result['shared_ledger_requests']},ensure_ascii=False))
