const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Element{
  constructor(tag='div'){this.tag=tag;this.children=[];this.style={};this.dataset={};this.listeners={};this._value='';this.checked=false;this.disabled=false;this.hidden=false;this.textContent=''}
  get value(){return this._value}
  set value(v){this._value=String(v)}
  get options(){return this.children}
  get childNodes(){return this.children}
  append(...items){this.children.push(...items);if(this.tag==='select'&&!this._value&&this.children.length)this._value=this.children[0].value}
  replaceChildren(...items){this.children=[];if(this.tag==='select')this._value='';this.append(...items)}
  addEventListener(type,fn){(this.listeners[type]??=[]).push(fn)}
  emit(type){this['on'+type]?.({target:this});for(const fn of this.listeners[type]||[])fn({target:this})}
  remove(){this.removed=true}
}
const profiles=JSON.parse(fs.readFileSync('configs/model_profiles_v1.json','utf8'));
const tasks=[{id:'click-custom-command',task_id:'click-fixture',scope:'fixture'},{id:'barrel-sort',task_id:'sort-fixture',scope:'fixture'},{id:'split-after-boundary',task_id:'split-fixture',scope:'fixture'}];
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function load(html,fast,oldScripts=false){
  const elements={};
  for(const match of html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){
    const el=new Element(match[1]);el.disabled=/\bdisabled(?:\s|>|$)/.test(match[2]);el.hidden=/\bhidden(?:\s|>|$)/.test(match[2]);el.checked=/\bchecked(?:\s|>|$)/.test(match[2]);elements[match[3]]=el;
  }
  for(const match of html.matchAll(/<select\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/select>/g)){
    const el=elements[match[1]];
    for(const opt of match[2].matchAll(/<option\b[^>]*\bvalue="([^"]+)"[^>]*>/g)){const o=new Element('option');o.value=opt[1];el.append(o)}
  }
  const listeners={},requests=[],storage=new Map();
  const context={document:{getElementById:id=>{assert(elements[id],'Missing DOM id '+id);return elements[id]},createElement:tag=>new Element(tag)},
    window:{addEventListener:(type,fn,options)=>{assert(type==='DOMContentLoaded');listeners[type]={fn,options}}},
    sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
    setInterval:()=>1,clearInterval:()=>{},crypto:{randomUUID:()=> 'fake-id-not-dispatched'},
    fetch:async(path,options)=>{
      requests.push({path,method:options?.method||'GET'});
      assert(!options?.method,'Page bootstrap must not POST');
      let data;
      if(path==='/api/catalog')data={tasks,profiles:{raw:'原版适配',adaptive_history:'上下文与任务状态',retrieval_on_change:'检索'},collaboration_available:true};
      else if(path==='/api/model-profiles')data=profiles;
      else if(path==='/api/runs')data=[];
      else throw Error('Unexpected bootstrap request '+path);
      return {ok:true,json:async()=>data};
    }};
  vm.createContext(context);
  const scripts=[...html.matchAll(/<script(?: src="([^"]+)")?>([\s\S]*?)<\/script>/g)];
  for(const part of scripts){
    const aliases={'/collaboration-panel.js':'collaboration_panel.js','/task-card-panel.js':'task_card_panel.js','/checkpoint-panel.js':'checkpoint_panel.js',
      '/capability-panel.js':'capability_panel.js','/execution-panel.js':'execution_panel.js','/model-profile-panel.js':'model_profile_panel.js'};
    const source=part[1]?fs.readFileSync(oldScripts&&part[1]==='/checkpoint-panel.js'?'temp/harness_closeout_20261027/checkpoint_panel.before.js':'scripts/'+aliases[part[1]],'utf8'):part[2];
    vm.runInContext(source,context,{filename:part[1]||'inline-panel.js'});
    if(fast)await tick();
  }
  await tick();
  const before=requests.filter(r=>r.path==='/api/catalog').length;
  if(listeners.DOMContentLoaded){assert(listeners.DOMContentLoaded.options.once===true);await listeners.DOMContentLoaded.fn();await tick()}
  await tick();
  return {elements,context,requests,before};
}
function exercise(result){
  const e=result.elements,c=result.context;
  assert(e.mode.value==='replay'&&e.collaborationMode.value==='single');
  assert(!e.taskCardEnabled.checked&&!e.allowPause.checked&&!e.allowCapabilities.checked);
  assert(e.collaborationMode.disabled&&e.allowPause.disabled&&e.allowCapabilities.disabled&&e.modelProfile.disabled);
  e.mode.value='live';e.mode.emit('change');assert(!e.collaborationMode.disabled,'Collaboration availability lost during startup');
  e.collaborationMode.value='document_review';e.collaborationMode.emit('change');
  assert(e.profile.value==='adaptive_history'&&!e.documentQuestionBox.hidden&&!e.allowCapabilities.disabled);
  assert(e.allowPause.disabled);e.taskCardEnabled.checked=true;e.taskCardEnabled.emit('change');assert(!e.allowPause.disabled);
  e.allowPause.checked=true;e.allowCapabilities.checked=true;
  e.collaborationMode.value='single';e.collaborationMode.emit('change');assert(!e.allowPause.checked&&!e.allowCapabilities.checked);
  assert(e.documentQuestionBox.hidden&&e.allowPause.disabled&&e.allowCapabilities.disabled);
  e.mode.value='replay';e.mode.emit('change');assert(c.taskCardCreation()===undefined&&c.modelProfileCreation()===undefined);
  assert(e.task.options.length===2&&e.modelProfile.disabled);
  c.display({id:'old-history',kind:'history',task:'split-after-boundary',profile:'raw',status:'finished',stage:'historical',repair_result:'unknown',metrics:{},artifacts:{}});
  assert(e.modelProfileRunState.textContent.includes('不补造')&&e.capabilityRunState.hidden);
  assert(result.requests.every(r=>r.method==='GET')&&result.requests.every(r=>!r.path.includes('inspect')));
}
(async()=>{
  const oldHtml=fs.readFileSync('temp/harness_closeout_20261027/task_panel.before.html','utf8');
  const old=await load(oldHtml,true,true);
  old.elements.mode.value='live';old.elements.mode.emit('change');
  assert(old.before===1&&old.elements.collaborationMode.disabled,'Expected deterministic old fast-response startup failure');
  const oldNormal=await load(oldHtml,false,true);
  oldNormal.elements.mode.value='live';oldNormal.elements.mode.emit('change');
  oldNormal.elements.collaborationMode.value='document_review';oldNormal.elements.collaborationMode.emit('change');
  oldNormal.elements.taskCardEnabled.checked=true;oldNormal.elements.taskCardEnabled.emit('change');
  assert(oldNormal.elements.allowPause.disabled,'Expected original task-card pause stale state');
  const html=fs.readFileSync('scripts/task_panel.html','utf8');
  for(const fast of [true,false]){const result=await load(html,fast);assert(result.before===0);exercise(result)}
  const report={scope:'Combined actual page scripts in Node fake DOM, not browser clicks',
    previous_fast_response_availability_failure_reproduced:true,previous_task_card_pause_stale_reproduced:true,bootstrap_waits_for_all_scripts:true,fast_and_normal_load_order_passed:true,
    offline_defaults:true,live_three_role_switch:true,pause_requires_card:true,unsupported_options_cleared:true,
    replay_omits_live_features:true,history_no_false_profile:true,no_tasks_models_or_environment_probes_started:true};
  fs.writeFileSync('temp/harness_closeout_20261027/panel-check.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
})().catch(error=>{console.error(error);process.exitCode=1});
