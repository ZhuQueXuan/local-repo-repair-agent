import json
import os
from pathlib import Path
import re
import sys
import threading
import urllib.request
from http.server import ThreadingHTTPServer
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',PYTHONDONTWRITEBYTECODE='1',LITELLM_LOCAL_MODEL_COST_MAP='True')
from collaboration_store import CollaborationStore
from task_service import make_handler
store=CollaborationStore(OUT/'http-store')
server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(store,'offline-closeout',0))
server.RequestHandlerClass=make_handler(store,'offline-closeout',server.server_port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base='http://127.0.0.1:'+str(server.server_port)
def get(path,raw=False):
    req=urllib.request.Request(base+path,headers={'X-Task-Token':'offline-closeout','Origin':base})
    with urllib.request.urlopen(req,timeout=5) as response:
        data=response.read();return data if raw else json.loads(data)
try:
    with patch('litellm.completion',side_effect=AssertionError('No model dispatch')),patch('execution_runtime.LocalProcessBackend.run_argv',side_effect=AssertionError('No version process')):
        html=get('/',raw=True).decode();assert "window.addEventListener('DOMContentLoaded'" in html
        assets=re.findall(r'<script src="([^"]+)"',html)
        assert len(assets)==6
        for asset in assets:assert get(asset,raw=True)
        assert b"$('taskCardEnabled').addEventListener('change',checkpointChoices)" in get('/checkpoint-panel.js',raw=True)
        assert get('/api/model-profiles')['profiles'][1]['status']=='offline_only'
        assert get('/api/execution-environment')['probe_performed'] is False
        assert get('/api/runs')==[] and store.list()==[]
finally:server.shutdown();server.server_close();thread.join(timeout=2)
report={'scope':'Temporary HTTP without supervisor/worker; no task POSTs or browser clicks','assets_verified':assets,
    'new_task_rows':0,'external_model_calls':0,'environment_probes_started':0,'browser_clicks_verified':False}
(OUT/'http-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report))
