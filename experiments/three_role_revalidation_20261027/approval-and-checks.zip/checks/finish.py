"""Record one failed real acceptance and its later offline-only projection fix."""
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');before=read(OUT/'ledger-before.json');after=read(OUT/'ledger-after.json')
audit=read(OUT/'batch/audit.json');result=read(OUT/'batch/result.json')
assert result['run_id']=='76a7df56932a44dda6c3af637b5c8e1d' and result['resolved'] is False and result['status']=='failed'
assert audit['input_hashes_verified']==452 and audit['new_parent_runs']==1 and audit['extra_selection_reruns']==0
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert read(ROOT/'data/deepseek_budget.json')==after
assert len(before['requests'])==2402 and len(after['requests'])==2408
assert all(after['requests'][k]==v for k,v in before['requests'].items())
invalidated=[n for n,h in plan['input_files_sha256'].items() if sha(ROOT/n)!=h]
assert set(invalidated)=={'scripts/document_model.py','scripts/test_document_context.py'},invalidated
history=read(OUT/'historical-before.json');assert all(sha(ROOT/n)==h for n,h in history.items())
old=read(OUT/'before-projection.json');new=read(OUT/'after-projection.json')
assert old['api_bytes']==18402 and new['api_bytes']==16333 and old['raw_messages_sha256']==new['raw_messages_sha256']
assert new['original_system_and_task_preserved'] and new['human_card_present_once'] and new['latest_tool_receipts_preserved']
log=(OUT/'document-tests-final.txt').read_text(encoding='utf-8-sig');assert 'Ran 44 tests in ' in log and log.rstrip().endswith('OK')
check={'formal_payloads_unchanged':53,'old_requests_unchanged':2402,'shared_requests_after':2408,'new_attempts':6,
       'input_hashes_verified_at_live_terminal':452,'old_freeze_invalidated_by_later_offline_fix':invalidated,
       'historical_artifacts_unchanged':len(history),'new_parent_runs':1,'extra_selection_reruns':0,
       'offline_followup_model_calls':0,'offline_checks_passed':44,'historical_files_sha256':history}
(OUT/'protection-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
name='53_验收_完整三角色失败与文档上下文补修.md'
body='用户具体批准后唯一76a7完整三角色真实验收失败：文档10合法动作找到相关资料，但交接前API视图18402>16384停止，修复/审查未开始，无候选，not_completed；本轮文档问题明确为Click默认值/帮助文字，非单因素对照。6尝试已知估算0.063684元/未知占位0.10，完整费用未知；正式53payload/原2402请求保持，现2408，56旧实验文件保持，452输入在真实终态核验保持。后续离线缩减文档历史可选索引，同记录/原任务/哈希核对任务卡/最新双回执保持，API16333，原16KB及费用/权限不改，新增1必要回归/原相关44项通过；非新模型成功，旧冻结2源码失效保留。无追加付费/面板重启/医疗/异机操作，51补丁通过与旧失败/比较不回填。后续先集中离线核对文档收口及上下文，避免逐次付费试错。'
def edit(p,marker,text):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';old=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in old and name not in old
    p.write_bytes(old.replace(marker,marker+'\n'+text+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[53真实失败与文档上下文补修](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[53真实失败与文档上下文补修]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**完整三角色真实失败，文档索引离线补修（2026-10-27）。** '+body+' 见[53]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [53完整三角色真实验收](Project/'+name+')在文档交接前触发长度保护，修复/审查未开始，仍未完整通过。后续仅离线补修历史索引，原记录18402→16333字节、44项相关检查通过，未追加模型重跑；51的已知Click补丁通过结果保持。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[53真实失败与文档上下文补修](../shixi_project/Project/'+name+')：'+body)
print(json.dumps({k:v for k,v in check.items() if k!='historical_files_sha256'}))
