"""Pure API-view replay. No query, worker, store mutation or transport."""
import ast,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_model import ProtectedDocumentModel
from minisweagent.models.litellm_model import LitellmModelConfig
from context_budget import message_bytes
from collaboration_protocol import canonical_bytes,sha256
from task_cards import encoded
home=OUT/'batch/store/runs/76a7df56932a44dda6c3af637b5c8e1d'
messages=json.loads((home/'consulting-trajectory.json').read_bytes())['messages']
card=json.loads((home/'task-card.json').read_bytes());last=card['all_inputs'][-1]
tree=ast.parse((ROOT/'scripts/task_cards.py').read_text(encoding='utf-8'))
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='begin_input')
scope=next(ast.literal_eval(v) for n in ast.walk(function) if isinstance(n,ast.Dict)
    for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value=='scope')
payload={'task_card_input_id':last['id'],'task_card_revision':last['revision'],'task_card_sha256':card['sha256'],
         'human_task_card':card['card'],'scope':scope}
receipt={'role':'user','content':encoded(payload).decode()}
assert sha256(encoded(receipt))==last['sha256'],'Must reconstruct the exact undispatched human card'
model=ProtectedDocumentModel.__new__(ProtectedDocumentModel)
model.config=LitellmModelConfig(model_name='deepseek/deepseek-flash')
model._task_card_receipt={'message':receipt}
raw=canonical_bytes(messages)
prepared=model._prepare_messages_for_api(messages)
assert canonical_bytes(messages)==raw
result={'raw_messages_sha256':sha256(raw),'raw_bytes':message_bytes(messages),'api_bytes':message_bytes(prepared),
        'hard_limit':16384,'original_system_and_task_preserved':prepared[:2]==messages[:2],
        'human_card_present_once':sum(m==receipt for m in prepared)==1,'latest_tool_receipts_preserved':prepared[-3:-1]==[{k:v for k,v in m.items() if k!='extra'} for m in messages[-2:]],
        'raw_history_preserved':True,'projection_events':getattr(model,'document_projection_events',[]),'model_calls':0}
mode=sys.argv[1] if len(sys.argv)>1 else 'before'
assert mode in {'before','after'}
if mode=='before':assert result['api_bytes']==18402
else:
    assert result['api_bytes']<=16384 and result['original_system_and_task_preserved'] and result['human_card_present_once'] and result['latest_tool_receipts_preserved']
p=OUT/(mode+'-projection.json');assert not p.exists();p.write_bytes(canonical_bytes(result))
print(json.dumps({k:v for k,v in result.items() if k!='projection_events'}))
