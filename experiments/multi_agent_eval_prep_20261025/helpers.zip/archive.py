from pathlib import Path
import json,shutil,sqlite3,sys,zipfile
r=Path.cwd();t=r/'temp/multi_agent_eval_prep_20261025';out=r/'experiments/multi_agent_eval_prep_20261025'
sys.path.insert(0,str(r/'scripts'))
from collaboration_protocol import canonical_bytes,sha256
from evaluation_preparation import DEFAULT_PACKET,verify_packet
before=json.loads((t/'before.json').read_bytes())
assert all(sha256((r/p).read_bytes())==h for p,h in before.items()),'Existing runtime/config/data changed'
assert (r/'data/deepseek_budget.json').read_bytes()==(t/'ledger-before.json').read_bytes()
with sqlite3.connect('file:'+str(r/'data/task_service/runs.sqlite3')+'?mode=ro',uri=True) as db:
 rows=dict(db.execute('SELECT id,payload FROM runs'));assert rows==json.loads((t/'production-before-rows.json').read_bytes())
 assert len(rows)==45 and db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 with sqlite3.connect(t/'production-after.sqlite3') as target:db.backup(target)
packet=verify_packet();plan=json.loads((DEFAULT_PACKET/'plan.json').read_bytes())
reg=r/'temp/regression/20261025_164628_6c53a7bc';adapter=r/'temp/regression/20261025_164631_828a6cd5'
summary=json.loads((reg/'summary.json').read_bytes());assert not summary['changed_protected_files'] and all(v['exit_code']==0 for v in summary['jobs'])
comparison=json.loads((t/'adapter-comparison.json').read_bytes());assert comparison['same_failed_nodeids']
qualification=json.loads((t/'last-qualification.json').read_bytes());assert all(v['qualified'] for v in qualification['results'])
old={}
for name in ('self_review_20261025','adjudication_panel_20261024','multi_agent_response_recheck_live_20261024'):
 base=r/'experiments'/name;hashes=json.loads((base/'artifact_sha256.json').read_bytes())
 assert all(sha256((base/p).read_bytes())==h for p,h in hashes.items()),name
 old[name]=len(hashes)
result={'scope':'Offline new-public-problem input preparation, not a live batch or Agent performance result.',
 'packet':packet,'qualified_tasks':6,'public_methods_reference_passed':12,'withheld_methods_reference_passed':19,
 'upstream_subsets':'No failures; Requests has one pre-existing skip. Repeated subsets are not independent unique tests.',
 'existing_runtime_config_data_unchanged':len(before),'original_payloads_identical':45,'production_database_bytes_identical':True,
 'ledger_identical':True,'actual_model_calls':0,'new_formal_runs':0,'old_archives_verified':old,
 'regression':{'upstream_native':301,'project_run':360,'project_passed':359,'project_skipped':1},'adapter':comparison['counts']}
(t/'verification.json').write_bytes(canonical_bytes(result));out.mkdir(exist_ok=True)
for p in t.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.sqlite3'}:shutil.copy2(p,out/p.name)
shutil.copy2(r/'data/deepseek_budget.json',out/'ledger-after.json')
def pack(name,paths,base):
 hashes={}
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as bundle:
  for p in paths:
   if p.is_file():
    rel=p.relative_to(base).as_posix();data=p.read_bytes();bundle.writestr(rel,data);hashes[rel]=sha256(data)
 (out/(name+'.sha256.json')).write_bytes(canonical_bytes(hashes))
 return len(hashes)
packet_count=pack('packet.zip',(p for p in DEFAULT_PACKET.rglob('*') if 'temp' not in p.relative_to(DEFAULT_PACKET).parts),r)
frozen=json.loads((DEFAULT_PACKET/'freeze.json').read_bytes())['files_sha256']
pack('preparation-code-and-policies.zip',(r/p for p in frozen if not p.startswith(DEFAULT_PACKET.relative_to(r).as_posix()+'/')),r)
pack('qualification.zip',Path(qualification['path']).rglob('*'),Path(qualification['path']))
pack('development-qualification.zip',(p for n in ('qualification-46430447','qualification-8421805a') for p in (t/n).rglob('*')),t)
pack('snapshot-blocker-probe.zip',(p for d in t.glob('snapshot-probe-*') for p in d.rglob('*')),t)
pack('regression.zip',reg.rglob('*'),reg);pack('adapter.zip',adapter.rglob('*'),adapter)
pack('helpers.zip',t.glob('*.py'),t)
docs=[r/p for p in ('AGENTS.md','README.md','tasks/README.md','Project/00_项目现状与快速接手.md','Project/项目开发流水账.md','Project/31_过程_多Agent新题筛选与离线冻结准备.md')]
pack('documentation.zip',docs,r)
with zipfile.ZipFile(out/'documentation.zip','a',zipfile.ZIP_DEFLATED) as bundle:bundle.write(r.parent/'job/AGENTS.md','job/AGENTS.md')
with zipfile.ZipFile(out/'documentation.zip') as bundle:(out/'documentation.zip.sha256.json').write_bytes(canonical_bytes({n:sha256(bundle.read(n)) for n in bundle.namelist()}))
(out/'README.json').write_bytes(canonical_bytes({'scope':result['scope'],'packet_files':packet_count,'task_count':6,'planned_slots':15,
 'readiness':'Not launchable. Common initial prompt, binary snapshots, terminal-only withheld grading and serial batch lifecycle still require integration.',
 'credentials':'No .env included; current credential bytes scanned in outer files and ZIP members.',
 'reproduce':'Restore packet.zip plus preparation-code-and-policies.zip to a project copy; verify 751 frozen inputs. Qualifier uses trusted source copies; dependencies/versions are in regression.zip.',
 'production':'45 original payloads and database/ledger bytes identical; original eight API catalog tasks (nine task directories) retained.'}))
from dotenv import dotenv_values
private=[v.encode() for k,v in dotenv_values(r/'.env',interpolate=False).items() if 'KEY' in k and v]
for p in out.iterdir():
 if not p.is_file():continue
 assert not any(key in p.read_bytes() for key in private),'Credential in archive'
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as bundle:assert all(not any(key in bundle.read(n) for key in private) for n in bundle.namelist()),'Credential in ZIP'
hashes={p.relative_to(out).as_posix():sha256(p.read_bytes()) for p in out.rglob('*') if p.is_file() and p!=out/'artifact_sha256.json'}
(out/'artifact_sha256.json').write_bytes(canonical_bytes(hashes));assert all(sha256((out/p).read_bytes())==h for p,h in hashes.items())
print(json.dumps(result|{'archived_files':len(hashes),'packet_zip_files':packet_count},ensure_ascii=False))
