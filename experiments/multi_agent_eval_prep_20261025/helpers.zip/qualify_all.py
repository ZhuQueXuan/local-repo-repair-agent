from pathlib import Path
import concurrent.futures,json,sys,traceback,uuid
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from evaluation_preparation import qualify,DEFAULT_PACKET
from collaboration_protocol import canonical_bytes
t=r/'temp/multi_agent_eval_prep_20261025';output=t/('qualification-'+uuid.uuid4().hex[:8]);output.mkdir()
tasks=[v['task'] for v in json.loads((DEFAULT_PACKET/'plan.json').read_bytes())['tasks']]
def one(task):
 try:
  result=qualify(DEFAULT_PACKET,task,output/task)
  return {'task':task,'qualified':True,'output':result['output'],
    'counts':{label:{part:{k:result[label][part][k] for k in ('tests_run','passed','successful')} for part in ('public','withheld','upstream')} for label in ('baseline','reference')}}
 except Exception as e:
  (output/(task+'-failure.txt')).write_text(traceback.format_exc(),encoding='utf-8')
  return {'task':task,'qualified':False,'error':str(e),'output':str(output/task)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(one,tasks))
(output/'qualification-summary.json').write_bytes(canonical_bytes(results))
(t/'last-qualification.json').write_bytes(canonical_bytes({'path':str(output),'results':results}))
for row in results: print(json.dumps(row,ensure_ascii=False))
assert all(v['qualified'] for v in results),'Candidate qualification incomplete; preserve failures, do not freeze launch claims'
