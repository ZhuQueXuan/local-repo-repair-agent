from pathlib import Path
from copy import deepcopy
import json,sys,shutil
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from task_workspace import load_task
from collaboration_protocol import canonical_bytes,sha256
packet=r/'evaluation/multi_agent_20261025'
assert not packet.exists(),'Never overwrite a prepared packet'
packet.mkdir(parents=True);(packet/'temp').mkdir()

def checks(source):return ('import unittest\n'+source+'\n').encode('utf-8')
cases=[
dict(task='boltons-addlist-iterator',base='barrel-sort',repo='mahmoud/boltons',splus=True,source='https://github.com/mahmoud/boltons/pull/458',
issue='OrderedMultiDict.addlist loses values from one-shot iterables and can leave an empty iterator as a ghost key. Accept an iterator as well as a reusable sequence; preserve existing values, order and mapping invariants. QueryParamDict must obey the same iterable contract. Do not change tests or introduce a new API.',
targets=['tests/test_dictutils.py','tests/test_urlutils.py'],
public='''from boltons.dictutils import OrderedMultiDict
class PublicCases(unittest.TestCase):
 def test_generator_values(self):
  d=OrderedMultiDict();d.addlist('a',(x for x in [1,2]));self.assertEqual(d.getlist('a'),[1,2]);self.assertEqual(d['a'],2)
 def test_reusable_list(self):
  d=OrderedMultiDict([('a',0)]);d.addlist('a',[1,2]);self.assertEqual(d.items(multi=True),[('a',0),('a',1),('a',2)])
''',
private='''from boltons.dictutils import OrderedMultiDict
from boltons.urlutils import QueryParamDict
class WithheldCases(unittest.TestCase):
 def test_empty_iterator_does_not_create_key(self):
  for cls in (OrderedMultiDict,QueryParamDict):
   with self.subTest(cls=cls.__name__):
    d=cls();d.addlist('a',iter([]));self.assertEqual(len(d),0);self.assertNotIn('a',d);self.assertEqual(d.keys(),[])
 def test_existing_key_and_falsey_values(self):
  for cls in (OrderedMultiDict,QueryParamDict):
   with self.subTest(cls=cls.__name__):
    d=cls([('a','old')]);d.addlist('a',iter([0,False,None]));self.assertEqual(d.getlist('a'),['old',0,False,None]);self.assertEqual(len(d.items(multi=True)),4)
 def test_query_parameter_generator(self):
  d=QueryParamDict();d.addlist('k',(x for x in ['a','b']));self.assertEqual(d.getlist('k'),['a','b']);self.assertEqual(d.to_text(),'k=a&k=b')
''', edits=[{'path':p,'old':'        if not v:\n            return\n        self_insert = self._insert','new':'        v = list(v)\n        if not v:\n            return\n        self_insert = self._insert','expected_occurrences':1} for p in ('boltons/dictutils.py','boltons/urlutils.py')]),
dict(task='click-abort-cause',base='click-custom-command',repo='pallets/click',splus=False,source='https://github.com/pallets/click/issues/2379',
issue='When standalone_mode=False, a command callback raising EOFError or KeyboardInterrupt is converted to click.Abort but the original cause is suppressed. Preserve the original exception as an inspectable chained cause, including subclasses. Keep the normal standalone Aborted message/exit status and unrelated exceptions unchanged.',
targets=['tests/test_basic.py'],
public='''import click
class PublicCases(unittest.TestCase):
 def test_eof_cause(self):
  original=EOFError('diagnostic')
  @click.command()
  def cli():raise original
  with self.assertRaises(click.Abort) as caught:cli.main([],standalone_mode=False)
  self.assertIs(caught.exception.__cause__,original)
 def test_normal_callback(self):
  @click.command()
  def cli():return 7
  self.assertEqual(cli.main([],standalone_mode=False),7)
''',
private='''import click
from click.testing import CliRunner
import asyncio
class WithheldCases(unittest.TestCase):
 def test_interrupt_and_eof_subclass(self):
  for original in (KeyboardInterrupt('stop'),asyncio.IncompleteReadError(b'part',9)):
   with self.subTest(kind=type(original).__name__):
    @click.command()
    def cli():raise original
    with self.assertRaises(click.Abort) as caught:cli.main([],standalone_mode=False)
    self.assertIs(caught.exception.__cause__,original)
 def test_standalone_exit_remains(self):
  @click.command()
  def cli():raise EOFError('details')
  result=CliRunner().invoke(cli,[]);self.assertEqual(result.exit_code,1);self.assertIn('Aborted!',result.output);self.assertNotIn('Traceback',result.output)
 def test_unrelated_error_not_wrapped(self):
  original=ValueError('other')
  @click.command()
  def cli():raise original
  with self.assertRaises(ValueError) as caught:cli.main([],standalone_mode=False)
  self.assertIs(caught.exception,original)
''',edits=[{'path':'src/click/core.py','old':'except (EOFError, KeyboardInterrupt):','new':'except (EOFError, KeyboardInterrupt) as e:','expected_occurrences':1},{'path':'src/click/core.py','old':'raise Abort() from None','new':'raise Abort() from e','expected_occurrences':1}]),
dict(task='requests-utf8-length',base='requests-json-pickle',repo='psf/requests',splus=True,source='https://github.com/psf/requests/pull/6589',
issue='With urllib3 2.x, string request bodies are sent as UTF-8 bytes, but Content-Length can count Unicode code points. Compute the byte length consistently for non-ASCII string bodies. Preserve ASCII and bytes behavior, and existing handling of seekable byte streams. This environment uses urllib3 2.x; no real network is needed for reproduction.',
targets=['tests/test_utils.py','tests/test_structures.py','tests/test_hooks.py'],
public='''from requests import Request
from requests.utils import super_len
class PublicCases(unittest.TestCase):
 def test_emoji_prepared_length(self):
  body='😀';p=Request('POST','https://example.invalid/',data=body).prepare();self.assertEqual(int(p.headers['Content-Length']),len(body.encode('utf-8')))
 def test_ascii_unchanged(self):self.assertEqual(super_len('plain'),5)
''',
private='''from requests import Request
from requests.utils import super_len
from io import BytesIO
class WithheldCases(unittest.TestCase):
 def test_multilingual_direct_lengths(self):
  for body in ('é','中文','e\\u0301','a😀中'):
   with self.subTest(body=body):self.assertEqual(super_len(body),len(body.encode('utf-8')))
 def test_prepared_lengths_match_bytes(self):
  for body in ('é中','😀😀'):
   with self.subTest(body=body):
    p=Request('PUT','https://example.invalid/',data=body).prepare();self.assertEqual(int(p.headers['Content-Length']),len(body.encode('utf-8')))
 def test_raw_bytes_and_stream_position(self):
  raw='é中'.encode('utf-8');self.assertEqual(super_len(raw),len(raw));s=BytesIO(raw);s.seek(1);self.assertEqual(super_len(s),len(raw)-1)
''',edits=[{'path':'requests/utils.py','old':'    total_length = None\n    current_position = 0\n','new':"    from urllib3 import __version__ as urllib3_version\n    if isinstance(o, str) and not urllib3_version.startswith('1.'):\n        o = o.encode('utf-8')\n    total_length = None\n    current_position = 0\n",'expected_occurrences':1}]),
dict(task='boltons-query-encoding',base='barrel-sort',repo='mahmoud/boltons',splus=False,source='https://github.com/mahmoud/boltons/pull/455',
issue='parse_qsl accepts an encoding argument, but percent-encoded non-UTF-8 query components are decoded incorrectly. Honor the caller-selected encoding for keys and values. Preserve default UTF-8, plus-to-space conversion, blank-value options and query ordering.',
targets=['tests/test_urlutils.py'],
public='''from boltons.urlutils import parse_qsl
class PublicCases(unittest.TestCase):
 def test_latin_value(self):self.assertEqual(parse_qsl('k=%E9',encoding='latin-1'),[('k','é')])
 def test_default_utf8(self):self.assertEqual(parse_qsl('k=%C3%A9'),[('k','é')])
''',
private='''from boltons.urlutils import parse_qsl
class WithheldCases(unittest.TestCase):
 def test_non_ascii_keys_and_values(self):self.assertEqual(parse_qsl('%E9=%F1',encoding='latin-1'),[('é','ñ')])
 def test_plus_and_order(self):self.assertEqual(parse_qsl('a+b=%E9&x=%F1',encoding='latin-1'),[('a b','é'),('x','ñ')])
 def test_blank_options(self):
  self.assertEqual(parse_qsl('%E9=&x=%F1',encoding='latin-1'),[('é',None),('x','ñ')]);self.assertEqual(parse_qsl('%E9=&x=%F1',keep_blank_values=False,encoding='latin-1'),[('x','ñ')])
''',edits=[{'path':'boltons/urlutils.py','old':"unquote(key.replace('+', ' '))",'new':"unquote(key.replace('+', ' '), encoding=encoding)",'expected_occurrences':1}, {'path':'boltons/urlutils.py','old':"unquote(value.replace('+', ' '))",'new':"unquote(value.replace('+', ' '), encoding=encoding)",'expected_occurrences':1}]),
dict(task='click-flag-default-map',base='click-custom-command',repo='pallets/click',splus=True,source='https://github.com/pallets/click/issues/2632',
issue='A dual boolean flag with show_default=True uses default_map at execution time, but its help can still display the declared opposite flag as the default. Make help reflect the effective default selected by the context. Preserve explicit true/false defaults, aliases and nested command context defaults.',
targets=['tests/test_defaults.py','tests/test_options.py'],
public='''import click
from click.testing import CliRunner
class PublicCases(unittest.TestCase):
 def test_context_true_help(self):
  @click.command(context_settings={'default_map':{'long':True}})
  @click.option('--long/--short',default=False,show_default=True)
  def cli(long):pass
  r=CliRunner().invoke(cli,['--help']);self.assertEqual(r.exit_code,0);self.assertIn('[default: long]',r.output)
 def test_no_override(self):
  @click.command()
  @click.option('--long/--short',default=True,show_default=True)
  def cli(long):pass
  self.assertIn('[default: long]',CliRunner().invoke(cli,['--help']).output)
''',
private='''import click
from click.testing import CliRunner
class WithheldCases(unittest.TestCase):
 def test_context_false_overrides_declared_true(self):
  @click.command(context_settings={'default_map':{'long':False}})
  @click.option('--long/--short','-l/-s',default=True,show_default=True)
  def cli(long):click.echo(str(long))
  r=CliRunner();self.assertIn('[default: short]',r.invoke(cli,['--help']).output);self.assertEqual(r.invoke(cli,[]).output.strip(),'False')
 def test_nested_context(self):
  @click.group(context_settings={'default_map':{'sub':{'enabled':True}}})
  def root():pass
  @root.command()
  @click.option('--enabled/--disabled',default=False,show_default=True)
  def sub(enabled):pass
  self.assertIn('[default: enabled]',CliRunner().invoke(root,['sub','--help']).output)
 def test_declared_false_remains(self):
  @click.command()
  @click.option('--enabled/--disabled',default=False,show_default=True)
  def cli(enabled):pass
  self.assertIn('[default: disabled]',CliRunner().invoke(cli,['--help']).output)
''',edits=[{'path':'src/click/core.py','old':'(self.opts if self.default else self.secondary_opts)[0]','new':'(self.opts if default_value else self.secondary_opts)[0]','expected_occurrences':1}]),
dict(task='boltons-unicode-lines',base='barrel-sort',repo='mahmoud/boltons',splus=False,source='https://github.com/mahmoud/boltons/pull/475',
issue='iter_splitlines corrupts ordinary text containing a space followed by 28 or 29 and fails to recognize the Unicode line/paragraph separators. Recognize actual Unicode separators while keeping normal dates intact. Preserve mixed ordinary line endings, empty input and indent behavior.',
targets=['tests/test_strutils.py'],
public='''from boltons.strutils import iter_splitlines
class PublicCases(unittest.TestCase):
 def test_ordinary_date(self):self.assertEqual(list(iter_splitlines('February 28, 2026')),['February 28, 2026'])
 def test_line_separator(self):self.assertEqual(list(iter_splitlines('a\\u2028b')),['a','b'])
''',
private='''from boltons.strutils import iter_splitlines,indent
class WithheldCases(unittest.TestCase):
 def test_paragraph_and_boundary_separators(self):self.assertEqual(list(iter_splitlines('\\u2029a\\u2028')),['','a',''])
 def test_dates_and_mixed_lines(self):self.assertEqual(list(iter_splitlines('March 29\\r\\nnext\\u2029last')),['March 29','next','last'])
 def test_indent_uses_real_line_boundaries(self):self.assertEqual(indent('Feb 28\\u2028next','  '),'  Feb 28\\n  next')
 def test_empty(self):self.assertEqual(list(iter_splitlines('')),[])
''',edits=[{'path':'boltons/strutils.py','old':r'\x2028|\x2029','new':r'\u2028|\u2029','expected_occurrences':1}])
]
plan_tasks=[];slots=[]
for index,row in enumerate(cases):
 base,original=load_task(row['base']);dest=packet/'public'/row['task'];(dest/'repo').mkdir(parents=True)
 for relative in original['source_files_sha256']:
  target=dest/'repo'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/'repo'/relative,target)
 (dest/'checks').mkdir();(dest/'checks/test_behavior.py').write_bytes(checks(row['public']))
 (dest/'issue.md').write_text('# '+row['task']+'\n\n'+row['issue']+'\n',encoding='utf-8')
 manifest={k:deepcopy(original[k]) for k in ('repository_url','base_tag','base_commit','archive_sha256','package','source_prefix','import_root','pytest_plugins') if k in original}
 manifest.update(task_id=row['task'],scope='new_public_issue_preparation_only',problem_url=row['source'],upstream_runner='pytest',upstream_target=row['targets'],full_target=row['targets'],source_files_sha256=original['source_files_sha256'],
  agent_test_command=('PYTHONPATH=src ' if original.get('import_root')=='src' else '')+'python -B -m pytest '+' '.join(row['targets'])+' -q -p no:cacheprovider',agent_issue_command='python -B -m unittest discover -s task_checks -v',
  task_files_sha256={p:sha256((dest/p).read_bytes()) for p in ('issue.md','checks/test_behavior.py')})
 (dest/'manifest.json').write_bytes(canonical_bytes(manifest))
 auth=packet/'evaluator'/row['task'];auth.mkdir(parents=True)
 (auth/'test_behavior.py').write_bytes(checks(row['private']))
 (auth/'reference.json').write_bytes(canonical_bytes({'scope':'Developer-reviewed minimal reference adapted to this frozen baseline; never model input.', 'source':row['source'],'edits':row['edits']}))
 shutil.copyfile(r/'temp/multi_agent_eval_prep_20261025'/(row['task']+'-source.json'),auth/'source.json')
 license_files=[n for n in manifest['source_files_sha256'] if n.upper().startswith('LICENSE')];assert license_files
 plan_tasks.append({'task':row['task'],'repository':row['repo'],'problem_url':row['source'],'base_commit':manifest['base_commit'],'splus_selected':row['splus'],'previous_task_source':row['base'],'license_files':license_files})
 order=(["D","S"] if index%2==0 else ["S","D"])
 if row['splus']:order.insert(index%3,'Splus')
 for variant in order:slots.append({'identity':'multi_agent_eval_proposal_20261025_'+row['task']+'_'+variant+'_r1','task':row['task'],'variant':variant,'repetition':1})
plan={'schema_version':1,'state':'offline_prepared_not_launchable','paid_launch_authorized':False,'scope':'Six public issues not previously assigned for local strategy development; repos/base versions are familiar. No training-contamination guarantee or SWE-bench claim.',
 'selection_rule':'Selected from official issue/changelog evidence before any model result. Six candidates remain regardless of later model success. Three S+ tasks selected in advance, one per repository.',
 'tasks':plan_tasks,'slots':slots,'base_profile':'adaptive_history','s_initial_seconds':300,'d_and_splus_phase_seconds':{'repairing':300,'reviewing':120,'revising':180,'final_review':90},'parent_seconds':1800,
 'limits':'No request/step/global-cost cap reintroduced. Existing hard guards and shared accounting persist. Actual usage reported, not assumed equal.',
 'feedback':'Only original issue, source, upstream subset and public checks to every group. Withheld results only after terminal candidate selection; no feedback or repair from them.',
 'abnormal':'Keep every predeclared identity. Transport/grade faults incomparable, not model failure; no retry or winner selection. Any new retry rule requires a new manifest, original results retained.',
 'adjudication':'Unmapped findings unresolved. Accepted/rejected/approve are not truth. Exact trusted version-bound checks/mappings only; already disclosed failures are not new discoveries.',
 'launch_blockers':['S/D initial prompt templates currently differ; require common first-phase runner before launch','Existing check_task exposes only public checks; terminal-only withheld evaluation and all artifact projections must be integrated and verified','Add serial predeclared-slot claims, cancellation, complete-cost/result collection and immutable runtime freeze before launch','S+ currently has scripted local integration evidence only; real provider behavior remains unverified'],
 'prior_local_tasks':sorted(p.name for p in (r/'tasks').iterdir() if p.is_dir() and (p/'manifest.json').exists()),'security_boundary':'Withheld from copied workspaces/review snapshots/prompts only. Repair Bash is not an OS sandbox; no confidentiality guarantee against intentional parent access.'}
(packet/'plan.json').write_bytes(canonical_bytes(plan))
print('Prepared six tasks / three repos / fifteen provisional slots; no live entry point or launch authorization.')
