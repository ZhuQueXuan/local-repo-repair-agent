from pathlib import Path
import json,sys
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from collaboration_protocol import canonical_bytes,sha256
from evaluation_preparation import DEFAULT_PACKET,verify_packet
p=DEFAULT_PACKET
assert not (p/'freeze.json').exists(),'Do not replace an existing freeze'
paths=[x for x in p.rglob('*') if x.is_file() and 'temp' not in x.relative_to(p).parts]
paths += [r/'scripts'/n for n in ('evaluation_preparation.py','test_evaluation_preparation.py','evaluation_freeze.py','check_task.py','task_workspace.py','collaboration_protocol.py','review_tools.py','collaboration_panel.py','task_service_store.py')]
paths += [r/'configs'/n for n in ('multi_agent_v1.json','self_review_v1.json','provider_priority.json','retrieval_delivery_trial_20261015.json')]
(p/'freeze.json').write_bytes(canonical_bytes({'version':1,'scope':'Offline input preparation only; runtime launch blockers remain. Not a paid/live launch authorization.',
 'files_sha256':{x.relative_to(r).as_posix():sha256(x.read_bytes()) for x in sorted(paths)}}))
print(json.dumps(verify_packet(),ensure_ascii=False))
