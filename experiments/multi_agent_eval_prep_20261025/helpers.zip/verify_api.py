import json,re,urllib.request
from pathlib import Path
t=Path('temp/multi_agent_eval_prep_20261025');base='http://127.0.0.1:8765'
with urllib.request.urlopen(base+'/',timeout=10) as response:html=response.read().decode()
token=re.search(r"const token='([^']+)'",html).group(1)
def get(route):
 with urllib.request.urlopen(urllib.request.Request(base+route,headers={'X-Task-Token':token,'Origin':base}),timeout=15) as response:return json.load(response)
rows=get('/api/runs');old=json.loads((t/'production-before-rows.json').read_bytes())
assert {r['id']:r for r in rows}=={k:json.loads(v) for k,v in old.items()}
catalog=get('/api/catalog');assert len(catalog['tasks'])==8
assert not any(v['id'] in {'boltons-addlist-iterator','click-abort-cause','requests-utf8-length','boltons-query-encoding','click-flag-default-map','boltons-unicode-lines'} for v in catalog['tasks'])
value={'original_payloads_unchanged':len(rows),'catalog_still_original_tasks':len(catalog['tasks']),'preparation_tasks_launchable_from_panel':False,'new_model_runs':0}
(t/'api-verification.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
print(json.dumps(value))
