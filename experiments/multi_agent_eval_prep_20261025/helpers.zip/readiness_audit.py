from pathlib import Path
import json,sys,uuid
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from evaluation_preparation import DEFAULT_PACKET,public_manifest,copy_public,verify_packet
from collaboration_protocol import canonical_bytes,sha256
from collaboration_panel import checked_bytes
from review_tools import seal_candidate
p=DEFAULT_PACKET;t=r/'temp/multi_agent_eval_prep_20261025';plan=json.loads((p/'plan.json').read_bytes())
binaries={}
for row in plan['tasks']:
 base,m=public_manifest(p,row['task']);found=[]
 for name in m['source_files_sha256']:
  try:checked_bytes(base/'repo',name).decode('utf-8')
  except UnicodeDecodeError:found.append(name)
 binaries[row['task']]=found
probe=t/('snapshot-probe-'+uuid.uuid4().hex[:8]);repo=probe/'repo'
manifest=copy_public(p,'click-abort-cause',repo);base=p/'public/click-abort-cause'
try:
 seal_candidate(manifest,base/'repo',repo,(base/'issue.md').read_bytes(),probe/'snapshot',run_id='preparation-only',producer_role_run_id='fixture')
except UnicodeDecodeError as error:
 snapshot={'status':'blocked','exception':type(error).__name__,'scope':'Actual existing seal_candidate on the public Click baseline copy; no model or record changes.'}
else:raise AssertionError('Binary snapshot limitation unexpectedly changed; re-review readiness')
single=(r/'scripts/task_service_worker.py').read_text(encoding='utf-8')
dual=(r/'scripts/collaboration_live.py').read_text(encoding='utf-8')
assert 'You are a helpful software engineering assistant. Use exactly one bash tool call per response.' in single
assert 'You are a software repairer. Use exactly one bash tool per response.' in dual
result={'public_repo_binary_paths':binaries,'binary_snapshot_probe':snapshot,'initial_prompt_match':False,
 'initial_systems':{'S':'You are a helpful software engineering assistant. Use exactly one bash tool call per response.',
                    'D_Splus':'You are a software repairer. Use exactly one bash tool per response.'},
 'evidence_sha256':{name:sha256((r/name).read_bytes()) for name in ('scripts/task_service_worker.py','scripts/collaboration_live.py','scripts/check_task.py','scripts/review_tools.py')},
 'existing_task_directories':len(list((r/'tasks').glob('*/manifest.json'))),'existing_catalog_task_count':8,'preparation_only':verify_packet(p),'models_called':0}
(t/'readiness-audit.json').write_bytes(canonical_bytes(result))
print(json.dumps({'packet_tasks':6,'existing_task_directories':result['existing_task_directories'],'existing_catalog_task_count':8,'snapshot':snapshot,'launchable':False},ensure_ascii=False))
