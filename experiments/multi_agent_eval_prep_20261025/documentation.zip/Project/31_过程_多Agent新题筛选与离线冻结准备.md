# 多Agent新题筛选与离线冻结准备

日期：2026-10-25。承接[21比较规则](21_规划_RAG与多Agent协作深化.md)、[27未完成项](27_调研_多Agent主流模式对照与未完成项.md)及[30的S+离线分支](30_过程_同一Agent分阶段自查与离线验收.md)。用户要求继续后，本轮准备新题、评分分层和比较槽位，不启动新的付费任务。

## 完成了什么

已实际准备来自3个熟悉公开仓库的6道不同问题：固定原始版本、许可证和需求，编写12个可见检查方法及19个开发侧保留检查方法，逐题执行原版失败/人工参考修复通过的核验，预声明15个比较槽位，冻结751份输入。新增工具可复核包哈希、构造只含公开材料的工作副本、核验参考适配和检查结果。

这是**离线输入准备包**，状态为offline_prepared_not_launchable、paid_launch_authorized=false；没有run_id、真实模型成绩或费用。正式运行还需统一首修提示、支持二进制素材的快照、终态保留评分和受控批次入口。没有把“输入已经准备好”写成“完整实验已经能安全启动”。

主产物：[evaluation/multi_agent_20261025/README.md](../evaluation/multi_agent_20261025/README.md)、[plan.json](../evaluation/multi_agent_20261025/plan.json)、[freeze.json](../evaluation/multi_agent_20261025/freeze.json)。不放在Job，不混进原任务目录或正式面板。

## 选题、来源与新题口径

先读9个既有任务目录、历史用途表和21/27/30，再查官方仓库问题/PR和发布记录；最终六题在任何模型结果出现之前选定，资格核验失败只修检查/参考适配，不按某组模型成功率换题。源码复用已有冻结版本，复制方法和核验过程，未整仓改变旧任务或注入人工缺陷。各自保留原LICENSE。

| 任务 | 官方证据 | 基线 | 关注点 | 预选S+ |
| --- | --- | --- | --- | --- |
| boltons-addlist-iterator | [PR458](https://github.com/mahmoud/boltons/pull/458) | boltons25.0.0，c23dbdad | 单次迭代器、空输入、不变量和URL容器的另一份实现 | 是 |
| click-abort-cause | [Issue2379](https://github.com/pallets/click/issues/2379)、[修复PR2380](https://github.com/pallets/click/pull/2380) | Click8.1.3，9c6f4c8e | 异常链、子类及原正常退出行为 | 否 |
| requests-utf8-length | [PR6589](https://github.com/psf/requests/pull/6589)、[2.32.0发布说明](https://github.com/psf/requests/blob/v2.32.4/HISTORY.md) | Requests2.31.0，147c8511；urllib3 2.8.0 | Unicode字符与UTF-8字节数、准备请求及字节流兼容 | 是 |
| boltons-query-encoding | [PR455](https://github.com/mahmoud/boltons/pull/455) | boltons25.0.0 | 查询串的键/值编码、空值、顺序与默认行为 | 否 |
| click-flag-default-map | [Issue2632](https://github.com/pallets/click/issues/2632) | Click8.1.3 | help和运行时默认值的一致性、父子上下文 | 是 |
| boltons-unicode-lines | [PR475](https://github.com/mahmoud/boltons/pull/475) | boltons25.0.0 | 真实Unicode分隔符、普通日期及indent调用链 | 否 |

“新题”仅指未作为本项目先前的策略调试任务，**不是新仓库、训练未见或私有题**。三个库都熟悉，旧任务曾涉及其中一些相同模块；不能据此声称全新仓库泛化。开发者知道公开参考修复是正常出题过程，但后续不能再用这些题调提示/策略后仍称独立新题。模型是否在训练中见过公开问题无法保证。

## 公开反馈、保留评价与参考实现

public/<task>/内只有原始repo、重新表述的需求、公开checks和清单。evaluator/<task>/保存额外检查、只供开发者做红/绿核验的参考文字适配和官方来源留证；不复制到工作副本。公开issue不附参考补丁，也不直接复制原讨论中的解决代码。参考适配是针对冻结旧版本的最小开发者实现，不能当成Agent产物。

每题保留检查仍依据同一需求，覆盖没有直接体现在公开样例中的变体，例如URL参数容器的一次性迭代器、空生成器、被包装异常的子类、反向默认值和嵌套上下文、编码后的键以及多种Unicode组合。后续各组必须拿到相同可见输入；保留评分仅在最终候选选定且所有模型阶段停止后运行，不据它追加修复或选优。当前正式check_task尚未接这条终态路径，本包没有提前伪造接入。

“保留”是**输入分发边界**，不是OS隔离：本机修复Bash仍能在权限允许时访问父目录，不能保证面对恶意任务时保密。正式接线需校验workspace、快照、prompt、报告、归档投影都不携带保留内容/参考答案；不将一次不复制文件的检查夸大成安全沙箱。

## 工具与可验证完成标准

新增[scripts/evaluation_preparation.py](../scripts/evaluation_preparation.py)和[13项测试](../scripts/test_evaluation_preparation.py)，未修改既有运行源码/策略或上游源码。

| 入口 | 实际行为 |
| --- | --- |
| validate_plan | 校验6题/至少3库/15个唯一槽位、每题S/D及预选3题S+一次，拒绝把计划标为ready或授权付费 |
| public_manifest/copy_public | 校验原始源码和公开文件摘要；只按白名单复制repo、TASK.md和公开task_checks，保留二进制字节，不复制manifest、保留检查或参考实现 |
| apply_reference | 仅允许已登记实现路径上的精确文字适配；不执行参考描述中的shell命令，拒绝改测试和不匹配旧版本 |
| qualify/child/check_qualification | 在两个全新temp副本分别运行原版/参考的公开、保留和相关上游子集；确认原版确实失败、参考确实通过，测试/需求/原件保持。记录模型调用0 |
| verify_packet | 检查751输入及包成员覆盖；不允许冻结漏掉保留材料、不登记的文件混进公开包，冻结后输入被改则在子进程执行前拒绝 |

源码清单含真实图片，二进制按已有checked_bytes安全读字节，不假装可UTF-8解码。开发者资格检查的Python子进程不继承API凭据，禁用网络连接/DNS；pytest子进程另装禁网挂钩，测试实际验证该挂钩生效。可信检查可导入包，不等于在任意不可信源码上提供OS沙箱。

```powershell
# 仅校验准备包：输出launchable=false，不调用模型
.venv\Scripts\python.exe -B scripts/evaluation_preparation.py --verify
# 在新temp副本核验一题的原版/参考；也没有模型调用
.venv\Scripts\python.exe -B scripts/evaluation_preparation.py --qualify boltons-addlist-iterator
```

没有--run或创建模型/任务的入口。若输入已冻结，qualify前后均验哈希。freeze.json整体摘要为d4f3de8c308ac4dc1e4ab211d06e5985656b9be88372966d50257bd1dc5a23fb；它固定的是准备输入，不包含完整可启动的运行代码/身份门控。后续接线必须另做运行级冻结，保留本快照。

## 资格核验的实际结果

最终输出temp/multi_agent_eval_prep_20261025/qualification-dd499c5a/。下表为独立测试方法数，保留方法中含subTest变体；不把subTest数量重复算通过率。

| 任务 | 原版公开通过 | 原版保留通过 | 参考公开/保留通过 | 相关上游子集：原版与参考 |
| --- | --- | --- | --- | --- |
| addlist迭代器 | 1/2 | 0/3 | 2/2、3/3 | 各151通过 |
| Click异常链 | 1/2 | 2/3 | 2/2、3/3 | 各56通过 |
| RequestsUTF-8长度 | 1/2 | 1/3 | 2/2、3/3 | 各237通过/1跳过，共238 |
| 查询串编码 | 1/2 | 0/3 | 2/2、3/3 | 各124通过 |
| Click默认标志 | 1/2 | 1/3 | 2/2、3/3 | 各116通过 |
| Unicode换行 | 0/2 | 1/4 | 2/2、4/4 | 各14通过 |

共12个公开、19个保留方法在参考版本通过；六题原版均在两类检查中至少复现一个失败。上游无失败，Requests跳过项是tests.test_utils.TestSuperLen.test_io_streams[None-Test]，原版与参考相同。部分上游文件跨题复用，不能将各行相加当成独立、唯一测试数量，也未运行三个库的全部测试。

这些是**出题/参考适配的程序结果，不是S/D/S+成绩**。首次检查因隔离Python缺少项目模块路径而无法启动；补路径后，Click参考适配漏掉except绑定导致UnboundLocalError，其他5题合格。补齐后六题均合格，没有换题。前置检查还纠正了不存在的旧版测试文件名、indent的字符串margin和保留尾部空行的预期；都在冻结前修正，日志/副本保留，未改Agent策略或真实模型成绩。

## 预声明15槽位与仍缺的运行条件

每题S/D各一次，共12槽位；提前指定addlist、Requests长度、Click默认标志各一条S+，各代表一个库。S/D首后顺序交错，S+位置轮换，完整顺序和稳定计划身份见plan.json。没有正式run_id或账本票据。基础策略固定adaptive_history、初修300秒，D/S+阶段300/120/180/90秒，父期限1800秒；不恢复请求总数、步数或全项目费用上限，实际消耗不保证相等。

现在不能启动比较，具体缺口已经核实：

1. **首修模板未对齐。** 现单Agent worker使用“helpful software engineering assistant”等模板，D/S+使用“software repairer”及另一份任务模板，不能悄悄当成相同基线。需共用一个实验初修入口，默认产品策略保持。
2. **二进制快照仍不支持。** 在Click实际准备副本调用现seal_candidate，遇原PNG素材真实抛UnicodeDecodeError。新准备工具能原样保存图片，不代表旧审查内核已能绑定不可读二进制对象；需补版本化绑定/只读索引边界。
3. **保留评分未接终态门控。** 现check_task仅做公开反馈，需正式登记保留检查、终态执行与成绩投影，防止结果/参考进入任何活跃模型阶段。
4. **批次生命周期未接。** 需串行槽位认领、取消、费用/版本汇总、异常incomparable、身份不可覆盖和完整运行级冻结。缺基础设施时保留结果，不只重跑失败一组或挑选优胜重试。
5. **S+仍无真实模型接入证据。** 脚本化四阶段不代表目标平台对长历史/跨工具阶段的实际表现；不能预写真实通过。

真实新增发现仍需精确、可信、版本绑定的独立复现；未映射意见记未知，已公开失败不计新增，approve/accepted不代替真值。后续第三文档Agent按这些比较结果的实际缺口决定，本轮不增角色、不恢复RAG或扩语言。

## 回归、原数据与交付

新增13/13检查通过（4.817秒），包含真实算术红/绿、pytest禁网、公开投影、二进制原样复制、路径/参考权限、冻结私有项遗漏、篡改前阻止子进程、不能伪标ready等。最终统一回归temp/regression/20261025_164628_6c53a7bc/退出0：上游原样301通过、41取消选择、0保护违规；本项目360项运行，359通过、1文件symlink权限跳过（264.210秒）；受保护文件零变化。

适配temp/regression/20261025_164631_828a6cd5/为169通过、6失败、1跳过，0保护违规/文件变化，失败nodeid与30的160635批次逐项相同，未当作通过。

本轮**2766份既有运行源码/配置/数据文件保持，正式45条payload、数据库和共享账本字节保持，0模型请求/0新正式身份**。面板已恢复，只读API确认仍为原8个可启动任务；本地任务目录9个，旧windowed-empty不符合现catalog合同，不能把目录数当面板数。六题保留在evaluation准备区，不进入面板。此前30/29/28成果哈希重新核对，未覆盖旧成绩。本轮没有浏览器点击验收新页面，因为未改页面；API恢复核验和准备CLI实际执行完成。

已更新00、流水账、README及两处协作地图。正式留证experiments/multi_agent_eval_prep_20261025/，包含完整准备包和依赖代码快照、最终/开发失败资格副本、原账/库前后、快照缺口复现、定向/统一/适配日志及API核验，按哈希封存。temp不是唯一备份，没有批量或递归删除。

下一步先离线补齐统一初修入口、二进制快照与终态评分/批次合同，通过边界验收后做新的可启动冻结；再安排明确的真实S/D/S+批次。本准备包不自动授权付费运行，也不能单凭参考答案通过率证明多Agent有收益。
