"""Read-only end audit of all eight fixed slots. No models, score selection or reruns."""
from collections import Counter
from decimal import Decimal
import hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c65_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
import comparison_batch as b
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(HOME/'plan.json');assert all(sha(ROOT/n)==h for n,h in plan['inputs'].items());slots=read(HOME/'slots.json');report=read(HOME/'comparison-summary.json')
assert len(slots)==report['slots']==len(report['results'])==2
assert len({s['run_id'] for s in slots})==2
claimed=len(list(HOME.glob('*.claimed')))
assert claimed==2 or (HOME/'billing-stop.json').exists() and claimed<2
assert [(s['task'],s['variant']) for s in slots]==[('click-resource-exceptions','improved'),('boltons-table-text','full')]
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows={r['id']:r for v, in db.execute('SELECT payload FROM runs') for r in [json.loads(v)]}
 roles=[json.loads(v) for v, in db.execute('SELECT payload FROM role_runs')]
assert len(rows)==2 and all(r['status'] in {'finished','failed','cancelled','interrupted'} for r in rows.values())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json')
assert len(before['requests'])==4037 and all(after['requests'][k]==v for k,v in before['requests'].items())
assert {k:v for k,v in before.items() if k!='requests'}=={k:v for k,v in after.items() if k!='requests'}
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
history=read(OUT/'history-before.json');assert len(history)==8439 and all(sha(ROOT/n)==h for n,h in history.items())
known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
unknown=[v for v in new.values() if v['status']!='settled'];placeholder=sum((Decimal(v['amount_cny']) for v in unknown),Decimal(0))
arms={v:{'resolved':0,'slots':1,'normal_submissions':0,'attempts':0,'known_price_estimate_cny':0,'unknown_placeholder_cny':0,'elapsed_seconds':0,'elapsed_unknown_runs':0} for v in ('improved','full')}
results=[]
for result in report['results']:
 row=rows[result['run_id']];variant=result['variant'];stat=arms[variant];run=HOME/'store/runs'/row['id']
 usage=result.get('usage',{}) if variant=='full' else result.get('metrics',{})
 attempts=usage.get('attempts',usage.get('requests',0))
 # usage_view intentionally rebuilds only billing fields. Runtime timing lives
 # in the finalized worker metrics, not created->ended (which includes queue).
 elapsed=row.get('metrics',{}).get('total_elapsed_seconds')
 if elapsed is None and row['status']=='cancelled' and not row.get('started'):elapsed=0
 if elapsed is None:stat['elapsed_unknown_runs']+=1
 else:assert isinstance(elapsed,(int,float)) and elapsed>=0
 stat['resolved']+=int(result['resolved']);stat['attempts']+=attempts
 stat['known_price_estimate_cny']+=usage.get('known_price_estimate_cny',0);stat['unknown_placeholder_cny']+=usage.get('unknown_placeholder_cny',0);stat['elapsed_seconds']+=elapsed or 0
 entry={k:result.get(k) for k in ['task','variant','run_id','status','agent_exit','resolved','repair_result','collaboration_result','review_verdict','candidate_selection','patch_sha256','evaluation_error','reason']}
 entry.update(attempts=attempts,known_price_estimate_cny=usage.get('known_price_estimate_cny',0),unknown_placeholder_cny=usage.get('unknown_placeholder_cny',0),elapsed_seconds=elapsed)
 entry['exported_patch_bytes']=(run/'repair.diff').stat().st_size if (run/'repair.diff').exists() else None
 traces={};tools=set()
 for path in sorted(run.glob('*trajectory.json')):
  messages=read(path).get('messages',[]);actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
  commands=[a['command'] for a in actions if isinstance(a.get('command'),str)]
  tools.update(a['tool'] for a in actions if a.get('tool'))
  traces[path.name]={'actions':len(actions),'bash_commands':len(commands),'test_commands':sum('pytest' in c or 'unittest' in c for c in commands),
   'submission_commands':sum('COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' in c for c in commands),
   'repeated_exact_commands':[{'command':c,'count':n} for c,n in Counter(commands).most_common(5) if n>1],
   'repair_control_rejections':sum(m['role']=='tool' and 'Repair execution contract:' in str(m.get('content','')) for m in messages),
   'format_corrections':sum(m.get('extra',{}).get('interrupt_type')=='FormatError' for m in messages)}
 entry['traces']=traces;entry['tools_observed']=sorted(tools)
 if variant!='full':
  summary=read(run/'summary.json') if (run/'summary.json').exists() else {}
  entry['limit_kind']=summary.get('limit_kind');entry['normal_submission']=row.get('agent_exit')=='Submitted'
  stat['normal_submissions']+=int(entry['normal_submission'])
 else:
  entry['roles']=[{k:r.get(k) for k in ['phase','status','reason']} for r in roles if r['run_id']==row['id']]
  entry['normal_repair_submission']=bool(any(r['phase']=='repairing' and r['status']=='succeeded' for r in entry['roles'])
   and traces.get('repairing-trajectory.json',{}).get('submission_commands',0)>0)
  stat['normal_submissions']+=int(entry['normal_repair_submission'])
  entry['complete_three_role']=bool(result['resolved'] and row.get('collaboration_result')=='completed' and row.get('review_verdict')=='approve'
   and all(any(r['phase']==p and r['status']=='succeeded' for r in entry['roles']) for p in ['consulting','repairing','reviewing']))
  docpath=run/'consultation-context.json'
  if docpath.exists():
   doc=read(docpath);entry.update(document_handoff_bytes=docpath.stat().st_size,document_status=doc['advice']['status'],document_citations=len(doc['excerpts']))
  review_path=run/'reviews.json'
  if review_path.exists():
   entry['review_reports']=read(review_path)
  response_path=run/'responses.json'
  if response_path.exists():entry['finding_responses']=read(response_path)
 if 'checks' in result:entry['checks']={k:{n:v[n] for n in ['tests_run','passed','successful']} for k,v in result['checks'].items()}
 if entry['resolved']:assert all(entry['checks'][p]['successful'] for p in ['public','withheld','upstream'])
 results.append(entry)
for stat in arms.values():
 for k in ['known_price_estimate_cny','unknown_placeholder_cny','elapsed_seconds']:stat[k]=round(stat[k],6)
assert sum(v['attempts'] for v in arms.values())==len(new)
assert abs(sum(v['known_price_estimate_cny'] for v in arms.values())-float(known))<0.000003
assert abs(sum(v['unknown_placeholder_cny'] for v in arms.values())-float(placeholder))<0.000003
audit={'stage':65,'source_base_commit':plan['base'],'plan_sha256':sha(HOME/'plan.json'),'frozen_inputs_verified':len(plan['inputs']),
 'slots':2,'all_terminal':True,'selection_reruns':0,'results':results,'arms':arms,'full_complete':sum(r.get('complete_three_role',False) for r in results),
 'platform_attempts':len(new),'known_price_estimate_cny':float(known),'unknown_placeholder_cny':float(placeholder),'complete_cost_estimate_cny':None if unknown else float(known),
 'formal_payloads_unchanged':53,'shared_requests_before':4037,'shared_requests_after':len(after['requests']),'historical_files_unchanged':8439,
 'billing_stop':read(HOME/'billing-stop.json') if (HOME/'billing-stop.json').exists() else None,'balance_probed':False,
 'platform_failures':[{k:v.get('failure',{}).get(k) for k in ['kind','provider','status_code']} for v in new.values() if v.get('failure')],
 'elapsed_scope':'Finalized worker metrics total_elapsed_seconds; preparation through finalization, excluding queued wait and later retained scoring. Not created-to-ended timestamps.',
 'scope':'Two known-task development acceptances, one single Click and one full table. Not a matched comparison, new benchmark, statistical rate or mechanism-causal effect.'}
b.write(OUT/'audit.json',audit);b.write(OUT/'new-request-receipts.json',new);b.write(OUT/'ledger-after.json',after)
print(json.dumps({k:audit[k] for k in ['slots','all_terminal','arms','full_complete','platform_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after']}))
