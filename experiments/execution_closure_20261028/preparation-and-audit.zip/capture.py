import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
assert not (OUT/'baseline.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
history={p.relative_to(ROOT).as_posix():sha(p) for d in ['experiments','evaluation'] for p in (ROOT/d).rglob('*') if p.is_file()}
for name,value in [('formal-before.json',formal),('ledger-before.json',ledger),('history-before.json',history)]:
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
tracked=subprocess.check_output(['git','ls-files','scripts','configs'],cwd=ROOT,text=True).splitlines()
for name in tracked:
 p=OUT/'source-before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
baseline={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'formal_payloads':len(formal),'requests':len(ledger['requests']),'old_files':len(history),'authorization':'先别继续加题了，分析这次反复读取、停滞和上下文超限的原因，把执行闭环修好，先离线验证，再做必要的少量真实验收。直接推进不用逐次问我，好坏结果都保留，旧成绩别改。','live_limit':2,'live_selection':'Two existing stage64 development regressions: Click resource exceptions, improved single; boltons table text, full. One new identity each, no selection reruns. Fixed after offline tests and before requests; never new benchmark scores.'}
(OUT/'baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(baseline,ensure_ascii=False))
