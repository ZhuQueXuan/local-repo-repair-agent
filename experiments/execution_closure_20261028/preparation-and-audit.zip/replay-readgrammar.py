"""Replay stage64 observations without executing old actions or calling models."""
import copy,json,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_state import TaskState
from tool_output_budget import ToolOutputBudget
from run_task_batch import StatefulModel,RecordedModel
from context_budget import ContextBudget,message_bytes
from minisweagent.models.litellm_model import LitellmModelConfig
from task_workspace import load_task

records=json.loads((ROOT/'temp/medium_comparison_20261028/diagnostics.json').read_bytes())
replays=[]; replay_id=uuid.uuid4().hex[:8]
for row in records:
 if row['run_id'] not in ['a6b0eeebc09d492db9d56c23bd2704ff','e38b6339e6e340efb448a1ab97f48aa0','67b49f2ce6da4fbbaa0f6bd97f93024f']:continue
 source,manifest=load_task(row['task'])
 work=OUT/'replay'/replay_id/row['run_id'];work.mkdir(parents=True)
 for n in manifest['source_files_sha256']:
  p=work/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((source/'repo'/n).read_bytes())
 state=TaskState(work,list(manifest['source_files_sha256']),guard_enabled=True)
 budget=ToolOutputBudget(work)
 old=Path(row['work'])
 events=[json.loads(x) for x in (old/'temp/tool-output/events.jsonl').read_text('utf-8').splitlines()]
 blocked=[]; stopped=None
 for index,event in enumerate(events,1):
  command=event['command'];decision=state.before_action(command)
  if decision:
   blocked.append(index)
   if decision['stop']:stopped=index;break
  else:
   output={'output':(old/event['full_output_path']).read_bytes().decode('utf-8'),'returncode':event['returncode'],
       'exception_info':event.get('exception_info','')}
   result=budget.process(output,command=command)
   state.observe(command,output,result['extra']['tool_output'])
 replays.append({'run_id':row['run_id'],'task':row['task'],'old_actions':len(events),'blocked_actions':blocked,
     'first_rejection':blocked[0] if blocked else None,'stop_before':stopped})
assert all(r['first_rejection'] and r['first_rejection']<r['old_actions'] for r in replays),replays

table=next(r for r in records if r['run_id']=='af74fa4d8a104ee5928f73728e2cda86')
raw=json.loads((ROOT/'temp/comparison_batches/c64_1028/store/runs'/table['run_id']/'trajectory.json').read_bytes())
messages=[m for m in raw['messages'] if m['role']!='exit'];before=copy.deepcopy(messages)
oldwork=Path(table['work'])
requests=[json.loads(x) for x in (oldwork/'temp/task-state/requests.jsonl').read_text('utf-8').splitlines()]
state_message=requests[-1]['message']
model=StatefulModel.__new__(StatefulModel)
from types import SimpleNamespace
model.task_state=SimpleNamespace(pinned_message=lambda:copy.deepcopy(state_message))
model.repository_retrieval=None;model.config=LitellmModelConfig(model_name='deepseek/deepseek-flash')
model.budget_config={'max_messages_utf8_bytes':16384}
options=dict(target_bytes=12288,keep_recent_tool_outputs=4,compact_completed_exchanges=True,retained_audit_entries=3,compact_to_target=True)
model.context_budget=ContextBudget(**options);model.context_budget.enable_assistant_archives(OUT/'context-replay'/replay_id)
prepared=RecordedModel._prepare_messages_for_api(model,messages)
legacy=ContextBudget(**options);legacy.enable_assistant_archives(OUT/'legacy-context-replay'/replay_id)
view=legacy.project(messages,prepared,reserved_bytes=message_bytes([state_message])+2)
oldview=view[:2]+[state_message]+view[2:]
newview=model._prepare_messages_for_api(messages)
assert message_bytes(oldview)>16384 and message_bytes(newview)<=16384
assert messages==before and newview[:2]==prepared[:2]
calls=[c['id'] for m in newview for c in m.get('tool_calls',[])]
tools=[m['tool_call_id'] for m in newview if m['role']=='tool']
assert calls==tools
result={'fixed_action_replays':replays,'table_exact_terminal_history':{'old_request_bytes':message_bytes(oldview),
 'new_request_bytes':message_bytes(newview),'hard_limit':16384,'projection':model.context_budget.events,
 'original_task_unchanged':True,'raw_history_unchanged':True,'tool_pairing_valid':True},
 'scope':'No model calls; no old commands executed; no old files or scores changed. Earlier stops and smaller request are offline observations, not successful repairs.'}
(OUT/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'replays':replays,'table_before':message_bytes(oldview),'table_after':message_bytes(newview),'model_calls':0}))
