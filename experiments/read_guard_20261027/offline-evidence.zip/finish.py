"""Protect historical data and seal this offline-only change and its checks."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/read_guard_20261027';assert not DEST.exists()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert (ROOT/'data/deepseek_budget.json').read_bytes()==(OUT/'ledger-before.json').read_bytes()
assert len(read(OUT/'ledger-before.json')['requests'])==2360
history=read(OUT/'history-before.json');assert all(sha((ROOT/n).read_bytes())==h for n,h in history.items())
oldplan=read(ROOT/'temp/click_closure_20261027/plan.json')
invalidated=[n for n,h in oldplan['input_files_sha256'].items() if sha((ROOT/n).read_bytes())!=h]
assert set(invalidated)=={'scripts/task_state.py','scripts/collaboration_live.py','scripts/test_task_state.py','scripts/test_collaboration_runtime.py'},invalidated
checks={}
for name,count in [('task-state-tests.txt',19),('runtime-tests-final.txt',26),('progress-tests.txt',17),('coordinator-tests.txt',14)]:
    text=(OUT/name).read_text(encoding='utf-8-sig');assert re.search(r'Ran '+str(count)+r' tests in ',text) and text.rstrip().endswith('OK'),name
    checks[name]=count
protect={'formal_payloads_unchanged':53,'shared_requests_unchanged':2360,'historical_files_unchanged':len(history),
         'model_calls':0,'new_live_identities':0,'checks_passed':sum(checks.values()),'checks':checks,
         'old_freeze_invalidated_by':invalidated,'historical_files_sha256':history}
write(OUT/'protection-check.json',protect)
name='50_修复_重复读取前缀识别与真实停止原因保留.md'
body='按49原轨迹离线修复目录前缀分号写法漏识别；原68动作读取识别0→45，固定动作重放第21次触发原NoProgress停止，非新模型修复成功。初修/返工的重复读取或接口停止原因不再被空候选覆盖，合法部分候选仍封存，其他完整性错误保持。3个必要回归加入既有文件，任务状态19/接线26/进度17/调度14共76定向通过；最初受限环境2项本机进程失败保留，获准实际Bash重验通过，非全回归。正式53payload/2360请求、40旧实验文件保持，0真实调用/新身份；49冻结4源码变更失效保留不复用。真实Click仍失败、旧比较不回填，不自动付费重跑，无面板重启/医疗/异机操作。'
def edit(p,marker,addition):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';text=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in text and name not in text
    text=text.replace(marker,marker+'\n'+addition+'\n',1)
    p.write_bytes(text.replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[50重复读取补修](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[50重复读取补修]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**重复读取保护补修（2026-10-27）。** '+body+' 见[50]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [50离线补修](Project/'+name+')已修正重复读取的目录前缀识别，以及停止原因被空候选错误覆盖的问题；76项定向检查通过。原Click失败轨迹会在第21个动作处触发已有停止规则，尚无补修后的真实模型成功结果。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[50重复读取补修](../shixi_project/Project/'+name+')：'+body)
patch=subprocess.check_output(['git','diff','--','scripts/task_state.py','scripts/collaboration_live.py','scripts/test_task_state.py','scripts/test_collaboration_runtime.py'],cwd=ROOT)
(OUT/'source-change.patch').write_bytes(patch)
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6
    assert not any(k in raw for k in keys),'Credential found; value withheld'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern found'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();members={}
names=['before-recognition.json','fixed-trace-replay.json','replay.py','finish.py','protection-check.json','source-change.patch',
       'task-state-tests.txt','runtime-tests.txt','runtime-tests-authorized.txt','runtime-tests-final.txt','stop-reason-final.txt','progress-tests.txt','coordinator-tests.txt']
with zipfile.ZipFile(DEST/'offline-evidence.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n in names:
        raw=(OUT/n).read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
with zipfile.ZipFile(DEST/'offline-evidence.zip') as z:assert all(sha(z.read(n))==h for n,h in members.items())
write(DEST/'offline-evidence.zip.sha256.json',members)
manifest={'stage':50,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
          'result':'offline_fix_only_no_new_model_repair','protection':protect,'replay':read(OUT/'fixed-trace-replay.json'),
          'credential_scan':{'keys_checked':2,'objects':scanned,'matches':0},'formal_database_and_ledger_not_uploaded':True}
write(DEST/'manifest.json',manifest)
write(DEST/'artifact_sha256.json',{p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()})
print(json.dumps({k:v for k,v in protect.items() if k not in {'historical_files_sha256','old_freeze_invalidated_by'}}))
