"""Replay frozen command observations, NEVER execute historical shell commands."""
import hashlib,json,sys,uuid,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_state import TaskState
from tool_output_budget import ToolOutputBudget
archive=ROOT/'experiments/click_closure_20261027/local-diagnostics.zip'
work=OUT/('replay-'+uuid.uuid4().hex);(work/'src/click').mkdir(parents=True)
(work/'src/click/core.py').write_text('Unchanged source fixture; historical commands are never executed.',encoding='utf-8')
state=TaskState(work,['src/click/core.py'],guard_enabled=True);budget=ToolOutputBudget(work)
blocked=[];stop=None;recognized=0
with zipfile.ZipFile(archive) as z:
    events=[json.loads(line) for line in z.read('temp/task-state/events.jsonl').decode().splitlines()]
    assert len(events)==69 and all(e['kind']=='executed' and not e['changed_files_this_action'] for e in events)
    recognized=sum(state._read_key(e['command']) is not None for e in events[1:])
    for i,event in enumerate(events):
        decision=state.before_action(event['command'])
        if decision:
            blocked.append({'model_action':i,'command':event['command'],'stop':decision['stop']})
            if decision['stop']:stop=i;break
            continue
        raw=z.read(event['output_path'])
        assert hashlib.sha256(raw).hexdigest()==event['output_sha256']
        output={'output':raw.decode('utf-8'),'returncode':event['returncode'],'exception_info':event.get('exception_info','')}
        receipt=budget.process(output,command=event['command'])['extra']['tool_output']
        state.observe(event['command'],output,receipt)
assert stop is not None and stop<68 and len(blocked)==3
before=json.loads((OUT/'before-recognition.json').read_bytes());assert before['recognized']==0
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'historical_model_actions':68,'recognized_reads_before':before['recognized'],'recognized_reads_after':recognized,
        'would_stop_on_model_action':stop,'blocked_reads':blocked,'transport_calls':0,'historical_commands_executed':0,
        'scope':'Fixed historical actions with unchanged source; demonstrates guard interception, not a new model repair or measured cost saving.'}
(OUT/'fixed-trace-replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'blocked_reads','scope'}}))
