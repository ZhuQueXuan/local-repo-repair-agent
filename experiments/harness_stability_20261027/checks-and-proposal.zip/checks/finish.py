import hashlib,json,sqlite3,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_panel import public_policy
from collaboration_protocol import canonical_bytes
from task_workspace import load_task
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_bytes(canonical_bytes(value))
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==json.loads((OUT/'payloads-before.json').read_bytes())
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
assert ledger==json.loads((OUT/'ledger-before.json').read_bytes())
assert len(formal)==53 and len(ledger['requests'])==2256
files=set((ROOT/'scripts').glob('*.py'))|set((ROOT/'scripts').glob('*.js'))|set((ROOT/'configs').glob('*.json'))
files.update((ROOT/'configs').glob('*-requirements.txt'));files.add(ROOT/'scripts/task_panel.html')
files.update((ROOT/'skills').glob('*/SKILL.md'));files.update((ROOT/'mini-swe-agent/src/minisweagent').rglob('*.py'))
plan_name=ROOT/'configs/harness_stability_revalidation_20261027.json';files.discard(plan_name)
tasks=['boltons-query-encoding','click-flag-default-map']
for task in tasks:
    source,manifest=load_task(task)
    files.update(source/'repo'/p for p in manifest['source_files_sha256'])
    files.update(source/p for p in (*manifest['task_files_sha256'],'manifest.json'))
    files.update((ROOT/'evaluation/multi_agent_20261025/evaluator'/task).glob('*'))
freeze={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files) if p.is_file()}
scope={'schema_version':1,'status':'scope_only_not_launchable','purpose':'Two known development cases; stability validation only, not a fresh effectiveness comparison.',
    'tasks':tasks,'maximum_new_parent_runs':2,'repetitions_each':1,'variants':['full'],
    'model_profile':'legacy_deepseek_v1','task_card':True,'capabilities':True,'allow_pause':False,
    'policy':public_policy(documents=True,question='What does the frozen repository documentation establish about the reported boundary, and what remains unspecified?'),
    'routing':['https://myai.bupt.edu.cn/llm-gw/v1','https://api.deepseek.com'],
    'outbound':['public issue and source','patch and public check results','role messages','task card','two local versioned Skills'],
    'withheld_checks_and_human_reference_to_models':False,'retained_scoring':'Only after both workers are terminal; keep all failures and costs.',
    'fees':{'shared_ledger':True,'max_total_cost_cny':None,'unknown_cost_is_unknown':True},
    'reruns_or_selection':False,'maximum_revision_per_run':1,'new_identity_required':True,
    'authorization':'Not granted. Previous one-task and twelve-slot grants do not authorize this proposal.',
    'input_files_sha256':freeze}
dump(plan_name,scope)
audit={'formal_payloads_unchanged':53,'shared_requests_unchanged':2256,'external_model_calls':0,
    'new_real_identities':0,'source_inputs_frozen':len(freeze),'proposal_sha256':sha(plan_name),
    'regression':'temp/regression/20261027_140305_405c3682','full_regression_passed':True,
    'final_panel_only_changes':['scripts/collaboration_panel.py','scripts/collaboration_panel.js'],
    'final_panel_checks':'19 existing checks + isolated HTTP and actual scripts in Node fake DOM; not browser clicks'}
dump(OUT/'protection-check.json',audit)
summary='2026-10-27最新：[47稳定性修复]({link})已按46负结果接v3：明确文档失败可受控继续但保留failed/degraded、完整JSON回执4096字节与确定分页、换行归一差异及当前版本检查收口。旧Click原动作API视图33950→21883字节，差异231631字节/5999行→557/11且与原导出补丁一致；原字节树保持。合成实际本机修复/评分/重放及暂停唯一续做通过，最终仍degraded，不冒称真实模型成绩。全回归301上游、412项目通过/1原权限跳过；最后面板19项/隔离HTTP/Node通过。正式53条/2256请求保持，0外部调用；8765已空闲重载，旧12结果保留。2题新真实复验仅候选冻结，未获本批授权、不执行；无异机或医疗项目变更。'
for path,link,marker in ((ROOT/'AGENTS.md','Project/47_修复_文档失败降级与审查预算及修复收口.md','## 当前阶段\n'),
    (ROOT/'Project/00_项目现状与快速接手.md','47_修复_文档失败降级与审查预算及修复收口.md','最后更新：2026-10-27。\n'),
    (ROOT.parent/'job/AGENTS.md','../shixi_project/Project/47_修复_文档失败降级与审查预算及修复收口.md','## 当前状态与导航\n')):
    raw=path.read_bytes();newline=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n')
    assert marker in text
    entry=summary.format(link=link)
    text=text.replace(marker,marker+'\n'+('- ' if '## ' in marker else '')+entry+'\n',1)
    path.write_bytes(text.replace('\n',newline.decode()).encode())
path=ROOT/'Project/项目开发流水账.md';raw=path.read_bytes();newline=b'\r\n' if b'\r\n' in raw else b'\n'
text=raw.decode().replace('\r\n','\n');text=text.replace('# 项目开发流水账\n','# 项目开发流水账\n\n**按负结果修稳定性（2026-10-27）。** 文档失败保留原失败事实后继续、完整回复限长、换行最小差异和当前版本测试收口已接v3，旧Click消息超限离线消除；合成本机暂停续做仍degraded而修复/审查/重放通过。全回归上游301、项目412通过/1原跳过，末面板19项/HTTP/Node通过；0外部调用，53正式payload/2256请求不变。空闲8765已重载。保留六题3/6对1/6、完整协作0/6的负结果，下一步仅冻结2题候选而未执行，不宣称效果改善。见[47](47_修复_文档失败降级与审查预算及修复收口.md)。\n',1)
path.write_bytes(text.replace('\n',newline.decode()).encode())
path=ROOT/'README.md';raw=path.read_bytes();newline=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n')
text=text.replace('下一轮优先离线稳定性改进。','已接入[47稳定性修复](Project/47_修复_文档失败降级与审查预算及修复收口.md)：明确文档失败后保留降级继续、完整回复限长、最小差异与修复收口；通过离线检查，尚无新版真实模型成绩。')
path.write_bytes(text.replace('\n',newline.decode()).encode())
doc=ROOT/'Project/47_修复_文档失败降级与审查预算及修复收口.md'
with doc.open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 本轮收尾\n\n全回归上游301通过、项目413项中412通过/1项原Windows权限跳过，5261保护输入无变更、上游联网违规0；最后仅增加面板降级字段和文字，另跑原19项与隔离HTTP/Node组合验证通过，不冒充其后的完整回归。适配层本轮未重跑，43的169/6/1仍是历史结果，六项旧差异未宣称解决。\n\n原53条payload、共享2256请求逐项一致，0真实模型调用或新付费身份；8765确认无在途任务后已加载本轮代码，健康检查通过，正式payload保持。实际浏览器未点击。封存入口 `experiments/harness_stability_20261027/manifest.json`，完整账本/正式库副本不上传。两题候选范围 `configs/harness_stability_revalidation_20261027.json` 为 scope_only_not_launchable；外发内容、路由、费用口径、每题一次/最多一次返工及输入哈希已列明，尚无执行授权。\n')
print(json.dumps(audit,ensure_ascii=False))
