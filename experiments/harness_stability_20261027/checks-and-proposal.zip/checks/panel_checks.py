import json,os,sys,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.request import Request,urlopen
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
from collaboration_store import CollaborationStore
from task_service import make_handler
wire=json.loads((OUT/'wire-continuation.json').read_bytes());s=CollaborationStore(Path(wire['home']))
server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(s,'stability-test',0))
server.RequestHandlerClass=make_handler(s,'stability-test',server.server_port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
def get(path):
    with urlopen(Request(f'http://127.0.0.1:{server.server_port}'+path,headers={'X-Task-Token':'stability-test'}),timeout=5) as r:return r.read()
try:
    with patch('litellm.completion',side_effect=AssertionError('No models')):
        view=json.loads(get('/api/runs/'+wire['child']+'/collaboration'))
        assert view['document_unavailable']['status']=='unavailable' and not view['consultations']
        assert view['collaboration_result']=='degraded' and view['roles'][0]['status']=='failed'
        assert '文档查阅失败'.encode() in get('/collaboration-panel.js')
        (OUT/'panel-api-view.json').write_text(json.dumps(view,ensure_ascii=False),encoding='utf-8')
finally:server.shutdown();thread.join(timeout=5);server.server_close()
src=(ROOT/'temp/final_engineering_20261027/panel_check.js').read_text(encoding='utf-8')
src=src.replace("'temp/final_engineering_20261027/panel-check.json'","'temp/stability_20261027/panel-check.json'")
needle="  const report={scope:"
extra="""  const displayCase=await load(html,true);const c=displayCase.context,e=displayCase.elements;
  c.fetch=async()=>({ok:true,json:async()=>({mode:'document_review_live',roles:[],usage:{available:false},candidates:[],consultations:[],collaboration_result:'degraded',review_verdict:'approve',document_unavailable:{status:'unavailable',reason_code:'document_repeated_evidence_limit'},reports:[],reviews:[],responses:[]})});
  vm.runInContext(\"selected='fixture';selectionRevision=7\",c);
  await c.refreshCollaboration({id:'fixture',kind:'collaboration_live',status:'finished'},7);
  assert(e.consultationResults.textContent.includes('文档查阅失败')&&e.consultationResults.textContent.includes('未提供建议或引用'));
"""
assert needle in src;src=src.replace(needle,extra+needle)
(OUT/'panel-check.js').write_text(src,encoding='utf-8')
print(json.dumps({'http_marker_preserved':True,'failed_role_preserved':True,'external_calls':0}))
