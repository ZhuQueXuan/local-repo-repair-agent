import hashlib,io,json,re,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;DEST=ROOT/'experiments/harness_stability_20261027'
assert not DEST.exists();DEST.mkdir()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,label,depth=0):
    global scanned
    assert depth<=6 and not any(k in raw for k in keys),'Credential detected; values not printed'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected; values not printed'
    scanned+=1
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for name in z.namelist():
                if name.endswith('/'):continue
                assert not Path(name).name.startswith('.env')
                scan(z.read(name),label+'!'+name,depth+1)
counts={};outer={}
def pack(name,entries):
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,label in entries:
            if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.lock':continue
            assert not path.name.startswith('.env')
            raw=path.read_bytes();scan(raw,label);assert label not in members;members[label]=sha(raw);z.writestr(label,raw)
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
    write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
    for tail in ('','.sha256.json'):outer[name+tail]=sha((DEST/(name+tail)).read_bytes())
audit=json.loads((OUT/'protection-check.json').read_bytes());wire=json.loads((OUT/'wire-continuation.json').read_bytes());home=Path(wire['home'])
entries=[(p,p.relative_to(home).as_posix()) for p in sorted(home.rglob('*')) if p.is_file()]
pack('synthetic-local-flow.zip',entries)
names=['offline_checks.py','offline-checks-wire.log','review-replay.json','wire-continuation.json','failure-guards.json',
    'panel_checks.py','panel-check.js','panel-check.json','panel-api-view.json','load_panel.py','panel-loaded.json','panel-final.log',
    'finish.py','seal.py','protection-check.json','source-before.json','focused.log','focused-elevated.log','regression.log']
reg=ROOT/audit['regression'];entries=[(OUT/n,'checks/'+n) for n in names]
entries += [(p,'regression/'+p.relative_to(reg).as_posix()) for p in reg.rglob('*') if p.is_file() and p.suffix in {'.log','.json','.xml'} and 'scratch' not in p.parts]
entries += [(ROOT/n,n) for n in ('Project/47_修复_文档失败降级与审查预算及修复收口.md','configs/harness_stability_revalidation_20261027.json')]
pack('checks-and-proposal.zip',entries)
def changed(args):return [p.decode() for p in subprocess.check_output(['git',*args],cwd=ROOT).split(b'\0') if p]
paths=sorted(set(changed(['diff','--name-only','-z','HEAD'])+changed(['ls-files','--others','--exclude-standard','-z'])))
paths=[n for n in paths if not n.startswith('experiments/')]
pack('current-changes.zip',[(ROOT/n,n) for n in paths])
manifest={'schema_version':1,'stage':47,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'archive_members':counts,'checks':audit,'review_replay':json.loads((OUT/'review-replay.json').read_bytes()),
    'synthetic_flow':wire,'external_model_calls':0,'historical_comparison_unchanged':True,
    'first_focused_run':'Sandbox denied Bash/hardlink; one stale pagination expectation. Retained, not accepted as green.',
    'second_focused_run':'Two new fixture mistakes corrected; final full run covers both.',
    'final_default':'301 upstream + 412 project pass, 1 original permission skip; 5261 protected files unchanged.',
    'final_panel_after_default':'19 existing tests + isolated HTTP + actual Node scripts, no browser click.',
    'shared_ledger_and_formal_database_full_not_uploaded':True,'credential_scan':{'keys_checked':2,'nested_objects':scanned,'matches':0},
    'proposal_status':'scope_only_not_launchable; no new real run identity or authorization'}
write(DEST/'manifest.json',manifest);outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archive_members':counts,'scanned_objects':scanned,'real_key_matches':0,'external_model_calls':0}))
