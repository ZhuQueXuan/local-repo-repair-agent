"""Reuse recorded negative examples; real local wire/checkpoint exercise, zero model IO."""
import json, os, sqlite3, sys, time, uuid
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1',MSWEA_SILENT_STARTUP='1',MSWEA_GLOBAL_CONFIG_DIR=str(ROOT/'temp/mini-global'))
from collaboration_protocol import canonical_bytes, sha256, ProtocolError, Handoff, RoleIdentity
from collaboration_store import CollaborationStore
from review_tools import ReviewEvidenceBroker,seal_candidate,IntegrityError
from collaboration_live import LiveRunner
from document_agent_demo import exercise
from harness_checkpoints import request_pause, continue_checkpoint, checkpoint_view
from task_cards import card_view
from context_budget import message_bytes
from collaboration_runtime import ProtectedReviewModel
from test_collaboration_runtime import RuntimeTests
from task_workspace import load_task

batch=ROOT/'temp/comparison_batches/cmp1027/store';store=CollaborationStore(batch)
run='38cee7b06f8d44d2b68fb17798954816'
history=json.loads((batch/'runs'/run/'reviewing-trajectory.json').read_bytes())['messages']
roles=store.roles(run);role=next(r for r in roles if r['phase']=='reviewing')
identity=RoleIdentity.parse({k:role[k] for k in ('run_id','role_run_id','session_id','role')})
candidate_id=store.state(run)['collaboration_state']['candidate_id'];snapshot=store.snapshot(run,candidate_id)
handoff=next(h for h in store.records(run,'handoff').values() if h.to_role_run_id==role['id'])
reports=list(store.records(run,'report').values())
broker=ReviewEvidenceBroker(snapshot,identity,handoff,reports=reports)
changed=deepcopy(history);replies=[];previous={}
for msg in changed:
    if msg.get('role')=='assistant':
        previous={a['tool_call_id']:a for a in msg.get('extra',{}).get('actions',[])}
    elif msg.get('role')=='tool' and msg.get('tool_call_id') in previous:
        action=previous[msg['tool_call_id']]
        result=broker.dispatch(identity,action['tool'],action['arguments'])
        replies.append({'tool':action['tool'],'old_bytes':len(msg['content'].encode()),'new_bytes':len(canonical_bytes(result))})
        assert len(canonical_bytes(result))<=4096
        msg['content']=canonical_bytes(result).decode()
test=RuntimeTests();test.setUp();model=test.model(review_context_bytes=32768)
old=model._prepare_messages_for_api(history);new=model._prepare_messages_for_api(changed)
assert message_bytes(new)<=32768,(message_bytes(old),message_bytes(new))
assert canonical_bytes(history)==canonical_bytes(json.loads((batch/'runs'/run/'reviewing-trajectory.json').read_bytes())['messages'])
review={'scope':'Same recorded calls on original immutable snapshot, tool envelopes rebuilt without model replies; not a successful real review.',
    'run_id':run,'old_api_message_bytes':message_bytes(old),'new_api_message_bytes':message_bytes(new),'hard_limit':32768,'replies':replies,'raw_history_unchanged':True}

# Re-seal the actual Click candidate using identical raw files; compare text diff only.
source,manifest=load_task('click-flag-default-map');case=OUT/('click-diff-'+uuid.uuid4().hex)
baseline=case/'baseline';work=case/'work'
for doc in snapshot.candidate.documents:
    if doc.side not in {'baseline','candidate'}:continue
    dest=(baseline if doc.side=='baseline' else work)/doc.path;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(snapshot.read(doc.document_id))
issue=next(d for d in snapshot.candidate.documents if d.side=='issue');raw_issue=snapshot.read(issue.document_id)
(work/'TASK.md').write_bytes(raw_issue)
(work/'task_checks').mkdir()
(work/'task_checks/test_behavior.py').write_bytes((source/'checks/test_behavior.py').read_bytes())
new_snapshot=seal_candidate(manifest,baseline,work,raw_issue,case/'snapshot',run_id='offline-click-diff',producer_role_run_id='offline-repairer')
old_diff=next(d for d in snapshot.candidate.documents if d.side=='diff');new_diff=next(d for d in new_snapshot.candidate.documents if d.side=='diff')
exported=(batch/'runs'/run/'repair.diff').read_bytes()
assert new_snapshot.read(new_diff.document_id)==exported
assert new_snapshot.candidate.source_tree_digest==snapshot.candidate.source_tree_digest
assert new_snapshot.candidate.baseline_digest==snapshot.candidate.baseline_digest
review['diff']={'old_bytes':old_diff.byte_count,'new_bytes':new_diff.byte_count,'old_lines':old_diff.line_count,'new_lines':new_diff.line_count,'matches_exported_patch':True,'raw_tree_hashes_unchanged':True}
(OUT/'review-replay.json').write_bytes(canonical_bytes(review))

def boundary(name,role,runner):
    if name=='after_role_completion' and role['phase']=='repairing':request_pause(runner.store,runner.run_id)
with patch('collaboration_runtime.run_document_consultation',side_effect=ProtocolError('document_repeated_evidence_limit')):
    s,first,summary,wires=exercise(allow_pause=True,allow_capabilities=True,model_profile='legacy_deepseek_v1',checkpoint=boundary,
        task_card={'goal':'验证降级查阅与续做保持事实','steps':[{'id':'fix','title':'修复并验证','status':'pending'}]})
parent=summary['run'];assert parent['status']=='paused',parent
before=s.get(parent['id']);view=checkpoint_view(s,parent['id'])
child=continue_checkpoint(s,parent['id'],{'request_key':'stability-'+uuid.uuid4().hex,'checkpoint_sha256':view['checkpoint_sha256'],
    'task_card':card_view(s,parent['id'])['card']})
s,runner,final,new_wires=exercise(continuation={'home':str(s.home),'run_id':child['id']})
assert s.get(parent['id'])==before
assert final['run']['status']=='finished' and final['run']['repair_result']=='passed' and final['run']['review_verdict']=='approve',final['run']
assert final['run']['collaboration_result']=='degraded'
assert s.roles(child['id'])[0]['status']=='failed' and not s.records(child['id'],'consultation')
assert 'consulting' not in final['counts'] and 'repairing' not in final['counts']
assert runner.session.agent.env.task_state.progress is not None
wire={'scope':'Synthetic model transport only; real local shell, evaluator, patch replay and pause/unique continuation. Zero external calls.',
    'home':str(s.home),'parent':parent['id'],'child':child['id'],'first_counts':summary['counts'],'child_counts':final['counts'],
    'status':final['run']['status'],'repair_result':final['run']['repair_result'],'collaboration_result':final['run']['collaboration_result'],
    'review_verdict':final['run']['review_verdict'],'failed_consultation_not_repeated':True,'source_parent_unchanged':True,
    'progress_restored':True,'external_model_calls':0}
(OUT/'wire-continuation.json').write_bytes(canonical_bytes(wire))

# Live recovery itself must reject provider, integrity, cancellation and expired parent.
from collaboration import RoleContext,role_identity
from collaboration_store import CollaborationStopped
from test_document_agent import DocumentStoreTests
checks=[]
for error in (RuntimeError('provider'),IntegrityError('changed'),ProtocolError('other')):
    fixture=DocumentStoreTests();st,p,_=fixture.make_parent();st.claim_parent(p['id'])
    r=st.claim_role(p['id'],'consulting',sha256(b'input'),0);ctx=RoleContext(st,r,time.monotonic()+30)
    live=LiveRunner.__new__(LiveRunner);live.store=st;live.run_id=p['id'];live.parent_deadline=time.monotonic()+60
    assert not live.document_unavailable(ctx,error,st.state(p['id'])['collaboration_state']['revision'],elapsed_seconds=0)
    checks.append(type(error).__name__)
    st.cancel(p['id'])
    try:live.document_unavailable(ctx,ProtocolError('document_repeated_evidence_limit'),1,elapsed_seconds=0)
    except CollaborationStopped:pass
    else:raise AssertionError('Cancellation swallowed')
(OUT/'failure-guards.json').write_bytes(canonical_bytes({'fatal_failures_preserved':checks,'cancellation_preserved':True,'external_model_calls':0}))
print(json.dumps({'review':review,'wire':wire},ensure_ascii=False))
