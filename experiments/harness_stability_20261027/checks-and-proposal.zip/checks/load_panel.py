"""Reload the owned loopback service only after proving it has no active work."""
import json,re,sqlite3,subprocess,sys,time
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import URLError
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;BASE='http://127.0.0.1:8765'
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    before=dict(db.execute('SELECT id,payload FROM runs'))
assert not any(json.loads(p)['status'] in {'queued','running','cancel_requested'} for p in before.values()),'Active work; do not restart'
def get(path):
    with urlopen(BASE+path,timeout=3) as r:return r.read()
try:
    html=get('/').decode();token=re.search(r"const token='([^']+)'",html).group(1)
    req=Request(BASE+'/api/shutdown',data=b'{}',headers={'X-Task-Token':token,'Content-Type':'application/json','Origin':BASE},method='POST')
    with urlopen(req,timeout=5) as r:assert r.status==200
    stopped=False
    for _ in range(50):
        try:get('/api/health')
        except (URLError,ConnectionResetError):stopped=True;break
        time.sleep(.1)
    assert stopped,'Previous server not stopped; do not launch duplicate'
except URLError as error:
    if hasattr(error,'code'):raise
with (OUT/'panel.log').open('wb') as log,(OUT/'panel-error.log').open('wb') as err:
    p=subprocess.Popen([sys.executable,'-B',str(ROOT/'scripts/task_service.py')],cwd=ROOT,stdout=log,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
ready=False
for _ in range(60):
    try:
        ready='文档查阅失败'.encode() in get('/collaboration-panel.js')
        if ready:break
    except (URLError,ConnectionResetError):pass
    time.sleep(.1)
assert ready and p.poll() is None
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    assert dict(db.execute('SELECT id,payload FROM runs'))==before
report={'url':BASE,'owned_new_process':p.pid,'idle_before_reload':True,'formal_payloads_unchanged':len(before),
    'health':json.loads(get('/api/health')),'current_failure_notice_served':True,'created_tasks':0,'external_model_calls':0}
(OUT/'panel-loaded.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
