"""Exactly two explicitly approved NEW regression identities; no resume or retry."""
import hashlib,json,os,sqlite3,subprocess,sys,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/stability_live_20261027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(LITELLM_LOCAL_MODEL_COST_MAP='True',MSWEA_SILENT_STARTUP='1',PYTHONDONTWRITEBYTECODE='1')
from collaboration_protocol import canonical_bytes
from collaboration_store import CollaborationStore
from task_service_store import worker_lock,TERMINAL
from comparison_batch import select_patch,evaluator
from task_workspace import prepare_task,changed_files
PLAN=ROOT/'configs/harness_stability_revalidation_20261027.json'
EXPECTED='fb350e3aa8c65fc344337474f03508756f512847962b05f96b36ee1e14be895c'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_bytes(canonical_bytes(v))
def verify():
    assert sha(PLAN.read_bytes())==EXPECTED,'Approved proposal changed'
    p=json.loads(PLAN.read_bytes())
    assert all(sha((ROOT/n).read_bytes())==h for n,h in p['input_files_sha256'].items()),'Frozen input changed'
    assert p['tasks']==['boltons-query-encoding','click-flag-default-map'] and p['maximum_new_parent_runs']==2
    return p
plan=verify()
assert sys.argv[1:]==['--run-approved-two'],'No implicit execution'
assert not HOME.exists(),'Existing identity/batch must not be replayed or replaced'
HOME.mkdir()
write(HOME/'authorization.json',{'approved':True,'maximum_runs':2,'proposal_sha256':EXPECTED,
    'source':'Human answered 批准这2次真实复验 to the concrete question in this conversation.',
    'tasks':plan['tasks'],'model_profile':plan['model_profile'],'no_selection_reruns':True,
    'outbound':plan['outbound'],'routing':plan['routing'],'fees':plan['fees']})
with worker_lock(HOME,'batch.lock') as owned:
    assert owned
    with worker_lock(ROOT/'data/task_service') as idle:
        assert idle,'Formal worker busy'
        with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
            before=dict(db.execute('SELECT id,payload FROM runs'))
        assert not any(json.loads(v)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for v in before.values())
        write(OUT/'live-formal-before.json',before)
        (OUT/'live-ledger-before.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
        store=CollaborationStore(HOME/'store');slots=[]
        write(HOME/'dispatched.json',{'proposal_sha256':EXPECTED,'state':'claiming_once'})
        for task in plan['tasks']:
            key='stability-'+uuid.uuid4().hex
            row=store.create_collaboration(task,'adaptive_history',key,plan['policy'],execution='live',
                model_profile=plan['model_profile'],allow_pause=False,allow_capabilities=True,task_card={
                'goal':'Fix the original issue under its constraints; retain failed documentation and uncertainty honestly.',
                'steps':[{'id':'repair','title':'Read, repair and validate the original issue','status':'pending'}],
                'instruction':'At most one revision. Retain all failures. Submit when current declared checks and diff are ready; no reruns for selection.'})
            slots.append({'task':task,'variant':'full','request_key':key,'run_id':row['id']})
        write(HOME/'slots.json',slots)
        for slot in slots:
            verify()
            with (HOME/(slot['request_key']+'.claimed')).open('x') as f:f.write(slot['run_id'])
            command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--collaboration','--run-id',slot['run_id'],'--home',str(store.home)]
            print(json.dumps({'starting':slot},ensure_ascii=False),flush=True)
            with (HOME/(slot['request_key']+'.log')).open('xb') as log:
                p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                last=None;deadline=time.monotonic()+1860
                while p.poll() is None:
                    row=store.get(slot['run_id']);marker=(row['status'],row.get('stage'))
                    if marker!=last:print(json.dumps({'run_id':row['id'],'status':marker[0],'phase':marker[1]}),flush=True);last=marker
                    if time.monotonic()>=deadline:
                        from execution_backend import terminate_owned_process
                        terminate_owned_process(p);p.wait(timeout=10)
                        store.update(slot['run_id'],status='failed',stage='done',reason='Owned worker deadline; no automatic replay')
                        break
                    time.sleep(.5)
                p.wait(timeout=10)
            row=store.get(slot['run_id'])
            if row['status'] not in TERMINAL:store.update(row['id'],status='failed',stage='done',reason='Worker ended without terminal result; no replacement')
            print(json.dumps({'ended':row['id'],'status':store.get(row['id'])['status']}),flush=True)
        verify()
        rows=[store.get(s['run_id']) for s in slots];assert all(r['status'] in TERMINAL and r['status']!='paused' for r in rows)
        write(HOME/'all-workers-terminal.json',{'run_ids':[r['id'] for r in rows],'retained_scoring_not_started_before_this_receipt':True})
        results=[]
        for slot,row in zip(slots,rows):
            result={**slot,**{k:row.get(k) for k in ('status','collaboration_result','repair_result','review_verdict','reason','metrics')},'resolved':False}
            patch,selection=select_patch(store,row);result['candidate_selection']=selection
            if patch is None:result['evaluation_error']='No sealed/exported final patch; retained in denominator'
            else:
                try:
                    repo,manifest=prepare_task(slot['task']);result['patch_sha256']=sha(patch.read_bytes())
                    p=subprocess.run(['git','-C',str(repo),'apply','--',str(patch)],capture_output=True,timeout=30)
                    if p.returncode:raise ValueError('Patch replay failed')
                    changes=changed_files(repo,manifest)
                    assert changes and all(n in manifest['source_files_sha256'] and n.startswith(manifest['source_prefix']) for n in changes)
                    result['checks']=evaluator(slot['task'],repo,HOME/'terminal-scores'/slot['request_key'])
                    result['resolved']=all(result['checks'][k]['successful'] for k in ('public','withheld','upstream'))
                except Exception as error:result['evaluation_error']=type(error).__name__+': '+str(error)[:180]
            results.append(result);write(HOME/'terminal-results.json',results)
        write(HOME/'result-summary.json',{'scope':'Two known development regressions after engineering fixes; not fresh effects/benchmark.','results':results,
            'new_parent_runs':2,'repetitions_each':1,'extra_selection_reruns':0,'all_failures_retained':True})
        print(json.dumps({'complete':True,'results':[{k:r.get(k) for k in ('task','run_id','status','resolved','collaboration_result','repair_result','review_verdict')} for r in results]},ensure_ascii=False),flush=True)
