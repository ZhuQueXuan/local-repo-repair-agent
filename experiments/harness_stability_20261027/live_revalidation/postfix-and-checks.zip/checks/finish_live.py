import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/stability_live_20261027'
audit=json.loads((HOME/'audit.json').read_bytes());assert audit['new_attempts']==31 and audit['resolved']==1
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    assert dict(db.execute('SELECT id,payload FROM runs'))==json.loads((OUT/'live-formal-before.json').read_bytes())
assert json.loads((ROOT/'data/deepseek_budget.json').read_bytes())==json.loads((OUT/'live-ledger-after.json').read_bytes())
plan=json.loads((ROOT/'configs/harness_stability_revalidation_20261027.json').read_bytes())
changed=[n for n,h in plan['input_files_sha256'].items() if hashlib.sha256((ROOT/n).read_bytes()).hexdigest()!=h]
assert set(changed)=={'scripts/collaboration_runtime.py','scripts/test_collaboration_runtime.py'},changed
report={'real_new_attempts':31,'formal_payloads_unchanged':53,'shared_requests_after':2287,
    'old_proposal_verified_before_postfix':451,'postfix_changes':changed,'old_proposal_now_stale':True,
    'postfix_external_model_calls':0,'new_parent_runs':2,'extra_selection_reruns':0,
    'postfix_targeted_tests':38,'postfix_targeted_passed':True,'failed_real_result_unchanged':True,
    'replay':json.loads((OUT/'card-guard-replay.json').read_bytes())}
(OUT/'postfix-protection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
summary='2026-10-27最新：[48两题真实复验]({link})在用户具体批准后执行2个新身份，query题完整通过、Click文档完成但初修未改代码即context_bytes停止，无候选，终态1/2/协作1/2，全部留证无重跑。31尝试已知估算0.312948元、未知占位0.20，完整费用未知；正式53payload/原2256请求保持，现2287。后续离线定位任务卡在压缩后追加未预留，原16546字节精确复现，补修后12123；38定向通过，真实Click失败保留，0额外真实调用。原451冻结在运行评分后保持，补修2源码后失效且不复用。下一步仅补修后的Click真实闭环待新具体授权，不立即循环付费或重做六题，不涉及异机/医疗。'
for path,link,marker in ((ROOT/'AGENTS.md','Project/48_验收_两题真实稳定性复验与任务卡预算补修.md','## 当前阶段\n'),
    (ROOT/'Project/00_项目现状与快速接手.md','48_验收_两题真实稳定性复验与任务卡预算补修.md','最后更新：2026-10-27。\n'),
    (ROOT.parent/'job/AGENTS.md','../shixi_project/Project/48_验收_两题真实稳定性复验与任务卡预算补修.md','## 当前状态与导航\n')):
    raw=path.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n');assert marker in text
    text=text.replace(marker,marker+'\n'+('- ' if marker.startswith('## ') else '')+summary.format(link=link)+'\n',1)
    path.write_bytes(text.replace('\n',nl.decode()).encode())
path=ROOT/'Project/项目开发流水账.md';raw=path.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n')
text=text.replace('# 项目开发流水账\n','# 项目开发流水账\n\n**两题真实复验一成一败（2026-10-27）。** 用户具体批准后query题完整通过，Click初修尚未改代码即16KB保护，无候选，1/2保留，不重跑。31尝试已知0.312948元、未知占位0.20，费用未知；正式53payload/旧2256请求不改，现2287。实际失败发现任务卡在压缩后才加入，离线补预留，同一轨迹16546→12123字节，38定向通过；未生成新真实成功。旧451冻结因此失效，补修后的Click仍待另批具体授权，不继续付费直到成功。见[48](48_验收_两题真实稳定性复验与任务卡预算补修.md)。\n',1)
path.write_bytes(text.replace('\n',nl.decode()).encode())
path=ROOT/'README.md';raw=path.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n')
text=text.replace('通过离线检查，尚无新版真实模型成绩。','[48两题真实复验](Project/48_验收_两题真实稳定性复验与任务卡预算补修.md)为1成功/1失败；后续补修任务卡预算，原失败轨迹离线已容纳，补修后尚无新的真实闭环。')
path.write_bytes(text.replace('\n',nl.decode()).encode())
print(json.dumps({k:v for k,v in report.items() if k!='replay'},ensure_ascii=False))
