import hashlib,json,sqlite3,sys
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/stability_live_20261027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_store import CollaborationStore
from collaboration_panel import usage_view
from collaboration_protocol import canonical_bytes
def write(p,v):p.write_bytes(canonical_bytes(v))
slots=json.loads((HOME/'slots.json').read_bytes());report=json.loads((HOME/'result-summary.json').read_bytes())
assert len(slots)==len(report['results'])==2 and len({s['run_id'] for s in slots})==2
store=CollaborationStore(HOME/'store');rows={s['run_id']:store.get(s['run_id']) for s in slots}
assert all(r['status'] in {'finished','failed','cancelled','interrupted'} for r in rows.values())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==json.loads((OUT/'live-formal-before.json').read_bytes())
before=json.loads((OUT/'live-ledger-before.json').read_bytes());after=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
assert all(after['requests'][k]==v for k,v in before['requests'].items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
assert all(v.get('attribution',{}).get('run_id') in rows for v in new.values())
fees={};details=[]
for slot,result in zip(slots,report['results']):
    run=slot['run_id'];assert run==result['run_id']
    requests=[v for v in new.values() if v['attribution']['run_id']==run]
    known=sum((Decimal(v['amount_cny']) for v in requests if v['status']=='settled'),Decimal(0))
    unknown=sum((Decimal(v['amount_cny']) for v in requests if v['status']!='settled'),Decimal(0))
    fees[run]={'attempts':len(requests),'known_price_estimate_cny':str(known),'unknown_placeholder_cny':str(unknown),'complete_cost_estimate_cny':str(known) if not unknown else None}
    role_rows=store.roles(run)
    info={**result,'roles':[{k:r.get(k) for k in ('id','phase','status','reason','result','elapsed_seconds')} for r in role_rows],
        'document_unavailable':rows[run].get('document_unavailable'),'usage':usage_view(store,rows[run]),'fees':fees[run]}
    output=store.home/'runs'/run
    info['projection_events']=json.loads((output/'review-context-projections.json').read_bytes())
    if (output/'repair-context-projections.json').is_file():info['repair_projection_count']=len(json.loads((output/'repair-context-projections.json').read_bytes()))
    info['skills_or_mcp_calls']=[{'phase':p,'tool':a.get('tool')} for p in ('consulting','reviewing','final_review')
        if (path:=output/(p+'-trajectory.json')).is_file() for m in json.loads(path.read_bytes())['messages']
        for a in m.get('extra',{}).get('actions',[]) if a.get('tool') in {'read_skill','read_change_summary'}]
    details.append(info)
plan=json.loads((ROOT/'configs/harness_stability_revalidation_20261027.json').read_bytes())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in plan['input_files_sha256'].items())
audit={'scope':'Two approved development regressions only; no fresh effectiveness claim.',
    'formal_payloads_unchanged':len(formal),'old_requests_unchanged':len(before['requests']),
    'new_attempts':len(new),'shared_requests_after':len(after['requests']),
    'known_price_estimate_cny':str(sum((Decimal(v['known_price_estimate_cny']) for v in fees.values()),Decimal(0))),
    'unknown_placeholder_cny':str(sum((Decimal(v['unknown_placeholder_cny']) for v in fees.values()),Decimal(0))),
    'complete_cost_estimate_cny':None if any(v['complete_cost_estimate_cny'] is None for v in fees.values()) else str(sum((Decimal(v['known_price_estimate_cny']) for v in fees.values()),Decimal(0))),
    'resolved':sum(r['resolved'] for r in report['results']),'collaboration_completed':sum(r['status']=='finished' and r['collaboration_result']=='completed' and r['review_verdict']=='approve' for r in report['results']),
    'input_hashes_verified':len(plan['input_files_sha256']),'extra_selection_reruns':0,'all_results_retained':True,'details':details}
write(HOME/'audit.json',audit);(OUT/'live-ledger-after.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
print(json.dumps({k:v for k,v in audit.items() if k!='details'},ensure_ascii=False))
