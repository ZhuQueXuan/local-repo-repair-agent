import hashlib,io,json,re,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/stability_live_20261027';DEST=ROOT/'experiments/harness_stability_20261027/live_revalidation'
assert not DEST.exists();DEST.mkdir()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6 and not any(k in raw for k in keys),'Credential detected; values not printed'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if n.endswith('/'):continue
                assert not Path(n).name.startswith('.env');scan(z.read(n),depth+1)
outer={};counts={}
def pack(name,entries):
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p,n in entries:
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock':continue
            assert not p.name.startswith('.env');raw=p.read_bytes();scan(raw);assert n not in members;members[n]=sha(raw);z.writestr(n,raw)
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
    write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
    for tail in ('','.sha256.json'):outer[name+tail]=sha((DEST/(name+tail)).read_bytes())
pack('both-real-runs.zip',[(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.rglob('*')) if p.is_file()])
checks=['execute_live.py','audit_live.py','replay_card_guard.py','card-guard-replay.json','card-budget-tests.log','card-budget-tests-final.log','postfix-protection.json','finish_live.py','seal_live.py']
pack('postfix-and-checks.zip',[(OUT/n,'checks/'+n) for n in checks]+
    [(ROOT/'configs/harness_stability_revalidation_20261027.json','original-approved-proposal.json'),
     (ROOT/'Project/48_验收_两题真实稳定性复验与任务卡预算补修.md','Project/48_验收_两题真实稳定性复验与任务卡预算补修.md'),
     (ROOT/'scripts/collaboration_runtime.py','postfix/scripts/collaboration_runtime.py'),
     (ROOT/'scripts/test_collaboration_runtime.py','postfix/scripts/test_collaboration_runtime.py')])
audit=json.loads((HOME/'audit.json').read_bytes());post=json.loads((OUT/'postfix-protection.json').read_bytes())
manifest={'schema_version':1,'stage':48,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'real_result':{k:v for k,v in audit.items() if k!='details'},'postfix':post,'archive_members':counts,
    'credential_scan':{'keys_checked':2,'nested_objects':scanned,'matches':0},
    'real_failed_click_not_rerun':True,'formal_database_and_shared_whole_ledger_not_uploaded':True,
    'scope':'One approved pair of known development cases, 1 completed and 1 unresolved; later card budget fix has offline evidence only.'}
write(DEST/'manifest.json',manifest);outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'scanned_objects':scanned,'credential_matches':0,'real_new_parent_runs':2,'real_resolved':1,'postfix_external_calls':0}))
