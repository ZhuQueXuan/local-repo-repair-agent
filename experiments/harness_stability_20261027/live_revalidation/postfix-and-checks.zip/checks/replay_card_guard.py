import json,os,sqlite3,sys
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/stability_live_20261027/store'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHON_DOTENV_DISABLED='1',MSWEA_SILENT_STARTUP='1')
from collaboration_store import CollaborationStore
from collaboration_runtime import RepairModel
from context_budget import message_bytes
from collaboration_protocol import canonical_bytes,sha256
from task_cards import encoded
from task_service_store import policy
from test_collaboration_runtime import RuntimeTests
run='a92a12533eb443c9a703d4d22d6eee35';s=CollaborationStore(HOME);parent=s.get(run)
output=HOME/'runs'/run;raw=json.loads((output/'repairing-trajectory.json').read_bytes());messages=raw['messages'];before=canonical_bytes(messages)
work=Path(parent['workspace']);pinned=json.loads((work/'temp/task-state/requests.jsonl').read_text(encoding='utf-8').splitlines()[-1])['message']
with s.connect() as db:
    inp=dict(db.execute("SELECT * FROM task_card_inputs WHERE run_id=? AND phase='repairing' ORDER BY rowid DESC LIMIT 1",(run,)).fetchone())
    card=dict(db.execute('SELECT * FROM task_cards WHERE run_id=?',(run,)).fetchone())
payload={'task_card_input_id':inp['id'],'task_card_revision':inp['revision'],'task_card_sha256':card['sha256'],'human_task_card':json.loads(card['payload']),
    'scope':'Current human plan replaces earlier card views. Apply only within your current role. The frozen original issue, write/read restrictions, tool capabilities, deadlines and program verification remain authoritative. Step status is human-reported, not test truth. Do not expand your role or claim independent verification from this card.'}
card_message={'role':'user','content':encoded(payload).decode()}
assert sha256(encoded(card_message))==inp['sha256']
test=RuntimeTests();test.setUp()
model=test.model(cls=RepairModel,task_state=SimpleNamespace(pinned_message=lambda:deepcopy(pinned)),context_policy=policy('adaptive_history')['context_budget'])
model.context_budget.enable_assistant_archives(OUT/'card-guard-replay')
legacy=model._prepare_messages_for_api(messages)+[card_message]
assert message_bytes(legacy)==raw['messages'][-1]['extra']['message_utf8_bytes']==16546
model._task_card_receipt={'message':card_message}
corrected=model._prepare_messages_for_api(messages)
assert message_bytes(corrected)<=16384
assert corrected[-1]==card_message and corrected.count(card_message)==1
assert canonical_bytes(messages)==before
report={'scope':'Exact saved raw trajectory, final pinned facts, and SHA-verified last human task card; API projection only, no model calls.',
    'run_id':run,'original_api_bytes':message_bytes(legacy),'new_api_bytes':message_bytes(corrected),'hard_limit':16384,
    'task_card_unchanged_and_once':True,'raw_history_unchanged':True,'events':model.context_budget.events,
    'real_run_result_still_failed':True,'external_model_calls':0}
(OUT/'card-guard-replay.json').write_bytes(canonical_bytes(report))
print(json.dumps({k:v for k,v in report.items() if k!='events'},ensure_ascii=False))
