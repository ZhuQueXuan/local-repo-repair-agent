"""Concentrated offline document boundaries; no model, worker or paid identity."""
import ast,copy,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_protocol import RoleIdentity,canonical_bytes,sha256
from document_model import ProtectedDocumentModel
from minisweagent.models.litellm_model import LitellmModelConfig
from context_budget import message_bytes
from task_cards import encoded,validate_card
from document_agent import (DocumentGrant,DocumentSnapshot,DocumentBroker,DocumentAdvice,
    DocumentHandoffTooLarge,document_rejection,ConsultationRecord,consultation_context)
folder=ROOT/'experiments/three_role_revalidation_20261027';archive=folder/'one-real-run.zip'
assert sha256(archive.read_bytes())==json.loads((folder/'artifact_sha256.json').read_bytes())['one-real-run.zip']
members=json.loads((folder/'one-real-run.zip.sha256.json').read_bytes())
with zipfile.ZipFile(archive) as z:
    def get(name):
        raw=z.read(name);assert sha256(raw)==members[name];return raw
    grant_name=next(n for n in z.namelist() if n.startswith('store/document_snapshots/') and n.endswith('/grant.json'))
    grant_raw=get(grant_name);grant=DocumentGrant.parse(json.loads(grant_raw))
    parent='store/runs/'+grant.run_id+'/'
    messages=json.loads(get(parent+'consulting-trajectory.json'))['messages']
    card=json.loads(get(parent+'task-card.json'));last=card['all_inputs'][-1]
    home=OUT/'document_replay';directory=home/'document_snapshots'/grant.run_id/grant.role_run_id
    if not directory.exists():(directory/'objects').mkdir(parents=True)
    if (directory/'grant.json').exists():assert (directory/'grant.json').read_bytes()==grant_raw
    else:(directory/'grant.json').write_bytes(grant_raw)
    for doc in grant.documents:
        target=directory/'objects'/doc.document_id;raw=get(grant_name.removesuffix('grant.json')+'objects/'+doc.document_id)
        if target.exists():assert target.read_bytes()==raw
        else:target.write_bytes(raw)
tree=ast.parse((ROOT/'scripts/task_cards.py').read_text(encoding='utf-8'))
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='begin_input')
scope=next(ast.literal_eval(v) for n in ast.walk(function) if isinstance(n,ast.Dict)
    for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value=='scope')
payload={'task_card_input_id':last['id'],'task_card_revision':last['revision'],'task_card_sha256':card['sha256'],
    'human_task_card':card['card'],'scope':scope}
original_card={'role':'user','content':encoded(payload).decode()};assert sha256(encoded(original_card))==last['sha256']
large=validate_card({'goal':'G','constraints':'C'*180,'instruction':'🙂'*400,
    'steps':[{'id':'repair','title':'repair','status':'pending'}]})
large_card={'role':'user','content':encoded(payload|{'task_card_input_id':'offline-capacity-card','human_task_card':large,
    'task_card_sha256':sha256(encoded(large))}).decode()}
assert len(encoded(large))<=2048 and len(encoded(large_card))<=4096
runtime=ast.parse((ROOT/'scripts/collaboration_runtime.py').read_text(encoding='utf-8'))
consult=next(n for n in runtime.body if isinstance(n,ast.FunctionDef) and n.name=='run_document_consultation')
hint=next(n.value.value for n in ast.walk(consult) if isinstance(n,ast.AugAssign) and isinstance(n.value,ast.Constant))
ends=[(i+1+len(m['tool_calls']),current) for current in (False,True) for i,m in enumerate(messages) if m.get('role')=='assistant' and m.get('tool_calls')]
matrix=[]
old_namespace={'__name__':'offline_old_document_model'}
exec(compile((OUT/'document-model-before.py').read_text(encoding='utf-8'),'document-model-before.py','exec'),old_namespace)
old_class=old_namespace['ProtectedDocumentModel']
for end,current in ends:
    raw=copy.deepcopy(messages[:end])
    if current:raw[0]['content']+=hint
    original=canonical_bytes(raw)
    for name,human in [('none',None),('original',original_card),('large_legal',large_card)]:
        model=ProtectedDocumentModel.__new__(ProtectedDocumentModel)
        model.config=LitellmModelConfig(model_name='deepseek/deepseek-flash');model._task_card_receipt={'message':human} if human else None
        old_model=old_class.__new__(old_class);old_model.config=model.config;old_model._task_card_receipt=model._task_card_receipt
        old_bytes=message_bytes(old_model._prepare_messages_for_api(raw))
        prepared=model._prepare_messages_for_api(raw)
        assert message_bytes(prepared)<=16384 and prepared[:2]==raw[:2] and canonical_bytes(raw)==original
        assert human is None or sum(m==human for m in prepared)==1
        prefixes=0
        for m in prepared:
            if m['role']!='tool':continue
            value=json.loads(m['content'])
            if not value.get('document_receipt_projection'):continue
            prefixes+=1;assert len(canonical_bytes(value))<=2048
            original_tool=next(t for t in raw if t['role']=='tool' and t['tool_call_id']==m['tool_call_id'])
            assert value['original_body_sha256']==sha256(original_tool['content'].encode())
            body=json.loads(original_tool['content']);spans=[body] if body.get('evidence') else body.get('hits',[])
            for shown in value['shown_spans']:
                actual=next(h for h in spans if h['evidence']['evidence_id']==shown['evidence']['evidence_id'])
                assert shown['evidence']==actual['evidence'] and actual['content'].startswith(shown['exact_prefix'])
        matrix.append({'current_submission_hint':current,'completed_read_groups':(end-2)//3,'card':name,'before_api_bytes':old_bytes,'api_bytes':message_bytes(prepared),'prefix_receipts':prefixes})
assert len(matrix)==30 and any(m['prefix_receipts'] for m in matrix)
snapshot=DocumentSnapshot(directory,grant);snapshot.verify()
identity=RoleIdentity(run_id=grant.run_id,role_run_id=grant.role_run_id,session_id='offline-audit',role='document_reader')
broker=DocumentBroker(snapshot,identity)
query='show_default';expected=[]
for doc in grant.documents:
    for number,line in enumerate(snapshot.read(doc.document_id).decode().splitlines(keepends=True),1):
        if query.casefold() in line.casefold():expected.append((doc.document_id,number))
assert 0<len(expected)<90
cursor=0;seen=[];pages=[]
while True:
    result=broker.dispatch(identity,'search_text',{'snapshot_id':grant.snapshot_id,'query':query,'cursor':cursor})
    assert len(canonical_bytes(result))<=4096
    seen.extend((h['evidence']['document_id'],h['evidence']['start_line']) for h in result['hits'])
    pages.append({'cursor':cursor,'next_cursor':result['next_cursor'],'hits':len(result['hits']),'bytes':len(canonical_bytes(result))})
    if result['next_cursor'] is None:break
    assert result['next_cursor']>cursor;cursor=result['next_cursor'];assert len(pages)<90
assert seen==expected
doc=next(d for d in grant.documents if d.path=='CHANGES.rst')
receipts=[broker.dispatch(identity,'read_lines',{'snapshot_id':grant.snapshot_id,'document_id':doc.document_id,'start':start,'end':start+79}) for start in (1,100)]
refs=tuple(r['evidence']['evidence_id'] for r in receipts)
def advice(ids):
    return DocumentAdvice(advice_id='offline-audit-advice',run_id=grant.run_id,role_run_id=grant.role_run_id,
        snapshot_id=grant.snapshot_id,task_digest=grant.task_digest,document_tree_digest=grant.document_tree_digest,
        status='information_not_found',answer='Offline handoff contract only; document applicability remains unverified.',
        evidence_ids=ids,unknowns=('No model answer or repair acceptance is produced by this audit.',))
try:broker.dispatch(identity,'submit_consultation',{'advice':advice(refs).model_dump(mode='json')})
except DocumentHandoffTooLarge as error:rejection=document_rejection(error)
else:raise AssertionError('The two long excerpts should expose the handoff limit')
assert broker.advice is None
broker.dispatch(identity,'submit_consultation',{'advice':advice(refs[:1]).model_dump(mode='json')})
record=ConsultationRecord(advice_id=broker.advice.advice_id,run_id=grant.run_id,
    relative_directory=directory.relative_to(home).as_posix(),grant=grant,advice=broker.advice,evidence=(broker.evidence[refs[0]],))
handoff=consultation_context(record,home);assert len(canonical_bytes(handoff))<=6144
result={'scope':'Offline capacity and handoff contract audit on verified copies, not real-model effectiveness or general stability.',
    'historical_archive_sha256':sha256(archive.read_bytes()),'verified_document_objects':len(grant.documents),
    'context_matrix':matrix,'context_cases_passed':len(matrix),'hard_context_bytes':16384,
    'search_query':query,'search_pages':pages,'search_matches_returned_without_gaps':len(seen),
    'oversized_handoff_rejected':rejection,'reduced_handoff_bytes':len(canonical_bytes(handoff)),
    'reduced_handoff_status':broker.advice.status,'new_model_calls':0,'new_live_identities':0}
(OUT/'audit-result-verified.json').write_bytes(canonical_bytes(result))
print(json.dumps({'context_cases':len(matrix),'max_api_bytes':max(m['api_bytes'] for m in matrix),
    'search_pages':len(pages),'search_matches':len(seen),'oversized_handoff_bytes':rejection['payload_bytes'],
    'reduced_handoff_bytes':len(canonical_bytes(handoff)),'new_model_calls':0}))
