"""Seal the concentrated offline audit; do not create a real model run."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;DEST=ROOT/'experiments/document_audit_20261027'
assert not DEST.exists()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert (ROOT/'data/deepseek_budget.json').read_bytes()==(OUT/'ledger-before.json').read_bytes()
assert len(read(OUT/'ledger-before.json')['requests'])==2408
history=read(OUT/'history-before.json');assert all(sha((ROOT/n).read_bytes())==h for n,h in history.items())
plan=read(ROOT/'temp/three_role_revalidation_20261027/plan.json')
invalidated=[n for n,h in plan['input_files_sha256'].items() if sha((ROOT/n).read_bytes())!=h]
assert set(invalidated)=={'scripts/document_model.py','scripts/document_agent.py','scripts/collaboration_runtime.py','scripts/test_document_context.py'}
log=(OUT/'document-tests-final-2.txt').read_text(encoding='utf-8-sig');assert 'Ran 47 tests in ' in log and log.rstrip().endswith('OK')
audit=read(OUT/'audit-result-verified.json');assert audit['context_cases_passed']==30 and audit['new_model_calls']==0
assert all(v['api_bytes']<=16384 for v in audit['context_matrix'])
check={'formal_payloads_unchanged':53,'shared_requests_unchanged':2408,'historical_files_unchanged':len(history),
    'model_calls':0,'new_real_runs':0,'checks_passed':47,'context_combinations_passed':30,'new_regression_tests':3,
    'old_stage53_freeze_cumulative_invalidated_files':invalidated,'historical_files_sha256':history}
write(OUT/'protection-check.json',check)
name='54_核查_文档阶段集中离线检查与收口补修.md'
body='按53继续集中离线核对完成：文档搜索补cursor稳定续页/完整JSON余量与目录字节分页，较长合法任务卡+双读取超限时仅API短展示（真实引用/准确前缀/不完整标记/正文哈希/重读入口），完整原回执与任务/卡/配对保持；加按具体缺口续页及及时交接提示，原16KB/80行/4KB读取/6KB交接/停止/权限/费用保持。47文档相关检查及30组合通过；原26公开文档13命中7+6两页无漏重，8510交接拒绝→脚本缩减4695合法未知，非模型成绩。3必要回归在原文件，未加新测试项目。正式53payload/2408请求、62旧实验保持，0真实调用/任务，无面板重启/医疗/异机。旧53冻结累计4源码失配不复用，51补丁通过/53真实失败及旧比较保留；新版完整三角色真实验收与复合验证命令进度识别仍待，不自动付费。'
def edit(p,marker,text):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';old=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in old and name not in old
    p.write_bytes(old.replace(marker,marker+'\n'+text+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[54文档集中核查](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[54文档集中核查]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**文档阶段集中离线核对完成（2026-10-27）。** '+body+' 见[54]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [54文档集中离线核对](Project/'+name+')已完成：搜索续页、较大任务卡下的读取展示和交接提示已补，47项检查及30组组合通过。本轮没有真实模型调用；新版完整三角色仍未真实验收通过。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[54文档集中核查](../shixi_project/Project/'+name+')：'+body)
sources=['scripts/document_agent.py','scripts/document_model.py','scripts/collaboration_runtime.py','scripts/test_document_context.py']
(OUT/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--',*sources],cwd=ROOT))
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6 and not any(k in raw for k in keys),'Credential found; value withheld'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern found'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();members={}
names=['audit.py','finish.py','audit-result.json','audit-result-final.json','audit-result-before-json-margin.json','audit-result-verified.json',
    'document-model-before.py','before-card-test.txt','before-page-test.txt','context-tests.txt','card-test-final.txt',
    'document-tests-final.txt','document-tests-final-2.txt','protection-check.json','source-change.patch']
with zipfile.ZipFile(DEST/'offline-evidence.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n in names:
        raw=(OUT/n).read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
with zipfile.ZipFile(DEST/'offline-evidence.zip') as z:assert all(sha(z.read(n))==h for n,h in members.items())
write(DEST/'offline-evidence.zip.sha256.json',members)
write(DEST/'manifest.json',{'stage':54,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'result':'offline_document_audit_complete_not_real_three_role_acceptance','protection':check,'audit':audit,
    'credential_scan':{'keys_checked':2,'objects':scanned,'matches':0},'formal_database_and_ledger_not_uploaded':True})
write(DEST/'artifact_sha256.json',{p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()})
print(json.dumps({k:v for k,v in check.items() if k not in {'historical_files_sha256','old_stage53_freeze_cumulative_invalidated_files'}}))
