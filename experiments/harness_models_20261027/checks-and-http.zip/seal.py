import hashlib
import json
from pathlib import Path
import zipfile
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_models_20261027'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Do not overwrite sealed evidence'
reports={name:json.loads((OUT/(name+'.json')).read_bytes()) for name in [
    'protocol-check','continuation-check','wire-replay','http-check','ui-check','panel-restored','protection-check']}
assert reports['continuation-check']['repair_result']=='passed' and reports['continuation-check']['source_unchanged']
assert reports['wire-replay']['requests_converted']==15
for name,count in [('compatibility.log',7),('normalization-compatibility.log',2)]:
    text=(OUT/name).read_text(encoding='utf-8');assert ('Ran '+str(count)+' tests') in text and text.rstrip().endswith('OK')
old=ROOT/'experiments/harness_runtime_20261026'
old_hashes=json.loads((old/'artifact_sha256.json').read_bytes())
assert all(sha((old/name).read_bytes())==v for name,v in old_hashes.items())
sources=['model_profiles.py','model_protocols.py','model_profile_panel.js','run_deepseek_smoke.py','review_model.py',
    'collaboration_runtime.py','collaboration_store.py','collaboration_panel.py','collaboration_live.py','task_service_store.py',
    'task_service_worker.py','task_service.py','harness_checkpoints.py','document_agent_demo.py','task_panel.html']
docs=[ROOT/'Project/41_过程_模型能力声明与角色绑定及Messages离线适配.md',ROOT/'Project/00_项目现状与快速接手.md',
    ROOT/'Project/项目开发流水账.md',ROOT/'AGENTS.md',ROOT/'README.md',ROOT/'GITHUB_SETUP.md',ROOT.parent/'job/AGENTS.md']
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(keys)==2
DEST.mkdir();outer={};counts={};scanned=0
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p,label in entries:
            if not p.is_file() or p.name in {'.env','server.lock','worker.lock','panel.log','panel-error.log'} or '__pycache__' in p.parts:continue
            raw=p.read_bytes();assert not any(k in raw for k in keys),'Credential scan blocked archive'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(k))==v for k,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes());outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
    counts[name]=len(members)
pack('source-and-documents.zip',[(ROOT/'scripts'/n,'scripts/'+n) for n in sources]+
    [(ROOT/'configs/model_profiles_v1.json','configs/model_profiles_v1.json')]+
    [(p,p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else 'job/AGENTS.md') for p in docs])
pack('checks-and-http.zip',[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.rglob('*'))])
home=Path(reports['continuation-check']['store_home'])
pack('scripted-pause-and-continuation.zip',[(p,p.relative_to(home).as_posix()) for p in sorted(home.rglob('*'))])
result={**reports['protection-check'],'scope':'Original model route capability declaration and role binding; second-vendor Messages codec is offline-only without live transport.',
    'reports':reports,'old_execution_delivery_files_verified':len(old_hashes),'archive_member_counts':counts,
    'credential_scan':{'keys_checked':2,'files_scanned':scanned,'matches':0},'distinct_existing_compatibility_checks_passed':7,
    'targeted_compatibility_repetitions':2,'full_regression_run':False,'new_formal_test_files':0,'browser_clicks_verified':False,
    'pending':['Authorized second-vendor transport/account/pricing/shared settlement','Real model behavior and quality',
        'Browser clicks','Full default and adapter regression','Consolidated system acceptance','Same-task initial-baseline comparison']}
write(DEST/'verification.json',result);outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'old_execution_delivery_files_verified':len(old_hashes),
    'protected_files':result['protected_old_files_hash_verified'],'formal_rows':result['formal_payloads_unchanged'],'ledger_requests':result['shared_ledger_requests']},ensure_ascii=False))
