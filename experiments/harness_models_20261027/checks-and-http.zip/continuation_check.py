import json
import os
from pathlib import Path
import sys
import uuid
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
from document_agent_demo import exercise
from harness_checkpoints import request_pause,continue_checkpoint,checkpoint_view
from task_cards import card_view
from collaboration_panel import usage_view
from model_profiles import validate_record,ModelConfigurationError
card={'goal':'保留原模型路由与角色配置','steps':[{'id':'work','title':'修复并核查','status':'pending'}]}
def boundary(name,role,runner):
    if name=='after_role_completion' and role['phase']=='consulting':request_pause(runner.store,runner.run_id)
store,first,summary,wires=exercise(allow_pause=True,allow_capabilities=True,model_profile='legacy_deepseek_v1',task_card=card,checkpoint=boundary)
source=summary['run'];assert source['status']=='paused',source
before=store.get(source['id']);view=checkpoint_view(store,source['id'])
bad=dict(source,model_profile_sha256='0'*64)
try:validate_record(bad,phases=[r['phase'] for r in store.roles(source['id'])])
except ModelConfigurationError:pass
else:raise AssertionError('Altered profile accepted')
child=continue_checkpoint(store,source['id'],{'request_key':'models-'+uuid.uuid4().hex,'checkpoint_sha256':view['checkpoint_sha256'],
    'task_card':card_view(store,source['id'])['card']})
assert child['model_profile_snapshot']==source['model_profile_snapshot'] and child['model_profile_sha256']==source['model_profile_sha256']
store,runner,final,new_wires=exercise(continuation={'home':str(store.home),'run_id':child['id']})
assert final['run']['status']=='finished' and final['run']['repair_result']=='passed' and final['run']['review_verdict']=='approve',final['run']
assert store.get(source['id'])==before and 'consulting' not in final['counts']
usage=usage_view(store,store.get(child['id']))
assert usage['lineage']['attempts']==len(wires)+len(new_wires)
report={'store_home':str(store.home),'source':source['id'],'child':child['id'],'source_unchanged':True,'model_profile_inherited':True,
    'role_bindings':child['model_profile_snapshot']['role_bindings'],'bad_profile_rejected':True,'completed_roles_not_repeated':True,
    'repair_result':'passed','review_verdict':'approve','counts':{'before':summary['counts'],'after':final['counts']},
    'lineage_usage':usage['lineage'],'external_model_calls':0,'model_profile_artifact':str(runner.output/'model-profile.json')}
(OUT/'continuation-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
