from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'scripts/task_panel.html';text=p.read_text(encoding='utf-8')
old='<label><input id="allowCapabilities"'
assert text.count(old)==1
text=text.replace(old,'<label for="modelProfile">模型能力配置</label><select id="modelProfile" disabled></select><p id="modelProfileDetails" class="hint">正在读取本地能力声明，不探测账号或调用模型。</p>'+old)
old="if($('allowCapabilities').checked)request.allow_capabilities=true;"
assert text.count(old)==1
text=text.replace(old,old+"if(typeof modelProfileCreation==='function'){const selectedModelProfile=modelProfileCreation();if(selectedModelProfile)request.model_profile=selectedModelProfile;}")
old='<script src="/execution-panel.js"></script>'
assert text.count(old)==1
text=text.replace(old,old+'<script src="/model-profile-panel.js"></script>')
old='<p id="capabilityRunState" class="hint" hidden></p>'
assert text.count(old)==1
text=text.replace(old,old+'<p id="modelProfileRunState" class="hint"></p>')
p.write_text(text,encoding='utf-8')
