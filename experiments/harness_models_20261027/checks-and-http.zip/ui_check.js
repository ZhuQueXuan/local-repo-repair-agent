const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('configs/model_profiles_v1.json','utf8'),catalog=JSON.parse(source);
function el(){return{value:'',children:[],addEventListener(type,fn){this.listener=fn},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const elements={mode:el(),modelProfile:el(),modelProfileDetails:el(),modelProfileRunState:el()};elements.mode.value='live';
let calls=0;
const context={$:id=>elements[id],node:(type,label)=>Object.assign(el(),{type,textContent:label}),text:(node,text)=>{node.textContent=text},
    display:()=>{},choices:()=>{},api:async path=>{calls++;assert(path==='/api/model-profiles');return catalog}};
vm.createContext(context);vm.runInContext(fs.readFileSync('scripts/model_profile_panel.js','utf8'),context);
(async()=>{
    await new Promise(resolve=>setImmediate(resolve));assert(calls===1&&!elements.modelProfile.disabled);
    assert(elements.modelProfile.children[1].disabled);
    assert(context.modelProfileCreation()==='legacy_deepseek_v1');
    elements.modelProfile.value='anthropic_messages_offline_v1';assert.throws(()=>context.modelProfileCreation());
    elements.mode.value='replay';elements.mode.listener();assert(elements.modelProfile.disabled&&context.modelProfileCreation()===undefined);
    context.display({kind:'history'});assert(elements.modelProfileRunState.textContent.includes('不补造'));
    const html=fs.readFileSync('scripts/task_panel.html','utf8');new vm.Script(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
    fs.writeFileSync('temp/harness_models_20261027/ui-check.json',JSON.stringify({scope:'Node fake DOM, not browser clicks',candidate_disabled:true,replay_no_model:true,old_records_not_rewritten:true,no_account_probe:true,inline_syntax:true},null,2));
    console.log('UI basic checks passed (fake DOM, not browser clicks)');
})().catch(e=>{console.error(e);process.exitCode=1});
