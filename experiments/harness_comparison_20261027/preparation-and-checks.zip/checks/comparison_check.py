"""Necessary comparison gates and real final-patch replay, never a model result."""
import json,os,sys,uuid
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
import comparison_batch as batch
from task_service_store import RunStore
from task_workspace import prepare_task,load_task
from task_service_worker import collect_patch
from evaluation_preparation import apply_reference
home=ROOT/'temp/comparison_batches/cmp1027'
plan=batch.verify(home)
assert len(plan['slots'])==12
for bad in ('../evaluator','unknown-task','click-fixture-fast-deep-equal'):
    try:batch.public_task(bad)
    except ValueError:pass
    else:raise AssertionError('Nonpublic task accepted')
q=json.loads((home/'qualification.json').read_bytes())
assert sum(v['reference']['public']['tests_run'] for v in q.values())==12
assert sum(v['reference']['withheld']['tests_run'] for v in q.values())==19
copied=ROOT/'temp/comparison_batches'/('copy-rejection-'+uuid.uuid4().hex);copied.mkdir()
for name in ('plan.json','plan-sha256.json'):(copied/name).write_bytes((home/name).read_bytes())
try:batch.verify(copied)
except ValueError as e:assert 'identity' in str(e)
else:raise AssertionError('Copied launch packet accepted')
auth=OUT/'unapproved-comparison-fixture.json';auth.write_text('{}')
with patch('litellm.completion',side_effect=AssertionError('No model in comparison check')):
    try:batch.execute(home,auth)
    except ValueError as e:assert 'approval' in str(e)
    else:raise AssertionError('Unapproved batch dispatched')
assert not (home/'dispatched.json').exists()
with patch('execution_runtime.runtime_identity',return_value={'changed':True}):
    try:batch.verify(home)
    except ValueError as e:assert 'environment' in str(e)
    else:raise AssertionError('Changed runtime accepted')
fixture=ROOT/'temp/comparison_batches'/('scoring-fixture-'+uuid.uuid4().hex);fixture.mkdir()
store=RunStore(fixture/'store');slots=[]
for slot in plan['slots']:
    row=store.create(slot['task'],'raw','live','fixture-'+uuid.uuid4().hex)
    slots.append({**slot,'run_id':row['id']})
with patch.object(batch,'evaluator',side_effect=AssertionError('Retained checks before terminal')) as e:
    try:batch.score(fixture,store,slots)
    except ValueError as error:assert 'terminal' in str(error)
    else:raise AssertionError('Scoring accepted active task')
    e.assert_not_called()
for slot in slots:store.update(slot['run_id'],status='failed',stage='done',repair_result='unknown')
first=slots[0];repo,manifest=prepare_task(first['task'])
reference=json.loads((batch.PACKET/'evaluator'/first['task']/'reference.json').read_bytes())
apply_reference(repo,manifest,reference['edits'])
output=store.home/'runs'/first['run_id'];output.mkdir(parents=True)
collect_patch(first['task'],repo,output,manifest)
with patch('litellm.completion',side_effect=AssertionError('No model in final scorer')):
    report=batch.score(fixture,store,slots)
assert len(report['results'])==12 and report['resolved']=={'baseline':1,'full':0}
assert all(report['results'][0]['checks'][k]['successful'] for k in ('public','withheld','upstream'))
assert sum('evaluation_error' in r for r in report['results'])==11
assert all(n!='evaluator' for n in (p.name for p in repo.iterdir()))
result={'scope':'Synthetic terminal records and one trusted reference patch; real independent clean replay/scoring, no Agent comparison result.',
 'plan_verified':12,'public_check_methods':12,'withheld_check_methods':19,
 'gates':['public task allowlist','copied packet rejected','exact approval required before records','runtime mismatch rejected',
 'retained scorer rejects active batch','clean reference patch public/withheld/upstream passes','11 no-candidate failures retained, denominator12'],
 'fixture_home':str(fixture),'copied_packet_rejection':str(copied),'external_model_calls':0,'batch_dispatched':False}
(OUT/'comparison-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
