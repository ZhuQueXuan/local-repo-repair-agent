"""Actual new-task worker wiring with trusted reference edits and synthetic transport."""
import json,os,sys,uuid
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
from comparison_inputs import PACKET
from task_service_store import RunStore
from task_service_worker import run_one
from deepseek_budget import SharedBudget,load_budget_config
from evaluation_preparation import apply_reference
from task_workspace import load_task
from self_review_demo import response
task='boltons-addlist-iterator';_,manifest=load_task(task)
reference=json.loads((PACKET/'evaluator'/task/'reference.json').read_bytes())
home=ROOT/'temp'/('cw-'+uuid.uuid4().hex);store=RunStore(home)
row=store.create(task,'raw','live',uuid.uuid4().hex,model_profile='legacy_deepseek_v1')
ledger=home/'synthetic_ledger.json';ledger.write_text(json.dumps({'historical_estimated_cost_cny':'0','historical_unknown_charge_reservation_cny':'0','blocked':False,'requests':{}}))
budget=SharedBudget(load_budget_config(),ledger_path=ledger,temp_dir=home/'locks')
calls=[]
def transport(**kwargs):
    calls.append(kwargs['messages'])
    apply_reference(Path(store.get(row['id'])['workspace']),manifest,reference['edits'])
    return response('bash',{'command':'echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT'})
settings={'DEEPSEEK_API_KEY':'synthetic-comparison-key','DEEPSEEK_API_BASE_URL':'https://api.deepseek.com','DEEPSEEK_CHAT_MODEL':'deepseek-flash'}
with patch('dotenv.dotenv_values',return_value=settings),patch('task_service_worker.RunBudget',return_value=budget),patch('litellm.completion',side_effect=transport):
    run_one(store,row['id'])
raw=store.get(row['id']);assert raw['status']=='finished' and raw['repair_result']=='passed',raw
# Reuse the existing full scripted demo, adapting only the task and trusted
# reference edit branch. No hidden check/reference is put in any API-view prompt.
source=(ROOT/'scripts/document_agent_demo.py').read_text(encoding='utf-8')
source=source.replace('"split-after-boundary"','"boltons-addlist-iterator"')
begin=source.index('            before, after = ');end=source.index('\n        data = next(',begin)
source=source[:begin]+'''            apply_reference(runner.work,runner.manifest,reference['edits'])
            return response("bash",{"command":"python -B -m unittest discover -s task_checks -v"},"SYNTHETIC_REFERENCE_EDIT")
'''+source[end:]
namespace={'__name__':'comparison_wire_fixture','__file__':str(ROOT/'scripts/document_agent_demo.py'),
 'apply_reference':apply_reference,'reference':reference}
exec(compile(source,'comparison_fixture_driver','exec'),namespace)
full_store,runner,summary,wires=namespace['exercise'](scenario='approve',allow_capabilities=True,model_profile='legacy_deepseek_v1',
    task_card={'goal':'Synthetic new-task wiring, not model effectiveness','steps':[{'id':'fix','title':'Repair','status':'pending'}]})
assert summary['run']['status']=='finished' and summary['run']['repair_result']=='passed' and summary['run']['review_verdict']=='approve'
report={'scope':'Raw existing worker and full existing scripted-demo core on a newly supported fixed comparison task; trusted reference edits, synthetic model replies/usage. Not a real comparison.',
 'task':task,'raw_store':str(home),'raw_run':row['id'],'raw_result':raw['repair_result'],'raw_calls':len(calls),
 'full_store':str(full_store.home),'full_run':summary['run_id'],'full_result':summary['run']['repair_result'],
 'full_verdict':summary['run']['review_verdict'],'full_counts':summary['counts'],'external_model_calls':0}
(OUT/'comparison-wires.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
