import hashlib,io,json,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/cmp1027'
DEST=ROOT/'experiments/harness_comparison_20261027/results'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists()
audit=json.loads((OUT/'comparison-audit.json').read_bytes());plan=json.loads((HOME/'plan.json').read_bytes())
assert audit['all_twelve_retained'] and all(sha((ROOT/n).read_bytes())==h for n,h in plan['files_sha256'].items())
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
DEST.mkdir();outer={};counts={};scanned=0
def scan(raw,depth=0):
 global scanned
 assert depth<=6 and not any(k in raw for k in keys);scanned+=1
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if n.endswith('/'):continue
    assert Path(n).name!='.env' and not Path(n).name.startswith('.env.')
    scan(z.read(n),depth+1)
def pack(name,entries):
 members={}
 with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p,n in entries:
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock':continue
   assert p.name!='.env' and not p.name.startswith('.env.')
   raw=p.read_bytes();scan(raw);assert n not in members;members[n]=sha(raw);z.writestr(n,raw)
 with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
 write(DEST/(name+'.sha256.json'),members)
 for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
 counts[name]=len(members)
pack('all-twelve-runs.zip',[(p,p.relative_to(HOME).as_posix()) for p in sorted((HOME/'store').rglob('*')) if p.is_file()]+
 [(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.glob('*.log'))])
files=['plan.json','plan-sha256.json','authorization.json','dispatched.json','slots.json','comparison-summary.json','terminal-results.json']
entries=[(HOME/n,'batch/'+n) for n in files]
entries += [(p,p.relative_to(HOME).as_posix()) for p in sorted((HOME/'terminal-scores').rglob('*')) if p.is_file()]
checks=['comparison-audit.json','audit_comparison.py','comparison-user-approval.json','comparison-live.log','replay_document_stops.py','document-stop-replay.json','write_comparison_report.py','seal_results.py']
entries += [(OUT/n,'checks/'+n) for n in checks]
entries += [(p,'checks/'+p.name) for p in sorted(OUT.glob('replayed-*.json'))]
entries.append((ROOT/'Project/46_评测_原版与完整Harness六题对照.md','Project/46_评测_原版与完整Harness六题对照.md'))
pack('scores-and-audit.zip',entries)
replay=json.loads((OUT/'document-stop-replay.json').read_bytes())
write(DEST/'verification.json',audit|{'archive_members':counts,'credential_scan':{'keys_checked':2,'nested_members_scanned':scanned,'matches':0},
 'document_failure_replays':replay,'provider_destinations':plan['destinations'],'extra_paid_retries':0,'formal_database_and_shared_ledger_full_not_uploaded':True,
 'test_scope':'23 existing service checks + six baseline/reference qualifications + synthetic two-arm/gate checks; no new full default/adapter repeat.'})
outer['verification.json']=sha((DEST/'verification.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'scanned':scanned,'credential_matches':0,'all_twelve_retained':True,'resolved':{k:v['resolved'] for k,v in audit['arms'].items()}}))
