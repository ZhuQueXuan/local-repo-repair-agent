import hashlib,json,sqlite3,sys
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/cmp1027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from comparison_batch import verify
plan=verify(HOME);slots=json.loads((HOME/'slots.json').read_bytes())
summary=json.loads((HOME/'comparison-summary.json').read_bytes());results=summary['results']
assert len(slots)==len(results)==12 and len({s['run_id'] for s in slots})==12
assert [s['request_key'] for s in slots]==[s['request_key'] for s in plan['slots']]
assert all(r['run_id']==s['run_id'] for r,s in zip(results,slots))
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==json.loads((OUT/'comparison-formal-before.json').read_bytes())
with sqlite3.connect(HOME/'store/runs.sqlite3') as db:
    rows={n:json.loads(p) for n,p in db.execute('SELECT id,payload FROM runs')}
    events=[(r,json.loads(p)) for r,p in db.execute("SELECT run_id,payload FROM events WHERE kind='usage_reserved'")]
assert set(rows)=={s['run_id'] for s in slots}
assert all(r['status'] in {'finished','failed','cancelled','interrupted'} for r in rows.values())
before=json.loads((OUT/'comparison-ledger-before.json').read_bytes())
after=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
assert all(after['requests'][k]==v for k,v in before['requests'].items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
owners={};fees={}
for slot in slots:
    run=slot['run_id'];tickets={k for k,v in new.items() if v.get('attribution',{}).get('run_id')==run}
    tickets.update(e['ticket'] for r,e in events if r==run)
    assert tickets<=set(new)
    for t in tickets:assert t not in owners;owners[t]=run
    receipts=[new[t] for t in tickets]
    known=sum((Decimal(r['amount_cny']) for r in receipts if r['status']=='settled'),Decimal(0))
    unknown=sum((Decimal(r['amount_cny']) for r in receipts if r['status']!='settled'),Decimal(0))
    fees[run]={'attempts':len(tickets),'known_price_estimate_cny':str(known),'unknown_placeholder_cny':str(unknown),
        'unknown_attempts':sum(r['status']!='settled' for r in receipts),'complete_cost_estimate_cny':str(known) if not unknown else None}
assert set(owners)==set(new),'Missing or unowned receipt'
arms={}
for arm in ('baseline','full'):
    selected=[r for r in results if r['variant']==arm]
    ids=[r['run_id'] for r in selected]
    arms[arm]={'slots':len(selected),'resolved':sum(r['resolved'] for r in selected),
       'statuses':{status:sum(r['status']==status for r in selected) for status in sorted({r['status'] for r in selected})},
       'approve_and_resolved':sum(r['resolved'] and r.get('review_verdict')=='approve' and r['status']=='finished' for r in selected),
       'attempts':sum(fees[n]['attempts'] for n in ids),
       'known_price_estimate_cny':str(sum((Decimal(fees[n]['known_price_estimate_cny']) for n in ids),Decimal(0))),
       'unknown_placeholder_cny':str(sum((Decimal(fees[n]['unknown_placeholder_cny']) for n in ids),Decimal(0))),
       'total_elapsed_seconds':round(sum(float(r.get('metrics',{}).get('total_elapsed_seconds',0)) for r in selected),3)}
pairs=summary['pairs'];full_only=[t for t,p in pairs.items() if p['full'] and not p['baseline']];baseline_only=[t for t,p in pairs.items() if p['baseline'] and not p['full']]
report={'scope':'One predeclared six-public-task/twelve-slot original-raw versus full-system comparison; no retries, no causal module attribution or broad benchmark claim.',
 'batch_plan_sha256':hashlib.sha256((HOME/'plan.json').read_bytes()).hexdigest(),'arms':arms,'pairs':pairs,
 'full_only_resolved':full_only,'baseline_only_resolved':baseline_only,'all_twelve_retained':True,
 'formal_rows_unchanged':len(formal),'old_shared_requests_unchanged':len(before['requests']),'new_attempts':len(new),
 'shared_requests_after':len(after['requests']),'fees_by_run':fees,
 'rows':[{k:r.get(k) for k in ('task','variant','run_id','status','agent_exit','collaboration_result','repair_result','review_verdict','resolved','evaluation_error','candidate_selection')} for r in results],
 'freeze_verified_after':len(plan['files_sha256']),'fresh_machine':'excluded_by_user_20261027'}
(OUT/'comparison-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'comparison-ledger-after.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
print(json.dumps({'arms':arms,'new_attempts':len(new),'shared_requests_after':report['shared_requests_after']},ensure_ascii=False))
