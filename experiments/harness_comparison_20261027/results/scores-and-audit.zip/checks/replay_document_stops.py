"""Replay stored actions through the frozen-current readonly loop, no model calls."""
import json,sys
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/cmp1027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent import DocumentSnapshot,DocumentGrant,DocumentBroker
from collaboration_protocol import RoleIdentity,ProtocolError,canonical_bytes
from collaboration_runtime import run_document_consultation
import sqlite3
with sqlite3.connect(HOME/'store/runs.sqlite3') as db:
    parents={n:json.loads(p) for n,p in db.execute('SELECT id,payload FROM runs')}
    roles=[json.loads(p) for (p,) in db.execute('SELECT payload FROM role_runs')]
results=[]
for run,parent in parents.items():
    if parent['kind']!='collaboration_live' or parent['status'] not in {'failed','finished'}:continue
    role=next(r for r in roles if r['run_id']==run and r['phase']=='consulting')
    if role['status']!='failed':continue
    path=HOME/'store/runs'/run/'consulting-trajectory.json'
    if not path.is_file():continue
    history=json.loads(path.read_bytes())['messages']
    actions=[m for m in history if m.get('role')=='assistant' and m.get('extra',{}).get('actions')]
    tools={a['tool'] for m in actions for a in m['extra']['actions']}
    if not tools<={'read_lines','search_text','submit_consultation'}:
        results.append({'run_id':run,'task':parent['task'],'status':'needs_capability_replay','tools':sorted(tools)});continue
    directory=HOME/'store/document_snapshots'/run/role['id']
    grant=DocumentGrant.parse(json.loads((directory/'grant.json').read_bytes()))
    identity=RoleIdentity(run_id=run,role_run_id=role['id'],session_id=role['session_id'],role='document_reader')
    broker=DocumentBroker(DocumentSnapshot(directory,grant),identity)
    class ReplayModel:
        usage=[]
        def __init__(self):self.messages=iter(actions);self.calls=0
        def query(self,messages):self.calls+=1;return next(self.messages)
        def contains_credentials(self,text):return False
        def format_observation_messages(self,message,outputs):
            return [{'role':'tool','tool_call_id':a['tool_call_id'],'content':canonical_bytes(v).decode()} for a,v in zip(message['extra']['actions'],outputs)]
    model=ReplayModel();context=SimpleNamespace(identity=identity,check=lambda:None)
    try:
        run_document_consultation(model,broker,context,OUT/('replayed-'+run+'.json'),'Offline diagnosis; actual recorded tool arguments, no model')
        result='completed'
    except Exception as error:result=type(error).__name__+': '+str(error)
    results.append({'run_id':run,'task':parent['task'],'recorded_assistant_actions':len(actions),
        'replayed_requests':model.calls,'reason':result,'external_model_calls':0})
(OUT/'document-stop-replay.json').write_text(json.dumps({'scope':'Offline exact stored actions, original read-only broker/loop; no source modification or model retry.','results':results},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False))
