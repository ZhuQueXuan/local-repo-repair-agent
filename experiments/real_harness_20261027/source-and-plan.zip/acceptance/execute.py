"""One explicitly approved public-task acceptance; no replacement dispatch."""
import hashlib,json,re,sqlite3,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
plan=json.loads((OUT/'acceptance-plan.json').read_bytes())
assert sha((OUT/'acceptance-plan.json').read_bytes())==json.loads((OUT/'plan-digest.json').read_bytes())['sha256']
assert not (OUT/'dispatched.json').exists(),'Use existing identity; no second dispatch'
for n,h in plan['files_sha256'].items():assert sha((ROOT/n).read_bytes())==h,n
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows=dict(db.execute('SELECT id,payload FROM runs'))
 assert len(rows)==52 and not any(json.loads(v)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for v in rows.values())
 with sqlite3.connect(OUT/'before.sqlite3') as target:db.backup(target)
write('payloads-before.json',rows)
(OUT/'ledger-before.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
base='http://127.0.0.1:8765'
with urllib.request.urlopen(base+'/',timeout=10) as response:html=response.read().decode('utf-8')
token=re.search(r"const token='([^']+)'",html).group(1)
def api(path,body=None):
 request=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),headers={'X-Task-Token':token,'Origin':base,'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=20) as response:return json.load(response)
write('authorization.json',{'approved':True,'source':'User answered 批准这一次真实验收 to the concrete data/destination/fee question in this conversation.',
 'plan_sha256':sha((OUT/'acceptance-plan.json').read_bytes()),'maximum_runs':1,'no_selection_reruns':True})
write('dispatched.json',{'request_key':plan['request']['request_key'],'plan_sha256':sha((OUT/'acceptance-plan.json').read_bytes()),'state':'dispatching'})
parent=api('/api/runs',plan['request']);write('parent.json',parent)
print(json.dumps({'run_id':parent['id'],'status':parent['status']}),flush=True)
until=time.monotonic()+1860;last=None
while time.monotonic()<until:
 current=api('/api/runs/'+parent['id']);marker=(current['status'],current.get('stage'))
 if marker!=last:print(json.dumps({'status':marker[0],'stage':marker[1]}),flush=True);last=marker
 write('latest.json',current)
 if current['status'] not in {'queued','running','cancel_requested'} and current.get('live_receipts_digest'):
  write('result.json',current);write('collaboration.json',api('/api/runs/'+parent['id']+'/collaboration'));print(json.dumps({'finished':current['status'],'repair_result':current.get('repair_result'),'review_verdict':current.get('review_verdict')}),flush=True);break
 time.sleep(2)
else:write('observer-limit.json',{'run_id':parent['id'],'action':'Inspect same identity, do not create replacement'})
