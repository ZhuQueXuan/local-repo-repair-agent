import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
plan=json.loads((OUT/'acceptance-plan.json').read_bytes())
assert all(sha((ROOT/n).read_bytes())==h for n,h in plan['files_sha256'].items())
row=json.loads((OUT/'result.json').read_bytes());run=ROOT/'data/task_service/runs'/row['id']
assert row['status']=='finished' and row['repair_result']=='passed' and row['review_verdict']=='approve' and row['collaboration_result']=='completed'
original=json.loads((OUT/'payloads-before.json').read_bytes())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 current=dict(db.execute('SELECT id,payload FROM runs'))
 assert set(current)-set(original)=={row['id']}
 assert all(current[n]==v for n,v in original.items())
 assert not any(json.loads(v)['status'] in {'queued','running','cancel_requested'} for v in current.values())
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes());old=json.loads((OUT/'ledger-before.json').read_bytes())
assert all(ledger['requests'][k]==v for k,v in old['requests'].items())
new={k:v for k,v in ledger['requests'].items() if k not in old['requests']}
assert len(new)==19 and len(ledger['requests'])==2035
assert all(v['attribution']['run_id']==row['id'] for v in new.values())
reports={n:json.loads((run/n/'report.json').read_bytes()) for n in ['baseline','repairing-verification','patch-replay']}
baseline=reports['baseline']['full_upstream_suite']
for r in [reports['repairing-verification'],reports['patch-replay']]:
 assert r['task_tests_passed'] and r['issue_checks']['tests_run']==10 and r['upstream_targeted']['tests_run']==4
 assert set(r['full_upstream_suite']['failures']+r['full_upstream_suite']['errors'])<=set(baseline['failures']+baseline['errors'])
collab=json.loads((OUT/'collaboration.json').read_bytes())
assert [r['status'] for r in collab['roles']]==['succeeded','succeeded','succeeded','skipped','skipped']
tools={p.name:json.loads(p.read_bytes())['receipts'] for p in run.glob('*tool-registry.json')}
summary={'scope':'One explicitly approved current Harness integration on known public issue, not new-task effectiveness.',
 'run_id':row['id'],'status':'finished','repair_result':'passed','review_verdict':'approve','collaboration_result':'completed',
 'roles':[{k:r.get(k) for k in ('phase','status','elapsed_seconds')} for r in collab['roles']],
 'total_elapsed_seconds':collab['total_elapsed_seconds'],'issue_before':reports['baseline']['issue_checks']['passed'],'issue_after':10,
 'targeted_passed':4,'extended_suite_passed':659,'extended_suite_total':660,
 'retained_baseline_failure':'test_more.TimeLimitedTests.test_zero_limit','clean_patch_replay':True,'new_regressions':[],
 'usage':collab['usage'],'formal_runs_before':52,'formal_runs_after':53,'old_payloads_unchanged':52,
 'shared_requests_before':2016,'shared_requests_after':2035,'old_requests_unchanged':2016,'new_attempts':19,
 'optional_skills_and_mcp_registered':True,'optional_skill_or_mcp_calls_in_this_live_run':sum(r['tool'] in {'read_skill','read_change_summary'} for rs in tools.values() for r in rs),
 'note':'Enabled registry does not prove model chose new tools. No real skill/MCP usage claim for this task.',
 'browser':'Work settings disabled at this turn; actual live browser not exercised, no request cancellation or pause triggered.',
 'fresh_machine':'excluded_by_user_20261027','all_229_frozen_inputs_match':True,'no_selection_reruns':True}
(OUT/'audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ledger-after.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
print(json.dumps({k:summary[k] for k in ['run_id','status','repair_result','review_verdict','formal_runs_after','shared_requests_after','optional_skill_or_mcp_calls_in_this_live_run']},ensure_ascii=False))
