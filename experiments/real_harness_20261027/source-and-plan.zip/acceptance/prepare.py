import hashlib,json,os,sys,uuid,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',MSWEA_SILENT_STARTUP='1',PYTHONDONTWRITEBYTECODE='1')
from task_service_worker import freeze_inputs
from collaboration_panel import public_policy
from execution_runtime import runtime_identity
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
plan_path=OUT/'acceptance-plan.json';assert not plan_path.exists()
scope=ROOT/'configs/final_acceptance_scope_v1.json'
text=scope.read_text(encoding='utf-8')
text=text.replace('"status": "not_verified", "criteria": ["recursive submodules"','"status": "excluded_by_user_20261027", "required": false, "criteria": ["recursive submodules"')
value=json.loads(text);assert next(x for x in value['acceptance_layers'] if x['id']=='fresh_machine')['required'] is False
text=text.replace('"next_step": ', '"user_scope_20261027": "Only current original-route real-model acceptance and same-task effectiveness comparison; fresh-machine installation explicitly excluded. This scope document still cannot dispatch.",\n  "next_step": ',1)
scope.write_bytes(text.encode('utf-8'))
notice='2026-10-27用户明确：取消异机安装验证；后续仅推进当前原路由真实模型全链路验收与原baseline/完整多Agent同题效果比较。真实接入先一个已知公开题的新冻结身份，沿用共享路由/费用，不恢复旧身份或重跑选优；效果比较需先补终态评分/批次门控及新冻结。详情见44。'
for p,marker in [(ROOT/'AGENTS.md','## 当前阶段'),(ROOT.parent/'job/AGENTS.md','## 当前状态与导航')]:
 s=p.read_text(encoding='utf-8');assert notice not in s;s=s.replace(marker,marker+'\n\n- '+notice,1);p.write_bytes(s.encode('utf-8'))
p=ROOT/'Project/00_项目现状与快速接手.md';s=p.read_text(encoding='utf-8');s=s.replace('最后更新：2026-10-27。','最后更新：2026-10-27。\n\n'+notice,1);p.write_bytes(s.encode('utf-8'))
p=ROOT/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('页面观察实际worker暂停及空白机器安装仍待验证。','页面观察实际worker暂停仍待验证。用户已取消异机安装验证，该项不再作为本轮门槛。');p.write_bytes(s.encode('utf-8'))
p=ROOT/'GITHUB_SETUP.md';s=p.read_text(encoding='utf-8');s+='\n\n2026-10-27用户取消异机安装验证；未执行且不再列为本轮验收门槛。接下来只做当前原路由真实接入和同题效果比较。安装步骤仍供参考，不声明在新机器实测通过。\n';p.write_bytes(s.encode('utf-8'))
question='Find the frozen changelog entries mentioning split_after or maxsplit. Cite the exact entries, state only what they establish, and list the input or boundary behavior they do not specify. A changelog is not a complete API contract; submit explicit unknowns rather than searching unrelated release history.'
body={'task':'split-after-boundary','profile':'adaptive_history','mode':'live','collaboration_mode':'document_review','policy_version':1,
 'document_question':question,'request_key':'harness-final-'+uuid.uuid4().hex,'model_profile':'legacy_deepseek_v1',
 'task_card':{'schema_version':1,'goal':'按原始问题完成受约束修复，以程序检查和独立审查为准。','steps':[{'id':'read','title':'查阅文档并明确未知','status':'pending'},{'id':'repair','title':'修复并完成程序检查','status':'pending'},{'id':'review','title':'独立审查并最多返工一次','status':'pending'}],
 'constraints':'不得修改检查或任务描述；方法包和变更概览不是验收证据。','instruction':'保留失败与未知，不循环到成功。','blocker':'','next_action':'先查阅指定文档问题'},
 'allow_capabilities':True,'allow_pause':True}
frozen=freeze_inputs('split-after-boundary',OUT)
for p in (ROOT/'configs').glob('*.json'):frozen[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
plan={'schema_version':1,'state':'prepared_for_user_requested_live_acceptance','authorization_basis':'User explicitly requested only the first two tasks (real-model acceptance and same-task comparison), after reviewing stage43 results; fresh-machine excluded.',
 'request':body,'policy':public_policy(documents=True,question=question),'files_sha256':dict(sorted(frozen.items())),
 'destinations':['https://myai.bupt.edu.cn/llm-gw/v1','https://api.deepseek.com'],
 'external_content':['fixed public task source','patch','checks results','role conversations','human task card','local skills'],
 'accounting':'Existing shared ledger. No project money cap, single unknown attempt reserve 0.10 CNY is not the whole run cost; unknown platform price stays unknown.',
 'parent_seconds':1800,'max_feedback_windows':1,'maximum_new_runs':1,'no_selection_reruns':True,
 'pause_scope':'Enabled contract but no planned pause/child, so this task can finish normally; cancellation/pause outcome not combined with successful completion.',
 'fresh_machine':'excluded_by_user','comparison_scope':'Separate preparation after this result; six old prepared tasks may be reused only through new scoring/batch freeze, no launch using old31 or v7.',
 'runtime_identity':runtime_identity(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()}
write(plan_path,plan)
write(OUT/'plan-digest.json',{'sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),'files':len(frozen),'external_model_calls':0})
print(json.dumps({'plan':str(plan_path),'files':len(frozen),'request_key':body['request_key'],'external_model_calls':0}))
