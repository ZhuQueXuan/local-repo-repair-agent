import hashlib
import json
from pathlib import Path
import zipfile
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_runtime_20261026'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Do not overwrite a sealed delivery'
reports={n:json.loads((OUT/(n+'.json')).read_bytes()) for n in ['runtime-probe','backend-check','continuation-check','http-check','ui-check','protection-check','panel-restored']}
assert reports['continuation-check']['repair_result']=='passed' and reports['continuation-check']['source_unchanged']
assert reports['backend-check']['owned_child_stopped']
for name,count in [('compatibility.log',8),('catalog-compatibility.log',2)]:
    text=(OUT/name).read_text(encoding='utf-8');assert ('Ran '+str(count)+' tests') in text and text.rstrip().endswith('OK')
old=ROOT/'experiments/harness_tools_20261026'
old_hashes=json.loads((old/'artifact_sha256.json').read_bytes())
assert all(sha((old/name).read_bytes())==expected for name,expected in old_hashes.items())
sources=['execution_backend.py','execution_runtime.py','execution_panel.js','run_deepseek_smoke.py',
    'run_task_batch.py','run_windowed_agent.py','collaboration_live.py','harness_checkpoints.py',
    'task_service.py','task_service_worker.py','task_service_store.py','task_panel.html']
documents=[ROOT/'Project/40_过程_执行后端接口与Python_Node环境声明.md',ROOT/'Project/00_项目现状与快速接手.md',
    ROOT/'Project/项目开发流水账.md',ROOT/'README.md',ROOT/'AGENTS.md',ROOT/'GITHUB_SETUP.md',ROOT.parent/'job/AGENTS.md']
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(keys)==2
DEST.mkdir();outer={};counts={};scanned=0
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,label in entries:
            if not path.is_file() or path.name in {'.env','server.lock','worker.lock'} or '__pycache__' in path.parts:continue
            raw=path.read_bytes();assert not any(k in raw for k in keys),'Credential scan rejected delivery'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(k))==v for k,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes());outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
    counts[name]=len(members)
pack('source-and-documents.zip',[(ROOT/'scripts'/n,'scripts/'+n) for n in sources]+
    [(ROOT/'configs/execution_backends_v1.json','configs/execution_backends_v1.json')]+
    [(p,p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else 'job/AGENTS.md') for p in documents])
pack('checks-and-http.zip',[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.rglob('*')) if p.name not in {'panel.log','panel-error.log'}])
home=Path(reports['continuation-check']['store_home'])
pack('scripted-pause-and-continuation.zip',[(p,p.relative_to(home).as_posix()) for p in sorted(home.rglob('*'))])
result={**reports['protection-check'],'scope':'Windows local execution backend and explicit runtime declaration/probe; not OS isolation, general JS service or real-model/system acceptance.',
    'reports':reports,'old_tools_delivery_files_verified':len(old_hashes),'archive_member_counts':counts,
    'credential_scan':{'keys_checked':2,'files_scanned':scanned,'matches':0},
    'existing_compatibility_checks_passed':10,'full_regression_run':False,'upstream_adapter_profile_run':False,
    'new_formal_test_files':0,'browser_clicks_verified':False,
    'pending':['Real browser/model acceptance','Full default and adapter regressions including six existing adapter differences',
        'Fresh-machine environment setup','Generic JS task service','OS-isolated backend','Model capability and role adaptation']}
write(DEST/'verification.json',result);outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'old_tools_delivery_files_verified':len(old_hashes),
    'protected_old_files':result['protected_old_files_hash_verified'],'formal_rows':result['formal_payloads_unchanged'],'ledger_requests':result['shared_ledger_requests']},ensure_ascii=False))
