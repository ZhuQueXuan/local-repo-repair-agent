"""Load current local panel code only when the formal store has no active work."""
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
BASE='http://127.0.0.1:8765'
token=''
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=[json.loads(row[0]) for row in db.execute('SELECT payload FROM runs')]
assert not any(row['status'] in {'queued','running','cancel_requested'} for row in rows),'Active work; do not restart'
def get(path):
    req=urllib.request.Request(BASE+path,headers={'X-Task-Token':token} if token else {})
    with urllib.request.urlopen(req,timeout=3) as response:return response.read()
ready=False
try:
    get('/api/health')
    token=re.search(r"const token='([^']+)'",get('/').decode()).group(1)
    try:
        ready=b'showExecutionReport' in get('/execution-panel.js')
    except urllib.error.HTTPError as error:
        if error.code!=404:raise
    if not ready:
        html=get('/').decode()
        token=re.search(r"const token='([^']+)'",html).group(1)
        request=urllib.request.Request(BASE+'/api/shutdown',data=b'{}',headers={'X-Task-Token':token,'Content-Type':'application/json','Origin':BASE},method='POST')
        with urllib.request.urlopen(request,timeout=5) as response:assert response.status==200
        for _ in range(30):
            try:get('/api/health')
            except urllib.error.URLError:break
            time.sleep(.1)
except urllib.error.URLError as error:
    if isinstance(error,urllib.error.HTTPError):raise
if not ready:
    with (OUT/'panel.log').open('wb') as log, (OUT/'panel-error.log').open('wb') as errors:
        process=subprocess.Popen([sys.executable,'-B',str(ROOT/'scripts/task_service.py')],cwd=ROOT,stdout=log,stderr=errors,creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
    for _ in range(50):
        try:
            ready=b'showExecutionReport' in get('/execution-panel.js')
            if ready:break
        except urllib.error.URLError:pass
        time.sleep(.1)
assert ready,'Panel did not start with current assets'
assert b'taskCardEnabled' in get('/')
result={'url':BASE,'health':json.loads(get('/api/health')),'current_execution_asset_loaded':True,'new_task_created':False,'external_model_calls':0}
(OUT/'panel-restored.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
