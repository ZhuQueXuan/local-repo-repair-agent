import json
import os
from pathlib import Path
import sys
import threading
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',PYTHONDONTWRITEBYTECODE='1',LITELLM_LOCAL_MODEL_COST_MAP='True')
from collaboration_store import CollaborationStore
from task_service import make_handler
store=CollaborationStore(OUT/'http-store')
server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(store,'offline-runtime-check',0))
port=server.server_port;server.RequestHandlerClass=make_handler(store,'offline-runtime-check',port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base='http://127.0.0.1:'+str(port)
def api(path,body=None,token='offline-runtime-check',raw=False):
    req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),
        headers={'X-Task-Token':token,'Origin':base,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=12) as r:
        data=r.read();return data if raw else json.loads(data)
try:
    with patch('execution_runtime.LocalProcessBackend.run_argv',side_effect=AssertionError('Reading declarations must not start any process')):
        declared=api('/api/execution-environment');assert declared['probe_performed'] is False
    assert b'inspectExecutionEnvironment' in api('/',raw=True)
    assert b'showExecutionReport' in api('/execution-panel.js',raw=True,token='')
    tasks=api('/api/catalog')['tasks']
    assert tasks and all(t['language']=='python' for t in tasks)
    assert 'fast-deep-equal-property-methods' not in {t['id'] for t in tasks}
    with patch('execution_runtime.LocalProcessBackend.run_argv',side_effect=AssertionError('Invalid request must not spawn')):
        for body,token,code in [({},'bad',403),({'command':'echo forbidden'},'offline-runtime-check',400)]:
            try:api('/api/execution-environment/inspect',body,token=token)
            except urllib.error.HTTPError as e:assert e.code==code
            else:raise AssertionError('Invalid inspection request accepted')
    checked=api('/api/execution-environment/inspect',{})
    assert checked['probe_performed'] is True
    assert all(checked['runtimes'][k]['status']=='available' for k in ['bash','python','git'])
    assert checked['runtimes']['node']['automatic_task_service_support'] is False
    assert api('/api/execution-environment')==checked
    assert store.list()==[]
finally:
    server.shutdown();server.server_close();thread.join(timeout=2)
report={'checks':['GET does not spawn','HTML and JS','authentication before spawn','command injection fields rejected',
    'actual fixed version probes','cached report timestamp','Node scope explicit','Python-only automatic catalog','no new tasks'],
    'report':checked,'workers_started':0,'external_model_calls':0,'browser_clicks_verified':False}
(OUT/'http-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':report['checks'],'external_model_calls':0},ensure_ascii=False))
