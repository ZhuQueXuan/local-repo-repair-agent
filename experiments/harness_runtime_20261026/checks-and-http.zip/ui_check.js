const fs=require('fs'),vm=require('vm'),assert=require('assert');
function element(){return {children:[],append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const elements={inspectExecutionEnvironment:element(),executionEnvironmentNotice:element(),executionEnvironmentResult:element()};
let calls=0,fail=false;
const sample=JSON.parse(fs.readFileSync('temp/harness_runtime_20261026/runtime-probe.json','utf8'));
const context={$:id=>elements[id],node:(type,label)=>Object.assign(element(),{type,textContent:label}),text:(el,value)=>{el.textContent=value},
    api:async(path,body)=>{calls++;assert(path==='/api/execution-environment/inspect');assert(Object.keys(body).length===0);if(fail)throw Error('synthetic error');return sample}};
vm.createContext(context);vm.runInContext(fs.readFileSync('scripts/execution_panel.js','utf8'),context);
assert(calls===0);
(async()=>{
    await elements.inspectExecutionEnvironment.onclick();assert(calls===1&&!elements.inspectExecutionEnvironment.disabled);
    assert(elements.executionEnvironmentResult.children.length===6);
    fail=true;await elements.inspectExecutionEnvironment.onclick();assert(!elements.inspectExecutionEnvironment.disabled);
    assert(elements.executionEnvironmentNotice.textContent==='synthetic error');
    const html=fs.readFileSync('scripts/task_panel.html','utf8');new vm.Script(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
    fs.writeFileSync('temp/harness_runtime_20261026/ui-check.json',JSON.stringify({scope:'Node fake DOM, not browser clicks',no_automatic_probe:true,explicit_button:true,error_reenables:true,inline_syntax:true},null,2));
    console.log('UI basic checks passed (fake DOM, not browser clicks)');
})().catch(error=>{console.error(error);process.exitCode=1});
