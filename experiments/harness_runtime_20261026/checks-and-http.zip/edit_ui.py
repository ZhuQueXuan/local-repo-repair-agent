from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'scripts/task_panel.html';text=p.read_text(encoding='utf-8')
old='<script src="/capability-panel.js"></script>'
assert text.count(old)==1
text=text.replace(old,old+'<script src="/execution-panel.js"></script>')
old='<main>'
assert text.count(old)==1
section='<section class="card" style="margin:18px 24px 0"><div class="row"><h2>本机执行环境</h2><button id="inspectExecutionEnvironment">检查执行环境</button></div><p id="executionEnvironmentNotice" class="hint">尚未检查。点击后只运行Bash/Node/Git版本命令，Python来自当前进程。</p><div id="executionEnvironmentResult"></div></section>'
text=text.replace(old,section+old)
p.write_text(text,encoding='utf-8')
