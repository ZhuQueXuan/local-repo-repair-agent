import json
import os
from pathlib import Path
import sys
import uuid
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',PYTHONDONTWRITEBYTECODE='1',LITELLM_LOCAL_MODEL_COST_MAP='True')
from document_agent_demo import exercise
from harness_checkpoints import request_pause,continue_checkpoint,checkpoint_view,CheckpointConflict
from task_cards import card_view
from collaboration_panel import usage_view
card={'goal':'验证执行环境声明与续做','steps':[{'id':'repair','title':'完成修复与核查','status':'pending'}]}
def checkpoint(name,role,runner):
    if name=='after_role_completion' and role['phase']=='consulting':request_pause(runner.store,runner.run_id)
store,first,summary,wires=exercise(scenario='revise',allow_capabilities=True,allow_pause=True,task_card=card,checkpoint=checkpoint)
source=summary['run'];assert source['status']=='paused',source
before=store.get(source['id']);view=checkpoint_view(store,source['id'])
body={'request_key':'environment-'+uuid.uuid4().hex,'checkpoint_sha256':view['checkpoint_sha256'],'task_card':card_view(store,source['id'])['card']}
with store.connect() as db:count=db.execute('SELECT COUNT(*) FROM runs').fetchone()[0]
with patch.dict(os.environ,{'MINI_TASK_BASH':str(OUT/'missing-bash.exe')}):
    try:continue_checkpoint(store,source['id'],body)
    except CheckpointConflict as error:assert '环境声明' in str(error)
    else:raise AssertionError('Changed environment accepted')
with store.connect() as db:assert db.execute('SELECT COUNT(*) FROM runs').fetchone()[0]==count
child=continue_checkpoint(store,source['id'],body)
store,runner,final,new_wires=exercise(scenario='revise',continuation={'home':str(store.home),'run_id':child['id']})
assert final['run']['status']=='finished' and final['run']['repair_result']=='passed' and final['run']['review_verdict']=='approve',final['run']
assert store.get(source['id'])==before and 'consulting' not in final['counts']
declaration=json.loads((runner.output/'execution-environment.json').read_bytes())
assert declaration['probe_performed'] is False and declaration['backend']['os_isolation'] is False
assert declaration['runtimes']['node']['automatic_task_service_support'] is False
usage=usage_view(store,store.get(child['id']))
assert usage['lineage']['attempts']==len(wires)+len(new_wires)
report={'store_home':str(store.home),'source':source['id'],'child':child['id'],'source_unchanged':True,
    'changed_environment_rejected_without_child':True,'same_environment_continued':True,'completed_roles_not_repeated':True,
    'repair_result':'passed','review_verdict':'approve','counts':{'before':summary['counts'],'after':final['counts']},
    'runtime_declaration_saved':True,'lineage_usage':usage['lineage'],'external_model_calls':0}
(OUT/'continuation-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
