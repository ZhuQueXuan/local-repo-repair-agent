import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',PYTHONDONTWRITEBYTECODE='1',LITELLM_LOCAL_MODEL_COST_MAP='True')
from execution_backend import LocalProcessBackend, WindowsGitBashBackend
from execution_runtime import bash_executable, runtime_report, runtime_identity
from run_task_batch import TaskEnvironment
from minisweagent.exceptions import Submitted
import shlex

work=OUT/'backend-work';work.mkdir(exist_ok=True)
env=TaskEnvironment(work,bash_executable())
text=env.execute({'command':"python -B -c "+shlex.quote("import sys; print('中文执行'); print(sys.executable); sys.exit(3)")})
assert text['returncode']==3 and '中文执行' in text['output'] and '.venv' in text['output'],text
assert env.execute({'command':"python -B -c 'raise SystemExit(7)' | tail -1"})['returncode']!=0
before=env.execute({'command':'rm forbidden-file'})
assert before['returncode']==-1 and 'Deletion' in before['exception_info']
timeout=env.execute({'command':"python -B -c 'import time; time.sleep(30)'"},timeout=.15)
assert timeout['returncode']==-1 and timeout['extra']['exception_type']=='TimeoutExpired'
try:env.execute({'command':'echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT'})
except Submitted:pass
else:raise AssertionError('Submission sentinel changed')
with patch.dict(os.environ,{'SHOULD_NOT_REACH_COMMAND':'private-test-value','DEEPSEEK_API_KEY':'synthetic-only'}):
    result=env.execute({'command':"python -B -c "+shlex.quote("import os; print(os.getenv('SHOULD_NOT_REACH_COMMAND')); print(os.getenv('DEEPSEEK_API_KEY'))")})
    assert result['output'].strip()=='None\nNone',result
serialized=env.serialize()['info']['config']
assert serialized['execution_backend']['os_isolation'] is False
with patch.dict(os.environ,{'MINI_TASK_NODE':str(OUT/'missing-node.exe')}):
    missing=runtime_report(probe=True)
    assert missing['runtimes']['node']['status']=='missing'
    assert missing['runtimes']['python']['status']=='available'
    assert missing['runtimes']['node']['automatic_task_service_support'] is False
identity=runtime_identity()
with patch.dict(os.environ,{'MINI_TASK_BASH':str(OUT/'missing-bash.exe')}):
    assert runtime_identity()!=identity
with patch.dict(os.environ,{'MINI_TASK_NODE':str(OUT/'missing-node.exe')}):
    assert runtime_identity()==identity  # Optional Node is not an active Python-task dependency.

class Cancelled(Exception):pass
pid_file=OUT/'owned-process.pid'
def check():
    if pid_file.exists():raise Cancelled()
command=[sys.executable,'-B','-c',"import os,time;from pathlib import Path;Path("+repr(str(pid_file))+ ").write_text(str(os.getpid()));time.sleep(30)"]
try:LocalProcessBackend().run_argv(command,cwd=work,timeout=5,check=check)
except Cancelled:pass
else:raise AssertionError('Cooperative cancellation ignored')
pid=int(pid_file.read_text())
import ctypes
handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,pid)
if handle:
    exit_code=ctypes.c_ulong();assert ctypes.windll.kernel32.GetExitCodeProcess(handle,ctypes.byref(exit_code))
    ctypes.windll.kernel32.CloseHandle(handle);assert exit_code.value!=259,'Owned child still active'
report={'checks':['UTF8/exit code','project Python on PATH','pipefail','deletion guard','shell timeout','submission sentinel',
    'secret environment excluded','backend serialization','optional Node missing','environment declaration binding','owned argv cancellation'],
    'owned_child_pid':pid,'owned_child_stopped':True,'external_model_calls':0,'runtime_report':runtime_report(probe=True)}
(OUT/'backend-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':report['checks'],'owned_child_stopped':True,'external_model_calls':0},ensure_ascii=False))
