import hashlib,json,re,sqlite3,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
before=json.loads((OUT/'before.json').read_bytes())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=db.execute('SELECT id,payload FROM runs').fetchall()
    active=[run_id for run_id,raw in rows if json.loads(raw)['status'] in {'queued','running','cancel_requested'}]
assert len(rows)==45 and not active
for name in ('data/task_service/runs.sqlite3','data/deepseek_budget.json'):
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==before[name]
result={'formal_rows':len(rows),'pending_or_running':len(active),'database_bytes_unchanged':True,'ledger_bytes_unchanged':True}
if '--http' in sys.argv:
    base='http://127.0.0.1:8765'
    with urllib.request.urlopen(base+'/',timeout=5) as response:html=response.read().decode()
    token=re.search(r"const token='([^']+)'",html).group(1)
    assert 'value="document_review"' in html and 'id="documentQuestion"' in html
    request=urllib.request.Request(base+'/api/runs',headers={'X-Task-Token':token})
    with urllib.request.urlopen(request,timeout=5) as response:listed=json.loads(response.read())
    result['panel_http_available']=True
    result['three_role_option_available']=True
    for name in ('data/task_service/runs.sqlite3','data/deepseek_budget.json'):
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==before[name]
    (OUT/'formal-panel-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
