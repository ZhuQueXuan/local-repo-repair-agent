from pathlib import Path
OUT=Path(__file__).parent
audit=(OUT/'audit_results.py').read_text(encoding='utf-8')
assert audit.count('20261025_181220_6e47ce74')==1
audit=audit.replace('20261025_181220_6e47ce74','20261025_182929_689d484d').replace("OUT/'verification.json'","OUT/'verification-template-safe.json'")
(OUT/'audit_template_safe.py').write_text(audit,encoding='utf-8')
seal=(OUT/'seal_evidence.py').read_text(encoding='utf-8')
assert seal.count("DEST=ROOT/'experiments/document_agent_20261025'")==1
seal=seal.replace("DEST=ROOT/'experiments/document_agent_20261025'","DEST=ROOT/'experiments/document_agent_20261025/template_safe'")
seal=seal.replace('20261025_181220_6e47ce74','20261025_182929_689d484d')
seal=seal.replace("OUT/'verification.json'","OUT/'verification-template-safe.json'")
(OUT/'seal_template_safe.py').write_text(seal,encoding='utf-8')
print('Prepared independent final audit/archive without overwriting the earlier evidence.')
