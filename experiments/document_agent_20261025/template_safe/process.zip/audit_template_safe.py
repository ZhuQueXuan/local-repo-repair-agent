import hashlib, json, sqlite3, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
before=json.loads((OUT/'before.json').read_bytes())
changed=[p for p,h in before.items() if not (ROOT/p).is_file() or sha((ROOT/p).read_bytes())!=h]
allowed={'scripts/review_tools.py','scripts/review_model.py','scripts/collaboration_store.py','scripts/collaboration_runtime.py',
    'scripts/collaboration_live.py','scripts/collaboration_panel.py','scripts/collaboration_panel.js','scripts/task_panel.html'}
assert set(changed)==allowed, changed
protected=[p for p in before if p.startswith(('data/','configs/','evaluation/'))]
assert not set(changed)&set(protected)
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    count=db.execute('SELECT COUNT(*) FROM runs').fetchone()[0]
assert count==45
packet=ROOT/'evaluation/multi_agent_20261025'
frozen=json.loads((packet/'freeze.json').read_bytes())['files_sha256']
runtime_drift=[]
for p,h in frozen.items():
    if sha((ROOT/p).read_bytes())!=h:
        runtime_drift.append(p)
        assert p.startswith('scripts/')
        assert sha((OUT/'before-code'/p).read_bytes())==h
    if p.startswith('evaluation/'):
        assert sha((ROOT/p).read_bytes())==h
old=json.loads((ROOT/'temp/multi_agent_eval_prep_20261025/adapter-comparison.json').read_bytes())
adapter_path=ROOT/'temp/regression/20261025_181222_8c3a755f'
adapter=json.loads((adapter_path/'adapter/upstream_results.json').read_bytes())
failed=sorted(r['nodeid'] for r in adapter['reports'] if r['outcome']=='failed')
assert failed==old['failed_nodeids'],failed
regpath=ROOT/'temp/regression/20261025_182929_689d484d'
reg=json.loads((regpath/'summary.json').read_bytes())
assert all(r['exit_code']==0 for r in reg['jobs'])
assert not reg['changed_protected_files']
assert not json.loads((adapter_path/'summary.json').read_bytes())['changed_protected_files']
home=ROOT/'temp/document_agent_demo/9a6dc3fea01b4b86a0e30bbf55b489a1'
demo=json.loads((home/'demonstration.json').read_bytes())
run_id=demo['run_id']
grade=json.loads((home/'runs'/run_id/'revising-verification/report.json').read_bytes())
archives={}
for name in ('multi_agent_eval_prep_20261025','self_review_20261025','adjudication_panel_20261024','multi_agent_response_recheck_live_20261024'):
    directory=ROOT/'experiments'/name
    hashes=json.loads((directory/'artifact_sha256.json').read_bytes())
    assert all(sha((directory/p).read_bytes())==h for p,h in hashes.items())
    archives[name]=len(hashes)
result={'changed_existing_code':sorted(changed),'unchanged_existing_files':len(before)-len(changed),
    'protected_data_config_packet_files_unchanged':len(protected),'formal_rows_unchanged':count,
    'formal_database_bytes_unchanged':True,'shared_ledger_bytes_unchanged':True,'external_model_calls':0,
    'old_freeze_file_count':len(frozen),'old_freeze_runtime_drift_expected':runtime_drift,
    'old_freeze_runtime_preserved_in_before_code':True,'old_archives_verified':archives,
    'regression':reg,'adapter_counts':adapter['counts'],'adapter_same_six_failures':True,
    'adapter_failed_nodeids':failed,'demo_home':str(home),'demo_id':run_id,'demo_counts':demo['counts'],
    'demo_usage':{k:demo['usage'][k] for k in ('attempts','known_prompt_tokens','known_completion_tokens','known_price_estimate_cny')},
    'demo_grader':grade,'browser_clicks_verified':False}
(OUT/'verification-template-safe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('regression','demo_grader','demo_usage')},ensure_ascii=False))
