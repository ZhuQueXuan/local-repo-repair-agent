import hashlib, json, shutil, stat, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
DEST=ROOT/'experiments/document_agent_20261025/template_safe'
assert not DEST.exists(), 'Do not overwrite an evidence archive'
DEST.mkdir()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def files(base):
    return [(p,p.relative_to(base).as_posix()) for p in sorted(base.rglob('*')) if p.is_file()
        and stat.S_ISREG(p.lstat().st_mode) and not any(x in {'__pycache__','.git'} for x in p.parts)
        and not p.name.endswith('.lock') and not p.name.startswith('.env')]
def pack(name, entries):
    hashes={}
    with zipfile.ZipFile(DEST/name,'w',zipfile.ZIP_DEFLATED) as archive:
        for p,rel in entries:
            assert rel not in hashes
            raw=p.read_bytes();archive.writestr(rel,raw);hashes[rel]=sha(raw)
    (DEST/(name+'.sha256.json')).write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf-8')
    return len(hashes)
code=[(p,p.relative_to(ROOT).as_posix()) for p in sorted((ROOT/'scripts').glob('*')) if p.is_file() and p.suffix in {'.py','.js','.html'}]
code += [(p,p.relative_to(ROOT).as_posix()) for p in sorted((ROOT/'configs').glob('*')) if p.is_file() and p.suffix in {'.json','.txt'}]
counts={'runtime-code.zip':pack('runtime-code.zip',code),
        'before-code.zip':pack('before-code.zip',files(OUT/'before-code'))}
names=['32_过程_双角色快照修复与第三文档角色离线接入.md','21_规划_RAG与多Agent协作深化.md',
    '31_过程_多Agent新题筛选与离线冻结准备.md','00_项目现状与快速接手.md','项目开发流水账.md']
docs=[(ROOT/'Project'/name,'shixi_project/Project/'+name) for name in names]
docs += [(ROOT/'README.md','shixi_project/README.md'),(ROOT/'AGENTS.md','shixi_project/AGENTS.md'),(ROOT.parent/'job/AGENTS.md','job/AGENTS.md')]
counts['documentation.zip']=pack('documentation.zip',docs)
demo=ROOT/'temp/document_agent_demo/9a6dc3fea01b4b86a0e30bbf55b489a1'
counts['first-successful-demo.zip']=pack('first-successful-demo.zip',files(demo))
counts['initial-local-permission-failure.zip']=pack('initial-local-permission-failure.zip',files(ROOT/'temp/document_agent_demo/329544ffc5ec4123ad98ad00ec98c79e'))
candidates=[]
for p in (ROOT/'temp/document_agent_demo').glob('*/demonstration.json'):
    value=json.loads(p.read_bytes())
    if value['scenario']=='revise' and value['run']['status']=='finished':candidates.append(p)
latest=max(candidates,key=lambda p:p.stat().st_mtime_ns)
latest_value=json.loads(latest.read_bytes())
counts['final-regression-demo.zip']=pack('final-regression-demo.zip',files(latest.parent))
for name,path in [('regression.zip','temp/regression/20261025_182929_689d484d'),('adapter.zip','temp/regression/20261025_181222_8c3a755f')]:
    counts[name]=pack(name,files(ROOT/path))
counts['process.zip']=pack('process.zip',[(p,p.name) for p in sorted(OUT.iterdir()) if p.is_file()])
shutil.copyfile(OUT/'verification-template-safe.json',DEST/'verification.json')
shutil.copyfile(OUT/'http-verification.json',DEST/'http-verification.json')
(DEST/'README.json').write_text(json.dumps({'date':'2026-10-25','scope':'Three-role offline implementation. All replies and usage scripted, no live model evaluation.',
    'current_regression_demo':str(latest.parent.relative_to(ROOT)),'current_regression_demo_id':latest_value['run_id'],
    'archive_member_counts':counts,'real_model_calls':0,'formal_rows_unchanged':45,'browser_clicks_verified':False,
    'old_freeze_not_rewritten':True,'old_runtime_preserved_in_before_code':True,
    'limits':['Third-role live provider not verified','No browser clicks: control disabled','Single explicit pre-repair documentation question; no dynamic delegation',
        'Binary implementation edits unsupported; original assets can be snapshotted','Known six adapter differences retained','Baseline effectiveness comparison deferred']},ensure_ascii=False,indent=2),encoding='utf-8')
hashes={p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()}
(DEST/'artifact_sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
from dotenv import dotenv_values
secrets=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
members=0
for name,expected in hashes.items():
    p=DEST/name
    assert sha(p.read_bytes())==expected
    if p.suffix=='.zip':
        listing=json.loads((DEST/(name+'.sha256.json')).read_bytes())
        with zipfile.ZipFile(p) as archive:
            assert set(archive.namelist())==set(listing)
            for relative,h in listing.items():
                raw=archive.read(relative)
                assert sha(raw)==h
                assert not any(secret in raw for secret in secrets),'Sensitive archive entry blocked'
                assert not Path(relative).name.startswith('.env')
                members+=1
    else:
        assert not any(secret in p.read_bytes() for secret in secrets),'Sensitive outer artifact blocked'
print(json.dumps({'archive':str(DEST),'outer_hash_entries':len(hashes),'verified_zip_members':members,'secret_matches':0,
    'current_regression_demo_id':latest_value['run_id'],'model_calls':0},ensure_ascii=False))
