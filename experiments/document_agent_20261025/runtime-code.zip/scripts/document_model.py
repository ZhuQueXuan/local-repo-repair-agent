"""Document specialist reuses the existing provider, guards and shared ledger."""
from collaboration_runtime import ProtectedReviewModel
from document_agent import DOCUMENT_SCHEMAS


class ProtectedDocumentModel(ProtectedReviewModel):
    tool_schemas = DOCUMENT_SCHEMAS
