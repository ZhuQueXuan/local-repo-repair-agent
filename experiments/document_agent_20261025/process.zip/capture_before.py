import hashlib, json, shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
protected = {}
for name in ('data', 'configs', 'scripts', 'evaluation/multi_agent_20261025'):
    for p in (ROOT / name).rglob('*'):
        if p.is_file() and not any(x in {'__pycache__', 'temp'} for x in p.relative_to(ROOT / name).parts) and p.suffix != '.lock':
            protected[p.relative_to(ROOT).as_posix()] = digest(p)
(OUT / 'before.json').write_text(json.dumps(protected, indent=2), encoding='utf-8')
for rel in protected:
    if rel.startswith(('scripts/', 'configs/')):
        dest = OUT / 'before-code' / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, dest)
print(json.dumps({'captured': len(protected)}))
