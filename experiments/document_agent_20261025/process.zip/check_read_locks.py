from pathlib import Path
root=Path(__file__).resolve().parents[2]
for name in ('scripts','configs','data','mini-swe-agent/src','mini-swe-agent/tests'):
    for p in (root/name).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            try: p.read_bytes()
            except OSError as e: print(p.relative_to(root).as_posix(),type(e).__name__)
