"""Isolated read-only HTTP check; no Supervisor, creation or model dispatch."""
import hashlib, json, re, secrets, sys, threading, urllib.request, urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from collaboration_store import CollaborationStore
from task_service import make_handler
HOME=ROOT/'temp/document_agent_demo/9a6dc3fea01b4b86a0e30bbf55b489a1'
selected=json.loads((HOME/'demonstration.json').read_bytes())
run_id=selected['run_id']
store=CollaborationStore(HOME)
assert store.get(run_id)['status']=='finished'
before=(HOME/'runs.sqlite3').read_bytes()
server=ThreadingHTTPServer(('127.0.0.1',0),object)
port=server.server_port
token=secrets.token_urlsafe(32)
Base=make_handler(store,token,port)
class ReadOnly(Base):
    def do_POST(self):self.send(403,{'error':'Read-only fixture; no writes or model workers'})
server.RequestHandlerClass=ReadOnly
thread=threading.Thread(target=server.serve_forever,daemon=True)
thread.start()
base='http://127.0.0.1:'+str(port)
count=0
def get(path):
    global count
    req=urllib.request.Request(base+path,headers={'X-Task-Token':token})
    with urllib.request.urlopen(req,timeout=10) as result:
        assert result.status==200
        count+=1
        return result.read()
try:
    html=get('/').decode()
    assert 'value="document_review"' in html and 'id="documentQuestion"' in html
    assert '<option value="replay">' in html and '<option value="single">' in html
    js=get('/collaboration-panel.js').decode()
    assert 'value.consultations' in js and 'text($(\'consultationResults\')' in js
    value=json.loads(get('/api/runs/'+run_id+'/collaboration'))
    assert value['synthetic'] and len(value['roles'])==5 and len(value['consultations'])==1
    context=value['consultations'][0]
    assert context['excerpts'] and context['advice']['status']=='answered'
    artifact=json.loads(get('/api/runs/'+run_id+'/artifacts/consultation-context.json'))
    assert artifact==context
    for candidate in value['candidates']:
        c=json.loads(get('/api/runs/'+run_id+'/candidates/'+candidate['candidate_id']))
        assert c['candidate_id']==candidate['candidate_id']
    req=urllib.request.Request(base+'/api/runs',data=b'{}',headers={'Content-Type':'application/json','X-Task-Token':token},method='POST')
    try:urllib.request.urlopen(req,timeout=5)
    except urllib.error.HTTPError as error:assert error.code==403
    else:raise AssertionError('must reject every write')
    assert before==(HOME/'runs.sqlite3').read_bytes()
    result={'run_id':run_id,'get_requests':count,'writes_rejected':True,'database_bytes_unchanged':True,
        'roles':len(value['roles']),'consultations':len(value['consultations']),'usage_attempts':value['usage']['attempts'],
        'browser_clicks_verified':False,'limit':'Browser automation disabled in Work settings; HTTP verification only.'}
    (Path(__file__).parent/'http-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
finally:
    server.shutdown();server.server_close();thread.join(timeout=5)
