import re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
out=Path(__file__).parent
html=(ROOT/'scripts/task_panel.html').read_text(encoding='utf-8')
scripts=re.findall(r'<script>(.*?)</script>',html,re.S)
assert len(scripts)==1
inline=out/'panel-inline.js'
inline.write_text(scripts[0],encoding='utf-8')
for path in (ROOT/'scripts/collaboration_panel.js',inline):
    result=subprocess.run(['D:/Node.js/node.exe','--check',str(path)],capture_output=True,text=True)
    print(path.name,result.returncode)
    if result.stdout:print(result.stdout)
    if result.stderr:print(result.stderr)
    assert result.returncode==0
