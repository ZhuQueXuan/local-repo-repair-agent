from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
def replace(path, changes):
    p = ROOT / path
    text = p.read_text(encoding='utf-8')
    for old, new in changes:
        assert text.count(old) == 1, (path, old[:100], text.count(old))
        text = text.replace(old, new)
    p.write_text(text, encoding='utf-8')
replace('scripts/task_panel.html', [
    ('<option value="dual_review">双 Agent 审查（实验）</option>', '<option value="dual_review">双 Agent 审查（实验）</option><option value="document_review">三角色：文档查阅＋修复＋审查（实验）</option>'),
    ('<p id="collaborationHint" class="hint"></p>', '<p id="collaborationHint" class="hint"></p><div id="documentQuestionBox" hidden><label for="documentQuestion">需要文档 Agent 查清的问题</label><textarea id="documentQuestion" maxlength="1000" rows="3" placeholder="例如：查阅仓库文档，说明这个接口的输入要求、兼容性约束及不确定项。"></textarea><p class="hint">只查冻结仓库文档；无资料时明确返回未知。当前仅离线验收，尚无真实第三角色模型证据。</p></div>'),
    ('<div id="roles" class="status-grid"></div>', '<div id="roles" class="status-grid"></div><details><summary>文档查阅与原文依据（原始版本；解释未独立证实）</summary><pre id="consultationResults"></pre></details>'),
    ('<option value="reviewer">审查者</option>', '<option value="reviewer">审查者</option><option value="document_reader">文档查阅者</option>'),
    ('let signature=JSON.stringify(request)', "if(request.collaboration_mode==='document_review')request.document_question=$('documentQuestion').value.trim();let signature=JSON.stringify(request)"),
])
replace('scripts/collaboration_panel.js', [
    ("const roleNames={repairing:", "stages.consulting='查阅文档';\nconst roleNames={consulting:'文档查阅',repairing:"),
    ("['dual_review','dual_review_diagnostic','self_review'].includes", "['dual_review','dual_review_diagnostic','self_review','document_review'].includes"),
    ("  if(selfCheck)$('collaborationHint')", "  const documents=selectMode.value==='document_review';$('documentQuestionBox').hidden=!documents;\n  if(documents)$('collaborationHint').textContent='文档查阅者先回答一个明确问题并提供原文 → 修复者 → 独立审查 → 至多一次返工/复核。文档说明不代替测试，缺资料明确返回未知；全部角色计费。当前仅离线集成验收，无真实第三角色模型效果证据。';\n  if(selfCheck)$('collaborationHint')"),
    ("  if(value.adjudications?.length)", "  if(value.mode.startsWith('document_review_'))text($('collaborationStatus'),'三角色：文档查阅 → 修复 → 审查；当前接线仅离线验收。\\n'+$('collaborationStatus').textContent.replace('双角色真实运行\\n',''));\n  text($('consultationResults'),value.consultations?.length?JSON.stringify(value.consultations,null,2):'尚无文档查阅结果；不补造依据。');\n  if(value.adjudications?.length)"),
    ("交接:value.handoffs,", "文档查阅:value.consultations,交接:value.handoffs,"),
])
print('Updated panel document mode, bounded question, role filter and cited results.')
