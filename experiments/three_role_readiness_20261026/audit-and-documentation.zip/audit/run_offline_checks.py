"""Concentrated checks using existing tests and the existing synthetic demo."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent

def main():
    environment = {k: v for k, v in os.environ.items()
        if k.upper() in {'PATH', 'SYSTEMROOT', 'WINDIR', 'COMSPEC', 'PATHEXT', 'USERPROFILE', 'HOME', 'APPDATA', 'LOCALAPPDATA',
            'PROGRAMDATA', 'PROGRAMFILES', 'PROGRAMFILES(X86)', 'SYSTEMDRIVE', 'PROCESSOR_ARCHITECTURE', 'NUMBER_OF_PROCESSORS'}}
    scratch = OUT / 'os_temp'
    scratch.mkdir(exist_ok=True)
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHON_DOTENV_DISABLED='1',
        LITELLM_LOCAL_MODEL_COST_MAP='True', MSWEA_SILENT_STARTUP='1',
        HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', DO_NOT_TRACK='1',
        PYTHONPATH=os.pathsep.join([str(ROOT / 'scripts'), str(ROOT / 'mini-swe-agent/src')]),
        MSWEA_GLOBAL_CONFIG_DIR=str(OUT / 'global_config'), TEMP=str(scratch), TMP=str(scratch), MINI_TASK_BASH='D:\\Git\\bin\\bash.exe')
    command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_document_agent', 'test_document_context',
        'test_collaboration', 'test_collaboration_feedback', 'test_collaboration_panel', 'test_document_integration']
    start = time.monotonic()
    with (OUT / 'focused-tests.log').open('w', encoding='utf-8') as log:
        completed = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
    result = {'command': command, 'exit_code': completed.returncode, 'elapsed_seconds': round(time.monotonic()-start, 3),
        'scope': 'Existing offline tests; replies/usage synthetic, local grading and patch replay real. No external model calls.'}
    (OUT / 'focused-tests.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    if completed.returncode:
        return completed.returncode
    with (OUT / 'additional-flows.log').open('w', encoding='utf-8') as log:
        completed = subprocess.run([sys.executable, '-B', str(OUT / 'additional_flows.py')], cwd=ROOT,
            env=environment, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'additional_flows_exit_code': completed.returncode}, ensure_ascii=False), flush=True)
    return completed.returncode

if __name__ == '__main__':
    sys.exit(main())
