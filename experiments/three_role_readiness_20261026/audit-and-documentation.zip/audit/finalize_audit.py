"""Verify and seal this completed offline audit; no model or dispatch code."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import zipfile

from audit_state import ROOT, OUT, snapshot

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    regression = ROOT / 'temp/regression/20261026_014200_411869bc'
    full = json.loads((regression / 'summary.json').read_bytes())
    assert not full['changed_protected_files']
    assert all(job['exit_code'] == 0 for job in full['jobs'])
    initial = json.loads((OUT / 'initial-audit.json').read_bytes())
    final = snapshot()
    assert final == initial['state'], 'Formal payloads or shared accounting changed during offline audit'
    targeted = json.loads((OUT / 'focused-tests.json').read_bytes())
    flows = json.loads((OUT / 'additional-flows.json').read_bytes())
    assert targeted['exit_code'] == 0 and len(flows) == 5
    old_plan = ROOT / 'temp/multi_agent_finish_20261025/review32_v7/three-role-acceptance-plan.json'
    original = json.loads(old_plan.read_bytes())
    current = {name: sha((ROOT / name).read_bytes()) for name in original['files_sha256']}
    changed = [name for name, value in current.items() if value != original['files_sha256'][name]]
    assert changed == ['scripts/task_panel.html'], changed
    old_archives = {}
    base = ROOT / 'experiments/three_role_acceptance_20261025'
    for part in ('', 'v4_followup', 'v5b_followup', 'v6_followup'):
        directory = base / part
        checks = json.loads((directory / 'artifact_sha256.json').read_bytes())
        assert all(sha((directory / name).read_bytes()) == expected for name, expected in checks.items())
        old_archives[part or 'original'] = len(checks)
    with zipfile.ZipFile(base / 'v6_followup/next-identity-prepared-only.zip') as previous:
        assert previous.read('three-role-acceptance-plan.json') == old_plan.read_bytes()
    documents = ['AGENTS.md', 'README.md', 'Project/00_项目现状与快速接手.md',
        'Project/33_过程_三角色真实接入诊断与多语言扩题准备.md',
        'Project/34_过程_三角色集中离线核查与最终验收标准.md', 'Project/项目开发流水账.md']
    result = {'state': 'offline_verified_not_launchable', 'external_model_calls': 0,
        'formal_rows': final['formal_rows'], 'shared_ledger_requests': final['ledger_requests'],
        'formal_payloads_unchanged': True, 'shared_ledger_bytes_unchanged': True,
        'active_runs': final['active_runs'], 'focused_tests': 74, 'additional_scripted_flows': 5,
        'regression': {k: full[k] for k in ('jobs', 'protected_files', 'changed_protected_files')},
        'old_archive_hashes_verified': old_archives, 'legacy_v7_mismatches': changed,
        'legacy_v7_plan_bytes_equal_original_sealed_copy': True,
        'legacy_v7_plan_sha256': sha(old_plan.read_bytes()), 'legacy_v7_dispatched': (old_plan.parent / 'acceptance-dispatched.json').exists(),
        'still_pending': ['current real three-role complete approval', 'real browser creation and in-flight cancellation', 'new-task baseline comparison'],
        'source_and_configuration_files': current,
        'documents_sha256': {name: sha((ROOT / name).read_bytes()) for name in documents}}
    assert not result['legacy_v7_dispatched']
    result['documents_sha256']['../job/AGENTS.md'] = sha((ROOT.parent / 'job/AGENTS.md').read_bytes())
    write(OUT / 'verification.json', result)
    destination = ROOT / 'experiments/three_role_readiness_20261026'
    destination.mkdir(exist_ok=True)
    from dotenv import dotenv_values
    secrets = [v.encode() for k, v in dotenv_values(ROOT / '.env', interpolate=False).items() if 'KEY' in k and v]
    scanned = 0
    inventory = {}
    omitted_env_files = []
    def archive(name, entries):
        nonlocal scanned
        path = destination / name
        members = {}
        with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as packed:
            for source, label in entries:
                if source.is_file():
                    if source.name == '.env':
                        omitted_env_files.append(label)
                        continue
                    raw = source.read_bytes()
                    assert not any(secret in raw for secret in secrets), 'Credential check blocked artifact'
                    scanned += 1
                    packed.writestr(label, raw)
                    members[label] = sha(raw)
        with zipfile.ZipFile(path) as packed:
            assert all(sha(packed.read(name)) == value for name, value in members.items())
        write(destination / (name + '.sha256.json'), members)
        inventory[name] = sha(path.read_bytes())
        inventory[name + '.sha256.json'] = sha((destination / (name + '.sha256.json')).read_bytes())
    archive('audit-and-documentation.zip', [(p, 'audit/' + p.relative_to(OUT).as_posix()) for p in OUT.rglob('*') if '__pycache__' not in p.parts]
        + [(ROOT / name, name) for name in documents] + [(ROOT.parent / 'job/AGENTS.md', 'job/AGENTS.md')])
    archive('runtime-inputs.zip', [(ROOT / name, name) for name in current])
    archive('default-regression.zip', [(p, p.relative_to(regression).as_posix()) for p in regression.rglob('*') if '__pycache__' not in p.parts])
    entries = []
    for row in flows:
        home = Path(row['evidence']).parent
        entries.extend((p, row['name'] + '/' + p.relative_to(home).as_posix()) for p in home.rglob('*') if '__pycache__' not in p.parts)
    archive('five-scripted-flows.zip', entries)
    result['credential_scan'] = {'configured_keys_scanned': len(secrets), 'files_scanned': scanned, 'matches': 0}
    result['omitted_environment_fixture_files'] = omitted_env_files
    write(destination / 'verification.json', result)
    inventory['verification.json'] = sha((destination / 'verification.json').read_bytes())
    write(destination / 'artifact_sha256.json', inventory)
    print(json.dumps({k: v for k, v in result.items() if k not in {'source_and_configuration_files', 'documents_sha256', 'regression'}}, ensure_ascii=False))

if __name__ == '__main__':
    main()
