"""Read-only readiness audit; does not import a model or dispatch a task."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def snapshot():
    database = ROOT / 'data/task_service/runs.sqlite3'
    with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as db:
        rows = dict(db.execute('SELECT id,payload FROM runs'))
    ledger_bytes = (ROOT / 'data/deepseek_budget.json').read_bytes()
    ledger = json.loads(ledger_bytes)
    return {'payload_sha256': {key: sha(raw.encode()) for key, raw in rows.items()},
            'formal_rows': len(rows), 'active_runs': [key for key, raw in rows.items()
                if json.loads(raw)['status'] in {'queued', 'running', 'cancel_requested'}],
            'ledger_sha256': sha(ledger_bytes), 'ledger_requests': len(ledger['requests'])}

def audit():
    report = {'state': snapshot(), 'scope': 'Read-only local files and localhost health, no model clients or task creation.'}
    freeze = ROOT / 'temp/multi_agent_finish_20261025/review32_v7/three-role-acceptance-plan.json'
    plan = json.loads(freeze.read_bytes())
    report['v7_frozen_inputs'] = len(plan['files_sha256'])
    report['v7_mismatches'] = [name for name, expected in plan['files_sha256'].items()
        if not (ROOT / name).is_file() or sha((ROOT / name).read_bytes()) != expected]
    report['v7_dispatched'] = (freeze.parent / 'acceptance-dispatched.json').exists()
    previous = ROOT / 'temp/regression/20261025_230234_ce3b2d80'
    known = json.loads((previous / 'protected_after.json').read_bytes())
    runtime = {name: expected for name, expected in known.items() if name.startswith(('scripts/', 'configs/', 'mini-swe-agent/'))}
    report['previous_regression_inputs'] = len(runtime)
    report['previous_regression_mismatches'] = [name for name, expected in runtime.items()
        if not (ROOT / name).is_file() or sha((ROOT / name).read_bytes()) != expected]
    report['previous_regression_summary'] = 'temp/regression/20261025_230234_ce3b2d80/summary.json'
    last = ROOT / 'temp/multi_agent_finish_20261025/atomic_review_v6/final-shared-ledger.json'
    old = json.loads(last.read_bytes())
    current = json.loads((ROOT / 'data/deepseek_budget.json').read_bytes())
    report['v6_ledger_requests_preserved'] = all(current['requests'].get(k) == v for k, v in old['requests'].items())
    try:
        with urllib.request.urlopen('http://127.0.0.1:8765/api/health', timeout=3) as response:
            report['service_health'] = {'status': response.status, 'body': json.loads(response.read())}
    except Exception as error:
        report['service_health'] = {'available': False, 'error_type': type(error).__name__}
    filename = sys.argv[1] if len(sys.argv) > 1 else 'initial-audit.json'
    assert filename in {'initial-audit.json', 'service-audit.json', 'final-audit.json'}
    (OUT / filename).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    compact = {k: v for k, v in report.items() if k != 'state'}
    compact['state'] = {k: v for k, v in report['state'].items() if k != 'payload_sha256'}
    print(json.dumps(compact, ensure_ascii=False))

if __name__ == '__main__':
    audit()
