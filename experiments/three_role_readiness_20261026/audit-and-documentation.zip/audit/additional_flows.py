"""Exercise uncovered three-role endings; all model replies are scripted."""
import json
from pathlib import Path
import socket
from unittest.mock import patch

from document_agent_demo import exercise
from collaboration_panel import collaboration_view

OUT = Path(__file__).parent
results = []

def reject_network(*args, **kwargs):
    raise AssertionError('External networking is forbidden in this offline audit')

def check(name, **options):
    store, runner, summary, wires = exercise(attack_bash=False, **options)
    record = summary['run']
    view = collaboration_view(store, summary['run_id'])
    assert view['synthetic'] is True
    assert all(w['phase'] in summary['counts'] for w in wires)
    assert summary['usage']['attempts'] == sum(summary['counts'].values())
    roles = store.roles(summary['run_id'])
    row = {'name': name, 'status': record['status'], 'repair_result': record.get('repair_result'),
        'review_verdict': record.get('review_verdict'), 'counts': summary['counts'],
        'role_states': {r['phase']: r['status'] for r in roles},
        'evidence': str(store.home / 'demonstration.json'), 'external_model_calls': 0}
    if name == 'direct_approval':
        assert record['status'] == 'finished' and record['repair_result'] == 'passed'
        assert record['review_verdict'] == 'approve'
        assert not {'revising', 'final_review'}.intersection(summary['counts'])
    elif name == 'documentation_unknown':
        assert record['status'] == 'finished' and record['repair_result'] == 'passed'
        assert view['consultations'][0]['advice']['status'] == 'information_not_found'
        assert view['consultations'][0]['advice']['unknowns']
        assert summary['counts'].get('final_review')
    elif name == 'cancel_final_review':
        assert record['status'] == 'cancelled' and not summary['counts'].get('final_review')
        assert not any(r['status'] in {'running', 'pending'} for r in roles)
    elif name == 'review_timeout':
        assert record['status'] == 'failed' and record['repair_result'] == 'passed'
        assert record['collaboration_result'] == 'degraded'
        assert record['review_verdict'] == 'unavailable'
        assert not {'reviewing', 'revising', 'final_review'}.intersection(summary['counts'])
    elif name == 'final_review_timeout':
        assert record['status'] == 'failed' and record['repair_result'] == 'passed'
        assert record['review_verdict'] == 'unavailable'
        assert summary['counts'].get('revising') and not summary['counts'].get('final_review')
        assert len(store.records(summary['run_id'], 'response')) == 1
    results.append(row)
    (OUT / 'additional-flows.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(row, ensure_ascii=False), flush=True)

def timeout_at(phase):
    def callback(name, role, runner):
        if name == 'after_role_claim' and role['phase'] == phase:
            raise TimeoutError('Scripted deadline boundary for offline integration audit')
    return callback

with patch.object(socket.socket, 'connect', reject_network), patch.object(socket, 'getaddrinfo', reject_network):
    check('direct_approval', scenario='approve')
    check('documentation_unknown', scenario='not_found')
    check('review_timeout', checkpoint=timeout_at('reviewing'))
    check('final_review_timeout', checkpoint=timeout_at('final_review'))
    check('cancel_final_review', cancel_phase='final_review')
