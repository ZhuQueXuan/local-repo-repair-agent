"""Reuse bounded archival and upload scans; no evaluation or model calls."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
source=(ROOT/'temp/current_comparison_20261027/seal.py').read_text('utf-8')
source=source.replace('c61_1027','c63_1028').replace('experiments/current_comparison_20261027','experiments/three_arm_20261028')
source=source.replace('evaluation/current_comparison_20261027','evaluation/three_arm_20261028').replace('all-four-runs.zip','all-six-runs.zip')
start=source.index("names=['baseline.json'");end=source.index("pack('preparation-and-audit.zip'",start)
names=['baseline.json','fixed-conditions.json','authorize.py','capture.py','prepare_packaging.py','service-tests.txt','authorization-record.json','offline-checks.json','create_packet.py','preflight.py','preflight.log','preparation.log','audit.py','audit.json','seal.py','source-change.patch','comparison_batch.py-before','comparison_inputs.py-before','new-request-receipts.json','document.py','memory-before-live.json','execution-driver.log']
source=source[:start]+'names='+repr(names)+'\n'+source[end:]
source=source.replace("[(OUT/n,n) for n in names]+[(p,p.relative_to(OUT).as_posix()) for p in sorted((OUT/'working-diffs').rglob('*')) if p.is_file()]","[(OUT/n,n) for n in names]")
target=OUT/'seal.py';assert not target.exists();target.write_text(source,encoding='utf-8')
source=(ROOT/'temp/current_comparison_20261027/prepare_commit.py').read_text('utf-8')
source=source.replace('current_comparison_20261027','three_arm_20261028').replace('c61_1027','c63_1028').replace('historical-before.json','history-before.json')
source=source.replace('Project/61_评测_当前版本两道新问题原版与完整组比较.md','Project/63_评测_两道新题原版改良单Agent与完整组三组比较.md')
source=source.replace("assert len(names)==248 and all(","assert len(names)==expected_count and all(")
source=source.replace("allowed={'AGENTS.md'", "expected_count=7+sum(1 for p in (ROOT/'evaluation/three_arm_20261028').rglob('*') if p.is_file())+8\nallowed={'AGENTS.md'")
source=source.replace('len(history)==7426','len(history)==7675').replace('all-four-runs.zip','all-six-runs.zip')
target=OUT/'prepare_commit.py';assert not target.exists();target.write_text(source,encoding='utf-8')
print('Prepared evidence and credential-scan helpers, zero models')
