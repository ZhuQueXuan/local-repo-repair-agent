"""Two unused behaviors in two familiar repositories; unchanged upstream bytes."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'scripts'))
from collaboration_protocol import canonical_bytes
DEST=ROOT/'evaluation/three_arm_20261028';assert not DEST.exists()
specs={
'click-empty-default-help':{
 'source':'click-abort-cause','target':['tests/test_defaults.py','tests/test_info_dict.py'],
 'problem':'https://github.com/pallets/click/issues/2500','license':'BSD-3-Clause; original LICENSE.rst retained',
 'issue':'''# Show an empty string default in option help

An option with default="" and show_default=True currently omits its default from --help. Display this empty string unambiguously as [default: ""] instead of silently hiding it. This must work for a directly declared empty string and when show_default is inherited from the command context. Do not change the actual value delivered to the command.

Keep show_default=False suppression, custom textual show_default labels, ordinary nonempty and numeric defaults, and the existing behavior of None and a false single boolean flag. Callable defaults remain labeled dynamic without invoking them just to render help. This task covers scalar string defaults, not an empty collection of multiple values. Change implementation only, leaving tests and metadata untouched.
''',
 'public':'''import unittest
import click
from click.testing import CliRunner
class Cases(unittest.TestCase):
 def test_direct_empty_default(self):
  @click.command()
  @click.option('--value',default='',show_default=True)
  def cli(value): pass
  result=CliRunner().invoke(cli,['--help'])
  self.assertEqual(result.exit_code,0);self.assertIn('[default: ""]',result.output)
 def test_context_empty_default(self):
  @click.command(context_settings={'show_default':True})
  @click.option('--value',default='')
  def cli(value): pass
  result=CliRunner().invoke(cli,['--help'])
  self.assertEqual(result.exit_code,0);self.assertIn('[default: ""]',result.output)
''',
 'withheld':'''import unittest
import click
from click.testing import CliRunner
def help_for(default,**kwargs):
 @click.command()
 @click.option('--value',default=default,**kwargs)
 def cli(value): pass
 result=CliRunner().invoke(cli,['--help']);assert result.exit_code==0,result.exception
 return result.output
class Cases(unittest.TestCase):
 def test_empty_help_and_runtime_value(self):
  @click.group(context_settings={'show_default':True})
  def cli(): pass
  @cli.command()
  @click.option('--text',default='')
  def sub(text): click.echo(repr(text))
  runner=CliRunner();self.assertIn('[default: ""]',runner.invoke(cli,['sub','--help']).output)
  self.assertEqual(runner.invoke(cli,['sub']).output,"''\\n")
 def test_suppressed_custom_and_ordinary_defaults(self):
  self.assertNotIn('default:',help_for('',show_default=False))
  self.assertIn('[default: (empty allowed)]',help_for('',show_default='empty allowed'))
  self.assertIn('[default: hello]',help_for('hello',show_default=True))
  self.assertIn('[default: 0]',help_for(0,show_default=True))
 def test_none_false_flag_and_dynamic_preserved(self):
  self.assertNotIn('default:',help_for(None,show_default=True))
  self.assertNotIn('default:',help_for(False,is_flag=True,show_default=True))
  calls=[]
  def dynamic(): calls.append(True);return ''
  self.assertIn('(dynamic)',help_for(dynamic,show_default=True));self.assertEqual(calls,[])
''',
 'edits':[{'path':'src/click/core.py','old':'            else:\n                default_string = str(default_value)\n',
 'new':'            elif default_value == "":\n                default_string = \'""\'\n            else:\n                default_string = str(default_value)\n','expected_occurrences':1}]},
'boltons-isoparse-fraction':{
 'source':'boltons-query-encoding','target':['tests/test_timeutils.py'],
 'problem':'https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md','license':'BSD-3-Clause; original LICENSE retained',
 'issue':'''# isoparse interprets fractional seconds with the wrong scale

isoparse('2024-03-05T06:07:08.125') gives 125 microseconds, but .125 seconds means 125000 microseconds. The function also rejects fractions longer than six digits instead of accepting their microsecond precision.

For naive date-time strings with a decimal point followed by digits after the seconds, interpret the fraction as a fraction of one second: right-pad shorter fractions to six decimal places and truncate excess digits without rounding or carrying into the next second. Preserve date-only and whole-second inputs, six-digit fractions, and datetime.isoformat round trips. Invalid calendar dates should still be rejected. Timezone offsets, Z suffixes, alternate fraction separators and general ISO8601 expansion are outside this task. Change implementation only; do not modify tests or metadata.
''',
 'public':'''import unittest
from boltons.timeutils import isoparse
class Cases(unittest.TestCase):
 def test_millisecond_fraction(self):
  self.assertEqual(isoparse('2024-03-05T06:07:08.125').microsecond,125000)
 def test_long_fraction_truncates(self):
  self.assertEqual(isoparse('2024-03-05T06:07:08.123456789').microsecond,123456)
''',
 'withheld':'''import unittest
from datetime import datetime
from boltons.timeutils import isoparse
class Cases(unittest.TestCase):
 def test_fraction_lengths_and_leading_zeroes(self):
  for part,micro in [('1',100000),('01',10000),('000001',1),('00001',10),('00420',4200),('0000001',0)]:
   with self.subTest(part=part):self.assertEqual(isoparse('2020-02-29T23:59:58.'+part),datetime(2020,2,29,23,59,58,micro))
 def test_truncation_never_rounds_or_carries(self):
  self.assertEqual(isoparse('2020-12-31T23:59:59.999999999999'),datetime(2020,12,31,23,59,59,999999))
  self.assertEqual(isoparse('2000-01-01T00:00:00.100000000000'),datetime(2000,1,1,0,0,0,100000))
 def test_existing_inputs_roundtrip_and_calendar_validation(self):
  self.assertEqual(isoparse('2024-03-05'),datetime(2024,3,5))
  self.assertEqual(isoparse('2024-03-05T06:07:08'),datetime(2024,3,5,6,7,8))
  for micro in (0,1,120000,851000,999999):
   dt=datetime(2024,3,5,6,7,8,micro);self.assertEqual(isoparse(dt.isoformat()),dt)
  with self.assertRaises(ValueError):isoparse('2023-02-29T00:00:00.1')
''',
 'edits':[{'path':'boltons/timeutils.py','old':'    dt_args = [int(p) for p in _NONDIGIT_RE.split(iso_str)]\n    return datetime(*dt_args)',
 'new':"    parts = _NONDIGIT_RE.split(iso_str)\n    if len(parts) == 7:\n        parts[-1] = parts[-1][:6].ljust(6, '0')\n    dt_args = [int(p) for p in parts]\n    return datetime(*dt_args)",'expected_occurrences':1}]}}
for task,s in specs.items():
 source=ROOT/'evaluation/multi_agent_20261025/public'/s['source'];base=json.loads((source/'manifest.json').read_bytes())
 public=DEST/'public'/task;authority=DEST/'evaluator'/task
 public.mkdir(parents=True);authority.mkdir(parents=True)
 for n,h in base['source_files_sha256'].items():
  raw=(source/'repo'/n).read_bytes();assert hashlib.sha256(raw).hexdigest()==h
  target=public/'repo'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 (public/'checks').mkdir();(public/'issue.md').write_bytes(s['issue'].encode());(public/'checks/test_behavior.py').write_bytes(s['public'].encode())
 (authority/'test_behavior.py').write_bytes(s['withheld'].encode())
 (authority/'reference.json').write_bytes(canonical_bytes({'edits':s['edits'],'scope':'Developer qualification only, never model input'}))
 (authority/'source.json').write_bytes(canonical_bytes({'problem_url':s['problem'],'base_tag':base['base_tag'],'base_commit':base['base_commit'],
  'license':s['license'],'previous_project_model_use_of_this_issue':False,'scope':'Unused concrete behavior in familiar public repository, not model-training-unseen'}))
 manifest={**base,'task_id':task,'problem_url':s['problem'],'upstream_target':s['target'],'full_target':s['target'],
  'agent_test_command':('PYTHONPATH=src ' if base.get('import_root')=='src' else '')+'python -B -m pytest '+' '.join(s['target'])+' -q -p no:cacheprovider',
  'task_files_sha256':{n:hashlib.sha256((public/n).read_bytes()).hexdigest() for n in ('issue.md','checks/test_behavior.py')}}
 (public/'manifest.json').write_bytes(canonical_bytes(manifest))
(DEST/'README.md').write_text('# Two-task three-arm comparison\n\nClick empty scalar default help and boltons isoparse fractional seconds. Original source bytes and BSD licenses retained. Raw, existing adaptive-history single agent, and full document/repair/review system once per task. Retained/reference tests never enter model workspaces. Familiar repositories, public issues; no training-unseen or official benchmark claim.\n',encoding='utf-8')
print('Created two public task inputs, zero models')
