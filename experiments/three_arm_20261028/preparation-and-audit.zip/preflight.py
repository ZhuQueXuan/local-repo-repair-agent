"""Offline exact design, visibility, dispatch, terminal denominator and billing gates."""
import copy,json,sys,uuid,zipfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c63_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
import comparison_batch as b
from comparison_inputs import TASKS,THREE_ARM_TASKS
from collaboration_store import CollaborationStore
from task_service_worker import freeze_inputs
from task_service_store import policy
from collaboration_protocol import canonical_bytes
def read(p):return json.loads(p.read_bytes())
checks=[];plan=b.verify(HOME)
assert len(plan['slots'])==6 and b.design_variants(plan)==('baseline','improved','full')
assert b.design_tasks({})==TASKS and b.design_variants({})==('baseline','full')
try:b.design_tasks({'design':'arbitrary'})
except ValueError:pass
else:raise AssertionError('Unknown design accepted')
checks.append('legacy/default two-arm and exact six-slot three-arm declarations verified')
for task in THREE_ARM_TASKS:
 target=OUT/'snapshots'/task;target.mkdir(parents=True)
 listing=freeze_inputs(task,target)
 with zipfile.ZipFile(target/'frozen_public_inputs.zip') as z:
  assert all('/public/'+task+'/' in n and '/evaluator/' not in n for n in z.namelist())
  assert all(b.sha(z.read(n))==listing[n] for n in z.namelist())
 assert not any('/evaluator/' in n for n in listing)
checks.append('public ZIPs exact; no withheld/reference in model snapshots')
testhome=ROOT/'temp/comparison_batches'/('offline63-'+uuid.uuid4().hex[:7]);testhome.mkdir()
testplan=copy.deepcopy(plan);testplan['batch_id']=testhome.name
(testhome/'qualification.json').write_bytes((HOME/'qualification.json').read_bytes())
def save_plan(p):
 b.write(testhome/'plan.json',p);b.write(testhome/'plan-sha256.json',{'sha256':b.sha((testhome/'plan.json').read_bytes())})
for mutate in ['missing_arm','unknown_arm']:
 bad=copy.deepcopy(testplan)
 if mutate=='missing_arm':bad['slots'].pop()
 else:bad['slots'][1]['variant']='arbitrary'
 save_plan(bad)
 try:b.verify(testhome)
 except ValueError:pass
 else:raise AssertionError('Bad plan accepted: '+mutate)
save_plan(testplan);b.verify(testhome)
auth=OUT/'synthetic-authorization.json';b.write(auth,{'approved':True,'plan_sha256':b.sha((testhome/'plan.json').read_bytes()),'maximum_runs':6})
store=CollaborationStore(testhome/'store')
active=store.create(THREE_ARM_TASKS[0],'raw','live','preflight-active',model_profile='legacy_deepseek_v1')
try:b.score(testhome,store,[{'task':THREE_ARM_TASKS[0],'variant':'baseline','run_id':active['id'],'request_key':'preflight-active','repetition':1}])
except ValueError:pass
else:raise AssertionError('Nonterminal score accepted')
store.cancel(active['id'])
commands=[]
class EndedWorker:
 def __init__(self,command,**kwargs):
  commands.append(command)
  identity=command[command.index('--run-id')+1]
  store.update(identity,status='failed',stage='done',reason='Offline synthetic transport; no model')
 def wait(self,timeout=None):return 0
with patch.object(b.subprocess,'Popen',EndedWorker):report=b.execute(testhome,auth)
assert report['slots']==6 and report['resolved']=={'baseline':0,'improved':0,'full':0}
assert all('No exported' in r['evaluation_error'] for r in report['results'])
slots=read(testhome/'slots.json');assert len(commands)==6 and len(list(testhome.glob('*.claimed')))==6
for slot,command in zip(slots,commands):
 row=store.get(slot['run_id'])
 assert ('--collaboration' in command)==(slot['variant']=='full')
 assert row['profile']==('raw' if slot['variant']=='baseline' else 'adaptive_history')
 if slot['variant']=='improved':
  assert row['kind']=='live' and row['configuration']==policy('adaptive_history')
  assert not row.get('collaboration_policy') and not row.get('task_card_enabled')
 if slot['variant']=='full':assert row['kind']=='collaboration_live'
try:b.execute(testhome,auth)
except ValueError:pass
else:raise AssertionError('Redispatch accepted')
checks.append('six actual dispatch branches with scripted terminal workers; improved binds existing adaptive_history only; no role flags on either single arm')
checks.append('missing/unknown arm rejected; active scoring blocked; all six failed slots retained; claimed batch cannot redispatch')
assert b.billing_failure({'requests':{'old':{'failure':{'kind':'insufficient_balance'}}}},{'old'}) is None
assert b.billing_failure({'requests':{'new':{'failure':{'kind':'connection_failed'}}}},set()) is None
assert b.billing_failure({'requests':{'new':{'failure':{'kind':'billing_rejected','status_code':402}}}},set())['status_code']==402
checks.append('only new explicit billing rejection stops; no balance probing')
b.write(OUT/'offline-checks.json',{'groups_passed':len(checks),'checks':checks,'existing_service_tests':23,'external_model_calls':0,'synthetic_home':str(testhome)})
print(json.dumps({'groups_passed':len(checks),'external_model_calls':0}))
