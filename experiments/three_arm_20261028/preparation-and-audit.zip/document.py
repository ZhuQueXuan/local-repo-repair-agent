"""Write the final six-slot comparison from verified receipts only."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
a=read(OUT/'audit.json');c=read(OUT/'fixed-conditions.json');arms=a['arms'];names={'baseline':'原版单Agent','improved':'改良单Agent','full':'完整多Agent'}
tasknames={'click-empty-default-help':'Click空字符串默认值帮助','boltons-isoparse-fraction':'boltons小数秒解析'}
docname='63_评测_两道新题原版改良单Agent与完整组三组比较.md'
scores='、'.join(f"{names[v]}{arms[v]['resolved']}/2" for v in names)
if arms['full']['resolved']>arms['improved']['resolved']:
 conclusion='本批完整组修复通过数高于改良单Agent；具体差异需结合逐题结果理解，不能归因于Agent数量。'
elif arms['full']['resolved']==arms['improved']['resolved']:
 conclusion='本批完整组与改良单Agent修复通过数相同，未显示修复数量的额外收益。'
else:conclusion='本批完整组修复通过数低于改良单Agent，增加角色没有带来本批修复数量收益。'
text=f'''# 两道新题三组系统比较

日期：2026-10-28。按用户明确授权，固定当前62版和条件，对两道此前未作为本项目调试题的公开问题，执行原版单Agent、改良单Agent和完整多Agent各一次，共6次真实运行。**独立补丁通过：{scores}；完整三角色成功{a['full_complete']}/2。** {conclusion}每组只有两道题且各一次，结论仅适用于本批观察。

## 题目与离线资格

| 问题 | 官方依据 | 原始源码 | 范围 |
| --- | --- | --- | --- |
| Click空字符串默认值帮助 | [Issue2500](https://github.com/pallets/click/issues/2500)、[PR2724](https://github.com/pallets/click/pull/2724) | 原Click8.1.3字节包 | 显示标量空字符串默认值，保持隐藏/自定义标签/普通与动态默认值 |
| boltons小数秒解析 | [官方变更记录](https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md)、[官方timeutils源码](https://github.com/mahmoud/boltons/blob/master/boltons/timeutils.py) | 原boltons25.0.0字节包 | 小数秒补至6位或截断，保留日期/整秒及原格式往返 |

两个仓库此前已用于本项目，具体问题此前没有参与策略调试；公开源码或问题可能被模型训练见过。这里的“新题”不代表训练未见或陌生仓库，也不是官方SWE-bench成绩。两题分别来自不同仓库，但仍是可修范围窄的小样本。

本轮复用原Mini-SWE-Agent底座、公共投影、批次锁和独立重放入口。Click与boltons官方维护记录可核对，原BSD-3-Clause许可及LICENSE随字节副本保留。无需引入另一个评测框架、安装依赖或转换仓库；直接换框架会改变既有Windows运行和计费条件，不能帮助保持这轮比较条件。

每题2项公开方法、3项保留方法。原始/参考版本均在隔离子进程执行，网络被阻断。保留中的兼容检查允许原始版本通过，不要求每个方法都红。

| 资格 | 原始公开/保留/上游 | 参考公开/保留/上游 |
| --- | --- | --- |
'''
for task in c['tasks']:
 q=a['qualification'][task]
 def values(version):return '、'.join(f"{q[version][k]['passed']}/{q[version][k]['tests_run']}" for k in ['public','withheld','upstream'])
 text+=f"| {tasknames[task]} | {values('baseline')} | {values('reference')} |\n"
text+=f'''
上游为登记的相关子集：Click默认值/信息字典共25项，boltons时间工具4项，不是两仓库全套。参考修复与保留检查只在评测侧，排除在模型工作副本、公共ZIP和提示之外；本地Bash没有OS沙箱，不能保证对恶意越级读取保密。

## 固定版本与三组条件

源码基线`{a['source_base_commit']}`，即62修复交付提交；本轮仅在[comparison_inputs.py](../scripts/comparison_inputs.py)登记两道题、在[comparison_batch.py](../scripts/comparison_batch.py)补第三组调度及分母统计，没有修改任何模型运行、提示模板、读取控制、上下文、时限、执行环境或价格规则。改良单Agent复用已存在的`adaptive_history`配置，无临时追加能力。

| 条件 | 原版单Agent | 改良单Agent | 完整多Agent |
| --- | --- | --- | --- |
| 主流程 | raw DefaultAgent2.4.6 | 现有adaptive_history StatefulAgent | 前置文档、修复、首审，最多一次必要返工/末审 |
| 输出与历史 | 原完整输出/历史 | 1KB输出展示、12KB目标压缩、原文档案 | 同一上下文基础加原角色保护与受控收口 |
| 状态 | 无附加任务状态 | 原有界任务状态与简单重复读取保护 | 任务卡、进展识别及62复合读取控制 |
| 文档/审查/Skills/MCP | 关闭 | 关闭 | 原只读文档/审查及Skills/MCP注册，是否调用由模型决定 |
| 修复时间 | 300秒 | 300秒 | 初修300秒，原父时限1800秒 |
| 后续机会 | 一次单Agent | 一次单Agent | 文档120/首审120/返工180/末审90秒，原分支规则 |
| 模型与费用 | 原北邮优先、DeepSeek备用、共享账本 | 同左 | 同左 |

三组公共问题、源码、公开检查和上游子集一致，温度0、16KB修复请求硬限及原提交约束保持。改良组不含完整组专有的复合读取/验证收口控制，也不含检索、任务卡或独立审查。这个比较回答“现有改良单Agent与完整系统各表现如何”，仍不能把差异单独归因于多Agent：角色数、提示、总时间、控制策略和修改机会同时不同。

题1按原版→改良→完整，题2按完整→改良→原版串行运行；不是完全随机化，改良组都在中间位置。所有身份先登记，再开始第一个模型，避免按结果增补身份。失败、超时、服务错误、取消和无候选都留在原6槽位分母；只运行一次，无按结果选优重跑。

计划`temp/comparison_batches/c63_1028/plan.json`，SHA256 `{a['plan_sha256']}`；{a['frozen_inputs_verified']}份冻结输入。授权记录和fixed-conditions在首个真实调用前保存，明确只授权这6次。原正式worker空闲/无排队任务、批次独占、唯一claimed及计费拒绝停止门控保持；不探测余额。

## 离线接线检查

已有23项服务生命周期/取消/来源检查实际通过，另5组窄检查验证旧双组设计保持、公共ZIP字节和保留排除、三条分派分支和现有配置绑定、缺组/未知组/活动评分/重复启动拒绝、所有6个失败仍保留分母及计费停止。调度检查用脚本化终态worker，0模型调用，不是模型解题成绩；本轮没有新增测试文件或把62的432/301当作本轮完整回归。

## 全部六次终态

| 问题 | 组别/新身份前缀 | 流程结果 | 独立补丁 | 公开/保留/上游 |
| --- | --- | --- | --- | --- |
'''
for r in a['results']:
 state=r['agent_exit'] if r['variant']!='full' else f"{r['collaboration_result']}/{r['review_verdict']}"
 checks='；'.join(f"{k}{r['checks'][k]['passed']}/{r['checks'][k]['tests_run']}" for k in ['public','withheld','upstream']) if r.get('checks') else (r.get('evaluation_error') or '无合法候选')
 text+=f"| {tasknames[r['task']]} | {names[r['variant']]}/{r['run_id'][:8]} | {state} | {'通过' if r['resolved'] else '未解决'} | {checks} |\n"
text+='''
正常提交、终态补丁通过、完整协作成功分别计数。所有6个worker终态后才开始保留评分；独立程序取最终导出补丁，或完整组失败时最后合法封存候选，在干净副本重放。没有合法候选仍未解决；不从失败工作目录补造候选。上下文保护停止留下的补丁按预声明规则评估，但不能算正常Submitted。

逐次运行观察：

'''
for r in a['results']:
 text+=f"- {tasknames[r['task']]}，{names[r['variant']]}：{r['reason'] or '记录正常结束'}"
 if r['variant']!='full':text+=f"；退出{r['agent_exit']}，保护类型{r.get('limit_kind')}，正常提交{r['normal_submission']}。\n"
 else:text+=f"；文档{r.get('document_status')}，交接{r.get('document_handoff_bytes')}字节/{r.get('document_citations',0)}引用，完整三角色{r['complete_three_role']}。\n"
 for trace,m in r['traces'].items():
  text+=f"  {trace}：{m['actions']}动作、{m['test_commands']}个含测试命令的Bash动作、{m['submission_commands']}个提交命令、{m['repair_control_rejections']}次修复控制拒绝。\n"
text+='''
动作计数只描述轨迹，不把含测试关键字的命令数当成独立通过数。原版Click未产生改动，0字节补丁的Final patch cannot replay代表没有修复，不是有效补丁被评测损坏。原版boltons已产生部分补丁，公开2/2、上游4/4，但先转int再转回字符串丢失了小数的前导零，保留仅1/3；其上下文停止和补丁错误分别留证。

完整组两题均正常提交，首审approve，无返工或降级；两次审查各有一次“必须恰好调用一个工具”的格式纠正，随后继续。两次修复均9个Bash动作，没有触发62新增的读取控制拒绝，所以不能把本批成功直接归因于那处守卫。Skills/MCP虽注册，但轨迹没有实际选择它们。

工具选择、角色状态、格式纠正及重复命令详manifest和原始trajectory。文档合法提交或information_not_found不代表提供了有用的问题依据；工具已注册不等于实际使用或产生收益。

## 耗时与费用

| 指标 | 原版 | 改良单Agent | 完整多Agent |
| --- | --- | --- | --- |
'''
for label,key in [('独立补丁通过','resolved'),('正常提交','normal_submissions'),('平台尝试','attempts'),('已知价格估算/元','known_price_estimate_cny'),('未知费用占位/元','unknown_placeholder_cny'),('运行累计耗时/秒','elapsed_seconds')]:
 vals=[]
 for v in names:
  val=arms[v][key]
  if key=='resolved':val=f'{val}/2'
  elif key=='normal_submissions':val=f'{val}/2（初修）' if v=='full' else f'{val}/2'
  elif key=='known_price_estimate_cny':val=f'{val:.6f}'
  vals.append(str(val))
 text+=f"| {label} | {' | '.join(vals)} |\n"
text+=f'''
共{a['platform_attempts']}次平台尝试，已知价格估算{a['known_price_estimate_cny']:.6f}元，未知费用占位{a['unknown_placeholder_cny']:.2f}元；完整费用{'未知' if a['complete_cost_estimate_cny'] is None else a['complete_cost_estimate_cny']}，不把占位与估算相加称作确认扣费。耗时取三组原worker收尾metrics中的total_elapsed_seconds，含本机准备/检查/收尾，排除排队等待与后续保留评分，不是纯模型延迟。完整组初步汇总曾错误退回“创建至结束”而包含排队，得到491.168秒；本轮已按原worker计时纠正为{arms['full']['elapsed_seconds']:.3f}秒，初步审计另存留证，原轨迹和评分未改。

六个身份北邮首试均500，按原固定策略转DeepSeek备用；没有发生余额不足/计费拒绝，不把500解释为余额或认证问题。所有失败均原样记账，计费停止记录`{a['billing_stop']}`，具体服务错误见manifest。

{conclusion}原版与改良组的差异主要对应现有上下文/任务状态组合；完整组增加的角色和控制也有额外成本，不能仅用角色数量解释结果。本轮两题/组各一次，不能估计稳定率或据此保证后续题表现。

## 保护和归档

正式53条payload、原3076条共享请求、7675份旧experiments/evaluation文件逐项保持；共享请求现{a['shared_requests_after']}，{a['frozen_inputs_verified']}冻结输入在终态评分后再次核对。46/58/61旧比较、59/60/62旧题开发复验不混合分母或回填成绩，没有恢复旧身份。医疗、异机、依赖和8765服务均未操作。

正式归档`experiments/three_arm_20261028/`含全部6身份、原始轨迹、合法候选/补丁、失败、资格红绿、独立评分、固定条件/授权、费用增量及审计。成员与外层SHA256核对，递归扫描两份真实凭据及令牌模式；正式数据库和整份共享账本不上传。仓库元数据接线是本轮仅有功能源码变动，旧packet全部保留。

本批执行结束，不追加运行修饰结果。这两题后续若用于修改策略，应转为开发回归题；下一次新效果比较需另选题、另冻结。
'''
target=ROOT/'Project'/docname;assert not target.exists();target.write_text(text,encoding='utf-8')
brief=f"2026-10-28最新：[63两题三组比较]({{prefix}}{docname})：按用户直接授权，62版两道新行为分属Click/boltons，预先冻结452输入后原版/现有adaptive_history单Agent/完整各一次共6身份，全部终态留证无选优重跑。补丁{scores}、完整协作{a['full_complete']}/2；{a['platform_attempts']}尝试已知估算{a['known_price_estimate_cny']:.6f}元/未知占位{a['unknown_placeholder_cny']:.2f}，完整费用未知。23原服务+5组窄门控、题目资格通过；只补两处比较接线，不改运行策略或时限。正式53payload/原3076请求/7675旧文件保持，现{a['shared_requests_after']}。旧成绩不改，无面板重启/医疗/异机；两熟悉仓库窄题单次系统观察，非统计或角色数因果结论。"
def insert(path,marker,value):
 s=path.read_text('utf-8');assert marker in s and docname not in s
 path.write_text(s.replace(marker,marker+'\n\n'+value,1),encoding='utf-8')
insert(ROOT/'AGENTS.md','## 当前阶段','- '+brief.format(prefix='Project/'))
insert(ROOT.parent/'job/AGENTS.md','## 当前状态与导航','- '+brief.format(prefix='../shixi_project/Project/'))
for relative,prefix in [('Project/00_项目现状与快速接手.md',''),('README.md','Project/')]:
 p=ROOT/relative;s=p.read_text('utf-8');assert docname not in s;at=s.index('\n')
 p.write_text(s[:at+1]+'\n'+brief.format(prefix=prefix)+'\n'+s[at+1:],encoding='utf-8')
p=ROOT/'Project/项目开发流水账.md';s=p.read_text('utf-8');assert docname not in s;at=s.index('\n')
p.write_text(s[:at+1]+f'\n我固定62版，在Click空默认帮助和boltons小数秒两道新行为上比较原版、现有改良单Agent与完整组。6次身份先登记，每组每题仅一次；补丁{scores}，完整协作{a["full_complete"]}/2。{conclusion}旧成绩与失败全保留，具体时限/控制差异和费用单列。[本轮详细记录]({docname})。\n'+s[at+1:],encoding='utf-8')
print(json.dumps({'document':str(target),'scores':scores},ensure_ascii=False))
