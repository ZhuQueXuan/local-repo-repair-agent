"""Replay original commands only to their first new rejection; no model calls."""
import json,sys,time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_workspace import prepare_task
from collaboration_runtime import RepairEnvironment
from minisweagent.exceptions import Submitted
from execution_runtime import bash_executable
results=[]
for task,old in [('boltons-indexed-update','422c623b77134568b3d8d59961bb2925'),('boltons-aware-relative','600b93384a60442d907d8aa66030f736')]:
 work,manifest=prepare_task(task)
 context=SimpleNamespace(check=lambda:None,deadline=time.monotonic()+90,store=SimpleNamespace(event=Mock()),
     identity=SimpleNamespace(run_id='offline-'+old,role_run_id='offline-repair'))
 env=RepairEnvironment(work,bash_executable(),context=context,source_files=list(manifest['source_files_sha256']),
     max_output_bytes=1024,python_import_root=work,state_policy={'guard_enabled':True,'implementation_prefix':manifest['source_prefix'],
      'progress_policy':{'stagnation_actions':8},'validation_commands':{'targeted':manifest['agent_test_command'],'issue':manifest['agent_issue_command']}})
 env.model=SimpleNamespace(contains_credentials=lambda _:False)
 trace=json.loads((ROOT/'temp/comparison_batches/f2_1027/store/runs'/old/'repairing-trajectory.json').read_bytes())
 actions=[a for m in trace['messages'] for a in m.get('extra',{}).get('actions',[])]
 for index,action in enumerate(actions,1):
  output=env.execute(action)
  if 'repair_action_rejected'==output.get('exception_info'):
   entry={'task':task,'historical_actions':len(actions),'first_new_rejection_action':index,
      'rejection':output['output'],'current_validation':env.task_state.progress.facts()['current_validation'],
      'work':str(work),'model_calls':0,'source':'Original fixed action sequence; not a new model result.'}
   if task=='boltons-indexed-update':
    assert entry['current_validation']=={'targeted':'passed','issue':'passed'} and index==6
    assert env.completed_submission is None
    try:env.execute({'command':'echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT'})
    except Submitted:pass
    else:raise AssertionError('Explicit submit did not finish')
    entry['explicit_scripted_submit_has_actual_receipt']=env.completed_submission is not None
   else:assert index==4
   results.append(entry);break
 else:raise AssertionError('Old loop was not intercepted')
(OUT/'replay.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False))
