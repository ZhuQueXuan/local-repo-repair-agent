"""Read-only final audit of two post-fix full-role development runs."""
import hashlib,json,sqlite3,subprocess
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=OUT/'live'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');assert sha(OUT/'plan.json')==read(OUT/'plan-sha256.json')['sha256']
assert all(sha(ROOT/n)==h for n,h in plan['files_sha256'].items())
result=read(HOME/'acceptance-results.json');assert len(result['results'])==2
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows={r['id']:r for (v,) in db.execute('SELECT payload FROM runs') for r in [json.loads(v)]}
 roles=[json.loads(v) for (v,) in db.execute('SELECT payload FROM role_runs')]
 rejects=[{'run_id':run,**json.loads(v)} for run,v in db.execute("SELECT run_id,payload FROM events WHERE kind='repair_action_rejected'")]
assert len(rows)==2 and all(r['status'] in {'finished','failed','interrupted','cancelled'} for r in rows.values())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json');assert after==read(OUT/'ledger-after.json')
assert len(before['requests'])==2714 and all(after['requests'][k]==v for k,v in before['requests'].items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
assert all(v.get('attribution',{}).get('run_id') in rows for v in new.values())
history=read(OUT/'historical-before.json');assert len(history)==7410 and all(sha(ROOT/n)==h for n,h in history.items())
known=sum((Decimal(r['amount_cny']) for r in new.values() if r['status']=='settled'),Decimal(0))
unknown=sum((Decimal(r['amount_cny']) for r in new.values() if r['status']!='settled'),Decimal(0))
summaries=[]
for r in result['results']:
 row=rows[r['run_id']];folder=HOME/'store/runs'/r['run_id'];traces={}
 for p in sorted(folder.glob('*trajectory.json')):
  messages=read(p).get('messages',[]);actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
  traces[p.name]={'actions':len(actions),'tools':sorted({a['tool'] for a in actions if 'tool' in a}),
   'submit_commands':sum(a.get('command')=='echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' for a in actions)}
 summary={k:r.get(k) for k in ['task','run_id','status','resolved','repair_result','collaboration_result','review_verdict','candidate_selection','evaluation_error','patch_sha256','complete_three_role_acceptance']}
 summary.update(usage=r.get('usage'),traces=traces)
 if 'checks' in r:summary['checks']={k:{n:v[n] for n in ['tests_run','passed','successful']} for k,v in r['checks'].items()}
 summary['rejected_actions']=sum(e['run_id']==r['run_id'] for e in rejects)
 work=Path(row['workspace']).resolve();assert work.is_relative_to(ROOT/'temp/comparison_tasks'/r['task'])
 state=work/'temp/task-state/state.json'
 if state.exists():summary['final_progress']=read(state).get('execution_progress')
 summaries.append(summary)
assert sum(r['usage']['attempts'] for r in result['results'])==len(new)
audit={'stage':59,'source_base_commit':read(OUT/'baseline.json')['source_commit'],'source_changed_files':[
 'scripts/execution_progress.py','scripts/collaboration_runtime.py','scripts/collaboration_live.py','scripts/test_execution_progress.py','scripts/test_collaboration_runtime.py'],
 'offline_tests_passed':68,'new_regressions_in_existing_files':3,'fixed_old_trace_replay':read(OUT/'replay.json'),
 'new_parent_runs':2,'selection_reruns':0,'results':summaries,'resolved':sum(r['resolved'] for r in result['results']),
 'complete_three_role_acceptance':sum(r['complete_three_role_acceptance'] for r in result['results']),
 'roles':[{k:r.get(k) for k in ['id','run_id','phase','status','reason']} for r in roles],
 'controlled_action_rejections':rejects,'frozen_inputs_verified':len(plan['files_sha256']),
 'formal_payloads_unchanged':53,'old_requests_unchanged':2714,'new_attempts':len(new),'shared_requests_after':len(after['requests']),
 'known_price_estimate_cny':float(known),'unknown_placeholder_cny':float(unknown),'complete_cost_estimate_cny':None if unknown else float(known),
 'historical_files_unchanged':7410,'balance_probed':False,'scope':'Two known development cases after the fix; not a new comparison, causal attribution or general success rate.'}
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'new-request-receipts.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:audit[k] for k in ['new_parent_runs','resolved','complete_three_role_acceptance','frozen_inputs_verified','new_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after','formal_payloads_unchanged','historical_files_unchanged']}))
