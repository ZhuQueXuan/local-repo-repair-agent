"""Original failed commands, clean copy, stop at first new rejection; zero models."""
import json,sys,time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_workspace import prepare_task
from collaboration_runtime import RepairEnvironment
from execution_runtime import bash_executable
task='boltons-empty-record-names';old='340247a86c81464aac8b6c4d72358a16'
work,manifest=prepare_task(task)
context=SimpleNamespace(check=lambda:None,deadline=time.monotonic()+90,store=SimpleNamespace(event=Mock()),
 identity=SimpleNamespace(run_id='offline-c62',role_run_id='offline-repair'))
env=RepairEnvironment(work,bash_executable(),context=context,source_files=list(manifest['source_files_sha256']),
 max_output_bytes=1024,python_import_root=work,state_policy={'guard_enabled':True,'implementation_prefix':manifest['source_prefix'],
 'progress_policy':{'stagnation_actions':8},'validation_commands':{'targeted':manifest['agent_test_command'],'issue':manifest['agent_issue_command']}})
env.model=SimpleNamespace(contains_credentials=lambda _:False)
trace=json.loads((ROOT/'temp/comparison_batches/c61_1027/store/runs'/old/'repairing-trajectory.json').read_bytes())
actions=[a for m in trace['messages'] for a in m.get('extra',{}).get('actions',[])]
outputs=[]
for index,action in enumerate(actions,1):
 output=env.execute(action);outputs.append({'index':index,'command':action['command'],'output':output})
 if output.get('exception_info')=='repair_action_rejected':
  assert index<20 and not env.completed_submission
  result={'historical_actions':len(actions),'first_new_rejection_action':index,'reason':output['output'],
   'full_covered_ranges':env._read_spans,'progress':env.task_state.progress.facts(),'model_calls':0,
   'scope':'Fixed original commands, not a model repair success','work':str(work),'outputs':outputs}
  # A true missing middle slice must remain executable, not mislabeled as delivered.
  missing=env.execute({'command':"sed -n '163,167p' boltons/namedutils.py"})
  assert missing['returncode']==0 and not missing['extra']['tool_output']['truncated']
  result['missing_middle_read']=missing
  (OUT/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  print(json.dumps({k:result[k] for k in ['historical_actions','first_new_rejection_action','model_calls','scope']}));break
else:raise AssertionError('Original loop not intercepted')
