from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
source=(ROOT/'temp/handoff_review_fix_20261027/audit.py').read_text('utf-8')
for before,after in {
 "'boltons-aware-relative'":"'boltons-empty-record-names'",
 '2781':'3046','7418':'7667',"'stage':60":"'stage':62",
 "'offline_tests_passed':78":"'offline_verification':read(OUT/'offline-report.json')",
 "'new_regressions_in_existing_files':1":"'new_regressions_in_existing_files':3",
 'One known development task after issue-context, handoff-budget and review-argument feedback changes; no fresh benchmark or causal success claim.':'One known development task after read-only loop control and honest visible-coverage repair; baseline remains unchanged, no fresh benchmark or causal success claim.',
 "'scripts/document_agent.py','scripts/review_tools.py','scripts/review_model.py','scripts/collaboration_runtime.py','scripts/collaboration_live.py',\n 'scripts/test_document_context.py','scripts/test_collaboration_runtime.py','scripts/test_document_integration.py'":"'scripts/collaboration_runtime.py','scripts/collaboration_live.py','scripts/test_collaboration_runtime.py'",
}.items():
 assert before in source,before
 source=source.replace(before,after)
source=source.replace("traces[path.name]={'actions':len(actions),", "traces[path.name]={'actions':len(actions),'bash_commands':sum('command' in a for a in actions),'submission_commands':sum('COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' in a.get('command','') for a in actions),'repair_rejections':sum(m.get('extra',{}).get('exception_info')=='repair_action_rejected' for m in messages),")
target=OUT/'audit.py';assert not target.exists();target.write_text(source,encoding='utf-8')
print('Audit prepared; no model calls')
