"""One full-role handoff/review development acceptance; never a retry batch."""
import hashlib,json,os,sqlite3,subprocess,sys,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=OUT/'live'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_protocol import canonical_bytes
from comparison_batch import input_listing,score,billing_failure
TASKS=('boltons-empty-record-names',)
from collaboration_store import CollaborationStore
from collaboration_panel import public_policy
from task_service_store import worker_lock,TERMINAL
from execution_runtime import runtime_identity
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_bytes(canonical_bytes(v))
def verify():
 p=read(OUT/'plan.json');assert sha(OUT/'plan.json')==read(OUT/'plan-sha256.json')['sha256']
 assert p['tasks']==list(TASKS) and len(p['slots'])==1 and p['maximum_runs']==1
 assert p['runtime_identity']==runtime_identity()
 expected=set(input_listing(TASKS))|{Path(__file__).relative_to(ROOT).as_posix(),(OUT/'offline-report.json').relative_to(ROOT).as_posix()}
 assert set(p['files_sha256'])==expected
 assert all(sha(ROOT/n)==h for n,h in p['files_sha256'].items())
 return p
if sys.argv[1:]==['--prepare']:
 assert not (OUT/'plan.json').exists()
 old=read(ROOT/'temp/comparison_batches/c61_1027/plan.json')
 p={k:old[k] for k in ['baseline','full','visibility','failure_policy','destinations','external_content','accounting','full_question']}
 p.update(schema_version=1,tasks=list(TASKS),variants=['full'],maximum_runs=1,repetitions=1,
  purpose='One known empty-name development task after compound/archived read control and honest truncation coverage repair; not a replacement comparison or independent new-task benchmark.',
  authorization=read(OUT/'baseline.json')['authorization'],source_base_commit=read(OUT/'baseline.json')['source_commit'],
  runtime_identity=runtime_identity(),slots=[{'task':t,'variant':'full','request_key':'read-coverage-'+uuid.uuid4().hex,'repetition':1} for t in TASKS],
  files_sha256=input_listing(TASKS),scoring='All models terminal before retained scoring. Original selection rules; no new candidate synthesized for failures.')
 for path in [Path(__file__),OUT/'offline-report.json']:p['files_sha256'][path.relative_to(ROOT).as_posix()]=sha(path)
 write(OUT/'plan.json',p);write(OUT/'plan-sha256.json',{'sha256':sha(OUT/'plan.json')})
 print(json.dumps({'prepared':True,'maximum_runs':1,'input_files':len(p['files_sha256']),'model_calls':0}));raise SystemExit()
assert sys.argv[1:]==['--execute']
p=verify();assert not HOME.exists()
HOME.mkdir();write(HOME/'consumed-authorization.json',{'human_instruction':p['authorization'],'plan_sha256':sha(OUT/'plan.json'),'maximum_runs':1})
with worker_lock(HOME,'batch.lock') as owned:
 assert owned
 with worker_lock(ROOT/'data/task_service') as idle:
  assert idle
  with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
   formal=dict(db.execute('SELECT id,payload FROM runs'))
  assert formal==read(OUT/'formal-before.json')
  assert not any(json.loads(v)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for v in formal.values())
  initial=set(read(ROOT/'data/deepseek_budget.json')['requests']);assert len(initial)==3046
  store=CollaborationStore(HOME/'store');slots=[]
  for slot in p['slots']:
   row=store.create_collaboration(slot['task'],'adaptive_history',slot['request_key'],public_policy(documents=True,question=p['full_question']),
    execution='live',model_profile='legacy_deepseek_v1',allow_capabilities=True,task_card={
     'goal':'Fix the original issue under its existing constraints; program checks and independent review determine outcomes.',
     'steps':[{'id':'repair','title':'Read, repair and verify the original issue','status':'pending'}],
     'instruction':'Retain uncertainty and failures. At most one revision; do not loop until success.'})
   slots.append({**slot,'run_id':row['id']})
  write(HOME/'slots.json',slots)
  for slot in slots:
   verify();(HOME/(slot['run_id']+'.claimed')).open('x').write(slot['request_key'])
   command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--collaboration','--run-id',slot['run_id'],'--home',str(store.home)]
   print(json.dumps({'starting':slot}),flush=True)
   with (HOME/(slot['run_id']+'.log')).open('xb') as log:
    process=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    try:process.wait(timeout=1860)
    except subprocess.TimeoutExpired:
     from execution_backend import terminate_owned_process
     terminate_owned_process(process);process.wait(timeout=10)
     store.update(slot['run_id'],status='failed',stage='done',reason='Owned acceptance deadline; no automatic replay')
   if store.get(slot['run_id'])['status'] not in TERMINAL:store.update(slot['run_id'],status='failed',stage='done',reason='Worker exited without terminal record; no retry')
   row=store.get(slot['run_id']);print(json.dumps({'ended':slot['run_id'],'status':row['status'],'collaboration_result':row.get('collaboration_result')}),flush=True)
   stop=billing_failure(read(ROOT/'data/deepseek_budget.json'),initial)
   if stop:
    write(HOME/'billing-stop.json',stop)
    for s in slots:
     if store.get(s['run_id'])['status']=='queued':store.cancel(s['run_id'])
    break
  verify();assert all(store.get(s['run_id'])['status'] in TERMINAL for s in slots)
  write(HOME/'worker-terminal.json',{'all_terminal':True,'retained_scoring_not_started_before_this_receipt':True})
  result=score(HOME,store,slots)
  for r in result['results']:
   roles=store.roles(r['run_id'])
   r['complete_three_role_acceptance']=bool(r['resolved'] and r['collaboration_result']=='completed' and r['review_verdict']=='approve'
       and all(any(x['phase']==phase and x['status']=='succeeded' for x in roles) for phase in ['consulting','repairing','reviewing']))
  write(HOME/'acceptance-results.json',result)
  write(OUT/'ledger-after.json',read(ROOT/'data/deepseek_budget.json'))
  print(json.dumps({'complete':True,'resolved':sum(r['resolved'] for r in result['results']),
     'complete_three_role_acceptance':sum(r['complete_three_role_acceptance'] for r in result['results']),'new_parent_runs':1}),flush=True)
