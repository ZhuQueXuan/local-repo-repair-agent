"""Read-only audit of one post-fix full-role acceptance."""
import hashlib,json,sqlite3
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=OUT/'live'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=read(OUT/'plan.json');assert sha(OUT/'plan.json')==read(OUT/'plan-sha256.json')['sha256']
assert p['tasks']==['boltons-empty-record-names'] and p['maximum_runs']==1
assert all(sha(ROOT/n)==h for n,h in p['files_sha256'].items())
report=read(HOME/'acceptance-results.json');assert len(report['results'])==1
r=report['results'][0]
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows=[json.loads(v) for (v,) in db.execute('SELECT payload FROM runs')]
 roles=[json.loads(v) for (v,) in db.execute('SELECT payload FROM role_runs')]
assert len(rows)==1 and rows[0]['status'] in {'finished','failed','cancelled','interrupted'}
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json')
assert after==read(OUT/'ledger-after.json') and len(before['requests'])==3046
assert all(after['requests'][k]==v for k,v in before['requests'].items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
assert all(v.get('attribution',{}).get('run_id')==r['run_id'] for v in new.values())
assert r['usage']['attempts']==len(new)
history=read(OUT/'history-before.json');assert len(history)==7667 and all(sha(ROOT/n)==h for n,h in history.items())
run=HOME/'store/runs'/r['run_id'];traces={}
for path in sorted(run.glob('*trajectory.json')):
 messages=read(path)['messages'];actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
 traces[path.name]={'actions':len(actions),'bash_commands':sum('command' in a for a in actions),'submission_commands':sum('COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' in a.get('command','') for a in actions),'repair_rejections':sum(m.get('extra',{}).get('exception_info')=='repair_action_rejected' for m in messages),'tools':sorted({a['tool'] for a in actions if 'tool' in a}),
   'rejections':[json.loads(m['content']) for m in messages if m['role']=='tool' and '"status":"rejected"' in m.get('content','')],
   'format_corrections':[m['content'][:1600] for m in messages if m.get('extra',{}).get('interrupt_type')=='FormatError']}
if (run/'consultation-context.json').exists():
 doc=read(run/'consultation-context.json');handoff_bytes=len((run/'consultation-context.json').read_bytes())
 assert handoff_bytes<=6144
else:doc=None;handoff_bytes=None
known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
unknown=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']!='settled'),Decimal(0))
audit={'stage':62,'source_base_commit':read(OUT/'baseline.json')['source_commit'],'source_changed_files':[
 'scripts/collaboration_runtime.py','scripts/collaboration_live.py','scripts/test_collaboration_runtime.py'],
 'offline_verification':read(OUT/'offline-report.json'),'new_regressions_in_existing_files':3,'old_record_replay':read(OUT/'replay.json'),
 'new_parent_runs':1,'selection_reruns':0,'result':{k:r.get(k) for k in ['task','run_id','status','resolved','repair_result','collaboration_result','review_verdict','complete_three_role_acceptance','candidate_selection','patch_sha256','evaluation_error']},
 'checks':{k:{n:v[n] for n in ['tests_run','passed','successful']} for k,v in r.get('checks',{}).items()},
 'usage':r['usage'],'roles':[{k:x.get(k) for k in ['id','run_id','phase','status','reason']} for x in roles],
 'traces':traces,'handoff_bytes':handoff_bytes,'document_status':doc['advice']['status'] if doc else None,
 'document_citations':len(doc['excerpts']) if doc else 0,'frozen_inputs_verified':len(p['files_sha256']),
 'formal_payloads_unchanged':53,'old_requests_unchanged':3046,'new_attempts':len(new),'shared_requests_after':len(after['requests']),
 'known_price_estimate_cny':float(known),'unknown_placeholder_cny':float(unknown),'complete_cost_estimate_cny':None if unknown else float(known),
 'historical_files_unchanged':7667,'balance_probed':False,'scope':'One known development task after read-only loop control and honest visible-coverage repair; baseline remains unchanged, no fresh benchmark or causal success claim.'}
audit['billing_stop']=read(HOME/'billing-stop.json') if (HOME/'billing-stop.json').exists() else None
audit['platform_failures']=[{k:v.get('failure',{}).get(k) for k in ['kind','provider','status_code']} for v in new.values() if v.get('failure')]
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'new-request-receipts.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:audit[k] for k in ['result','checks','handoff_bytes','document_status','document_citations','frozen_inputs_verified','new_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after']}))
