import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=OUT/'live';DEST=ROOT/'experiments/read_coverage_fix_20261027'
audit=json.loads((OUT/'audit.json').read_bytes());assert audit['new_parent_runs']==1 and not DEST.exists()
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def scan(raw,depth=0):
 global scanned
 scanned+=1;assert depth<=7 and not any(k in raw for k in keys),'Credential detected; value withheld'
 assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();outer={};counts={}
def pack(name,entries):
 members={}
 with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p,n in entries:
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock' or p.name.endswith(('-wal','-shm')):continue
   assert not p.name.startswith('.env') and n not in members
   raw=p.read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
 with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
 write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
 for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
pack('one-full-acceptance.zip',[(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.rglob('*')) if p.is_file()])
(OUT/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*audit['source_changed_files']],cwd=ROOT))
names=['baseline.json', 'protection-before.json', 'collaboration_runtime.py-before', 'collaboration_live.py-before', 'test_collaboration_runtime.py-before', 'capture_baseline.py', 'runtime-tests.txt', 'runtime-tests-native.txt', 'runtime-tests-final.txt', 'runtime-tests-release.txt', 'diagnostic-investigation.txt', 'regression-driver.log', 'regression-final-driver.log', 'replay.py', 'replay.json', 'replay.log', 'replay-native.log', 'prepare.py', 'prepare_audit.py', 'offline-report.json', 'run_acceptance.py', 'plan.json', 'plan-sha256.json', 'audit.py', 'audit.json', 'new-request-receipts.json', 'source-change.patch', 'document.py', 'seal.py']
names.extend(['offline_final.py','memory-observation.json','memory-before-live.json','acceptance-driver.log'])
entries=[(OUT/n,n) for n in names if (OUT/n).is_file()]
for folder in audit['offline_verification']['regression_directories']:
 for name in ['summary.json','protected_before.json','protected_after.json','native.log','project.log','native/upstream_results.json']:
  p=ROOT/folder/name
  if p.is_file():entries.append((p,'regression/'+Path(folder).name+'/'+name))
pack('offline-and-source.zip',entries)
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 row=json.loads(db.execute('SELECT payload FROM runs').fetchone()[0])
work=Path(row['workspace']).resolve();assert work.is_relative_to(ROOT/'temp/comparison_tasks'/row['task'])
entries=[(p,p.relative_to(work).as_posix()) for name in ['task-state','tool-output','context-history'] for p in sorted((work/'temp'/name).rglob('*')) if p.is_file()]
pack('local-execution-diagnostics.zip',entries)
write(DEST/'manifest.json',dict(audit,archive_members=counts,credential_scan={'keys_checked':2,'objects_including_nested':scanned,'matches':0},formal_database_and_whole_shared_ledger_uploaded=False))
outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archive_members':counts,'credential_matches':0,'objects_scanned':scanned}))
