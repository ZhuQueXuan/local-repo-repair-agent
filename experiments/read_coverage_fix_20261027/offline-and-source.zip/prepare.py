"""Reuse the existing one-run acceptance driver, with a fresh frozen identity."""
import ast,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
source=(ROOT/'temp/handoff_review_fix_20261027/run_acceptance.py').read_text('utf-8')
replacements={
 "TASKS=('boltons-aware-relative',)":"TASKS=('boltons-empty-record-names',)",
 "len(initial)==2781":"len(initial)==3046",
 "temp/comparison_batches/f2_1027/plan.json":"temp/comparison_batches/c61_1027/plan.json",
 "One known timeutils development task after handoff and review corrections":"One known empty-name development task after compound/archived read control and honest truncation coverage repair",
 "'handoff-review-'":"'read-coverage-'",
}
for before,after in replacements.items():
 assert before in source,before
 source=source.replace(before,after)
ast.parse(source)
target=OUT/'run_acceptance.py';assert not target.exists()
target.write_text(source,encoding='utf-8')
baseline=json.loads((OUT/'protection-before.json').read_bytes())
(OUT/'baseline.json').write_text(json.dumps({'source_commit':baseline['head'],
 'authorization':'用户：继续完善修复未解决的项目。沿用本会话已明确授权：先离线验证，再必要真实验收，真实模型调用无需逐次询问；好坏结果全保留、旧成绩不改。',
 'maximum_runs':1,'task':'boltons-empty-record-names','purpose':'Known-task development acceptance only, never replace stage61 scores',
 'formal_before':baseline['formal'],'requests_before':baseline['requests'],'historical_before':baseline['history']},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'prepared_driver':True,'maximum_runs':1,'model_calls':0}))
