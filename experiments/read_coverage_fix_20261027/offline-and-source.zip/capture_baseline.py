"""Read-only baseline and trace capture, not the stdlib inspect module."""
import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
if not (OUT/'protection-before.json').exists():
 with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
  formal=dict(db.execute('SELECT id,payload FROM runs'))
 history={p.relative_to(ROOT).as_posix():sha(p) for d in ['experiments','evaluation'] for p in (ROOT/d).rglob('*') if p.is_file()}
 (OUT/'formal-before.json').write_text(json.dumps(formal),encoding='utf-8')
 (OUT/'ledger-before.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
 (OUT/'history-before.json').write_text(json.dumps(history),encoding='utf-8')
 source=['scripts/collaboration_runtime.py','scripts/collaboration_live.py','scripts/test_collaboration_runtime.py']
 for name in source:(OUT/(Path(name).name+'-before')).write_bytes((ROOT/name).read_bytes())
 (OUT/'protection-before.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'formal':len(formal),'requests':len(read(ROOT/'data/deepseek_budget.json')['requests']),'history':len(history)}),encoding='utf-8')
print((OUT/'protection-before.json').read_text())
home=ROOT/'temp/comparison_batches/c61_1027/store/runs'
for identity,filename in [('90e949799a4a48b5b1c477e708d7b3f1','trajectory.json'),('340247a86c81464aac8b6c4d72358a16','repairing-trajectory.json')]:
 data=read(home/identity/filename);messages=data['messages']
 print('RUN',identity,'keys',list(data),'messages',len(messages))
 for i,m in enumerate(messages):
  if i<12 or i>=len(messages)-4:
   print(i,m['role'],'bytes',len(json.dumps(m,ensure_ascii=False).encode()),'content',str(m.get('content'))[:400], 'actions',m.get('extra',{}).get('actions'))
 raw={'messages':[{'index':i,'role':m['role'],'content':str(m.get('content')),'actions':m.get('extra',{}).get('actions')} for i,m in enumerate(messages)]}
 (OUT/(identity+'-messages.json')).write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
