"""Gate a single paid acceptance on final sequential offline checks."""
import hashlib,json,re,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
first=ROOT/'temp/regression/20261027_223516_73ff3e99'
log=(OUT/'regression-final-driver.log').read_text('utf-8-sig')
match=re.search(r'Summary: (.+)',log);assert match,'Final regression has not finished'
last=Path(match[1].strip()).parent;summary=read(last/'summary.json');old=read(first/'summary.json')
assert summary['changed_protected_files']==[] and len(summary['jobs'])==1
project=summary['jobs'][0];assert project['scope']=='project' and project['exit_code']==0
assert project['tests_run']==433 and project['skipped']==1
assert old['jobs'][0]['counts']=={'passed':301}
assert set(old['changed_protected_files'])=={'scripts/collaboration_runtime.py','scripts/test_collaboration_runtime.py'}
for name,count in [('runtime-tests-native.txt',32),('runtime-tests-final.txt',32),('diagnostic-investigation.txt',1)]:
 text=(OUT/name).read_text('utf-8-sig');assert f'Ran {count} test' in text and text.rstrip().endswith('OK')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
assert read(ROOT/'data/deepseek_budget.json')==read(OUT/'ledger-before.json')
history=read(OUT/'history-before.json');assert len(history)==7667 and all(sha(ROOT/n)==h for n,h in history.items())
record={'regression_directories':[first.relative_to(ROOT).as_posix(),last.relative_to(ROOT).as_posix()],
 'native_passed':301,'final_project_tests':433,'final_project_passed':432,'final_project_skipped':1,
 'first_project_errors':['Frozen live run input changed during local edits','MemoryError while copying a fixture'],
 'first_project_passed':430,'first_project_skipped':1,'restricted_environment_failures_retained':6,
 'first_regression_changed_files':old['changed_protected_files'],'final_regression_changed_files':summary['changed_protected_files'],
 'targeted_actual_bash_checks':32,'source_fixed_for_final_sequential_run':True,
 'new_tests_in_existing_file':3,'replay':{k:read(OUT/'replay.json')[k] for k in ['historical_actions','first_new_rejection_action','model_calls','scope']},
 'formal_payloads_unchanged':53,'shared_requests_unchanged':3046,'historical_files_unchanged':7667,
 'external_model_calls':0,'adapter_not_repeated':'No changes to process backend, subprocess environment or upstream adapter'}
(OUT/'offline-report.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False))
