"""Protect old artifacts and seal this feature delivery, without model calls."""
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_task_cards_20261026'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
before=json.loads((OUT/'protected-before.json').read_bytes())
changed=[];locked=[]
for name,expected in before.items():
    try:
        if not (ROOT/name).is_file() or sha((ROOT/name).read_bytes())!=expected:
            changed.append(name)
    except PermissionError:
        assert name in {'data/task_service/server.lock','data/task_service/worker.lock'},name
        locked.append(name)
assert not changed,changed
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=dict(db.execute('SELECT id,payload FROM runs'))
    assert rows==json.loads((OUT/'formal-payloads-before.json').read_bytes())
    assert not db.execute("SELECT 1 FROM sqlite_master WHERE name='task_cards'").fetchone()
assert not any(json.loads(raw)['status'] in {'queued','running','cancel_requested'} for raw in rows.values())
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
basic=json.loads((OUT/'basic-check.json').read_bytes())
wire=json.loads((OUT/'final-wire-check.json').read_bytes())
assert wire['unique_api_input_ids_bound_to_audit']
assert 'Ran 5 tests' in (OUT/'compatibility-check.log').read_text(encoding='utf-8')
assert (OUT/'compatibility-check.log').read_text(encoding='utf-8').rstrip().endswith('OK')
with sqlite3.connect(OUT/'ui-preview/runs.sqlite3') as db:
    ui_rows=[json.loads(row[0]) for row in db.execute('SELECT payload FROM runs')]
assert len(ui_rows)==2 and all(row['status']=='cancelled' for row in ui_rows)
result={'scope':'First Harness task-card version; no pause/resume or full-system acceptance claim.',
    'protected_old_files_listed':len(before),'protected_old_files_hash_verified':len(before)-len(locked),
    'occupied_runtime_lock_files_not_byte_verified':locked,'changed_old_protected_files':changed,'formal_payloads_unchanged':len(rows),
    'formal_task_card_schema_migrated':False,'shared_ledger_requests':len(ledger['requests']),
    'external_model_calls':0,'new_formal_runs':0,'new_formal_test_files':0,'full_regression_run':False,
    'basic_check':basic,'final_wire_check':wire,'existing_compatibility_checks_passed':5,
    'browser_verified':['isolated creation with card','save revision 2','switch clears/restores card','cancel makes card read-only','isolated server stopped'],
    'browser_scope':'Temporary loopback store without supervisor/worker/model; mode=live field did not execute any model.',
    'original_panel':json.loads((OUT/'panel-restored.json').read_bytes()),
    'pending':['pause at a safe role boundary','checkpoint continuation as linked new identity','tool and Skills expansion','additional model adapters','real model/full system evaluation']}
write(OUT/'verification.json',result)
DEST.mkdir(exist_ok=False)
sources=['task_cards.py','task_service_store.py','collaboration_store.py','collaboration_panel.py','task_service.py','task_service_worker.py','collaboration_runtime.py','collaboration_live.py','document_agent_demo.py','task_card_panel.js','task_panel.html']
documents=[ROOT/'Project/36_过程_Harness任务卡与运行中要求补充.md',ROOT/'Project/35_调研_Agent_Harness主流方案与项目演进建议.md',
    ROOT/'Project/00_项目现状与快速接手.md',ROOT/'Project/项目开发流水账.md',ROOT/'AGENTS.md',ROOT/'README.md',ROOT.parent/'job/AGENTS.md']
from dotenv import dotenv_values
secrets=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
outer={};scanned=0
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for path,label in entries:
            if path.is_file() and path.name!='.env' and '__pycache__' not in path.parts:
                raw=path.read_bytes()
                assert not any(key in raw for key in secrets),'Credential scan blocked delivery'
                archive.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as archive:
        assert all(sha(archive.read(key))==value for key,value in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes());outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
pack('source-and-documents.zip',[(ROOT/'scripts'/name,'scripts/'+name) for name in sources]
    +[(path,path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else 'job/AGENTS.md') for path in documents])
pack('checks-and-ui.zip',[(p,p.relative_to(OUT).as_posix()) for p in OUT.rglob('*') if p.is_file()])
demo=Path(basic['demo_evidence']).parent
pack('scripted-five-stage.zip',[(p,p.relative_to(demo).as_posix()) for p in demo.rglob('*') if p.is_file()])
failed=ROOT/'temp/document_agent_demo/015f529d35a64b70b2c0a1b78ff25712'
pack('first-scripted-fixture-failure.zip',[(p,p.relative_to(failed).as_posix()) for p in failed.rglob('*') if p.is_file()])
shutil.copyfile(OUT/'task-card-save.png',DEST/'task-card-save.png')
outer['task-card-save.png']=sha((DEST/'task-card-save.png').read_bytes())
result['credential_scan']={'keys_checked':len(secrets),'files_scanned':scanned,'matches':0}
write(DEST/'verification.json',result)
outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({k:v for k,v in result.items() if k not in {'basic_check','final_wire_check','original_panel'}},ensure_ascii=False))
