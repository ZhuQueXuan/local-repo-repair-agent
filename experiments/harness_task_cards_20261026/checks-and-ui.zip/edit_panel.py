from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'scripts/task_panel.html'
value = path.read_text(encoding='utf-8')
changes = [
    ('</style></head><body>', '''</style><style>
textarea,input[type=text]{font:inherit;border:1px solid #c8d1dc;border-radius:7px;padding:9px;width:100%;background:white}textarea{resize:vertical;min-height:70px}input[type=checkbox]{margin-right:8px}.task-card-step{display:grid;grid-template-columns:minmax(0,1fr) 160px auto;gap:8px;margin:9px 0}.task-card-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.task-card-actions .primary{width:auto;margin-top:0}#taskCardNotice{white-space:pre-wrap}@media(max-width:700px){.task-card-step{grid-template-columns:1fr}.task-card-step button{justify-self:start}}
</style></head><body>'''),
    ('<button id="start" class="primary">', '''<label><input id="taskCardEnabled" type="checkbox" disabled>开启任务计划与要求补充</label><p class="hint">仅新建真实任务可选；默认关闭。开启会将任务卡随后续模型请求发送，不属于原冻结baseline。</p><div id="taskCardDraftBox" hidden><label for="taskCardDraftGoal">本次目标</label><textarea id="taskCardDraftGoal" maxlength="300" rows="2">按原始问题完成修复，并保留修改依据。</textarea><label for="taskCardDraftSteps">计划步骤（每行一个，最多8个）</label><textarea id="taskCardDraftSteps" rows="3">定位并理解问题
完成受约束的修改
检查修改并整理结果</textarea><label for="taskCardDraftConstraints">额外约束（仍须遵守原任务权限）</label><textarea id="taskCardDraftConstraints" maxlength="300" rows="2"></textarea></div><button id="start" class="primary">'''),
    ('<section class="card" id="collaboration" hidden>', '''<section class="card" id="taskCardSection" hidden><h2>任务计划与要求补充</h2><p id="taskCardNotice" class="hint"></p><div id="taskCardEditor" hidden><p id="taskCardVersion" class="hint"></p><label for="taskCardGoal">目标</label><textarea id="taskCardGoal" maxlength="300" rows="2"></textarea><label for="taskCardConstraints">额外约束</label><textarea id="taskCardConstraints" maxlength="300" rows="2"></textarea><label>计划步骤 · 状态由用户维护，不是验收成绩</label><div id="taskCardSteps"></div><button id="taskCardAddStep" disabled>添加步骤</button><label for="taskCardBlocker">当前阻塞（人工记录）</label><textarea id="taskCardBlocker" maxlength="180" rows="2"></textarea><label for="taskCardNext">建议下一步</label><textarea id="taskCardNext" maxlength="180" rows="2"></textarea><label for="taskCardInstruction">当前补充要求</label><textarea id="taskCardInstruction" maxlength="400" rows="2" placeholder="保存后，下次调用读取最新整张任务卡；不会打断在途请求。"></textarea><div class="task-card-actions"><button id="taskCardSave" class="primary" disabled>保存任务卡</button><button id="taskCardDiscard" disabled>放弃编辑并刷新</button></div><h3>当前版本的调用记录</h3><div id="taskCardDelivery"></div><details><summary>版本与调用记录</summary><pre id="taskCardAudit"></pre></details></div></section><section class="card" id="collaboration" hidden>'''),
    ('if(typeof collaborationChoices===\'function\')collaborationChoices();', "if(typeof collaborationChoices==='function')collaborationChoices();if(typeof taskCardChoices==='function')taskCardChoices();"),
    ('function select(id){resetCollaboration();', "function select(id){resetCollaboration();if(typeof resetTaskCard==='function')resetTaskCard();"),
    ('display(row);await refreshCollaboration(row,revision);', "display(row);await refreshCollaboration(row,revision);if(selected!==row.id||selectionRevision!==revision)return;if(typeof refreshTaskCard==='function')await refreshTaskCard(row,revision);"),
    ("let signature=JSON.stringify(request),saved=", "if(typeof taskCardCreation==='function'){const card=taskCardCreation();if(card)request.task_card=card;}let signature=JSON.stringify(request),saved="),
    ('<script src="/collaboration-panel.js"></script>', '<script src="/collaboration-panel.js"></script><script src="/task-card-panel.js"></script>'),
]
for old, new in changes:
    assert value.count(old) == 1, old[:100]
    value = value.replace(old, new, 1)
path.write_text(value, encoding='utf-8')
