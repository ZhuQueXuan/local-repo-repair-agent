"""One scoped offline feature check, not a benchmark or real-model acceptance."""
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch
import uuid

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1', LITELLM_LOCAL_MODEL_COST_MAP='True', PYTHONDONTWRITEBYTECODE='1')
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'mini-swe-agent/src')]
from task_service_store import RunStore
from task_cards import card_view, update_card, validate_card, TaskCardConflict, export_card
from document_agent_demo import exercise
from task_service_worker import ServiceRawModel
from deepseek_budget import SharedBudget, load_budget_config
from test_collaboration_runtime import response

card = {'schema_version': 1, 'goal': '按原问题修复 {{ literal }}', 'constraints': '不改保护文件',
    'steps': [{'id': 'locate', 'title': '定位问题', 'status': 'pending'}, {'id': 'change', 'title': '完成修改', 'status': 'pending'}],
    'blocker': '', 'next_action': '先定位', 'instruction': 'FIRST_CARD_LITERAL'}
home = OUT / ('store-' + uuid.uuid4().hex)
store = RunStore(home)
old = store.create('barrel-sort', 'raw', 'live', 'legacy')
with store.connect() as db:
    old_payload = db.execute('SELECT payload FROM runs WHERE id=?', (old['id'],)).fetchone()[0]
assert not card_view(store, old['id'])['enabled']
with store.connect() as db:
    assert not db.execute("SELECT 1 FROM sqlite_master WHERE name='task_cards'").fetchone()
row = store.create('barrel-sort', 'raw', 'live', 'interactive', task_card=card)
assert store.create('barrel-sort', 'raw', 'live', 'interactive', task_card=card)['id'] == row['id']
try:
    store.create('barrel-sort', 'raw', 'live', 'interactive')
    raise AssertionError('idempotency changed silently')
except ValueError:
    pass
view = card_view(store, row['id'])
assert view['revision'] == 1 and view['can_edit']
changed = dict(view['card'], instruction='SECOND_CARD_LITERAL')
view = update_card(store, row['id'], {'revision': 1, 'card': changed})
assert view['revision'] == 2
try:
    update_card(store, row['id'], {'revision': 1, 'card': card})
    raise AssertionError('stale update silently replaced current input')
except TaskCardConflict:
    pass
try:
    validate_card(dict(card, instruction='中' * 400, constraints='文' * 300, goal='标' * 300))
    raise AssertionError('oversized card accepted')
except ValueError:
    pass
store.update(row['id'], status='running')
ledger = home / 'synthetic-ledger.json'
ledger.write_text(json.dumps({'historical_estimated_cost_cny': '0', 'historical_unknown_charge_reservation_cny': '0', 'blocked': False, 'requests': {}}), encoding='utf-8')
budget = SharedBudget(load_budget_config(), ledger_path=ledger, temp_dir=home / 'locks')
settings = {'DEEPSEEK_API_KEY': 'offline-card-key', 'DEEPSEEK_API_BASE_URL': 'https://api.deepseek.com', 'DEEPSEEK_CHAT_MODEL': 'deepseek-flash'}
model = ServiceRawModel(settings, service_store=store, service_run_id=row['id'], budget=budget,
    ledger_path=home/'model-ledger.json', error_path=home/'model-error.json')
with patch('litellm.completion', return_value=response('bash', {'command': 'echo SCRIPTED_NOT_EXECUTED'})) as transport:
    model.query([{'role': 'user', 'content': 'Original fixed issue'}])
    wire = transport.call_args.kwargs['messages']
    assert 'SECOND_CARD_LITERAL' in json.dumps(wire) and 'FIRST_CARD_LITERAL' not in json.dumps(wire)
    assert 'Original fixed issue' in json.dumps(wire)
assert card_view(store,row['id'])['inputs'][0]['status'] == 'response_received'
with patch('litellm.completion') as transport:
    try:
        model.query([{'role': 'user', 'content': 'x'*17000}])
    except Exception:
        pass
    else:
        raise AssertionError('old hard bound was lost')
    transport.assert_not_called()
assert card_view(store,row['id'])['inputs'][0]['status'] == 'not_dispatched'
store.cancel(row['id'])
assert not card_view(store,row['id'])['can_edit']
try:
    update_card(store,row['id'],{'revision':2,'card':card})
    raise AssertionError('cancelled plan was changed')
except ValueError:
    pass
with store.connect() as db:
    assert old_payload == db.execute('SELECT payload FROM runs WHERE id=?',(old['id'],)).fetchone()[0]

def checkpoint(name, role, runner):
    if name == 'after_role_claim' and role['phase'] == 'reviewing':
        view = card_view(runner.store, runner.run_id)
        update_card(runner.store,runner.run_id,{'revision':view['revision'],'card':dict(view['card'], instruction='AFTER_REPAIR_NEW_CARD')})

demo_store, runner, summary, wires = exercise(task_card=card, checkpoint=checkpoint)
assert summary['run']['status'] == 'finished' and summary['run']['repair_result'] == 'passed'
for wire in wires:
    payload = json.dumps(wire['messages'])
    assert 'task_card_revision' in payload
    if wire['phase'] in {'reviewing','revising','final_review'}:
        assert 'AFTER_REPAIR_NEW_CARD' in payload and 'FIRST_CARD_LITERAL' not in payload
    else:
        assert 'FIRST_CARD_LITERAL' in payload
view = card_view(demo_store,summary['run_id'])
assert view['revision'] == 2 and not view['can_edit']
assert len(view['inputs']) == len(wires) and all(value['status']=='response_received' for value in view['inputs'])
assert (runner.output/'task-card.json').is_file()
result = {'scope':'Scripted transport/usage; real local five-stage files, grading and patch replay. No live model calls.',
    'single_model_card_and_unchanged_guard':True,'stale_save_conflict':True,'legacy_payload_unchanged':True,'cancelled_card_readonly':True,
    'five_stage_revision_delivery':True,'demo_evidence':str(demo_store.home/'demonstration.json'),
    'demo_card_audit':str(runner.output/'task-card.json'),'single_store':str(home),'external_model_calls':0}
(OUT/'basic-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
