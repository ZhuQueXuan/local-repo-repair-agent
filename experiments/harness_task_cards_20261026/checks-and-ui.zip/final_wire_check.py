"""Narrow final-wire check for unique input IDs; no shell, HTTP or model."""
import json
import os
from pathlib import Path
import socket
import sys
from unittest.mock import patch
import uuid

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_cards import card_view,update_card,export_card,encoded
from task_service_store import RunStore
from task_service_worker import ServiceRawModel
from deepseek_budget import SharedBudget,load_budget_config
from test_collaboration_runtime import response
store=RunStore(OUT/('final-wire-'+uuid.uuid4().hex))
card={'goal':'按原任务定位并修复','steps':[{'id':'locate','title':'定位问题','status':'pending'}],'instruction':'UNIQUE_INPUT_ONE'}
parent=store.create('barrel-sort','raw','live','final-wire',task_card=card)
store.update(parent['id'],status='running')
ledger=store.home/'synthetic-ledger.json'
ledger.write_text(json.dumps({'historical_estimated_cost_cny':'0','historical_unknown_charge_reservation_cny':'0','blocked':False,'requests':{}}),encoding='utf-8')
model=ServiceRawModel({'DEEPSEEK_API_KEY':'offline-final-wire-key','DEEPSEEK_API_BASE_URL':'https://api.deepseek.com','DEEPSEEK_CHAT_MODEL':'deepseek-flash'},
    service_store=store,service_run_id=parent['id'],budget=SharedBudget(load_budget_config(),ledger_path=ledger,temp_dir=store.home/'locks'),
    ledger_path=store.home/'model-ledger.json',error_path=store.home/'model-error.json')
messages=[{'role':'user','content':'ORIGINAL_ISSUE_UNCHANGED'}]
original=encoded(messages)
wires=[]
def transport(**kwargs):
    wires.append(kwargs['messages'])
    return response('bash',{'command':'echo SCRIPTED_NOT_EXECUTED'})
def no_network(*args,**kwargs):raise AssertionError('No network allowed')
with patch.object(socket.socket,'connect',no_network),patch.object(socket,'getaddrinfo',no_network),patch('litellm.completion',side_effect=transport):
    model.query(messages)
    view=card_view(store,parent['id'])
    update_card(store,parent['id'],{'revision':view['revision'],'card':dict(view['card'],instruction='UNIQUE_INPUT_TWO')})
    model.query(messages)
assert encoded(messages)==original
payloads=[json.loads(wire[-1]['content']) for wire in wires]
assert [p['task_card_revision'] for p in payloads]==[1,2]
assert payloads[0]['task_card_input_id']!=payloads[1]['task_card_input_id']
audit=json.loads(export_card(store,parent['id'],store.home).read_bytes())
assert [p['task_card_input_id'] for p in payloads]==[r['id'] for r in audit['all_inputs']]
assert all(r['status']=='response_received' and r['attempts']==1 for r in audit['all_inputs'])
store.cancel(parent['id'])
result={'unique_api_input_ids_bound_to_audit':True,'latest_revision_delivered':[1,2],'raw_messages_unchanged':True,'transport_mocked':True,'external_model_calls':0}
(OUT/'final-wire-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
