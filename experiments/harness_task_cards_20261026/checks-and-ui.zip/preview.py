"""Isolated task-card UI fixture. NO supervisor, worker, model client or .env."""
import json
import os
from pathlib import Path
import sys
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1', LITELLM_LOCAL_MODEL_COST_MAP='True', PYTHONDONTWRITEBYTECODE='1')
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'mini-swe-agent/src')]
from task_service_store import RunStore
from task_service import make_handler

store = RunStore(OUT/'ui-preview')
card = {'schema_version':1,'goal':'查看任务计划与要求补充功能','constraints':'离线界面夹具，不运行模型',
    'steps':[{'id':'locate','title':'定位问题','status':'in_progress'},{'id':'change','title':'完成修改','status':'pending'}],
    'blocker':'等待人工补充要求','next_action':'在任务卡填写下一步','instruction':'这是离线界面预览'}
row = store.create('barrel-sort','raw','live','task-card-ui-preview',task_card=card)
store.update(row['id'],transport_scope='scripted_offline',scope='Isolated UI fixture; no worker or model execution.',stage='agent')
server = ThreadingHTTPServer(('127.0.0.1',0),type('Empty',(),{}))
with patch('dotenv.dotenv_values',return_value={}):
    Base = make_handler(store,'isolated-task-card-preview',server.server_port)
class Handler(Base):
    def send(self,status,value,content_type='application/json; charset=utf-8'):
        if content_type.startswith('text/html'):
            value=value.replace('仓库修复 · 任务面板'.encode(),'离线任务卡预览 · 不连接模型'.encode())
        return super().send(status,value,content_type)
server.RequestHandlerClass=Handler
(OUT/'preview-server.json').write_text(json.dumps({'url':'http://127.0.0.1:'+str(server.server_port),'run_id':row['id'],'scope':'Isolated local UI fixture; no supervisor and no model client.'}),encoding='utf-8')
print('Isolated preview ready',flush=True)
try:
    server.serve_forever(poll_interval=.5)
finally:
    server.server_close()
