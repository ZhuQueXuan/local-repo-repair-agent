import unittest
from pkg.calc import total

class Behavior(unittest.TestCase):
    def verify(self, values, expected):
        try:
            actual = total(values)
        except Exception as error:
            self.fail("Declared input raised " + type(error).__name__)
        self.assertEqual(actual, expected)

    def test_empty(self): self.verify([], 0)
    def test_negative(self): self.verify([-3, -2], -5)
    def test_positive(self): self.verify([2, 3], 5)
