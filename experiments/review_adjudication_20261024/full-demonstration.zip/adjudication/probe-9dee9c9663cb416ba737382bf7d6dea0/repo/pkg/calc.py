def total(values):
    return sum(values) if values else 1
