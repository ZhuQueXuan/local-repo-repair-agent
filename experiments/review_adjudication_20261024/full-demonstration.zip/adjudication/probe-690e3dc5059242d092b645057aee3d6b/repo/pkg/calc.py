def total(values):
    return max(0, sum(values))
