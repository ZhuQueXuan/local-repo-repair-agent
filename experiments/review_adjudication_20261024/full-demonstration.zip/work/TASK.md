Empty input must return zero; nonempty input must return its sum.
