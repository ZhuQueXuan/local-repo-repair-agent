"""Protect old data and update navigation after exactly one terminal real run."""
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');before=read(OUT/'ledger-before.json');after=read(OUT/'ledger-after.json')
audit=read(OUT/'batch/audit.json');result=read(OUT/'batch/result.json')
assert result['run_id']=='0d9ac92ab2044ef283c476fea62a8b1f'
assert result['resolved'] is True and result['collaboration_result']=='degraded' and result['review_verdict']=='approve'
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert read(ROOT/'data/deepseek_budget.json')==after
assert len(before['requests'])==2360 and len(after['requests'])==2402
assert all(after['requests'][k]==v for k,v in before['requests'].items())
assert all(sha(ROOT/n)==h for n,h in plan['input_files_sha256'].items())
history=read(OUT/'historical-before.json');assert all(sha(ROOT/n)==h for n,h in history.items())
check={'formal_payloads_unchanged':53,'old_requests_unchanged':2360,'shared_requests_after':2402,'new_attempts':42,
       'frozen_inputs_unchanged':len(plan['input_files_sha256']),'historical_artifacts_unchanged':len(history),
       'new_parent_runs':1,'extra_selection_reruns':0,'source_changes_this_turn':0}
(OUT/'protection-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
name='51_验收_重复读取补修后的Click单题真实复验.md'
body='用户明确批准后仅新增一次Click真实验收：补丁干净重放公开2/保留3/登记上游116全过，修复passed、首审approve；文档对269行文档三次读取815—835越界，failed并按47降级继续，因此协作degraded，不能称三角色完整通过。实际31修复动作，无重复读取拦截，无法将成功单独归因50；Skill实际读取但交接失败，MCP未用。42尝试已知估算0.319182元、未知占位0.10，完整费用未知；正式53payload/原2360请求保持，现2402，452冻结/44历史文件保持。0源码变更/追加重跑，旧失败与六题比较不回填。下一步仅优先离线改善文档选错目标的纠正及复合验证命令识别，不自动付费，无面板重启/医疗/异机操作。'
def edit(p,marker,addition):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';text=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in text and name not in text
    p.write_bytes(text.replace(marker,marker+'\n'+addition+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[51 Click真实复验](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[51 Click真实复验]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**Click修复通过、文档失败降级（2026-10-27）。** '+body+' 见[51]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [51单次Click真实复验](Project/'+name+')的补丁、公开/保留/相关上游检查及首审已通过；文档角色仍因越界读取失败，按已有规则降级后完成，完整三角色协作仍未通过。该结果是已知题开发复验，不回填六题比较。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[51 Click真实复验](../shixi_project/Project/'+name+')：'+body)
print(json.dumps(check))
