"""Seal one terminal run, exact approval, scores and current progress documents."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=OUT/'batch';DEST=ROOT/'experiments/click_guard_revalidation_20261027'
assert not DEST.exists();assert (HOME/'audit.json').is_file();DEST.mkdir()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6 and not any(k in raw for k in keys),'Credential detected; values not printed'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if n.endswith('/'):continue
                assert not Path(n).name.startswith('.env');scan(z.read(n),depth+1)
outer={};counts={}
def pack(name,entries):
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p,n in entries:
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock':continue
            assert not p.name.startswith('.env');raw=p.read_bytes();scan(raw);assert n not in members;members[n]=sha(raw);z.writestr(n,raw)
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
    write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
    for tail in ('','.sha256.json'):outer[name+tail]=sha((DEST/(name+tail)).read_bytes())
pack('one-real-run.zip',[(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.rglob('*')) if p.is_file()])
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    payload=json.loads(db.execute('SELECT payload FROM runs').fetchone()[0])
work=Path(payload['workspace']);assert work.is_relative_to(ROOT/'temp/comparison_tasks/click-flag-default-map')
diagnostics=[]
for name in ('task-state','tool-output','context-history'):
    for p in sorted((work/'temp'/name).rglob('*')):
        if p.is_file():diagnostics.append((p,p.relative_to(work).as_posix()))
assert diagnostics
pack('local-diagnostics.zip',diagnostics)
names=['run_once.py','plan.json','plan-sha256.json','readiness.json','consumed-authorization.json','explicit-user-approval.json','inspect_result.py','inspection.json','finish.py','protection-check.json','seal.py']
pack('approval-and-checks.zip',[(OUT/n,'checks/'+n) for n in names]+
    [(ROOT/'Project/51_验收_重复读取补修后的Click单题真实复验.md','Project/51_验收_重复读取补修后的Click单题真实复验.md')])
audit=json.loads((HOME/'audit.json').read_bytes());result=json.loads((HOME/'result.json').read_bytes())
manifest={'schema_version':1,'stage':51,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'result':{k:result.get(k) for k in ('task','run_id','status','resolved','collaboration_result','repair_result','review_verdict','evaluation_error')},
    'audit':{k:v for k,v in audit.items() if k not in {'roles','usage'}},'archive_members':counts,
    'credential_scan':{'keys_checked':2,'nested_objects':scanned,'matches':0},
    'approval':'Explicit human approval for exactly this one new post-stage-50 run; previous grants not reused.',
    'formal_database_and_whole_shared_ledger_not_uploaded':True,
    'scope':'Exactly one known Click development case after a specific code fix. Previous results retained. Not a fresh benchmark or proof of general stability.'}
write(DEST/'manifest.json',manifest);outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archive_members':counts,'scanned_objects':scanned,'credential_matches':0,'new_real_runs':1,'resolved':result['resolved']}))
