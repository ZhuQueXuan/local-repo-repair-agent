"""Archive one real task and necessary offline checks, excluding whole formal data."""
import hashlib,io,json,re,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;LIVE=OUT/'live_attempt_1';BATCH=LIVE/'batch'
DEST=ROOT/'experiments/document_finalize_20261027';assert not DEST.exists()
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6 and not any(k in raw for k in keys),'Credential detected; values withheld'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();outer={};counts={}
def pack(name,entries):
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p,n in entries:
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock':continue
            assert not p.name.startswith('.env') and n not in members
            raw=p.read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
    write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
    for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
pack('one-real-run.zip',[(p,p.relative_to(BATCH).as_posix()) for p in sorted(BATCH.rglob('*')) if p.is_file()])
names=['standing-user-authorization.json','source-change.patch','review_model-before.py','document_model-before.py',
    'collaboration_runtime-before.py','test_document_context-before.py','finalization-wire.txt','finalization-loop.txt',
    'document-tests.txt','runtime-tests.txt','audit_final.py','final-audit.json','finish.py','seal.py']
entries=[(OUT/n,'checks/'+n) for n in names]
entries += [(LIVE/n,'live/'+n) for n in ['run_once.py','plan.json','plan-sha256.json','explicit-user-approval.json','consumed-authorization.json','inspect_result.py','inspection.json']]
entries += [(ROOT/'Project/56_修复与验收_文档受控交接与完整三角色通过.md','Project/56_修复与验收_文档受控交接与完整三角色通过.md')]
pack('authorization-and-checks.zip',entries)
import sqlite3
with sqlite3.connect((BATCH/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:parent=json.loads(db.execute('SELECT payload FROM runs').fetchone()[0])
work=Path(parent['workspace']);assert work.is_relative_to(ROOT/'temp/comparison_tasks/click-flag-default-map')
diagnostics=[(p,p.relative_to(work).as_posix()) for name in ('task-state','tool-output','context-history') for p in sorted((work/'temp'/name).rglob('*')) if p.is_file()]
pack('local-diagnostics.zip',diagnostics)
audit=json.loads((OUT/'final-audit.json').read_bytes());result=json.loads((BATCH/'result.json').read_bytes())
write(DEST/'manifest.json',{'stage':56,'source_base_commit':audit['source_base_commit'],
    'source_patch':'authorization-and-checks.zip/checks/source-change.patch','result':{k:result.get(k) for k in
        ('run_id','status','resolved','collaboration_result','repair_result','review_verdict','complete_three_role_acceptance','patch_sha256')},
    'audit':audit,'archive_members':counts,'credential_scan':{'keys_checked':2,'nested_objects':scanned,'matches':0},
    'formal_database_and_whole_shared_ledger_not_uploaded':True,'scope':'One known Click development case. All three roles succeeded with independent clean replay; not a fresh benchmark, stable success rate or causal benefit claim.'})
outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archive_members':counts,'objects_scanned':scanned,'credential_matches':0,'complete_three_role_acceptance':True}))
