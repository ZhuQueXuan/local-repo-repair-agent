"""Update repository navigation after the verified controlled-closure acceptance."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
audit=json.loads((OUT/'final-audit.json').read_bytes());assert audit['complete_three_role_acceptance'] is True
name='56_修复与验收_文档受控交接与完整三角色通过.md'
body='用户已持续批准原范围必要真实验收，无需逐次追问，沿用原北邮/DeepSeek及外发材料/共享费用，遇余额不足或计费拒绝停止，余额未知不探测。按55加受控文档收口：同请求两次无新增后关闭查找，只公布/只接受submit，模型自行提交有据事实与未知，原引用/6KB/期限/格式纠正保持；49文档+26接线共75离线通过（新2回归）。本轮唯一8efb真实完整通过：文档3999字节/4真实引用交接，查找关闭后仅提交，作者确实接收；初修/首审succeeded、approve，无降级，补丁干净重放公开2/保留3/登记上游116全过。31尝试已知估算0.339022元/未知占位0.10，完整费用未知；正式53payload/原2446请求保持，现2477，452输入/74旧实验保持。没有重跑选优/面板重启/医疗/异机。旧失败/六题负成绩保留；是已知题单次闭环，非通用质量/稳定率/收益证明。本轮当前目标收尾，不无目的追加付费。'
def edit(p,marker,text):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';old=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in old and name not in old
    p.write_bytes(old.replace(marker,marker+'\n'+text+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[56受控交接与完整三角色通过](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[56受控交接与完整三角色通过]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**新版完整三角色单次真实通过（2026-10-27）。** '+body+' 见[56]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [56新版完整三角色单次真实通过](Project/'+name+')：受控文档交接后，文档/修复/审查均成功、无降级，Click补丁干净重放公开2/保留3/登记上游116全过。75项相关离线检查通过；旧失败与六题负比较不回填，不能推断通用成功率或多Agent收益。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[56受控交接与完整三角色通过](../shixi_project/Project/'+name+')：'+body)
print('Updated current status and standing authorization in repository and Job navigation.')
