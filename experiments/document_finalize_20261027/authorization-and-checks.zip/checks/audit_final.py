"""Read-only final acceptance, citations, author handoff and conservation audit."""
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;LIVE=OUT/'live_attempt_1';BATCH=LIVE/'batch'
import sys
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent import ConsultationRecord,consultation_context
from collaboration_protocol import canonical_bytes
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result=read(BATCH/'result.json');audit=read(BATCH/'audit.json');plan=read(LIVE/'plan.json')
assert result['run_id']=='8efbd91f5de942478a81bd654a13066d' and result['complete_three_role_acceptance'] is True
assert result['status']=='finished' and result['collaboration_result']=='completed' and result['review_verdict']=='approve'
assert all(result['checks'][key]['successful'] for key in ('public','withheld','upstream'))
assert [(result['checks'][key]['passed'],result['checks'][key]['tests_run']) for key in ('public','withheld','upstream')]==[(2,2),(3,3),(116,116)]
assert all(any(r['phase']==phase and r['status']=='succeeded' for r in audit['roles']) for phase in ('consulting','repairing','reviewing'))
assert all(sha(ROOT/n)==h for n,h in plan['input_files_sha256'].items())
assert audit['new_parent_runs']==1 and audit['extra_selection_reruns']==0 and audit['new_attempts']==31
history=read(OUT/'historical-before.json');assert len(history)==74 and all(sha(ROOT/n)==h for n,h in history.items())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
before=read(OUT/'ledger-before.json');after=read(LIVE/'ledger-after.json')
assert read(ROOT/'data/deepseek_budget.json')==after and len(before['requests'])==2446 and len(after['requests'])==2477
assert all(after['requests'][k]==v for k,v in before['requests'].items())
home=BATCH/'store/runs'/result['run_id'];records=read(home/'consultations.json');assert len(records)==1
record=ConsultationRecord.parse(records[0]);payload=consultation_context(record,BATCH/'store')
assert len(canonical_bytes(payload))<=6144 and record.advice.status=='answered' and record.advice.unknowns
assert len(record.advice.evidence_ids)==4 and len(payload['excerpts'])==4
doc_trace=read(home/'consulting-trajectory.json')['messages']
switches=[m for m in doc_trace if m.get('role')=='user' and m.get('content','').startswith('Document lookup is now CLOSED')]
assert len(switches)==1
switch=doc_trace.index(switches[0]);after_switch=[a for m in doc_trace[switch+1:] for a in m.get('extra',{}).get('actions',[])]
assert len(after_switch)==1 and after_switch[0]['tool']=='submit_consultation'
repair_trace=read(home/'repairing-trajectory.json')['messages']
assert any('document_tree_digest' in m.get('content','') and record.advice.advice_id in m.get('content','') for m in repair_trace)
patched=home/'repair.diff';assert sha(patched)==result['patch_sha256']
review_trace=read(home/'reviewing-trajectory.json')['messages']
corrections=[m['content'] for m in review_trace if m['role']=='user' and m.get('content','').startswith('Invalid review tool call:')]
for name,count in [('document-tests.txt',49),('runtime-tests.txt',26)]:
    text=(OUT/name).read_text(encoding='utf-8-sig');assert f'Ran {count} tests in ' in text and text.rstrip().endswith('OK')
report={'complete_three_role_acceptance':True,'public_passed':2,'withheld_passed':3,'registered_upstream_passed':116,
    'consultation_status':record.advice.status,'consultation_claim_truth':'not independently established; changelog excerpts and explicit unknowns retained',
    'consultation_handoff_bytes':len(canonical_bytes(payload)),'exact_citations_validated':len(payload['excerpts']),
    'controlled_finalization_switches':1,'after_switch_tools':[a['tool'] for a in after_switch],
    'author_received_consultation':True,'review_format_corrections':corrections,
    'source_base_commit':plan['base_commit'],'frozen_inputs_verified':452,'source_changes_before_run':[
        'scripts/review_model.py','scripts/document_model.py','scripts/collaboration_runtime.py','scripts/test_document_context.py'],
    'formal_payloads_unchanged':53,'old_requests_unchanged':2446,'shared_requests_after':2477,
    'new_parent_runs':1,'extra_selection_reruns':0,'new_attempts':31,'known_price_estimate_cny':audit['known_price_estimate_cny'],
    'unknown_placeholder_cny':audit['unknown_placeholder_cny'],'complete_cost_estimate_cny':None,
    'historical_files_unchanged':74,'offline_tests_passed':75,'historical_files_sha256':history,
    'authorization':'Standing explicit human approval for necessary acceptances across fixes while credit remains; no balance endpoint probed or balance claimed.'}
(OUT/'final-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in {'historical_files_sha256','review_format_corrections','source_changes_before_run','authorization'}}))
