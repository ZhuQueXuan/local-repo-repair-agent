"""Read the completed identity only; never calls a worker or model."""
import json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent;HOME=OUT/'batch'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_store import CollaborationStore
from collaboration_protocol import canonical_bytes
slot=json.loads((HOME/'slot.json').read_bytes());s=CollaborationStore(HOME/'store');row=s.get(slot['run_id']);roles=s.roles(row['id'])
assert row['status'] in {'finished','failed','cancelled','interrupted'}
output=s.home/'runs'/row['id'];phases={}
for role in roles:
    path=output/(role['phase']+'-trajectory.json')
    if not path.is_file():continue
    value=json.loads(path.read_bytes());messages=value['messages']
    actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
    phases[role['phase']]={'assistant_actions':len(actions),'tools':[a.get('tool','bash') for a in actions],
        'exit_records':[{k:m.get('extra',{}).get(k) for k in ('exit_status','limit_kind','message_utf8_bytes','max_messages_utf8_bytes')} for m in messages if m.get('role')=='exit']}
    if role['role']=='repairer':
        work=Path(row['workspace']);path=work/'temp/task-state/requests.jsonl'
        if path.is_file():
            records=[json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
            phases[role['phase']]['program_progress_phases']=list(dict.fromkeys(json.loads(v['message']['content'].split('\n',1)[1]).get('execution_progress',{}).get('phase') for v in records))
        path=work/'temp/task-state/progress.jsonl'
        if path.is_file():
            records=[json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
            phases[role['phase']]['last_progress']=records[-1] if records else None
summary={'task':slot['task'],'run_id':row['id'],'status':row['status'],'collaboration_result':row['collaboration_result'],
    'repair_result':row['repair_result'],'review_verdict':row['review_verdict'],'reason':row['reason'],
    'document_unavailable':row.get('document_unavailable'),'phases':phases,
    'projection_events':{name:json.loads(path.read_bytes()) for name in ('repair-context-projections','review-context-projections','document-context-projections') if (path:=output/(name+'.json')).is_file()}}
(OUT/'inspection.json').write_bytes(canonical_bytes(summary))
print(json.dumps({k:v for k,v in summary.items() if k not in {'projection_events','phases'}},ensure_ascii=False))
print(json.dumps({'phase_details':{k:{a:b for a,b in v.items() if a!='last_progress'} for k,v in phases.items()}},ensure_ascii=False))
