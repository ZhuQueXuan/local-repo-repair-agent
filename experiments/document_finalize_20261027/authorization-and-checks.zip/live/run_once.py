"""One user-requested post-fix Click closure, never a retry loop."""
import hashlib,json,os,sqlite3,subprocess,sys,time,uuid
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent;BATCH=OUT/'batch'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(LITELLM_LOCAL_MODEL_COST_MAP='True',MSWEA_SILENT_STARTUP='1',PYTHONDONTWRITEBYTECODE='1')
from collaboration_protocol import canonical_bytes
from collaboration_store import CollaborationStore
from collaboration_panel import public_policy,usage_view
from task_service_store import worker_lock,TERMINAL
from comparison_batch import select_patch,evaluator
from task_workspace import prepare_task,changed_files
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_bytes(canonical_bytes(v))
PLAN=OUT/'plan.json'
def verify():
    assert sha(PLAN.read_bytes())==json.loads((OUT/'plan-sha256.json').read_bytes())['sha256']
    plan=json.loads(PLAN.read_bytes())
    assert plan['tasks']==['click-flag-default-map'] and plan['maximum_new_parent_runs']==1
    assert all(sha((ROOT/n).read_bytes())==h for n,h in plan['input_files_sha256'].items()),'Prepared input changed'
    return plan
if sys.argv[1:]==['--prepare']:
    assert not PLAN.exists(),'Prepared plan must not be overwritten'
    original=json.loads((ROOT/'configs/harness_stability_revalidation_20261027.json').read_bytes())
    original.update(tasks=['click-flag-default-map'],maximum_new_parent_runs=1,status='prepared_under_standing_human_approval',
        purpose='One known Click development case after the controlled document finalization fix; supported facts and explicit unknowns remain mandatory. Full three-role acceptance requires a successful consultation, repair, review and independent final checks. Not a fresh benchmark or causal comparison.',
        authorization='Human standing approval explicitly permits necessary real acceptances across fixes while credit is available; this is one frozen run under that approval.',
        request_key='controlled-document-finalization-'+uuid.uuid4().hex,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip())
    original['input_files_sha256']={n:sha((ROOT/n).read_bytes()) for n in original['input_files_sha256']}
    original['input_files_sha256'][Path(__file__).relative_to(ROOT).as_posix()]=sha(Path(__file__).read_bytes())
    original['policy']=public_policy(documents=True,question='For the reported Click boolean-flag help/default_map issue, what do the frozen repository documents say about default_map, effective option defaults and show_default/help text? Cite only supported statements and explicitly mark behavior or interactions that are not documented; do not infer new repair requirements.')
    write(PLAN,original);write(OUT/'plan-sha256.json',{'sha256':sha(PLAN.read_bytes()),'input_files':len(original['input_files_sha256'])})
    print(json.dumps({'prepared':True,'tasks':original['tasks'],'maximum_runs':1,'inputs':len(original['input_files_sha256']),'model_calls':0}))
    raise SystemExit(0)
assert sys.argv[1:]==['--execute-one'],'Choose prepare or explicit one-run execution'
plan=verify();assert not BATCH.exists(),'Never replay or replace this identity'
approval=json.loads((OUT/'explicit-user-approval.json').read_bytes())
assert approval.get('approved') is True and approval.get('maximum_new_parent_runs')==1
assert approval.get('task')=='click-flag-default-map' and approval.get('plan_sha256')==sha(PLAN.read_bytes())
assert approval.get('source') and not (OUT/'consumed-authorization.json').exists()
write(OUT/'consumed-authorization.json',{'plan_sha256':sha(PLAN.read_bytes()),'new_parent_runs_allowed':1,'no_second_dispatch':True})
BATCH.mkdir()
write(BATCH/'authorization.json',{'approved':True,'maximum_runs':1,'plan_sha256':sha(PLAN.read_bytes()),
    'source':approval['source'],
    'routing':plan['routing'],'outbound':plan['outbound'],'fees':plan['fees'],'no_selection_reruns':True})
with worker_lock(BATCH,'batch.lock') as owned:
    assert owned
    with worker_lock(ROOT/'data/task_service') as idle:
        assert idle,'Formal worker busy'
        with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
            before=dict(db.execute('SELECT id,payload FROM runs'))
        assert len(before)==53 and not any(json.loads(v)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for v in before.values())
        write(OUT/'formal-before.json',before);ledger_before=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
        write(OUT/'ledger-before.json',ledger_before);assert len(ledger_before['requests'])==2446
        protected={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for top in ('experiments/harness_comparison_20261027','experiments/harness_stability_20261027','experiments/click_closure_20261027','experiments/read_guard_20261027','experiments/click_guard_revalidation_20261027','experiments/document_correction_20261027','experiments/three_role_revalidation_20261027','experiments/document_audit_20261027','experiments/full_three_role_acceptance_20261027') for p in (ROOT/top).rglob('*') if p.is_file()}
        write(OUT/'historical-before.json',protected)
        store=CollaborationStore(BATCH/'store')
        write(BATCH/'dispatched.json',{'request_key':plan['request_key'],'plan_sha256':sha(PLAN.read_bytes()),'state':'claiming_once'})
        row=store.create_collaboration(plan['tasks'][0],'adaptive_history',plan['request_key'],plan['policy'],execution='live',
            model_profile=plan['model_profile'],allow_pause=False,allow_capabilities=True,task_card={
            'goal':'Fix the original issue under its constraints; retain failed documentation and uncertainty honestly.',
            'steps':[{'id':'repair','title':'Read, repair and validate the original issue','status':'pending'}],
            'instruction':'At most one revision. Retain all failures. Submit when current declared checks and diff are ready; no reruns for selection.'})
        slot={'task':plan['tasks'][0],'variant':'full','request_key':plan['request_key'],'run_id':row['id']};write(BATCH/'slot.json',slot)
        verify()
        command=[sys.executable,'-B',str(ROOT/'scripts/task_service_worker.py'),'--collaboration','--run-id',row['id'],'--home',str(store.home)]
        print(json.dumps({'starting':slot},ensure_ascii=False),flush=True)
        with (BATCH/'worker.log').open('xb') as log:
            process=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            last=None;deadline=time.monotonic()+1860
            while process.poll() is None:
                current=store.get(row['id']);marker=(current['status'],current.get('stage'))
                if marker!=last:print(json.dumps({'status':marker[0],'phase':marker[1]}),flush=True);last=marker
                if time.monotonic()>=deadline:
                    from execution_backend import terminate_owned_process
                    terminate_owned_process(process);process.wait(timeout=10)
                    store.update(row['id'],status='failed',stage='done',reason='Owned worker deadline; no automatic replay')
                    break
                time.sleep(.5)
            process.wait(timeout=10)
        current=store.get(row['id'])
        if current['status'] not in TERMINAL:store.update(row['id'],status='failed',stage='done',reason='Worker ended without terminal result; no replacement')
        current=store.get(row['id']);assert current['status'] in TERMINAL and current['status']!='paused'
        verify();write(BATCH/'worker-terminal.json',{'run_id':row['id'],'status':current['status'],'retained_scoring_not_started_before_this_receipt':True})
        result={**slot,**{k:current.get(k) for k in ('status','collaboration_result','repair_result','review_verdict','reason','metrics')},'resolved':False}
        patch,selection=select_patch(store,current);result['candidate_selection']=selection
        if patch is None:result['evaluation_error']='No sealed/exported final patch; retained as unresolved'
        else:
            try:
                repo,manifest=prepare_task(slot['task']);result['patch_sha256']=sha(patch.read_bytes())
                applied=subprocess.run(['git','-C',str(repo),'apply','--',str(patch)],capture_output=True,timeout=30)
                if applied.returncode:raise ValueError('Patch replay failed')
                changes=changed_files(repo,manifest)
                assert changes and all(n in manifest['source_files_sha256'] and n.startswith(manifest['source_prefix']) for n in changes)
                result['checks']=evaluator(slot['task'],repo,BATCH/'terminal-score')
                result['resolved']=all(result['checks'][k]['successful'] for k in ('public','withheld','upstream'))
            except Exception as error:result['evaluation_error']=type(error).__name__+': '+str(error)[:180]
        roles=store.roles(row['id'])
        result['complete_three_role_acceptance']=bool(result['resolved'] and current.get('status')=='finished'
            and current.get('collaboration_result')=='completed' and current.get('review_verdict')=='approve'
            and all(any(r['phase']==phase and r['status']=='succeeded' for r in roles) for phase in ('consulting','repairing','reviewing')))
        write(BATCH/'result.json',result)
        with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:assert dict(db.execute('SELECT id,payload FROM runs'))==before
        after=json.loads((ROOT/'data/deepseek_budget.json').read_bytes());assert all(after['requests'][k]==v for k,v in ledger_before['requests'].items())
        new={k:v for k,v in after['requests'].items() if k not in ledger_before['requests']}
        assert all(v.get('attribution',{}).get('run_id')==row['id'] for v in new.values())
        known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
        unknown=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']!='settled'),Decimal(0))
        assert all(sha((ROOT/n).read_bytes())==h for n,h in protected.items());verify()
        audit={'new_parent_runs':1,'old_requests_unchanged':len(ledger_before['requests']),'new_attempts':len(new),'shared_requests_after':len(after['requests']),
            'known_price_estimate_cny':str(known),'unknown_placeholder_cny':str(unknown),'complete_cost_estimate_cny':str(known) if not unknown else None,
            'formal_payloads_unchanged':53,'historical_artifacts_unchanged':len(protected),'input_hashes_verified':len(plan['input_files_sha256']),
            'extra_selection_reruns':0,'roles':store.roles(row['id']),'usage':usage_view(store,current),
            'scope':'One known Click development regression; prior failures remain. No fresh comparison or general stability claim.'}
        write(BATCH/'audit.json',audit);write(OUT/'ledger-after.json',after)
        print(json.dumps({'complete':True,'result':{k:result.get(k) for k in ('task','run_id','status','resolved','collaboration_result','repair_result','review_verdict')},
            'attempts':len(new),'known_price_estimate_cny':str(known),'unknown_placeholder_cny':str(unknown)},ensure_ascii=False),flush=True)
