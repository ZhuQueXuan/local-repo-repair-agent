"""Read-only protection audit, then update progress navigation; no model calls."""
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');before=read(OUT/'ledger-before.json');after=read(OUT/'ledger-after.json')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert read(ROOT/'data/deepseek_budget.json')==after
assert len(before['requests'])==2287 and len(after['requests'])==2360
assert all(after['requests'][k]==v for k,v in before['requests'].items())
assert all(sha(ROOT/n)==h for n,h in plan['input_files_sha256'].items())
history=read(OUT/'historical-before.json');assert all(sha(ROOT/n)==h for n,h in history.items())
check={'formal_payloads_unchanged':len(formal),'old_requests_unchanged':len(before['requests']),
       'shared_requests_after':len(after['requests']),'new_attempts':73,
       'frozen_inputs_unchanged':len(plan['input_files_sha256']),'historical_artifacts_unchanged':len(history),
       'new_parent_runs':1,'extra_selection_reruns':0,'source_changes_this_turn':0}
(OUT/'protection-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
name='49_验收_Click补修后的单题真实闭环.md'
body='用户明确批准后仅新增一次Click真实验收，文档成功；初修68个Bash动作反复读源码，无实现变更/验证或候选，最后DeepSeek连接408/ProviderUnavailable，未进审查，完整闭环未通过。本轮未再触发任务卡context_bytes停止，但不证明整体稳定。73尝试已知估算0.556818元、未知占位0.20，完整费用未知；正式53payload/旧2287请求保持，现2360，452冻结输入/32历史文件保持。0源码变更、0追加重跑；阶段48 query成功与Click失败、六题负比较均保留。下一步先离线分析修复者停滞，不自动新付费，不涉及异机或医疗。'
def edit(p,transform):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n'
    text=raw.decode('utf-8').replace('\r\n','\n');updated=transform(text)
    if updated!=text:p.write_bytes(updated.replace('\n',newline).encode('utf-8'))
def insert(text,marker,value):
    assert marker in text
    if name in text:return text
    return text.replace(marker,marker+'\n'+value+'\n',1)
edit(ROOT/'AGENTS.md',lambda s:insert(s,'## 当前阶段\n','- 2026-10-27最新：[49 Click单题闭环](Project/'+name+')：'+body))
edit(ROOT/'Project/00_项目现状与快速接手.md',lambda s:insert(s,'最后更新：2026-10-27。\n','2026-10-27最新：[49 Click单题闭环]('+name+')：'+body))
edit(ROOT/'Project/项目开发流水账.md',lambda s:insert(s,'# 项目开发流水账\n','**Click单次闭环仍失败（2026-10-27）。** '+body+' 见[49]('+name+')。'))
old='补修后尚无新的真实闭环。'
replacement='补修后的一次Click真实闭环仍失败：未再超长，但修复者反复读源码未修改，最后接口超时，未进入审查，见[49](Project/'+name+')；接下来先离线处理停滞，不立即付费重跑。'
edit(ROOT/'README.md',lambda s:s.replace(old,replacement,1))
job=ROOT.parent/'job/AGENTS.md'
edit(job,lambda s:insert(s,'## 当前状态与导航\n','- 2026-10-27主项目最新：[49 Click单题闭环](../shixi_project/Project/'+name+')：'+body))
print(json.dumps(check))
