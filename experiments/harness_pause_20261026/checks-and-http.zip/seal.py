"""Seal the feature and its explicitly limited offline evidence, no model transport."""
import hashlib
import json
from pathlib import Path
import zipfile
from dotenv import dotenv_values

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
DEST=ROOT/'experiments/harness_pause_20261026'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Do not overwrite a sealed delivery'
protection=json.loads((OUT/'protection-check.json').read_bytes())
basic=json.loads((OUT/'basic-check.json').read_bytes())
archive=json.loads((OUT/'archive-check.json').read_bytes())
http=json.loads((OUT/'http-check.json').read_bytes())
terminal=json.loads((OUT/'terminal-check.json').read_bytes())
assert basic['final_status']=='finished' and basic['synthetic_ledger_attempts']==10
assert archive['old_archives_preserved']==3 and archive['source_payload_unchanged']
assert http['preview_service_stopped'] and terminal['terminal_pause_flag_cleared']
log=(OUT/'compatibility.log').read_text(encoding='utf-8')
assert 'Ran 5 tests' in log and log.rstrip().endswith('OK')
sources=['harness_checkpoints.py','task_service_store.py','collaboration_store.py',
    'collaboration.py','collaboration_live.py','collaboration_panel.py','task_service.py',
    'task_service_worker.py','task_cards.py','document_agent_demo.py','checkpoint_panel.js',
    'task_panel.html','collaboration_panel.js']
documents=[ROOT/'Project/37_过程_Harness阶段暂停与检查点续做.md',
    ROOT/'Project/36_过程_Harness任务卡与运行中要求补充.md',ROOT/'Project/35_调研_Agent_Harness主流方案与项目演进建议.md',
    ROOT/'Project/00_项目现状与快速接手.md',ROOT/'Project/项目开发流水账.md',ROOT/'AGENTS.md',ROOT/'README.md',ROOT.parent/'job/AGENTS.md']
secrets=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(secrets)>=2,'Private key scan unavailable'
DEST.mkdir()
outer={};scanned=0;counts={}
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,label in entries:
            if not path.is_file() or path.name in {'.env','server.lock','worker.lock'} or '__pycache__' in path.parts:
                continue
            raw=path.read_bytes()
            assert not any(secret in raw for secret in secrets),'Credential scan blocked delivery'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:
        assert all(sha(z.read(k))==v for k,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    outer[name]=sha((DEST/name).read_bytes())
    outer[name+'.sha256.json']=sha((DEST/(name+'.sha256.json')).read_bytes())
    counts[name]=len(members)
pack('source-and-documents.zip',[(ROOT/'scripts'/n,'scripts/'+n) for n in sources]+
     [(p,p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else 'job/AGENTS.md') for p in documents])
pack('checks-and-http.zip',[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.rglob('*'))])
for name,home in [('four-boundary-scripted-chain.zip',basic['store_home']),
                  ('output-archive-scripted-chain.zip',archive['store_home']),
                  ('isolated-http-fixture.zip',str(ROOT/'temp/document_agent_demo/89a44c79e573497ba4c7a403f4f3b189'))]:
    home=Path(home)
    pack(name,[(p,p.relative_to(home).as_posix()) for p in sorted(home.rglob('*'))])
result={**protection,'scope':'Optional role-boundary checkpoints and linked continuation; scripted replies, local execution. Not live-model/browser/full-regression acceptance.',
        'basic_check':basic,'output_archive_check':archive,'http_check':http,'terminal_check':terminal,
        'compatibility_checks_passed':5,'full_regression_run':False,'new_formal_test_files':0,
        'browser_clicks_verified':False,'original_panel':json.loads((OUT/'panel-restored.json').read_bytes()),
        'credential_scan':{'keys_checked':len(secrets),'files_scanned':scanned,'matches':0},'archive_member_counts':counts,
        'pending':['Real model behavior','Current browser clicks','Abnormal process failure scenarios','Consolidated end-to-end tests','Tool and Skills interfaces']}
write(DEST/'verification.json',result)
outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'protected_files':protection['protected_old_files_hash_verified'],'formal_rows':protection['formal_payloads_unchanged'],'ledger_requests':protection['shared_ledger_requests']},ensure_ascii=False))
