from pathlib import Path
root=Path(__file__).resolve().parents[2]
path=root/'scripts/collaboration_live.py'
text=path.read_text(encoding='utf-8')
start=text.index('    def repair(self, context):')
init=text.index('            env = RepairEnvironment',start)
stop=text.index('            status = self.session.start(self.issue.decode())',init)
block=text[init:stop]
block='\n'.join(line[4:] if line.startswith('    ') else line for line in block.split('\n'))
# A restored author session must not rerun preflight commands from the old role.
prestart=block.index('        preflight = env.execute')
prestop=block.index('        instruction = ',prestart)
pre=block[prestart:prestop]
block=block[:prestart]+'        if imported is None:\n'+''.join('    '+line+'\n' for line in pre.rstrip('\n').split('\n'))+block[prestop:]
helper='''    def make_repair_session(self, context, imported=None):
        configuration = self.store.get(self.run_id)["configuration"]
'''+block+'''        if imported is not None:
            from copy import deepcopy
            agent.messages = deepcopy(imported["messages"])
            agent.env.completed_submission = deepcopy(imported["submission"])
            agent.extra_template_vars.update(deepcopy(imported["extra_template_vars"]))
            if self.documents:
                agent.extra_template_vars["document_consultation"] = document_context
            # Verified old tool outputs remain historical; their paths are not
            # capabilities in the new checkout. Current feedback supplies IDs.
            self.session.submitted_history()
        return self.session

'''
replacement='''    def repair(self, context):
        if context.role["phase"] == "repairing":
            self.make_repair_session(context)
'''
text=text[:start]+helper+replacement+text[stop:]
text=text.replace('''            if self.session is None:
                raise ProtocolError("No in-process repair session; automatic resume prohibited")''','''            if self.session is None:
                if self.restored_session is None:
                    raise ProtocolError("No verified repair history; automatic resume prohibited")
                self.make_repair_session(context, self.restored_session)''',1)
text=text.replace('''            text = repair_feedback(self.work, review, evidence, self.manifest)
''','''            text = repair_feedback(self.work, review, evidence, self.manifest)
            if record.get("continued_from"):
                text = ("This is an explicitly linked NEW continuation identity using verified imported author history. "
                    "Do not replay old commands or requests. Old paths/IDs in historical messages are not current capabilities. "
                    "Use the current feedback bindings and this checkout; frozen issue and restrictions remain unchanged.\\n" + text)
''',1)
# repair() still needs the current record for the continuation notice.
text=text.replace('''    def repair(self, context):
        if context.role''','''    def repair(self, context):
        record = self.store.get(self.run_id)
        if context.role''',1)
path.write_text(text,encoding='utf-8')
