"""One offline checkpoint chain; scripted model transport, real local work."""
import json
import os
from pathlib import Path
import sys
import uuid

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent_demo import exercise
from harness_checkpoints import request_pause,continue_checkpoint,checkpoint_view,CheckpointConflict
from collaboration_protocol import canonical_bytes
from task_cards import card_view

card={'schema_version':1,'goal':'完成原问题，按阶段暂停并核对续做','steps':[{'id':'work','title':'完成受约束修复','status':'in_progress'}],
    'constraints':'旧身份不重跑','instruction':'CHECKPOINT_CARD','blocker':'','next_action':'在安全边界推进'}
phases=['consulting','repairing','reviewing','revising']
all_wires=[];rows=[]
def callback(target):
    def checkpoint(name,role,runner):
        if name=='after_role_completion' and role['phase']==target:
            request_pause(runner.store,runner.run_id)
    return checkpoint

store,runner,summary,wires=exercise(task_card=card,allow_pause=True,checkpoint=callback('consulting'))
all_wires.extend(wires)
first_payload=store.get(summary['run_id'])
assert first_payload['status']=='paused',first_payload
paused_ids=[]
for ordinal,phase in enumerate(phases):
    row=store.get(summary['run_id']);paused_ids.append(row['id'])
    assert row['status']=='paused' and row.get('live_receipts_digest')
    view=checkpoint_view(store,row['id']);assert view['can_continue']
    key='offline-continuation-'+uuid.uuid4().hex
    body={'request_key':key,'checkpoint_sha256':row['checkpoint_sha256'],'task_card':dict(card,instruction='CONTINUED_CARD_'+str(ordinal))}
    # Tamper one checkpoint work file before the first continuation. A clean
    # refusal must create no child; restore the exact original fixture bytes.
    if ordinal==0:
        path=store.home/row['checkpoint_path'];manifest=json.loads(path.read_bytes())
        name=next(n for n in manifest['files_sha256'] if n.startswith('work/'))
        target=path.parent/name;original=target.read_bytes();target.write_bytes(original+b'\nTAMPER')
        count=len(store.list())
        try:
            continue_checkpoint(store,row['id'],body)
            raise AssertionError('tampered checkpoint accepted')
        except CheckpointConflict:pass
        assert len(store.list())==count
        target.write_bytes(original)
    before=canonical_bytes(store.get(row['id']))
    child=continue_checkpoint(store,row['id'],body)
    assert child['id']!=row['id'] and child['continued_from']==row['id']
    assert canonical_bytes(store.get(row['id']))==before
    assert continue_checkpoint(store,row['id'],body)['id']==child['id']
    try:
        continue_checkpoint(store,row['id'],dict(body,request_key=uuid.uuid4().hex))
        raise AssertionError('second identity accepted')
    except CheckpointConflict:pass
    rows.append({'source':row['id'],'child':child['id'],'next_phase':row['checkpoint_next_phase'],
        'remaining_seconds':child['remaining_parent_seconds'],'source_unchanged':True})
    stop=phases[ordinal+1] if ordinal+1<len(phases) else None
    store,runner,summary,wires=exercise(continuation={'home':str(store.home),'run_id':child['id']},checkpoint=callback(stop) if stop else None)
    all_wires.extend(wires)
    (OUT/'progress.json').write_text(json.dumps({'transitions':rows,'latest_run':summary['run'],'phases':[w['phase'] for w in all_wires]},ensure_ascii=False,indent=2),encoding='utf-8')
assert summary['run']['status']=='finished',summary['run']
assert summary['run']['repair_result']=='passed' and summary['run']['review_verdict']=='approve'
assert [w['phase'] for w in all_wires]==['consulting']*3+['repairing']*2+['reviewing']*2+['revising']*2+['final_review']
assert store.get(paused_ids[0])==first_payload
assert all(store.get(key)['status']=='paused' for key in paused_ids)
ledger=json.loads((store.home/'synthetic_ledger.json').read_bytes())
assert len(ledger['requests'])==len(all_wires)
assert all(r['status'] not in {'queued','running','cancel_requested'} for r in store.list())
result={'scope':'One scripted transport/usage chain, real source/grading/replay. Not live model acceptance.',
    'transitions':rows,'paused_sources':paused_ids,'final_run':summary['run']['id'],'final_status':summary['run']['status'],
    'repair_result':summary['run']['repair_result'],'review_verdict':summary['run']['review_verdict'],
    'phase_call_counts':{p:sum(w['phase']==p for w in all_wires) for p in phases+['final_review']},
    'old_parent_payloads_unchanged':True,'tampered_checkpoint_rejected_without_child':True,'idempotent_one_child_per_source':True,
    'synthetic_ledger_attempts':len(ledger['requests']),'store_home':str(store.home),'external_model_calls':0}
(OUT/'basic-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
