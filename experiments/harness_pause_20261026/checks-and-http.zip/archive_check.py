"""Focused continuation with old output archives retained and counters carried."""
import json
import os
from pathlib import Path
import sys
import uuid

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent_demo import exercise
from harness_checkpoints import request_pause,continue_checkpoint,checkpoint_view
from task_cards import card_view
from collaboration_protocol import sha256
from collaboration_panel import usage_view

card={'goal':'按原题修复并保留旧输出归档','steps':[{'id':'work','title':'完成修复','status':'in_progress'}]}
def checkpoint(name,role,runner):
    if name=='after_role_completion' and role['phase']=='repairing':request_pause(runner.store,runner.run_id)
store,oldrunner,summary,wires=exercise(task_card=card,allow_pause=True,checkpoint=checkpoint)
row=summary['run'];assert row['status']=='paused',row
before=store.get(row['id']);view=checkpoint_view(store,row['id']);current=card_view(store,row['id'])
events=oldrunner.session.agent.env.output_budget.events
assert events
hashes={e['full_output_path']:e['sha256'] for e in events}
child=continue_checkpoint(store,row['id'],{'request_key':'archive-'+uuid.uuid4().hex,'checkpoint_sha256':view['checkpoint_sha256'],'task_card':current['card']})
store,newrunner,summary,newwires=exercise(continuation={'home':str(store.home),'run_id':child['id']})
assert summary['run']['status']=='finished' and summary['run']['repair_result']=='passed',summary['run']
assert summary['run']['review_verdict']=='approve'
assert [w['phase'] for w in newwires]==['reviewing']*2+['revising']*2+['final_review']
assert store.get(row['id'])==before
for name,expected in hashes.items():assert sha256((newrunner.work/name).read_bytes())==expected
new_events=newrunner.session.agent.env.output_budget.events
assert len(new_events)>len(events)
assert new_events[len(events)]['sequence']==len(events)+1
assert newrunner.session.agent.env.task_state.original_files==oldrunner.session.agent.env.task_state.original_files
usage=usage_view(store,store.get(child['id']))
assert usage['lineage']['attempts']==len(wires)+len(newwires)
assert usage['lineage']['segments']==2
result={'scope':'Scripted replies/usage; actual local repair/checks/replay. Not live model success.',
    'source':row['id'],'child':child['id'],'store_home':str(store.home),
    'old_archives_preserved':len(hashes),'new_output_sequence_continues':True,'task_state_original_files_preserved':True,
    'source_payload_unchanged':True,'only_pending_roles_executed':True,'repair_result':'passed','review_verdict':'approve',
    'lineage_usage':usage['lineage'],'external_model_calls':0}
(OUT/'archive-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
