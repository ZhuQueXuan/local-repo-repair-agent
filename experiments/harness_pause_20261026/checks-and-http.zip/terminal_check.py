"""Final-completion hygiene; no model, shell or HTTP."""
import os
from pathlib import Path
import sys
import json
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True';os.environ['PYTHON_DOTENV_DISABLED']='1'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from test_collaboration_store import make_store
from collaboration import CollaborationCoordinator
from collaboration_mock import ScriptedRunner
from harness_checkpoints import checkpoint_view
store,parent=make_store()
store.update(parent['id'],harness_pause_version=1,pause_requested=False)
def checkpoint(name,role):
    if name=='after_role_output' and role['phase']=='reviewing':store.update(parent['id'],pause_requested=True)
result=CollaborationCoordinator(store,ScriptedRunner(store,verdict='approve'),checkpoint=checkpoint).run(parent['id'])
assert result['status']=='finished' and not result['pause_requested']
assert not checkpoint_view(store,parent['id'])['pause_requested']
payload={'final_completion_wins_over_pause':True,'terminal_pause_flag_cleared':True,'external_model_calls':0,'scope':'Synthetic coordinator fixture only, no execution/model transport'}
(OUT/'terminal-check.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print(json.dumps(payload))
