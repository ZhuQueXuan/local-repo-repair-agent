"""Check the isolated preview API; it has no supervisor or dispatch path."""
import json
from pathlib import Path
import urllib.request
import urllib.error
import uuid

OUT=Path(__file__).parent
config=json.loads((OUT/'preview-server.json').read_bytes())
base=config['url']
def api(path,body=None,token='offline-checkpoint-preview'):
    request=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),
        headers={'X-Task-Token':token,'Content-Type':'application/json','Origin':base})
    with urllib.request.urlopen(request,timeout=10) as response:return response.status,json.loads(response.read())
source=config['paused_run'];queued=config['queued_run']
status,before=api('/api/runs/'+source)
try:
    api('/api/runs/'+queued+'/pause',{},token='wrong')
    raise AssertionError('unauthenticated pause accepted')
except urllib.error.HTTPError as error:assert error.code==403
_,pending=api('/api/runs/'+queued+'/pause',{})
assert pending['pause_requested'] and pending['status']=='queued'
_,view=api('/api/runs/'+queued+'/checkpoint')
assert view['pause_requested'] and not view['can_continue']
api('/api/runs/'+queued+'/cancel',{})
_,checkpoint=api('/api/runs/'+source+'/checkpoint')
assert checkpoint['can_continue']
_,card=api('/api/runs/'+source+'/task-card')
body={'request_key':'http-continuation-'+uuid.uuid4().hex,'checkpoint_sha256':checkpoint['checkpoint_sha256'],
    'task_card':dict(card['card'],instruction='HTTP_NEW_CARD_LEAVE_SOURCE_UNCHANGED')}
status,child=api('/api/runs/'+source+'/continue',body)
assert status==201 and child['continued_from']==source and child['status']=='queued'
assert api('/api/runs/'+source+'/continue',body)[1]['id']==child['id']
try:
    api('/api/runs/'+source+'/continue',dict(body,request_key=uuid.uuid4().hex))
    raise AssertionError('extra child allowed')
except urllib.error.HTTPError as error:assert error.code==409
assert api('/api/runs/'+source)[1]==before
_,childcard=api('/api/runs/'+child['id']+'/task-card')
assert childcard['card']['instruction']=='HTTP_NEW_CARD_LEAVE_SOURCE_UNCHANGED'
_,collaboration=api('/api/runs/'+child['id']+'/collaboration')
assert collaboration['usage']['lineage']['segments']==2
assert collaboration['usage']['lineage']['attempts']==2
assert collaboration['roles'][0]['inherited_from']==source
api('/api/runs/'+child['id']+'/cancel',{})
status,_=api('/api/shutdown',{})
assert status==200
result={'api_scope':'isolated temp HTTP without workers; not browser-click evidence','pause_queued_defers_until_worker_boundary':True,
    'authentication_enforced':True,'continued_child_once':child['id'],'source_payload_unchanged':True,'updated_card_only_on_child':True,
    'inherited_document_stage_explicit':True,'lineage_usage_attempts':2,'preview_service_stopped':True,
    'external_model_calls':0,'browser_clicks_verified':False,'browser_block':'Local browser use disabled in Work settings; not changed.'}
(OUT/'http-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
