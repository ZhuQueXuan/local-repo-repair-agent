from pathlib import Path
root=Path(__file__).resolve().parents[2]
path=root/'scripts/task_panel.html'
s=path.read_text(encoding='utf-8')
pairs=[
('<button id="start" class="primary">','<label><input id="allowPause" type="checkbox" disabled>允许双/三角色在阶段结束后暂停与续做</label><p class="hint">需开启任务卡；默认关闭。继续会创建关联新任务并产生后续模型用量。</p><button id="start" class="primary">'),
('<section class="card" id="taskCardSection" hidden>','<section class="card" id="checkpointSection" hidden><h2>阶段暂停与续做</h2><p id="checkpointStatus" class="hint"></p><pre id="checkpointLineage"></pre><button id="checkpointPause" disabled>在当前角色完成后暂停</button><div id="checkpointContinueCard" hidden><label for="checkpointInstruction">续做时的补充要求（旧任务卡保持不变）</label><textarea id="checkpointInstruction" maxlength="400" rows="2"></textarea></div><button id="checkpointContinue" disabled>从检查点创建新任务并继续（调用模型）</button><p id="checkpointNotice" class="hint"></p></section><section class="card" id="taskCardSection" hidden>'),
("if(typeof resetTaskCard==='function')resetTaskCard();","if(typeof resetTaskCard==='function')resetTaskCard();if(typeof resetCheckpoint==='function'){resetCheckpoint();$('checkpointContinueCard').dataset.loadedFor='';}"),
("if(typeof refreshTaskCard==='function')await refreshTaskCard(row,revision);","if(typeof refreshTaskCard==='function')await refreshTaskCard(row,revision);if(selected!==row.id||selectionRevision!==revision)return;if(typeof refreshCheckpoint==='function')await refreshCheckpoint(row,revision);"),
("if(card)request.task_card=card;}","if(card)request.task_card=card;}if($('allowPause').checked)request.allow_pause=true;"),
('<script src="/task-card-panel.js"></script>','<script src="/task-card-panel.js"></script><script src="/checkpoint-panel.js"></script>')]
for a,b in pairs:
    assert s.count(a)==1,a
    s=s.replace(a,b,1)
path.write_text(s,encoding='utf-8')
