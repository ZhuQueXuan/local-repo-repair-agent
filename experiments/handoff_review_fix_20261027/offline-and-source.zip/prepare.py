import ast,hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
source=(ROOT/'temp/repair_closeout_20261027/run_acceptance.py').read_text('utf-8')
source=source.replace('Exactly two full-role post-fix development acceptances','One full-role handoff/review development acceptance')
source=source.replace('from comparison_inputs import FRESH_TASKS',"TASKS=('boltons-aware-relative',)").replace('FRESH_TASKS','TASKS')
for old,new in [("len(p['slots'])==2","len(p['slots'])==1"),("p['maximum_runs']==2","p['maximum_runs']==1"),
 ('maximum_runs=2','maximum_runs=1'),("'maximum_runs':2","'maximum_runs':1"),("'new_parent_runs':2","'new_parent_runs':1"),
 ('len(initial)==2714','len(initial)==2781'),('Two known development tasks, full-role post-fix acceptance only','One known timeutils development task after handoff and review corrections'),("'closeout-'","'handoff-review-'")]:
 source=source.replace(old,new)
ast.parse(source)
target=OUT/'run_acceptance.py';assert not target.exists();target.write_text(source,encoding='utf-8')
logs={'context-tests.txt':23,'document-tests.txt':23,'runtime-tests.txt':29,'integration-tests.txt':3}
for name,count in logs.items():
 text=(OUT/name).read_text('utf-8-sig');assert 'Ran '+str(count)+' tests in ' in text and text.rstrip().endswith('OK')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==json.loads((OUT/'formal-before.json').read_bytes())
assert json.loads((ROOT/'data/deepseek_budget.json').read_bytes())==json.loads((OUT/'ledger-before.json').read_bytes())
history=json.loads((OUT/'historical-before.json').read_bytes())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in history.items())
report={'offline_tests_passed':sum(logs.values()),'suites':logs,'new_regressions_in_existing_files':1,
 'expanded_existing_checks':['exact handoff budget feedback','original issue supplied to document model'],
 'old_trace_replay':json.loads((OUT/'replay.json').read_bytes()),'model_calls':0,'formal_payloads_unchanged':53,'shared_requests_unchanged':2781,'historical_files_unchanged':len(history)}
(OUT/'offline-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'offline_tests_passed':sum(logs.values()),'maximum_runs':1,'shared_requests_unchanged':2781}))
