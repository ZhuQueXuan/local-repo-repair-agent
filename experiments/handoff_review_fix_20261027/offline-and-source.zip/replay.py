"""Read-only replay of the actual rejected handoff and review read arguments."""
import json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent import DocumentGrant,DocumentEvidence,DocumentAdvice,ConsultationRecord,consultation_context,DocumentHandoffTooLarge,document_rejection
from collaboration_protocol import Candidate,Requirement,RoleIdentity,Handoff,ProgramReport,canonical_bytes
from review_tools import ReviewSnapshot,ReviewEvidenceBroker,ReviewReadRangeError,review_rejection,ReadLines
OLD=ROOT/'temp/repair_closeout_20261027/live/store';RUN='ae0950e2d075476d86533ab85fa5475e'
trace=json.loads((OLD/'runs'/RUN/'consulting-trajectory.json').read_bytes())
grant_path=next((OLD/'document_snapshots'/RUN).glob('*/grant.json'))
grant=DocumentGrant.parse(json.loads(grant_path.read_bytes()))
evidence={}
for m in trace['messages']:
 if m['role']!='tool':continue
 d=json.loads(m['content'])
 for h in ([d] if d.get('evidence') else d.get('hits',[])):
  ref=DocumentEvidence.parse(h['evidence']);evidence[ref.evidence_id]=ref
submits=[a for m in trace['messages'] for a in m.get('extra',{}).get('actions',[]) if a['tool']=='submit_consultation']
advice=DocumentAdvice.parse(submits[-1]['arguments']['advice'])
record=ConsultationRecord(advice_id=advice.advice_id,run_id=RUN,relative_directory=grant_path.parent.relative_to(OLD).as_posix(),
 grant=grant,advice=advice,evidence=tuple(evidence.values()))
try:consultation_context(record,OLD)
except DocumentHandoffTooLarge as error:
 assert error.payload_bytes==6187
 handoff_feedback=document_rejection(error)
 assert handoff_feedback['budget']['over_by_bytes']==43 and len(canonical_bytes(handoff_feedback))<=4096
else:raise AssertionError('Old rejected handoff unexpectedly passed')
with sqlite3.connect((OLD/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 objects=[(k,json.loads(v)) for k,v in db.execute('SELECT kind,payload FROM collaboration_objects WHERE run_id=?',(RUN,))]
 role=json.loads(db.execute('SELECT payload FROM role_runs WHERE run_id=? AND phase=?',(RUN,'reviewing')).fetchone()[0])
snap=next(v for k,v in objects if k=='snapshot');candidate=Candidate.parse(snap['candidate'])
snapshot=ReviewSnapshot(OLD/snap['relative_directory'],candidate,snap['manifest_sha256'],tuple(Requirement.parse(r) for r in snap['requirements']))
identity=RoleIdentity(run_id=RUN,role_run_id=role['id'],session_id=role['session_id'],role='reviewer')
handoff=Handoff.parse(next(v for k,v in objects if k=='handoff'))
broker=ReviewEvidenceBroker(snapshot,identity,handoff,reports=[ProgramReport.parse(v) for k,v in objects if k=='report'])
review_trace=json.loads((OLD/'runs'/RUN/'reviewing-trajectory.json').read_bytes())
old_request=[a for m in review_trace['messages'] for a in m.get('extra',{}).get('actions',[]) if a['tool']=='read_lines'][-1]['arguments']
try:broker.dispatch(identity,'read_lines',old_request)
except ReviewReadRangeError as error:range_feedback=review_rejection(error)
else:raise AssertionError('Old 81-line request unexpectedly passed')
assert range_feedback['requested_line_count']==81 and not broker.evidence
example=range_feedback['example_only_not_executed']
receipt=broker.dispatch(identity,'read_lines',example)
assert receipt['status']=='ok' and len(broker.evidence)==1
result={'old_handoff_bytes':6187,'limit_bytes':6144,'handoff_feedback':handoff_feedback,
 'old_review_range':old_request,'review_range_feedback':range_feedback,
 'developer_corrected_read_received_real_evidence':True,'corrected_evidence_lines':(receipt['evidence']['start_line'],receipt['evidence']['end_line']),
 'old_runs_not_modified':True,'model_calls':0,'scope':'Read-only old-record rejection replay; developer-chosen corrected read, not a model review or new score.'}
(OUT/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'old_handoff_bytes':6187,'new_budget':handoff_feedback['budget'],'old_range_lines':81,'corrected_range':example,'model_calls':0},ensure_ascii=False))
