"""Temporary no-worker UI after one scripted document-stage checkpoint."""
import json
import os
from pathlib import Path
import sys
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from document_agent_demo import exercise
from harness_checkpoints import request_pause
from task_service import make_handler

card={'schema_version':1,'goal':'离线核对阶段暂停与关联续做','constraints':'仅临时库，无执行器，不调用真实模型',
    'steps':[{'id':'inspect','title':'查清文档','status':'done'},{'id':'repair','title':'修复原问题','status':'pending'}],
    'instruction':'旧暂停记录保持只读','blocker':'等待用户补充要求后继续','next_action':'从已保存文档结果开始修复'}
def checkpoint(name,role,runner):
    if name=='after_role_completion' and role['phase']=='consulting':request_pause(runner.store,runner.run_id)
store,runner,summary,wires=exercise(task_card=card,allow_pause=True,checkpoint=checkpoint,attack_bash=False,allow_capabilities=True,model_profile='legacy_deepseek_v1')
assert summary['run']['status']=='paused',summary['run']
queued=store.create_collaboration('split-after-boundary','adaptive_history','queued-pause-ui',summary['run']['collaboration_policy'],execution='live',task_card=card,allow_pause=True)
store.update(queued['id'],transport_scope='scripted_offline')
server=ThreadingHTTPServer(('127.0.0.1',0),BaseHTTPRequestHandler)
with patch('dotenv.dotenv_values',return_value={}):
    Base=make_handler(store,'offline-checkpoint-preview',server.server_port)
class Handler(Base):
    def send(self,status,value,content_type='application/json; charset=utf-8'):
        if content_type.startswith('text/html'):
            value=value.replace('仓库修复 · 任务面板'.encode(),'离线暂停预览 · 无执行器'.encode())
        return super().send(status,value,content_type)
server.RequestHandlerClass=Handler
result={'url':'http://127.0.0.1:'+str(server.server_port),'home':str(store.home),'paused_run':summary['run']['id'],'queued_run':queued['id'],
    'scope':'Document checkpoint replies/usage synthetic. Preview HTTP has no supervisor/worker; continuation creation never dispatches models.'}
(OUT/'preview-server.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
patch('litellm.completion',side_effect=AssertionError('No external model in browser acceptance')).start()
try:server.serve_forever(poll_interval=.5)
finally:server.server_close()
