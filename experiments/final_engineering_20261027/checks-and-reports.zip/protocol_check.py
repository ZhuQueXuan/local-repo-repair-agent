import json
import os
from pathlib import Path
import sys
from copy import deepcopy
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
from model_protocols import AnthropicMessagesOfflineAdapter
from model_profiles import ModelConfigurationError,selection_fields
from review_model import ReviewModel
from review_tools import SCHEMAS
from test_provider_priority import PriorityTests

codec=AnthropicMessagesOfflineAdapter()
tools=[{'type':'function','function':{'name':n,'description':'Read fixed snapshot','parameters':s.model_json_schema()}} for n,s in SCHEMAS.items()]
messages=[{'role':'system','content':'Read-only reviewer.'},{'role':'user','content':'Read the candidate.'},
    {'role':'assistant','content':None,'tool_calls':[{'id':'call_a','type':'function','function':{'name':'read_diff','arguments':'{"candidate_id":"c"}'}},
    {'id':'call_b','type':'function','function':{'name':'read_report','arguments':'{"report_id":"r"}'}}]},
    {'role':'tool','tool_call_id':'call_a','content':'diff-data'},{'role':'tool','tool_call_id':'call_b','content':'report-data'},
    {'role':'user','content':'Keep unknowns explicit.'}]
payload=codec.prepare(messages,tools,model='offline-native-fixture')
assert payload['system']=='Read-only reviewer.' and len(payload['messages'])==3
assert [b['type'] for b in payload['messages'][-1]['content']]==['tool_result','tool_result','text']
raw={'id':'offline-response','model':'offline-native-fixture','type':'message','role':'assistant','stop_reason':'tool_use',
    'content':[{'type':'text','text':'Inspect the diff.'},{'type':'tool_use','id':'next_call','name':'read_diff','input':{'candidate_id':'c'}}],
    'usage':{'input_tokens':100,'output_tokens':20,'cache_creation_input_tokens':30,'cache_read_input_tokens':40}}
normalized=codec.normalize(raw,allowed_tools=set(SCHEMAS))
assert normalized.prompt_tokens==170 and normalized.completion_tokens==20
assert normalized.raw_usage==raw['usage']
actions=ReviewModel._parse_actions(type('OfflineParser',(),{'tool_schemas':SCHEMAS})(),normalized.as_upstream_response())
assert actions==[{'tool':'read_diff','arguments':{'candidate_id':'c'},'tool_call_id':'next_call'}]
failures=[]
def reject(label,call):
    try:call()
    except ModelConfigurationError:failures.append(label)
    else:raise AssertionError(label+' accepted')
reject('pending tool before user',lambda:codec.prepare(messages[:3]+[messages[-1]],tools,model='offline'))
reject('orphan result',lambda:codec.prepare([messages[1],messages[3]],tools,model='offline'))
reject('thinking field',lambda:codec.prepare([messages[1]|{'reasoning_content':'not_supported'}],tools,model='offline'))
reject('missing usage',lambda:codec.normalize(dict(raw,usage={}),allowed_tools=set(SCHEMAS)))
reject('negative usage',lambda:codec.normalize(dict(raw,usage={'input_tokens':-1,'output_tokens':1}),allowed_tools=set(SCHEMAS)))
reject('truncated reply',lambda:codec.normalize(dict(raw,stop_reason='max_tokens'),allowed_tools=set(SCHEMAS)))
reject('unknown block',lambda:codec.normalize(dict(raw,content=[{'type':'thinking','thinking':'hidden'}]),allowed_tools=set(SCHEMAS)))
reject('unregistered output tool',lambda:codec.normalize(raw,allowed_tools={'read_lines'}))
reject('native live transport absent',lambda:codec.complete(api_key='synthetic-only'))
reject('offline profile creation',lambda:selection_fields('anthropic_messages_offline_v1',execution='live',phases=['repairing','reviewing']))
reject('unknown profile creation',lambda:selection_fields('new-name-only',execution='live'))

# Use the existing synthetic budget fixture: rejected capability checks must not reserve a ticket.
fixture=PriorityTests();fixture.setUp();model=fixture.model();ledger_before=fixture.path.read_bytes()
with patch('run_deepseek_smoke.LitellmModel._query',side_effect=AssertionError('No dispatch')):
    reject('legacy thinking rejected before reserve',lambda:model._query([{'role':'user','content':'x','reasoning_content':'unsupported'}]))
assert model.requests==0 and fixture.path.read_bytes()==ledger_before
result={'request_payload':payload,'raw_reply':raw,'normalized':{'prompt_tokens':normalized.prompt_tokens,'completion_tokens':normalized.completion_tokens,
    'raw_usage':normalized.raw_usage,'actions':actions},'rejections':failures,'legacy_rejection_reservations':0,'external_model_calls':0,
    'scope':'Synthetic Messages format conversion and existing tool parser; no native vendor transport or real model quality acceptance.'}
(OUT/'protocol-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rejections':len(failures),'native_reply_parsed_by_existing_reviewer':True,'external_model_calls':0}))
