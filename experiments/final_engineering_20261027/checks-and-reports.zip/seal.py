"""Seal reviewable sources/reports, without pytest scratch or live account data."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DEST=ROOT/'experiments/final_engineering_20261027'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not DEST.exists(),'Never overwrite sealed results'
final=ROOT/'temp/regression/20261027_025801_1ab23420'
initial=ROOT/'temp/regression/20261027_024746_7a3384ec'
adapter=ROOT/'temp/regression/20261027_025633_062e3945'
summary=read(final/'summary.json')
assert [j['exit_code'] for j in summary['jobs']]==[0,0]
assert summary['jobs'][0]['counts']=={'passed':301}
assert summary['jobs'][1]['tests_run']==408 and summary['jobs'][1]['skipped']==1
assert not summary['changed_protected_files']
assert not read(adapter/'summary.json')['changed_protected_files']
assert read(OUT/'adapter-comparison.json')['new_failures']==[]
protection=read(OUT/'protection-check.json')
assert protection['formal_payloads_unchanged']==52 and protection['shared_ledger_requests']==2016
old=ROOT/'experiments/harness_closeout_20261027'
oldhash=read(old/'artifact_sha256.json')
assert all(sha((old/n).read_bytes())==v for n,v in oldhash.items())
with zipfile.ZipFile(ROOT/'experiments/three_role_acceptance_20261025/adapter-regression.zip') as z:
    archived= json.loads(z.read('adapter/upstream_results.json'))
    oldresult=read(ROOT/'temp/regression/20261025_230923_64443451/adapter/upstream_results.json')
    failed=lambda d:{r['nodeid'] for r in d['reports'] if r['outcome']=='failed'}
    assert archived['counts']==oldresult['counts'] and failed(archived)==failed(oldresult)
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(keys)==2
DEST.mkdir();outer={};counts={};scanned=0
def pack(name,entries):
    global scanned
    members={}
    with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,label in entries:
            if not path.is_file() or '__pycache__' in path.parts or path.suffix in {'.pyc','.lock'}:continue
            assert path.name!='.env' and not path.name.startswith('.env.'),'Environment fixture must stay local'
            raw=path.read_bytes();assert not any(k in raw for k in keys),'Credential scan rejected archive'
            assert label not in members,label
            z.writestr(label,raw);members[label]=sha(raw);scanned+=1
    with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==v for n,v in members.items())
    write(DEST/(name+'.sha256.json'),members)
    for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
    counts[name]=len(members)
manifest=read(OUT/'current-source-manifest.json')['files_sha256']
documents=['README.md','GITHUB_SETUP.md','AGENTS.md','Project/00_项目现状与快速接手.md','Project/项目开发流水账.md',
 'Project/43_测试_当前版本集中工程检查与收尾.md']
pack('source-and-documents.zip',[(ROOT/n,n) for n in manifest]+[(ROOT/n,n) for n in documents]+[(ROOT.parent/'job/AGENTS.md','job/AGENTS.md')])
entries=[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.iterdir()) if p.is_file()
    and p.name!='formal-payloads-before.json']
for name,run in [('default-initial',initial),('default-final',final),('adapter-current',adapter)]:
    entries += [(p,name+'/'+p.relative_to(run).as_posix()) for p in sorted(run.rglob('*')) if p.is_file()
        and not {'scratch','os_temp','global_config','__pycache__'}.intersection(p.relative_to(run).parts)]
pack('checks-and-reports.zip',entries)
homes={}
for report in ['continuation-check.json','pause-check.json','card-check.json','browser-check.json']:
    value=read(OUT/report)
    if 'store_home' in value:homes[report]=Path(value['store_home'])
    if 'demo_evidence' in value:homes[report]=Path(value['demo_evidence']).parent
if 'single_store' in read(OUT/'card-check.json'):homes['card-single']=Path(read(OUT/'card-check.json')['single_store'])
pack('scripted-workflows.zip',[(p,name+'/'+p.relative_to(home).as_posix()) for name,home in homes.items() for p in sorted(home.rglob('*')) if p.is_file()])
shot=OUT/'browser-paused-top.png';(DEST/shot.name).write_bytes(shot.read_bytes());outer[shot.name]=sha(shot.read_bytes())
result={**protection,'scope':'Current-code engineering acceptance with six unchanged adapter differences and isolated real-browser checks; no paid or live-model acceptance.',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 'final_default':summary['jobs'],'initial_project_error':'Windows WinError 5 during synthetic budget atomic replacement; retained, fixed, targeted and full regression rerun.',
 'adapter':read(OUT/'adapter-comparison.json'),'browser':read(OUT/'browser-check.json'),
 'reports':{n:read(OUT/n) for n in ['backend-check.json','continuation-check.json','pause-check.json','card-check.json','wire-replay.json','protocol-check.json','boundary-checks.json','http-check.json'] if (OUT/n).exists()},
 'old_closeout_delivery_files_verified':len(oldhash),'archive_member_counts':counts,'credential_scan':{'keys_checked':2,'files_scanned':scanned,'matches':0},
 'new_permanent_regression_tests':2,'formal_service_restarted':False,
 'pending':['Current original-route real-model three-role acceptance','Real-model in-flight cancellation','Browser observation of actual worker pause',
 'New same-task baseline comparison after scoring/batch gate and freeze','Fresh-machine install','New-vendor live transport remains unimplemented'],
 'regression_scratch_policy':'Generated pytest environments and formal payload snapshot remain local; full logs, results, inventory and protected hashes are sealed. No .env fixtures or live task payloads are in these archives.'}
write(DEST/'verification.json',result);outer['verification.json']=sha((DEST/'verification.json').read_bytes())
write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan':result['credential_scan'],'default_jobs':summary['jobs'],'formal_rows':52,'ledger_requests':2016},ensure_ascii=False))
