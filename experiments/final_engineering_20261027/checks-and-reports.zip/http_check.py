import json
import os
from pathlib import Path
import sys
import threading
import urllib.request
import urllib.error
import uuid
from http.server import ThreadingHTTPServer
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
from collaboration_store import CollaborationStore
from task_service import make_handler
store=CollaborationStore(OUT/'http-store')
server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(store,'offline-model-check',0))
server.RequestHandlerClass=make_handler(store,'offline-model-check',server.server_port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base='http://127.0.0.1:'+str(server.server_port)
def api(path,body=None,token='offline-model-check',raw=False):
    req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),
        headers={'X-Task-Token':token,'Origin':base,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=5) as r:return r.read() if raw else json.load(r)
try:
    with patch('litellm.completion',side_effect=AssertionError('No model dispatch allowed')):
        catalog=api('/api/model-profiles');assert catalog['default_profile']=='legacy_deepseek_v1'
        assert catalog['profiles'][1]['status']=='offline_only'
        assert b'modelProfileCreation' in api('/model-profile-panel.js',token='',raw=True)
        assert b'modelProfile' in api('/',raw=True)
        body={'task':'split-after-boundary','profile':'adaptive_history','mode':'live','collaboration_mode':'document_review',
            'document_question':'What compatibility does the README establish?','policy_version':1,'request_key':uuid.uuid4().hex,
            'model_profile':'legacy_deepseek_v1'}
        before=len(store.list())
        for selected in ['anthropic_messages_offline_v1','unregistered',{'repairer':'other-model'}]:
            try:api('/api/runs',dict(body,model_profile=selected,request_key=uuid.uuid4().hex))
            except urllib.error.HTTPError as error:assert error.code==400
            else:raise AssertionError('Invalid profile accepted')
        assert len(store.list())==before
        row=api('/api/runs',body);assert row['model_profile_id']=='legacy_deepseek_v1'
        assert set(row['model_profile_snapshot']['role_bindings'])=={'consulting','repairing','reviewing','revising','final_review'}
        assert api('/api/runs',body)['id']==row['id']
        try:api('/api/runs',{k:v for k,v in body.items() if k!='model_profile'})
        except urllib.error.HTTPError as error:assert error.code==409
        else:raise AssertionError('Same key changed model selection')
        api('/api/runs/'+row['id']+'/cancel',{})
        body2={k:v for k,v in body.items() if k!='document_question'};body2.update(collaboration_mode='single',request_key=uuid.uuid4().hex)
        single=api('/api/runs',body2);assert single['model_profile_snapshot']['role_bindings']=={'single_agent':'legacy_deepseek_v1'}
        api('/api/runs/'+single['id']+'/cancel',{})
        legacy=api('/api/runs',{k:v for k,v in dict(body2,request_key=uuid.uuid4().hex).items() if k!='model_profile'})
        assert 'model_profile_id' not in legacy
        api('/api/runs/'+legacy['id']+'/cancel',{})
        try:api('/api/model-profiles',token='wrong')
        except urllib.error.HTTPError as error:assert error.code==403
        else:raise AssertionError('Catalog authentication bypass')
finally:server.shutdown();server.server_close();thread.join(timeout=2)
report={'catalog':catalog,'checks':['catalog no transport','offline profile disabled','HTML/assets','bad profile before create',
    'three-role bindings','single-role binding','same-key idempotence/conflict','legacy no implicit metadata rewrite','authenticated catalog'],
    'new_temp_runs':3,'all_cancelled':True,'workers_started':0,'external_model_calls':0,'browser_clicks_verified':False}
(OUT/'http-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'checks':len(report['checks']),'external_model_calls':0}))
