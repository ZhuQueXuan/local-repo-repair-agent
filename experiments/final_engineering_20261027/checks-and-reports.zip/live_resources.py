import hashlib
import json
from pathlib import Path
import sqlite3
import urllib.request
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=dict(db.execute('SELECT id,payload FROM runs'))
assert len(rows)==52 and not any(json.loads(v)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for v in rows.values())
base='http://127.0.0.1:8765'
def get(path):
    with urllib.request.urlopen(base+path,timeout=5) as r:return r.read()
health=json.loads(get('/api/health'));html=get('/').decode('utf-8')
assert "window.addEventListener('DOMContentLoaded'" in html
script=get('/checkpoint-panel.js')
assert b"$('taskCardEnabled').addEventListener('change',checkpointChoices)" in script
assert hashlib.sha256(script).digest()==hashlib.sha256((ROOT/'scripts/checkpoint_panel.js').read_bytes()).digest()
report={'url':base,'health':health,'new_bootstrap_served':True,'new_checkpoint_listener_served':True,
    'service_restarted':False,'note':'Existing panel serves unchanged frontend; no active worker. New workers import current budget code.',
    'new_task_created':False,'external_model_calls':0,'browser_clicks_verified':False}
(OUT/'live-resource-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report))
