import hashlib
import json
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
value=json.loads((ROOT/'configs/final_acceptance_scope_v1.json').read_bytes())
assert value['state']=='scope_only_not_launchable'
assert value['paid_launch_authorized'] is False and value['creates_runs'] is False
for forbidden in ('request_key','run_id','dispatch','execute_command','api_key'):
    assert not re.search(r'"'+forbidden+r'"\s*:',json.dumps(value)),forbidden
defaults=value['current_product']
assert defaults['default_mode']=='replay' and defaults['default_collaboration']=='single'
assert defaults['task_card_default'] is defaults['phase_pause_default'] is defaults['tool_skills_default'] is False
assert len({x['id'] for x in value['acceptance_layers']})==5
for item in value['feature_review_items']:assert (ROOT/item['evidence_entry']).is_file(),item
readme=(ROOT/'README.md').read_text(encoding='utf-8')
checked=[]
for target in re.findall(r'\]\(([^)]+)\)',readme):
    if '://' in target:continue
    assert (ROOT/target.split('#')[0]).is_file(),target
    checked.append(target)
input_paths=list((ROOT/'scripts').glob('*.py'))+list((ROOT/'scripts').glob('*.js'))+[ROOT/'scripts/task_panel.html']
input_paths+=list((ROOT/'configs').glob('*.json'))+list((ROOT/'configs').glob('*-requirements.txt'))+list((ROOT/'skills').glob('*/SKILL.md'))
fingerprint={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(input_paths)}
(OUT/'current-source-manifest.json').write_text(json.dumps({'state':'source_snapshot_only_not_launchable','files_sha256':fingerprint,
    'scope':'Current source/config/UI/method files only, not a model task freeze, dependency lock or executable acceptance identity.'},ensure_ascii=False,indent=2),encoding='utf-8')
report={'scope_json_no_launch_fields':True,'default_switches_match_documentation':True,'acceptance_layers':5,
        'feature_evidence_entries':len(value['feature_review_items']),'readme_local_links_verified':checked,'source_files_fingerprinted':len(fingerprint),
        'external_model_calls':0,'scope_check_launches_regression':False}
(OUT/'scope-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
