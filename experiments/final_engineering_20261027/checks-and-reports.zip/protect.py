import hashlib
import json
from pathlib import Path
import sqlite3

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
before=json.loads((OUT/'protected-before.json').read_bytes())
changed=[name for name,digest in before.items() if not (ROOT/name).is_file() or sha((ROOT/name).read_bytes())!=digest]
assert not changed,changed
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=dict(db.execute('SELECT id,payload FROM runs'))
    assert rows==json.loads((OUT/'formal-payloads-before.json').read_bytes())
    tables={r[0] for r in db.execute('SELECT name FROM sqlite_master')}
    assert not {'task_cards','harness_continuations'} & tables
assert not any(json.loads(p)['status'] in {'queued','running','cancel_requested','preparing_continuation'} for p in rows.values())
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
assert len(ledger['requests'])==2016
old=ROOT/'experiments/harness_task_cards_20261026'
old_manifest=json.loads((old/'artifact_sha256.json').read_bytes())
assert all(sha((old/name).read_bytes())==digest for name,digest in old_manifest.items())
result={'protected_old_files_hash_verified':len(before),'changed_old_protected_files':changed,
        'formal_payloads_unchanged':len(rows),'formal_task_cards_or_continuations_schema_added':False,
        'shared_ledger_requests':len(ledger['requests']),'new_formal_runs':0,
        'old_task_card_delivery_files_verified':len(old_manifest),'external_model_calls':0}
(OUT/'protection-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
