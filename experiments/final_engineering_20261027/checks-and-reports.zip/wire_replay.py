import json
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
os.environ.update(PYTHON_DOTENV_DISABLED='1',LITELLM_LOCAL_MODEL_COST_MAP='True',PYTHONDONTWRITEBYTECODE='1')
os.environ.update(MSWEA_GLOBAL_CONFIG_DIR=str(ROOT/'temp/mini-global'),MSWEA_SILENT_STARTUP='1')
from model_protocols import AnthropicMessagesOfflineAdapter
from model_profiles import validate_record,selection_fields
from review_tools import SCHEMAS
from document_agent import DOCUMENT_SCHEMAS
from harness_capabilities import ReadSkill,ReadChangeSummary
from minisweagent.models.utils.actions_toolcall import BASH_TOOL
from collaboration_protocol import sha256,canonical_bytes
summary=json.loads((OUT/'continuation-check.json').read_bytes());home=Path(summary['store_home'])
wires=json.loads((home/('wire-'+summary['source']+'.json')).read_bytes())+json.loads((home/('wire-'+summary['child']+'.json')).read_bytes())
codec=AnthropicMessagesOfflineAdapter();records=[]
for wire in wires:
    tools=[]
    schemas=DOCUMENT_SCHEMAS if wire['phase']=='consulting' else SCHEMAS
    schemas=dict(schemas,read_skill=ReadSkill,read_change_summary=ReadChangeSummary)
    for name in wire['tool_names']:
        tools.append(BASH_TOOL if name=='bash' else {'type':'function','function':{'name':name,'description':'Offline replay tool','parameters':schemas[name].model_json_schema()}})
    native=codec.prepare(wire['messages'],tools,model='offline-native-fixture')
    assert all(m['role'] in {'user','assistant'} for m in native['messages'])
    records.append({'phase':wire['phase'],'input_sha256':sha256(canonical_bytes(wire['messages'])),'native_sha256':sha256(canonical_bytes(native)),
        'input_messages':len(wire['messages']),'native_messages':len(native['messages'])})
phases=['consulting','repairing','reviewing','revising','final_review']
fields=selection_fields('legacy_deepseek_v1',execution='live',phases=phases)
assert fields['model_profile_snapshot']['role_requirements']['consulting']['tool_mode']=='one_or_two_serial_reads_or_one_submission'
assert fields['model_profile_snapshot']['role_requirements']['reviewing']['tool_mode']=='one_read_or_submission'
assert fields['model_profile_snapshot']['role_requirements']['repairing']['tool_mode']=='one_bash_call'
validate_record(fields,phases=phases)
report={'scope':'Replay actual scripted API-view histories through native Messages codec only; no live transport, no new model replies or repair execution.',
    'requests_converted':len(records),'phases':sorted({r['phase'] for r in records}),'requests':records,
    'latest_role_requirements_verified':True,'external_model_calls':0}
(OUT/'wire-replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'requests_converted':len(records),'role_requirements_verified':True,'external_model_calls':0}))
