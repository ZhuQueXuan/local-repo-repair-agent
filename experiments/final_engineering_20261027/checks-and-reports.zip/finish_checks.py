from pathlib import Path
import hashlib
import json
import subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
scope=json.loads((ROOT/'configs/final_acceptance_scope_v1.json').read_bytes())
raw=subprocess.check_output(['git','show','HEAD:configs/final_acceptance_scope_v1.json'],cwd=ROOT).decode('utf-8')
raw=raw.replace('"status": "current_full_regression_pending"','"status": "engineering_checked_with_six_known_adapter_differences"')
raw=raw.replace('"status": "pending_browser_validation"','"status": "isolated_browser_actions_verified_worker_and_live_model_pending"')
old=json.loads(raw)['next_step']
raw=raw.replace('"next_step": '+json.dumps(old),'"engineering_evidence": '+json.dumps(scope['engineering_evidence'],ensure_ascii=False)+',\n  "next_step": '+json.dumps(scope['next_step']))
assert json.loads(raw)==scope
(ROOT/'configs/final_acceptance_scope_v1.json').write_bytes(raw.encode('utf-8'))
# Keep the original guide's LF convention rather than rewriting every line.
guide=ROOT/'GITHUB_SETUP.md';guide.write_bytes(guide.read_text(encoding='utf-8').encode('utf-8'))
s=(ROOT/'temp/harness_closeout_20261027/scope_check.py').read_text(encoding='utf-8')
s=s.replace("'full_regression_run':False","'scope_check_launches_regression':False")
(OUT/'scope_check.py').write_text(s,encoding='utf-8')
s=(ROOT/'temp/harness_closeout_20261027/live_resources.py').read_text(encoding='utf-8')
s=s.replace('Only HTML/JS changed; existing handlers read files with no-store. Refresh loads new resources.',
 'Existing panel serves unchanged frontend; no active worker. New workers import current budget code.')
s=s.replace('live-resources.json','live-resource-check.json')
(OUT/'live_resources.py').write_text(s,encoding='utf-8')
for name in ['scope_check.py','live_resources.py']:
    subprocess.run([str(ROOT/'.venv/Scripts/python.exe'),'-B',str(OUT/name)],cwd=ROOT,check=True)
before=json.loads((ROOT/'temp/regression/20261027_025801_1ab23420/protected_after.json').read_bytes())
changes=[n for n,h in before.items() if hashlib.sha256((ROOT/n).read_bytes()).hexdigest()!=h]
assert changes==['configs/final_acceptance_scope_v1.json'],changes
(OUT/'post-regression-source-check.json').write_text(json.dumps({'runtime_sources_still_match_final_regression':True,
 'only_post_regression_protected_change':changes,'reason':'Scope-only documentary status update, still cannot launch.'},indent=2),encoding='utf-8')
print('Current runtime bytes match final regression; only scope-only status JSON changed afterward.')
