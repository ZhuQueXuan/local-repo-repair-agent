import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'scripts'))
from collaboration_store import CollaborationStore
from task_cards import card_view
from harness_checkpoints import checkpoint_view
preview=json.loads((OUT/'preview-server.json').read_bytes())
store=CollaborationStore(Path(preview['home']))
source=store.get(preview['paused_run'])
original=json.loads((store.home/'demonstration.json').read_bytes())['run']
assert source==original,'Paused source payload changed'
created=store.get('eb7de18abe164e479fc6851a09ff1915')
child=store.get('55e3dc3c2d31452ca690c5cf420a02eb')
assert created['status']==child['status']=='cancelled'
assert created['model_profile_id']=='legacy_deepseek_v1'
assert child['continued_from']==source['id']
assert child['model_profile_snapshot']==source['model_profile_snapshot']
assert card_view(store,created['id'])['revision']==2
assert 'BROWSER_SAVED' in card_view(store,created['id'])['card']['instruction']
assert not card_view(store,created['id'])['can_edit']
assert not checkpoint_view(store,source['id'])['can_continue']
rows=store.list();assert len(rows)==4 and all(r['status'] in {'paused','cancelled'} for r in rows)
ledger=json.loads((store.home/'synthetic_ledger.json').read_bytes())
assert len(ledger['requests'])==3,'Browser dispatched extra requests'
report={'scope':'Actual Edge UI on isolated temporary HTTP service with no Supervisor/worker; provider entry blocked after scripted paused fixture.',
 'url':preview['url'],'store_home':str(store.home),'source_run':source['id'],'created_run':created['id'],'child_run':child['id'],
 'checks':['offline defaults','three-role strategy lock','card enables pause','offline-only profile disabled','create all-option temporary three-role task',
 'save card revision 2','queued cancellation and readonly card','checkpoint creates linked child','inherited document phase and model profile',
 'source unchanged and repeat continuation disabled','request pause message','single/replay disable unsupported options'],
 'created_rows_during_browser':2,'fixture_rows':2,'final_rows':4,'all_queues_cancelled':True,'source_payload_unchanged':True,
 'synthetic_fixture_requests_before_and_after':3,'browser_console_errors':0,'workers_started':0,'external_model_calls':0,
 'not_verified':['real model in-flight cancellation','browser observes actual worker boundary pause','stale card save in two browser tabs','real-model outcome','fresh machine'],
 'screenshots':['browser-paused-top.png','browser-paused.png']}
(OUT/'browser-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
