"""Read-only HTTP proof viewer, deliberately no Supervisor or write routes."""
from pathlib import Path
import json,secrets,sys
from http.server import ThreadingHTTPServer
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from collaboration_store import CollaborationStore
from task_service import make_handler
selected=json.loads((root/'temp/self_review_20261025/selected-demo.json').read_bytes())
store=CollaborationStore(Path(selected['home']))
assert store.get(selected['run_id'])['status']=='finished'
assert not any(r['status'] in ('queued','running','cancel_requested') for r in store.list())
Base=make_handler(store,secrets.token_urlsafe(32),8766)
class ReadOnly(Base):
    def do_POST(self):self.send(403,{'error':'Offline demonstration viewer; no writes or worker.'})
server=ThreadingHTTPServer(('127.0.0.1',8766),ReadOnly)
print('Read-only synthetic S+ proof viewer on 127.0.0.1:8766',flush=True)
try:server.serve_forever()
finally:server.server_close()
