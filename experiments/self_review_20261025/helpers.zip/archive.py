from pathlib import Path
import hashlib,io,json,shutil,sqlite3,sys,zipfile
root=Path.cwd();t=root/'temp/self_review_20261025';out=root/'experiments/self_review_20261025'
sys.path.insert(0,str(root/'scripts'))
from collaboration_protocol import canonical_bytes,sha256
from collaboration_store import CollaborationStore
before=json.loads((t/'before.json').read_bytes())
changed=[p for p,h in before.items() if sha256((root/p).read_bytes())!=h]
expected={'scripts/collaboration_live.py','scripts/collaboration_panel.js','scripts/collaboration_panel.py',
          'scripts/collaboration_runtime.py','scripts/collaboration_store.py','scripts/task_panel.html'}
assert set(changed)==expected,changed
with sqlite3.connect('file:'+str(root/'data/task_service/runs.sqlite3')+'?mode=ro',uri=True) as db:
    rows=dict(db.execute('SELECT id,payload FROM runs'))
    assert rows==json.loads((t/'production-before-rows.json').read_bytes())
    assert len(rows)==45 and db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert db.execute('SELECT count(*) FROM collaboration_adjudications').fetchone()[0]==1
    with sqlite3.connect(t/'production-after.sqlite3') as target:db.backup(target)
assert (root/'data/deepseek_budget.json').read_bytes()==(t/'ledger-before.json').read_bytes()
old_verified={}
for name in ('adjudication_panel_20261024','review_adjudication_20261024','multi_agent_response_recheck_live_20261024'):
    base=root/'experiments'/name;manifest=json.loads((base/'artifact_sha256.json').read_bytes())
    assert all(sha256((base/n).read_bytes())==h for n,h in manifest.items()),name
    old_verified[name]=len(manifest)
selected=json.loads((t/'selected-demo.json').read_bytes());home=Path(selected['home']);run=selected['run_id'];run_out=Path(selected['output'])
store=CollaborationStore(home)
record=store.get(run);assert record['status']=='finished' and record['repair_result']=='passed'
frozen=json.loads((run_out/'inputs.json').read_bytes())['files_sha256']
assert all(sha256((root/n).read_bytes())==h for n,h in frozen.items())
raw_history=json.loads((run_out/'self-review-history.json').read_bytes())
assert raw_history==json.loads((t/'rendered-history.json').read_bytes())
assert len({role['session_id'] for role in store.roles(run)})==1
reg=root/'temp/regression/20261025_160605_8df1a512';regression=json.loads((reg/'summary.json').read_bytes())
assert not regression['changed_protected_files'] and all(v['exit_code']==0 for v in regression['jobs'])
adapter=root/'temp/regression/20261025_160635_5298fc95'
comparison=json.loads((t/'adapter-comparison.json').read_bytes());assert comparison['same_failed_nodeids']
verification={'date':'2026-10-25','scope':'S+ offline wiring; all replies/usage synthetic. No actual model performance result.',
    'original_payloads_identical':45,'production_database_bytes_identical':sha256((root/'data/task_service/runs.sqlite3').read_bytes())==before['data/task_service/runs.sqlite3'],
    'ledger_identical':True,'real_model_requests':0,'new_formal_runs':0,'existing_changed':changed,'existing_unchanged':len(before)-len(changed),
    'old_archives_verified':old_verified,'frozen_inputs':len(frozen),'fixture_run_id':run,'single_logical_session':True,
    'phase_calls':selected['counts'],'synthetic_attempts':record['metrics']['attempts'],'posthoc_pass_counts':[2,6],
    'upstream_native_passed':301,'project_tests':347,'project_passed':346,'project_skipped':1,'targeted':18,'adapter':comparison['counts']}
assert verification['production_database_bytes_identical']
(t/'verification.json').write_bytes(canonical_bytes(verification))
out.mkdir(exist_ok=True)
for name in ('before.json','production-before.sqlite3','production-after.sqlite3','production-before-rows.json','ledger-before.json',
    'targeted.log','demo.log','demo-second.log','demo-third.log','demo-fourth.log','demo-final.log','regression.log','adapter.log',
    'adapter-comparison.json','selected-demo.json','api-verification.json','browser-verification.json','browser-choices-ax.txt','browser-final-dom.txt',
    'panel-proof.png','panel-history.png','rendered-history.json','posthoc-checks.json','verification.json','panel.log','panel-error.log'):
    if (t/name).is_file():shutil.copy2(t/name,out/name)
shutil.copy2(root/'data/deepseek_budget.json',out/'ledger-after.json')
(out/'final-record.json').write_bytes(canonical_bytes(record))
shutil.copy2(home/'demonstration.json',out/'demonstration.json')
def pack(destination,paths,base=root):
    hashes={}
    with zipfile.ZipFile(out/destination,'w',zipfile.ZIP_DEFLATED) as bundle:
        for p in paths:
            if not p.is_file():continue
            raw=p.read_bytes();name=p.relative_to(base).as_posix()
            bundle.writestr(name,raw);hashes[name]=sha256(raw)
    (out/(destination+'.sha256.json')).write_bytes(canonical_bytes(hashes))
    return len(hashes)
sources=[root/p for p in sorted(expected)]+[root/'scripts'/n for n in ('self_review.py','self_review_demo.py','test_self_review.py')]+[root/'configs/self_review_v1.json']
pack('implementation.zip',sources)
fixture_files=pack('fixture.zip',home.rglob('*'),home)
pack('actual-workspace.zip', (p for p in Path(record['workspace']).rglob('*') if '.git' not in p.relative_to(record['workspace']).parts),Path(record['workspace']))
pack('posthoc-probes.zip',(t/'posthoc-cases').rglob('*'),t/'posthoc-cases')
pack('regression.zip',reg.rglob('*'),reg)
pack('adapter.zip',adapter.rglob('*'),adapter)
failure_dirs=[root/'temp/self_review_demo'/n for n in ('7f3d44a708c84dc2b42547254b7fe42e','c65242e84e3f45d392a2bce0d96bd48d','a0ca87af724e4fcd99aaca62f66c39a0')]
pack('development-failures.zip',(p for folder in failure_dirs for p in folder.rglob('*')),root/'temp/self_review_demo')
pack('helpers.zip',(p for p in t.glob('*.py')),t)
docs=[root/p for p in ('AGENTS.md','README.md','Project/00_项目现状与快速接手.md','Project/项目开发流水账.md','Project/30_过程_同一Agent分阶段自查与离线验收.md')]
pack('documentation.zip',docs)
with zipfile.ZipFile(out/'documentation.zip','a',zipfile.ZIP_DEFLATED) as bundle:
    bundle.write(root.parent/'job/AGENTS.md','job/AGENTS.md')
# Add the extra document to its integrity listing too.
with zipfile.ZipFile(out/'documentation.zip') as bundle:
    (out/'documentation.zip.sha256.json').write_bytes(canonical_bytes({n:sha256(bundle.read(n)) for n in bundle.namelist()}))
(out/'README.json').write_bytes(canonical_bytes({'scope':verification['scope'],'fixture':run,'fixture_files':fixture_files,
    'proof':'fixture.zip includes one-run SQLite, immutable snapshots, all 175 frozen inputs, actual trajectories and synthetic ledger. final-record.json is after final receipts attachment.',
    'limits':'Only scripted responses, known public development fixture. No real S+ model calls, new tasks, S/D/S+ effect comparison, arbitrary finding adjudication or OS sandbox.',
    'production':'All original 45 payloads, database bytes, current registered adjudication and shared ledger preserved.'}))
from dotenv import dotenv_values
private=[v.encode() for k,v in dotenv_values(root/'.env',interpolate=False).items() if 'KEY' in k and v]
for p in out.rglob('*'):
    if not p.is_file():continue
    assert not any(key in p.read_bytes() for key in private),'Credential scan blocked archive'
    if p.suffix=='.zip':
        with zipfile.ZipFile(p) as bundle:
            assert all(not any(key in bundle.read(n) for key in private) for n in bundle.namelist()),'Credential scan blocked ZIP member'
manifest={p.relative_to(out).as_posix():sha256(p.read_bytes()) for p in out.rglob('*') if p.is_file() and p!=out/'artifact_sha256.json'}
(out/'artifact_sha256.json').write_bytes(canonical_bytes(manifest))
assert all(sha256((out/n).read_bytes())==h for n,h in manifest.items())
print(json.dumps(verification|{'artifact_files':len(manifest),'fixture_files':fixture_files},ensure_ascii=False))
