from pathlib import Path
import json,hashlib,sqlite3,shutil
r=Path.cwd();t=r/'temp/self_review_20261025'
paths=[p for folder in ('scripts','configs','data') for p in (r/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.lock']
(t/'before.json').write_text(json.dumps({p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},ensure_ascii=False,indent=2),encoding='utf-8')
with sqlite3.connect('file:'+str(r/'data/task_service/runs.sqlite3')+'?mode=ro',uri=True) as db:
    rows=dict(db.execute('SELECT id,payload FROM runs'))
    assert len(rows)==45 and not any(json.loads(v)['status'] in ('queued','running','cancel_requested') for v in rows.values())
    with sqlite3.connect(t/'production-before.sqlite3') as backup:db.backup(backup)
(t/'production-before-rows.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
shutil.copy2(r/'data/deepseek_budget.json',t/'ledger-before.json')
print('Saved current source/config/data hashes, 45 original payloads, consistent database and ledger; no pending task.')
