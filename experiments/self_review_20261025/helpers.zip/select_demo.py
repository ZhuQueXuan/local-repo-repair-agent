from pathlib import Path
import json,hashlib
r=Path.cwd();t=r/'temp/self_review_20261025'
choices=[]
for p in (r/'temp/self_review_demo').glob('*/demonstration.json'):
    value=json.loads(p.read_bytes())
    if value['run']['status']!='finished' or value['counts']!={'repairing':2,'reviewing':3,'revising':2,'final_review':2} or value['run'].get('transport_scope')!='scripted_offline':continue
    output=p.parent/'runs'/value['run_id']
    frozen=json.loads((output/'inputs.json').read_bytes())['files_sha256']
    if not all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in frozen.items()):continue
    choices.append((p.stat().st_mtime_ns,p,value))
assert choices,'No successful fixture with all current frozen inputs'
_,p,value=max(choices,key=lambda v:v[0])
result={'home':str(p.parent),'run_id':value['run_id'],'output':str(p.parent/'runs'/value['run_id']),
    'scope':value['scope'],'counts':value['counts']}
(t/'selected-demo.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
