import json,re,urllib.request,urllib.error
from pathlib import Path
t=Path('temp/self_review_20261025');base='http://127.0.0.1:8765'
with urllib.request.urlopen(base+'/',timeout=10) as response:page=response.read().decode()
assert '同一 Agent 分阶段自查 S+（实验）' in page
token=re.search(r"const token='([^']+)'",page).group(1)
def get(route):
    with urllib.request.urlopen(urllib.request.Request(base+route,headers={'X-Task-Token':token,'Origin':base}),timeout=15) as response:return json.load(response)
rows=get('/api/runs');assert len(rows)==45
before=json.loads((t/'production-before-rows.json').read_bytes())
assert {r['id']:r for r in rows}=={k:json.loads(v) for k,v in before.items()}
old=get('/api/runs/d3173d4153e544ccbf0eb066834848f8/collaboration')
assert len(old['adjudications'])==1 and len(old['reviews'])==2
assert old['mode']=='dual_review_diagnostic'
result={'formal_records':45,'all_original_api_payloads_unchanged':True,'old_adjudication_batches':1,'self_review_choice_in_page':True,'new_runs_created':0,'new_model_requests':0}
(t/'api-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
