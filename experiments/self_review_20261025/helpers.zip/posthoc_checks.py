from pathlib import Path
import json,sys
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from collaboration_store import CollaborationStore
from collaboration_protocol import canonical_bytes,sha256
from review_adjudication import OfflineAdjudicator,ProbePlan
from collaboration_adjudication import CHECK_IDS,PROBE
t=r/'temp/self_review_20261025'; selected=json.loads((t/'selected-demo.json').read_bytes())
store=CollaborationStore(Path(selected['home']));run=selected['run_id']
roles=store.roles(run)
with store.connect() as db:
    rows=[json.loads(v[0]) for v in db.execute("SELECT payload FROM collaboration_objects WHERE run_id=? AND kind='snapshot'",(run,))]
first=next(v['candidate']['candidate_id'] for v in rows if v['candidate']['producer_role_run_id']==roles[0]['id'])
last=store.get(run)['final_candidate_id']
judge=OfflineAdjudicator(t/'posthoc-cases')
plan=ProbePlan.parse({'plan_id':'posthoc-disclosed-falsey','task_digest':store.get(run)['task_digest'],'probe_sha256':sha256(PROBE.read_bytes()),
    'scope':'Six declared, developer-known cases, only after scripted S+ terminal result; never fed to models and never rewrites scores.',
    'checks':[{'check_id':k,'test_id':'registered_probe.FalseyRemainder.test_'+k,'requirement_ref':'issue:paragraph-4','prior_visibility':'already_reported'} for k in CHECK_IDS]})
key=judge.register_probe(plan,PROBE);results=[]
for cid in (first,last):
    receipt=judge.run_probe(store.snapshot(run,cid),key,timeout=10)
    assert receipt.status=='completed'
    results.append(receipt.model_dump(mode='json')|{'results':judge._receipts[receipt.receipt_id][3]})
counts=[sum(v=='passed' for v in item['results'].values()) for item in results]
assert counts==[2,6],counts
(t/'posthoc-checks.json').write_bytes(canonical_bytes({'scope':plan.scope,'results':results,'counts':counts,'no_model_calls':True,'original_score_unchanged':True}))
print(json.dumps({'posthoc_pass_counts':counts,'models_called':0,'scores_rewritten':False}))
