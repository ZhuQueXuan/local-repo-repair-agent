"""Seal four original outcomes and narrow preparation evidence, excluding live data."""
import hashlib,io,json,re,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/f2_1027'
DEST=ROOT/'experiments/fresh_comparison_20261027'
audit=json.loads((OUT/'audit.json').read_bytes());assert audit['all_terminal'] and not DEST.exists()
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def scan(raw,depth=0):
 global scanned
 scanned+=1;assert depth<=7 and not any(k in raw for k in keys),'Credential detected; value withheld'
 assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();outer={};counts={}
def pack(name,entries):
 members={}
 with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p,n in entries:
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock' or p.name.endswith(('-wal','-shm')):continue
   assert not p.name.startswith('.env') and n not in members
   raw=p.read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
 with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
 write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
 for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
pack('all-four-runs.zip',[(p,p.relative_to(HOME).as_posix()) for p in sorted(HOME.rglob('*')) if p.is_file()])
patch=subprocess.check_output(['git','diff','--binary','--','scripts/comparison_inputs.py','scripts/comparison_batch.py','scripts/task_service_worker.py'],cwd=ROOT)
(OUT/'source-change.patch').write_bytes(patch)
names=['baseline.json','authorization-record.json','offline-checks.json','create_packet.py','preflight.py','audit.py','audit.json','seal.py','source-change.patch',
 'comparison_batch.py-before','comparison_inputs.py-before','task_service_worker.py-before','new-request-receipts.json','diagnose.py','diagnostics.json','document.py']
pack('preparation-and-audit.zip',[(OUT/n,n) for n in names]+[(p,p.relative_to(OUT).as_posix()) for p in sorted((OUT/'working-diffs').rglob('*')) if p.is_file()])
pack('public-and-scoring-inputs.zip',[(p,p.relative_to(ROOT/'evaluation/fresh_comparison_20261027').as_posix()) for p in sorted((ROOT/'evaluation/fresh_comparison_20261027').rglob('*')) if p.is_file()])
write(DEST/'manifest.json',dict(audit,archive_members=counts,credential_scan={'keys_checked':2,'objects_including_nested':scanned,'matches':0},
 formal_database_and_whole_shared_ledger_uploaded=False,source_patch='preparation-and-audit.zip/source-change.patch'))
outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan_objects':scanned,'matches':0}))
