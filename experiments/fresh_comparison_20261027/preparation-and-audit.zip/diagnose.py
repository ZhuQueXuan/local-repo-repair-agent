"""Descriptive post-run command counts; never change score or call a model."""
from collections import Counter
import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/f2_1027'
slots=json.loads((HOME/'slots.json').read_bytes());results=[]
for s in slots:
 folder=HOME/'store/runs'/s['run_id'];traces={}
 for p in sorted(folder.glob('*trajectory.json')):
  messages=json.loads(p.read_bytes()).get('messages',[])
  actions=[a for m in messages for a in m.get('extra',{}).get('actions',[])]
  commands=[a['command'] for a in actions if isinstance(a.get('command'),str)]
  repeats=Counter(commands)
  traces[p.name]={'actions':len(actions),'bash_commands':len(commands),
   'test_commands':sum('pytest' in c or 'unittest' in c for c in commands),
   'submission_commands':sum('COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' in c for c in commands),
   'repeated_exact_commands':[{'command':c,'count':n} for c,n in repeats.most_common(5) if n>1]}
 with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
  row=json.loads(db.execute('SELECT payload FROM runs WHERE id=?',(s['run_id'],)).fetchone()[0])
 workspace=Path(row['workspace']).resolve()
 assert workspace.is_relative_to(ROOT/'temp/comparison_tasks'/s['task'])
 raw=subprocess.check_output(['git','-C',str(workspace),'diff','--binary','--','boltons/'])
 target=OUT/'working-diffs'/s['run_id'];target.mkdir(parents=True,exist_ok=True)
 (target/'unsealed-working.diff').write_bytes(raw)
 results.append({**s,'traces':traces,'working_diff_bytes':len(raw),'working_diff_sha256':hashlib.sha256(raw).hexdigest(),
 'working_diff_scope':'Diagnostic only; never substitute for a missing exported or legally sealed candidate.'})
(OUT/'diagnostics.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{k:r[k] for k in ['task','variant','traces']} for r in results],ensure_ascii=False))
