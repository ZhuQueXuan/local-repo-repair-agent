"""Create two untouched public baselines and developer-only scoring cases."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'scripts')]
from collaboration_protocol import canonical_bytes
SOURCE=ROOT/'evaluation/multi_agent_20261025/public/boltons-query-encoding'
DEST=ROOT/'evaluation/fresh_comparison_20261027'
assert not DEST.exists()
base=json.loads((SOURCE/'manifest.json').read_bytes())

clock='''import unittest
from unittest.mock import patch
from datetime import datetime, timedelta, timezone
from boltons import timeutils
class FixedDateTime(datetime):
    @classmethod
    def now(cls, tz=None):
        current=cls(2026,1,10,12,tzinfo=timezone.utc)
        return current.replace(tzinfo=None) if tz is None else current.astimezone(tz)
'''
specs={
'boltons-indexed-update':{
'target':'tests/test_setutils.py','problem':'https://github.com/mahmoud/boltons/pull/474',
'issue':'''# IndexedSet.update mishandles multiple input iterables

Calling IndexedSet.update with several list inputs raises TypeError. With tuple or iterator inputs it can instead insert each input object as a member, rather than adding its elements.

Honor update's documented support for one or more iterables. Preserve insertion order, uniqueness, existing members and single-input/no-input behavior. Consume one-shot iterables correctly and flatten only the sequence of input arguments: tuple-valued elements must remain elements. Change implementation only; do not alter tests or metadata.
''',
'public':'''import unittest
from boltons.setutils import IndexedSet
class Cases(unittest.TestCase):
 def test_list_inputs(self):
  value=IndexedSet([1]); result=value.update([2,3],[3,4]); self.assertEqual(list(value),[1,2,3,4]); self.assertIsNone(result)
 def test_iterator_inputs(self):
  value=IndexedSet(); value.update(iter([4,2]),iter([2,7])); self.assertEqual(list(value),[4,2,7])
''',
'withheld':'''import unittest
from boltons.setutils import IndexedSet
class Cases(unittest.TestCase):
 def test_tuple_elements_and_inputs(self):
  value=IndexedSet([(0,1)]); value.update(((2,3),(0,1)),((4,5),)); self.assertEqual(list(value),[(0,1),(2,3),(4,5)])
 def test_empty_and_three_sources(self):
  value=IndexedSet(['a']); value.update([],iter(['b','a']),('c','b')); self.assertEqual(list(value),['a','b','c'])
 def test_existing_call_shapes(self):
  value=IndexedSet([1]); value.update(); value.update(iter([2,1])); self.assertEqual(list(value),[1,2])
''',
'edits':[{'path':'boltons/setutils.py','old':'other = chain(others)','new':'other = chain.from_iterable(others)','expected_occurrences':1}]},
'boltons-aware-relative':{
'target':'tests/test_timeutils.py','problem':'https://github.com/mahmoud/boltons/pull/469',
'issue':'''# Relative time helpers reject aware datetimes when other is omitted

decimal_relative_time and relative_time raise TypeError for a timezone-aware datetime if the optional comparison datetime is omitted. Supplying an aware comparison explicitly already works.

Support the default comparison for aware input datetimes, including non-UTC offsets, using the current instant. Preserve the existing UTC-based naive-input behavior, explicit-comparison semantics, rounding, cardinalization and human-readable past/future wording. Do not silently remove timezone information from an aware input. Change implementation only; do not alter tests or metadata.
''',
'public':clock+'''class Cases(unittest.TestCase):
 def test_decimal_aware_default(self):
  with patch.object(timeutils,'datetime',FixedDateTime):
   value=datetime(2026,1,10,9,tzinfo=timezone.utc); self.assertEqual(timeutils.decimal_relative_time(value),(3.0,'hours'))
 def test_text_aware_default(self):
  with patch.object(timeutils,'datetime',FixedDateTime):
   self.assertEqual(timeutils.relative_time(datetime(2026,1,8,12,tzinfo=timezone.utc)),'2 days ago')
''',
'withheld':clock+'''class Cases(unittest.TestCase):
 def test_positive_and_negative_offsets(self):
  with patch.object(timeutils,'datetime',FixedDateTime):
   for offset in (timedelta(hours=5,minutes=30),timedelta(hours=-7)):
    with self.subTest(offset=offset):
     value=datetime(2026,1,10,10,tzinfo=timezone.utc).astimezone(timezone(offset)); self.assertEqual(timeutils.decimal_relative_time(value),(2.0,'hours'))
 def test_future_and_rounding(self):
  with patch.object(timeutils,'datetime',FixedDateTime):
   self.assertEqual(timeutils.relative_time(datetime(2026,1,12,12,tzinfo=timezone.utc)),'2 days from now')
   self.assertEqual(timeutils.decimal_relative_time(datetime(2026,1,10,10,30,tzinfo=timezone.utc),ndigits=1,cardinalize=False),(1.5,'hour'))
 def test_naive_and_explicit_comparison(self):
  with patch.object(timeutils,'datetime',FixedDateTime):
   self.assertEqual(timeutils.decimal_relative_time(datetime(2026,1,9,12)),(1.0,'day'))
   first=datetime(2026,1,10,9,tzinfo=timezone.utc); other=datetime(2026,1,10,18,tzinfo=timezone(timedelta(hours=8)))
   self.assertEqual(timeutils.decimal_relative_time(first,other),(1.0,'hour'))
''',
'edits':[{'path':'boltons/timeutils.py','old':'    if other is None:\n        other = datetime.now(timezone.utc).replace(tzinfo=None)\n    diff = other - d',
'new':'    if other is None:\n        other = datetime.now(d.tzinfo) if d.tzinfo is not None else datetime.now(timezone.utc).replace(tzinfo=None)\n    diff = other - d','expected_occurrences':1}]}}
for task,s in specs.items():
 public=DEST/'public'/task; authority=DEST/'evaluator'/task
 public.mkdir(parents=True);authority.mkdir(parents=True)
 for n,h in base['source_files_sha256'].items():
  raw=(SOURCE/'repo'/n).read_bytes(); assert hashlib.sha256(raw).hexdigest()==h
  p=public/'repo'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 (public/'checks').mkdir();(public/'issue.md').write_bytes(s['issue'].encode());(public/'checks/test_behavior.py').write_bytes(s['public'].encode())
 (authority/'test_behavior.py').write_bytes(s['withheld'].encode())
 (authority/'reference.json').write_bytes(canonical_bytes({'edits':s['edits'],'scope':'Developer qualification only; never sent to models'}))
 (authority/'source.json').write_bytes(canonical_bytes({'problem_url':s['problem'],'corroboration':'https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md',
 'base_tag':base['base_tag'],'base_commit':base['base_commit'],'license':'BSD-3-Clause, original LICENSE retained','prior_project_model_usage':False,
 'selection':'Two concrete behaviors absent from prior task ids; frozen before any model outcomes. Familiar repository, public issues, no training-contamination claim.'}))
 manifest={**base,'task_id':task,'problem_url':s['problem'],'upstream_target':[s['target']],'full_target':[s['target']],
  'agent_test_command':'python -B -m pytest '+s['target']+' -q -p no:cacheprovider',
  'task_files_sha256':{n:hashlib.sha256((public/n).read_bytes()).hexdigest() for n in ('issue.md','checks/test_behavior.py')}}
 (public/'manifest.json').write_bytes(canonical_bytes(manifest))
(DEST/'README.md').write_bytes(b'# Two fresh public issues for a four-slot system comparison\n\nBoltons 25.0.0 unchanged source, familiar repository; public issues #474 and #469. Two arms once each, all outcomes retained. BSD-3-Clause LICENSE retained in each source. Reference and withheld cases stay in evaluator; no OS sandbox claim. Source selection and qualification precede model dispatch. This is not SWE-bench or a cross-repository evaluation.\n')
print('Created two untouched public tasks; 4 public and 6 retained methods.')
