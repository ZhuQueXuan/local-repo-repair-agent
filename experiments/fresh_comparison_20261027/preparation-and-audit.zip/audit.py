"""Audit four terminal results without changing any run or whole shared ledger."""
import hashlib,json,sqlite3,sys
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/f2_1027'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from comparison_batch import verify
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=verify(HOME);slots=read(HOME/'slots.json');report=read(HOME/'comparison-summary.json')
assert len(slots)==len(report['results'])==report['slots']==4
assert len({s['run_id'] for s in slots})==4 and len(list(HOME.glob('*.claimed')))==4
assert sorted((s['task'],s['variant']) for s in slots)==sorted((t,v) for t in plan['tasks'] for v in ('baseline','full'))
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows={r['id']:r for (v,) in db.execute('SELECT payload FROM runs') for r in [json.loads(v)]}
 roles=[json.loads(v) for (v,) in db.execute('SELECT payload FROM role_runs')]
assert len(rows)==4 and all(r['status'] in {'finished','failed','cancelled','interrupted'} for r in rows.values())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json')
assert len(before['requests'])==2477 and all(after['requests'][k]==v for k,v in before['requests'].items())
assert {k:v for k,v in before.items() if k!='requests'}=={k:v for k,v in after.items() if k!='requests'}
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
history=read(OUT/'historical-before.json')
assert all(sha(ROOT/n)==h for n,h in history.items())
known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
unknown=[v for v in new.values() if v['status']!='settled']
unknown_placeholder=sum((Decimal(v['amount_cny']) for v in unknown),Decimal(0))
arm_stats={v:{'resolved':0,'slots':2,'attempts':0,'known_price_estimate_cny':0,'unknown_placeholder_cny':0,'elapsed_seconds':0} for v in ('baseline','full')}
result_rows=[]
for result in report['results']:
 row=rows[result['run_id']];variant=result['variant'];stat=arm_stats[variant]
 usage=result.get('usage') if variant=='full' else result['metrics']
 attempts=usage.get('attempts',usage.get('requests',0))
 stat['resolved']+=int(result['resolved']);stat['attempts']+=attempts
 stat['known_price_estimate_cny']+=usage['known_price_estimate_cny'];stat['unknown_placeholder_cny']+=usage['unknown_placeholder_cny']
 elapsed=usage.get('total_elapsed_seconds',row.get('metrics',{}).get('total_elapsed_seconds'))
 if elapsed is None:
  from datetime import datetime
  elapsed=(datetime.fromisoformat(row['ended'])-datetime.fromisoformat(row['created'])).total_seconds()
 stat['elapsed_seconds']+=elapsed
 tools=set()
 run=HOME/'store/runs'/row['id']
 for p in run.glob('*trajectory.json'):
  for m in read(p).get('messages',[]):
   for a in m.get('extra',{}).get('actions',[]):
    if a.get('tool'):tools.add(a['tool'])
 entry={k:result.get(k) for k in ['task','variant','run_id','status','agent_exit','resolved','repair_result','collaboration_result','review_verdict','candidate_selection','patch_sha256','evaluation_error']}
 entry.update(attempts=attempts,known_price_estimate_cny=usage['known_price_estimate_cny'],unknown_placeholder_cny=usage['unknown_placeholder_cny'],elapsed_seconds=elapsed,tools_observed=sorted(tools))
 if 'checks' in result:
  entry['checks']={k:{x:d[x] for x in ['tests_run','passed','successful']} for k,d in result['checks'].items()}
 if entry['resolved']:assert all(result['checks'][k]['successful'] for k in ('public','withheld','upstream'))
 result_rows.append(entry)
for stat in arm_stats.values():
 for k in ['known_price_estimate_cny','unknown_placeholder_cny','elapsed_seconds']:stat[k]=round(stat[k],6)
assert sum(s['attempts'] for s in arm_stats.values())==len(new)
assert abs(sum(s['known_price_estimate_cny'] for s in arm_stats.values())-float(known))<0.000002
assert abs(sum(s['unknown_placeholder_cny'] for s in arm_stats.values())-float(unknown_placeholder))<0.000002
full_complete=sum(r['variant']=='full' and r['resolved'] and r['collaboration_result']=='completed' and r['review_verdict']=='approve' for r in result_rows)
audit={'stage':58,'source_base_commit':read(OUT/'baseline.json')['source_commit'],'plan_sha256':sha(HOME/'plan.json'),
 'frozen_inputs_verified':len(plan['files_sha256']),'slots':4,'all_terminal':True,'selection_reruns':0,'results':result_rows,
 'arms':arm_stats,'full_complete':full_complete,'known_price_estimate_cny':float(known),'unknown_placeholder_cny':float(unknown_placeholder),
 'complete_cost_estimate_cny':None if unknown else float(known),'platform_attempts':len(new),'shared_requests_before':2477,'shared_requests_after':len(after['requests']),
 'formal_payloads_unchanged':53,'historical_files_unchanged':len(history),'billing_stop':read(HOME/'billing-stop.json') if (HOME/'billing-stop.json').exists() else None,
 'qualification':{t:{v:{p:{k:d[k] for k in ['tests_run','passed','successful']} for p,d in data.items()} for v,data in versions.items()} for t,versions in read(HOME/'qualification.json').items()},
 'roles':[{k:r.get(k) for k in ['id','run_id','phase','status','reason']} for r in roles],
 'balance_probed':False,'scope':'Two new-to-project public issues in a familiar repository, each arm once. Not model-training-unseen, cross-repository, statistical or module-causal evidence.'}
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'new-request-receipts.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ledger-after.json').write_bytes((ROOT/'data/deepseek_budget.json').read_bytes())
print(json.dumps({k:audit[k] for k in ['slots','all_terminal','frozen_inputs_verified','arms','full_complete','platform_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after','formal_payloads_unchanged','historical_files_unchanged']}))
