import socket
def denied(*a, **k): raise RuntimeError('Offline qualification forbids network')
def pytest_configure(config):
 socket.socket.connect=socket.socket.connect_ex=socket.getaddrinfo=denied
