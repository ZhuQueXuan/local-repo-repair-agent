"""Finalize one terminal acceptance; no transport, worker, retry or source edit."""
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');audit=read(OUT/'batch/audit.json');result=read(OUT/'batch/result.json')
before=read(OUT/'ledger-before.json');after=read(OUT/'ledger-after.json')
assert result['run_id']=='943260d8e65649a8a9dd06f75a3160fb'
assert result['status'] in {'finished','failed','cancelled','interrupted'}
assert audit['new_parent_runs']==1 and audit['extra_selection_reruns']==0
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert read(ROOT/'data/deepseek_budget.json')==after
assert len(before['requests'])==2408 and all(after['requests'][k]==v for k,v in before['requests'].items())
assert len(after['requests'])==2408+audit['new_attempts']
assert all(sha(ROOT/n)==h for n,h in plan['input_files_sha256'].items())
history=read(OUT/'historical-before.json');assert all(sha(ROOT/n)==h for n,h in history.items())
check={'formal_payloads_unchanged':53,'old_requests_unchanged':2408,'shared_requests_after':len(after['requests']),
    'new_attempts':audit['new_attempts'],'frozen_inputs_unchanged':len(plan['input_files_sha256']),
    'historical_files_unchanged':len(history),'new_parent_runs':1,'extra_selection_reruns':0,'source_changes_this_turn':0}
(OUT/'protection-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
summary=read(OUT/'navigation-summary.json');body=summary['body']
name='55_验收_集中核查后的完整三角色单次真实验收.md'
assert (ROOT/'Project'/name).is_file()
def edit(p,marker,text):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';old=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in old and name not in old
    p.write_bytes(old.replace(marker,marker+'\n'+text+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[55集中核查后真实验收](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[55集中核查后真实验收]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**集中核查后单次真实验收（2026-10-27）。** '+body+' 见[55]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [55集中核查后单次真实验收](Project/'+name+')：'+summary['readme'])
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[55集中核查后真实验收](../shixi_project/Project/'+name+')：'+body)
print(json.dumps(check))
