"""Replay only public frozen document reads in a new copy, with scripted correction."""
import json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from collaboration_protocol import RoleIdentity,ProtocolError,canonical_bytes,sha256
from document_agent import (DocumentGrant,DocumentSnapshot,DocumentBroker,document_rejection,
    DocumentAdvice,ConsultationRecord,consultation_context)
folder=ROOT/'experiments/click_guard_revalidation_20261027'
archive=folder/'one-real-run.zip'
assert sha256(archive.read_bytes())==json.loads((folder/'artifact_sha256.json').read_bytes())['one-real-run.zip']
members=json.loads((folder/'one-real-run.zip.sha256.json').read_bytes())
home=OUT/'verified_replay'
with zipfile.ZipFile(archive) as z:
    def get(name):
        raw=z.read(name);assert sha256(raw)==members[name];return raw
    grant_name=next(n for n in z.namelist() if n.startswith('store/document_snapshots/') and n.endswith('/grant.json'))
    grant_raw=get(grant_name);grant=DocumentGrant.parse(json.loads(grant_raw))
    directory=home/'document_snapshots'/grant.run_id/grant.role_run_id
    assert not directory.exists();(directory/'objects').mkdir(parents=True)
    (directory/'grant.json').write_bytes(grant_raw)
    prefix=grant_name.removesuffix('grant.json')
    for doc in grant.documents:
        (directory/'objects'/doc.document_id).write_bytes(get(prefix+'objects/'+doc.document_id))
    trajectory=json.loads(get('store/runs/'+grant.run_id+'/consulting-trajectory.json'))
snapshot=DocumentSnapshot(directory,grant);snapshot.verify()
identity=RoleIdentity(run_id=grant.run_id,role_run_id=grant.role_run_id,session_id='offline-replay',role='document_reader')
broker=DocumentBroker(snapshot,identity);bad=None;skipped=[]
for message in trajectory['messages']:
    for action in message.get('extra',{}).get('actions',[]):
        if action['tool']=='read_lines':bad=action;break
        if action['tool']=='read_skill':skipped.append('read_skill: method only, never source evidence');continue
        assert action['tool'] in {'search_text','list_files'}
        broker.dispatch(identity,action['tool'],action['arguments'])
    if bad:break
assert bad is not None
before_ids=set(broker.evidence)
try:broker.dispatch(identity,bad['tool'],bad['arguments'])
except ProtocolError as error:feedback=document_rejection(error)
else:raise AssertionError('Historical wrong-document range must still reject')
assert set(broker.evidence)==before_ids
assert feedback['selected_document']['line_count']==269 and feedback['previously_issued_matches']
match=feedback['previously_issued_matches'][0]
assert match['evidence_id'] in before_ids and match['document_id']!=bad['arguments']['document_id']
corrected=bad['arguments']|{'document_id':match['document_id']}
receipt=broker.dispatch(identity,'read_lines',corrected)
evidence_id=receipt['evidence']['evidence_id']
assert evidence_id in broker.evidence and sha256(receipt['content'].encode())==receipt['evidence']['span_sha256']
advice=DocumentAdvice(advice_id='offline-corrected-advice',run_id=grant.run_id,role_run_id=grant.role_run_id,
    snapshot_id=grant.snapshot_id,task_digest=grant.task_digest,document_tree_digest=grant.document_tree_digest,
    status='information_not_found',answer='Scripted correction replay. Applicability to the repair question is not established.',
    evidence_ids=(evidence_id,),unknowns=('This is not a model answer or a new behavioral acceptance.',))
broker.dispatch(identity,'submit_consultation',{'advice':advice.model_dump(mode='json')})
record=ConsultationRecord(advice_id=advice.advice_id,run_id=grant.run_id,relative_directory=directory.relative_to(home).as_posix(),grant=grant,
    advice=advice,evidence=(broker.evidence[evidence_id],))
payload=consultation_context(record,home)
original_feedback=next(json.loads(m['content']) for m in trajectory['messages'] if m.get('role')=='tool'
    and json.loads(m['content']).get('reason')=='invalid_document_read_range')
result={'scope':'Offline scripted correction on a verified public-document copy. No model request, old worker, new live identity or repair score.',
    'historical_run_id':grant.run_id,'historical_failure_unchanged':'document_repeated_format_errors',
    'source_archive_sha256':sha256(archive.read_bytes()),'document_objects_verified':len(grant.documents),
    'original_bad_request':bad['arguments'],'before_feedback':original_feedback,'after_feedback':feedback,
    'corrected_request':corrected,'corrected_evidence':receipt['evidence'],'consultation_status':advice.status,
    'handoff_bytes':len(canonical_bytes(payload)),'feedback_bytes':len(canonical_bytes({'status':'rejected',**feedback})),
    'evidence_ids_before_failed_read':len(before_ids),'failed_read_issued_evidence':False,
    'skipped_method_reads':skipped,'new_model_calls':0,'new_live_identities':0}
(OUT/'fixed-record-replay.json').write_bytes(canonical_bytes(result))
print(json.dumps({k:v for k,v in result.items() if k in {'document_objects_verified','consultation_status','handoff_bytes','feedback_bytes','new_model_calls','new_live_identities'}}))
