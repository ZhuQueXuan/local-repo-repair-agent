"""Audit and archive the completed offline document correction only."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;DEST=ROOT/'experiments/document_correction_20261027'
assert not DEST.exists()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert (ROOT/'data/deepseek_budget.json').read_bytes()==(OUT/'ledger-before.json').read_bytes()
assert len(read(OUT/'ledger-before.json')['requests'])==2402
history=read(OUT/'history-before.json');assert all(sha((ROOT/n).read_bytes())==h for n,h in history.items())
plan=read(ROOT/'temp/click_guard_revalidation_20261027/plan.json')
invalidated=[n for n,h in plan['input_files_sha256'].items() if sha((ROOT/n).read_bytes())!=h]
assert set(invalidated)=={'scripts/document_agent.py','scripts/test_document_context.py'},invalidated
log=(OUT/'document-tests-final.txt').read_text(encoding='utf-8-sig')
assert 'Ran 43 tests in ' in log and log.rstrip().endswith('OK')
replay=read(OUT/'fixed-record-replay.json');assert replay['new_model_calls']==0 and replay['consultation_status']=='information_not_found'
check={'formal_payloads_unchanged':53,'shared_requests_unchanged':2402,'historical_files_unchanged':len(history),
       'model_calls':0,'new_live_identities':0,'checks_passed':43,'new_regression_tests':3,
       'old_freeze_invalidated_by':invalidated,'historical_files_sha256':history}
write(OUT/'protection-check.json',check)
name='52_修复_文档目标与行号错配的纠正提示.md'
body='接续51离线补文档读取纠错：对已授权文档给出实际目标/行数、原会话最多3个重叠已发证据和同一命中复制ID/行号提示，错误回执含状态小于4096字节；不自动换文档/裁行或新发证据，原80行/6KB交接/16KB上下文/三次错误停止与权限保持。既有文档相关43项通过（新增3必要回归）；原51公开文档26对象核验副本重放，改选options后读取及2380字节未知交接合法，非模型成功或问题依据。正式53payload/2402请求、52旧实验文件保持，0真实调用/新身份；51原冻结2源码失效保留，原Click修复通过/文档降级与六题成绩不回填。真实模型纠错及复合验证命令进度识别仍待，不自动付费，无面板重启/医疗/异机操作。'
def edit(p,marker,text):
    raw=p.read_bytes();newline='\r\n' if b'\r\n' in raw else '\n';old=raw.decode('utf-8').replace('\r\n','\n')
    assert marker in old and name not in old
    p.write_bytes(old.replace(marker,marker+'\n'+text+'\n',1).replace('\n',newline).encode('utf-8'))
edit(ROOT/'AGENTS.md','## 当前阶段\n','- 2026-10-27最新：[52文档纠错](Project/'+name+')：'+body)
edit(ROOT/'Project/00_项目现状与快速接手.md','最后更新：2026-10-27。\n','2026-10-27最新：[52文档纠错]('+name+')：'+body)
edit(ROOT/'Project/项目开发流水账.md','# 项目开发流水账\n','**文档目标与行号纠错补修（2026-10-27）。** '+body+' 见[52]('+name+')。')
edit(ROOT/'README.md','## 当前证据与未完成项\n','- [52文档纠错补修](Project/'+name+')已为读错文档/行号提供具体目标和已返回搜索证据，43项离线检查与原记录脚本化纠正通过；新版文档角色尚未真实复验。51的Click修复通过、协作降级结果保持。')
edit(ROOT.parent/'job/AGENTS.md','## 当前状态与导航\n','- 2026-10-27主项目最新：[52文档纠错](../shixi_project/Project/'+name+')：'+body)
(OUT/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--','scripts/document_agent.py','scripts/test_document_context.py'],cwd=ROOT))
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
    global scanned
    scanned+=1;assert depth<=6 and not any(k in raw for k in keys),'Credential found; value withheld'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern found'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();members={}
with zipfile.ZipFile(DEST/'offline-evidence.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n in ['replay.py','finish.py','fixed-record-replay.json','before-range-test.txt','document-tests-final.txt','protection-check.json','source-change.patch']:
        raw=(OUT/n).read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
with zipfile.ZipFile(DEST/'offline-evidence.zip') as z:assert all(sha(z.read(n))==h for n,h in members.items())
write(DEST/'offline-evidence.zip.sha256.json',members)
write(DEST/'manifest.json',{'stage':52,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'result':'offline_correction_only_not_a_new_model_success','protection':check,'replay':replay,
    'credential_scan':{'keys_checked':2,'objects':scanned,'matches':0},'formal_database_and_ledger_not_uploaded':True})
write(DEST/'artifact_sha256.json',{p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()})
print(json.dumps({k:v for k,v in check.items() if k not in {'historical_files_sha256','old_freeze_invalidated_by'}}))
