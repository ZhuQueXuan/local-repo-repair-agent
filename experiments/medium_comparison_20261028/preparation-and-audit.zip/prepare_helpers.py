"""Adapt the existing comparison audit and gates without changing runtime policy."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;OLD=ROOT/'temp/three_arm_20261028'
def save(name,source):
 target=OUT/name;assert not target.exists();target.write_text(source,encoding='utf-8')
source=(OLD/'preflight.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('THREE_ARM_TASKS','MEDIUM_TASKS'),
 ('len(plan[\'slots\'])==6','len(plan[\'slots\'])==8'),("('baseline','improved','full')","('improved','full')"),
 ('offline63-','offline64-'),("'maximum_runs':6","'maximum_runs':8"),("report['slots']==6","report['slots']==8"),
 ("{'baseline':0,'improved':0,'full':0}","{'improved':0,'full':0}"),('len(commands)==6','len(commands)==8'),
 ("len(list(testhome.glob('*.claimed')))==6","len(list(testhome.glob('*.claimed')))==8"),
 ('six-slot three-arm','eight-slot two-arm'),('six actual dispatch','eight actual dispatch'),('all six failed','all eight failed'),('three actual dispatch','two actual dispatch')]:
 source=source.replace(old,new)
source=source.replace("bad['slots'][1]['variant']='arbitrary'","bad['slots'][1]['variant']='baseline'")
save('preflight.py',source)
source=(OLD/'authorize.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('3076','3177'),('7675','7941'),
 ("len(plan['slots'])==6","len(plan['slots'])==8"),('maximum_runs=6','maximum_runs=8'),("'maximum_runs':6","'maximum_runs':8"),
 ("'authorized_slots':6","'authorized_slots':8"),('six-run','eight-run'),('six-slot','eight-slot'),
 ('third existing single profile','existing improved/full two-arm selection'),
 ('Task1 baseline/improved/full; Task2 full/improved/baseline. Serial, single repetition; improved always middle, not full order randomization.',
  'Tasks1/3 improved then full; Tasks2/4 full then improved. Serial, one repetition, alternating order, no randomization.'),
 ('Unused specific behaviors in two familiar public repositories; no model-training-unseen claim.',
  'Four unused interacting behaviors in two familiar repositories, three boltons and one Click; locally preclassified moderate, not external difficulty or training-unseen evidence.'),
 ("['baseline','improved','full'","['improved','full'")]:source=source.replace(old,new)
source=source.replace("'baseline','improved','full',","'improved','full',")
source=source.replace("public_sources=['https://github.com/pallets/click/issues/2500','https://github.com/pallets/click/pull/2724','https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md']",
 "public_sources=['https://github.com/pallets/click/issues/2447','https://github.com/pallets/click/pull/3058','https://github.com/mahmoud/boltons/pull/471','https://github.com/mahmoud/boltons/pull/472','https://github.com/mahmoud/boltons/pull/464','https://github.com/mahmoud/boltons/pull/465','https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md']")
source=source.replace("condition.update(plan_sha256=digest,","condition.update(complexity_qualification={t:read(ROOT/'evaluation/medium_comparison_20261028/evaluator'/t/'source.json')['complexity_rationale'] for t in plan['tasks']},plan_sha256=digest,")
save('authorize.py',source)
source=(OLD/'audit.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('3076','3177'),('7675','7941'),
 ("==6","==8"),("'stage':63","'stage':64"),("'slots':6","'slots':8"),("'slots':2","'slots':4"),
 ('Two unused concrete public issues, two familiar repositories, each of three systems once;','Four unused interacting-behavior public tasks, two familiar repositories, each of two systems once;')]:source=source.replace(old,new)
save('audit.py',source)
source=(OLD/'diagnose.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('len(rows)==6','len(rows)==8'),("'terminal_runs':6","'terminal_runs':8")]:source=source.replace(old,new)
save('diagnose.py',source)
source=(OLD/'seal.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('all-six-runs.zip','all-eight-runs.zip'),
 ("'audit-preliminary-queue-timing.json'","'prepare_helpers.py'")]:source=source.replace(old,new)
save('seal.py',source)
source=(OLD/'prepare_commit.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('7675','7941'),('all-six-runs.zip','all-eight-runs.zip'),
 ('Project/63_评测_两道新题原版改良单Agent与完整组三组比较.md','Project/64_评测_四道中等任务改良单Agent与完整组比较.md')]:source=source.replace(old,new)
save('prepare_commit.py',source)
source=(OLD/'delivery.py').read_text('utf-8')
for old,new in [('three_arm_20261028','medium_comparison_20261028'),('c63_1028','c64_1028'),('7675','7941'),("'new_parent_runs':6","'new_parent_runs':8")]:source=source.replace(old,new)
save('delivery.py',source)
print('Prepared offline gates, final read-only audit and archival helpers; zero models')
