"""Four preselected interacting-behavior tasks on untouched upstream source."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'scripts'))
from collaboration_protocol import canonical_bytes
DEST=ROOT/'evaluation/medium_comparison_20261028';assert not DEST.exists()
specs={}
specs['click-resource-exceptions']={
 'source':'click-abort-cause','target':['tests/test_context.py'],
 'problem':'https://github.com/pallets/click/issues/2447','corroboration':'https://github.com/pallets/click/pull/3058',
 'complexity':'Resource lifecycle spans Context enter/exit, explicit close, nested scopes and command invocation, preserving callback order and error propagation.',
 'issue':'''# Forward exceptions to resources managed by Context

A resource registered with Context.with_resource receives (None, None, None) on exit even when the command or a with-context body failed. A resource that commits on success and rolls back on failure therefore sees an incorrect success. Forward the active exception type, the original exception object and its traceback when the outermost Context scope exits.

Handle both direct Context usage and nested command/group invocation. Preserve deferred cleanup for nested entry of the same Context, LIFO resource/call_on_close ordering, successful cleanup, explicit close() without an error, and reuse of a Context after cleanup. Even if resource cleanup raises, the current-context stack must be popped and its consumed cleanup stack must not run again. Keep the command's original exception propagation when cleanup itself succeeds. Changing Context's suppression behavior based on a resource's truthy __exit__ return is outside this task. Change only existing implementation files; leave tests and metadata unchanged.
''',
 'public':'''import unittest
import click
from click.testing import CliRunner
class Resource:
 def __init__(self,events,name): self.events,self.name=events,name
 def __enter__(self): return self
 def __exit__(self,typ,value,tb): self.events.append((self.name,typ,value,tb))
class Cases(unittest.TestCase):
 def test_direct_error_reaches_resource(self):
  events=[];error=ValueError('failed')
  with self.assertRaises(ValueError):
   with click.Context(click.Command('c')) as ctx:
    ctx.with_resource(Resource(events,'r'));raise error
  self.assertIs(events[0][1],ValueError);self.assertIs(events[0][2],error);self.assertIsNotNone(events[0][3])
 def test_group_resource_observes_subcommand_failure(self):
  events=[];error=RuntimeError('sub failed')
  @click.group()
  @click.pass_context
  def cli(ctx): ctx.with_resource(Resource(events,'group'))
  @cli.command()
  def sub(): raise error
  result=CliRunner().invoke(cli,['sub'])
  self.assertIs(result.exception,error);self.assertIs(events[0][2],error)
 def test_cleanup_failure_does_not_leave_current_context(self):
  before=click.get_current_context(silent=True)
  class Bad(Resource):
   def __exit__(self,*args): raise LookupError('cleanup')
  with self.assertRaises(LookupError):
   with click.Context(click.Command('c')) as ctx: ctx.with_resource(Bad([],'bad'))
  self.assertIs(click.get_current_context(silent=True),before)
''',
 'withheld':'''import unittest
from contextlib import contextmanager
import click
from click.testing import CliRunner
class Cases(unittest.TestCase):
 def test_nested_same_context_defers_and_forwards_error(self):
  seen=[];ctx=click.Context(click.Command('c'));error=KeyError('x')
  @contextmanager
  def managed():
   try: yield
   except BaseException as e: seen.append(e);raise
  with self.assertRaises(KeyError):
   with ctx:
    ctx.with_resource(managed())
    with ctx: pass
    self.assertEqual(seen,[]);raise error
  self.assertEqual(seen,[error])
 def test_lifo_callbacks_success_and_explicit_close(self):
  seen=[];ctx=click.Context(click.Command('c'))
  class R:
   def __enter__(self): return self
   def __exit__(self,typ,value,tb): seen.append(('resource',typ,value,tb))
  ctx.with_resource(R());ctx.call_on_close(lambda:seen.append('callback'));ctx.close()
  self.assertEqual(seen,['callback',('resource',None,None,None)]);ctx.close();self.assertEqual(len(seen),2)
 def test_function_resource_and_context_reuse_after_failure(self):
  seen=[];ctx=click.Context(click.Command('c'))
  @contextmanager
  def managed():
   try: yield
   except ValueError: seen.append('rollback');raise
   else: seen.append('commit')
  with self.assertRaises(ValueError):
   with ctx: ctx.with_resource(managed());raise ValueError('x')
  with ctx: ctx.with_resource(managed())
  self.assertEqual(seen,['rollback','commit'])
 def test_nested_command_resources_have_same_error_and_reverse_order(self):
  seen=[];error=OSError('x')
  class R:
   def __init__(self,name): self.name=name
   def __enter__(self): return self
   def __exit__(self,typ,value,tb): seen.append((self.name,typ,value,tb is not None))
  @click.group()
  @click.pass_context
  def cli(ctx): ctx.with_resource(R('group'))
  @cli.command()
  @click.pass_context
  def sub(ctx): ctx.with_resource(R('sub'));raise error
  result=CliRunner().invoke(cli,['sub']);self.assertIs(result.exception,error)
  self.assertEqual(seen,[('sub',OSError,error,True),('group',OSError,error,True)])
 def test_stack_is_clean_and_consumed_after_cleanup_raises(self):
  before=click.get_current_context(silent=True);seen=[];ctx=click.Context(click.Command('c'))
  def bad(): seen.append('bad');raise RuntimeError('cleanup')
  with self.assertRaises(RuntimeError):
   with ctx: ctx.call_on_close(bad)
  self.assertIs(click.get_current_context(silent=True),before)
  with ctx: ctx.call_on_close(lambda:seen.append('new'))
  self.assertEqual(seen,['bad','new'])
'''}
specs['boltons-barrel-slices']={
 'source':'boltons-query-encoding','target':['tests/test_listutils.py'],
 'problem':'https://github.com/mahmoud/boltons/pull/471','corroboration':'https://github.com/mahmoud/boltons/pull/472',
 'complexity':'One coherent Python slice contract across iter_slice, __getitem__, del_slice and __delitem__, including segmented state and subsequent mutations.',
 'issue':'''# Make BarrelList slice reads and deletions agree with list

BarrelList claims slicing works across internal list borders, but clipped bounds, reverse steps, and deletion spanning barrels can return the wrong values or fail. For integer/None bounds and nonzero integer steps, slice reading and deletion should have Python list semantics regardless of how values are split across internal lists. This covers obj[slice], iter_slice(start, stop, step), del obj[slice], and del_slice(start, stop, step).

Preserve order, duplicate values, length and the BarrelList type of a slice result. Support negative and out-of-range bounds, omitted endpoints, reverse and extended steps, empty ranges and full deletion. A zero step must raise ValueError without mutation. After deletion the object must remain usable for append/extend/pop and further slice reads; maintain a usable internal structure even when empty. Slicing must not mutate the source. Exact internal partition shapes and asymptotic performance are not scored. Ordinary item-index changes and slice assignment are outside this task. Modify only existing implementation files.
''',
 'public':'''import unittest
from boltons.listutils import BarrelList
def segmented():
 value=BarrelList();value.lists=[[0,1,2],[3,4],[5,6,7,8,9]];return value
class Cases(unittest.TestCase):
 def test_clipped_forward_slice(self):
  value=segmented();self.assertEqual(list(value[-50:50:2]),list(range(10))[-50:50:2])
 def test_reverse_slice(self):
  value=segmented();self.assertEqual(list(value[::-1]),list(range(10))[::-1])
 def test_cross_barrel_deletion(self):
  value=segmented();del value[1:8];self.assertEqual(list(value),[0,8,9]);self.assertEqual(len(value),3)
''',
 'withheld':'''import unittest
from boltons.listutils import BarrelList
def make(data):
 value=BarrelList();value.lists=[data[:3],data[3:6],data[6:]];return value
class Cases(unittest.TestCase):
 def test_read_matrix_matches_list_and_does_not_mutate(self):
  data=[0,1,1,3,4,5,6,7,8]
  for start,stop,step in [(None,None,-2),(-20,20,3),(7,1,-2),(20,-20,-3),(2,2,1),(None,-1,1),(-3,None,1)]:
   with self.subTest(args=(start,stop,step)):
    value=make(data);part=value[slice(start,stop,step)]
    self.assertIsInstance(part,BarrelList);self.assertEqual(list(part),data[slice(start,stop,step)])
    self.assertEqual(list(value.iter_slice(start,stop,step)),list(part));self.assertEqual(list(value),data)
 def test_extended_and_reverse_deletions(self):
  data=list(range(12))
  for sl in [slice(None,None,2),slice(None,None,-2),slice(10,1,-3),slice(-50,50,3)]:
   with self.subTest(slice=sl):
    expected=data[:];del expected[sl];value=make(data);value.del_slice(sl.start,sl.stop,sl.step)
    self.assertEqual(list(value),expected);self.assertEqual(len(value),len(expected))
 def test_endpoints_empty_ranges_and_all(self):
  data=list(range(9))
  for sl in [slice(2,None),slice(None,None),slice(100,200),slice(7,2),slice(-50,2),slice(-2,99)]:
   with self.subTest(slice=sl):
    expected=data[:];del expected[sl];value=make(data);del value[sl];self.assertEqual(list(value),expected)
 def test_zero_step_raises_without_mutation(self):
  data=list(range(9));value=make(data)
  for call in [lambda:list(value.iter_slice(None,None,0)),lambda:value.del_slice(None,None,0),lambda:value[::0]]:
   with self.assertRaises(ValueError): call()
   self.assertEqual(list(value),data)
 def test_followup_mutations_after_empty_and_partial_deletion(self):
  for sl in [slice(None,None),slice(1,8)]:
   expected=list(range(9));value=make(expected);del expected[sl];del value[sl]
   expected.append(40);value.append(40);expected.extend([41,42]);value.extend([41,42])
   self.assertEqual(value.pop(),expected.pop());self.assertEqual(list(value),expected)
   self.assertEqual(list(value[::-1]),expected[::-1])
'''}
specs['boltons-jsonl-seek']={
 'source':'boltons-query-encoding','target':['tests/test_jsonutils.py'],
 'problem':'https://github.com/mahmoud/boltons/pull/464','corroboration':'https://github.com/mahmoud/boltons/pull/465',
 'complexity':'Iterator initialization, relative offset normalization, bytes/text newline alignment and EOF behavior must agree with forward/reverse consumption.',
 'issue':'''# Repair JSONLIterator relative seeking and end-of-stream boundaries

JSONLIterator documents rel_seek=0.0 as the beginning and 1.0 as the end. Relative seeking in binary streams currently mixes text and bytes, an explicit 1.0 is rejected, negative relative fractions seek past the end, and aligning a cursor beyond the last newline can loop forever.

Support -1.0 < rel_seek <= 1.0, with a negative fraction interpreted relative to the end (for example -0.25 is the same position as 0.75). Reject values outside that range. For intermediate positions retain the existing alignment rule: align to the first newline at or after the calculated target, or EOF if none remains. Use the stream's text/bytes newline type. Forward iteration starts after that separator; binary reverse iteration includes the preceding complete line. Preserve omitted-rel_seek forward iteration from the caller's current cursor, reverse's default end positioning, ignore_errors, and stream ownership. This task covers seekable in-memory text/binary streams and binary files; general Unicode text-file byte-cookie seeking and unrelated reverse_iter_lines encoding changes are outside scope. Change only existing implementation files.
''',
 'public':'''import io,unittest
from boltons.jsonutils import JSONLIterator
DATA=b'{"i":0}\\n{"i":1}\\n{"i":2}\\n{"i":3}\\n'
class Cases(unittest.TestCase):
 def test_binary_middle_seek_matches_text(self):
  a=list(JSONLIterator(io.BytesIO(DATA),rel_seek=0.3));b=list(JSONLIterator(io.StringIO(DATA.decode()),rel_seek=0.3))
  self.assertEqual(a,b);self.assertEqual(a,[{'i':2},{'i':3}])
 def test_explicit_endpoint_forward_and_reverse(self):
  self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=1.0)),[])
  self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=1.0,reverse=True)),[{'i':3},{'i':2},{'i':1},{'i':0}])
 def test_negative_seek_equals_position_from_end(self):
  a=list(JSONLIterator(io.BytesIO(DATA),rel_seek=-0.7));b=list(JSONLIterator(io.BytesIO(DATA),rel_seek=0.3));self.assertEqual(a,b)
''',
 'withheld':'''import io,unittest
from boltons.jsonutils import JSONLIterator
DATA=b'{"x":0}\\n{"x":1}\\n{"x":2}\\n{"x":3}\\n{"x":4}\\n'
class GuardedBytes(io.BytesIO):
 def __init__(self,data): super().__init__(data);self.reads=0
 def read(self,*args):
  self.reads+=1
  if self.reads>6: raise AssertionError('alignment must terminate at EOF')
  return super().read(*args)
class Cases(unittest.TestCase):
 def test_varied_offsets_forward_and_reverse_match_separator_oracle(self):
  for pos in (0.12,0.35,0.62,0.9):
   target=int(len(DATA)*pos);sep=DATA.find(b'\\n',target);sep=len(DATA) if sep<0 else sep
   expected=[__import__('json').loads(line) for line in DATA[sep:].splitlines() if line.strip()]
   prior=[__import__('json').loads(line) for line in DATA[:sep].splitlines() if line.strip()]
   self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=pos)),expected)
   self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=pos,reverse=True)),prior[::-1])
 def test_no_remaining_newline_terminates_and_keeps_stream_open(self):
  stream=GuardedBytes(b'{"x":0}\\n{"x":1}')
  self.assertEqual(list(JSONLIterator(stream,rel_seek=0.9)),[]);self.assertFalse(stream.closed)
  stream=GuardedBytes(b'');self.assertEqual(list(JSONLIterator(stream,rel_seek=0.5)),[])
 def test_zero_endpoint_negative_and_invalid_bounds(self):
  for reverse in (False,True):
   for pos in (-1.0,1.01,-2):
    with self.assertRaises(ValueError):JSONLIterator(io.BytesIO(DATA),reverse=reverse,rel_seek=pos)
  self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=0)),[{'x':i} for i in range(5)])
  self.assertEqual(list(JSONLIterator(io.BytesIO(DATA),rel_seek=-0.38)),list(JSONLIterator(io.BytesIO(DATA),rel_seek=0.62)))
 def test_existing_cursor_default_reverse_and_ignore_errors(self):
  stream=io.BytesIO(DATA);stream.seek(8);self.assertEqual(list(JSONLIterator(stream)),[{'x':i} for i in range(1,5)])
  stream=io.BytesIO(DATA);self.assertEqual(list(JSONLIterator(stream,reverse=True)),[{'x':i} for i in reversed(range(5))]);self.assertFalse(stream.closed)
  self.assertEqual(list(JSONLIterator(io.BytesIO(b'{"a":1}\\nbad\\n{"a":2}\\n'),ignore_errors=True)),[{'a':1},{'a':2}])
 def test_alignment_across_multiple_blocks(self):
  data=b'{"s":"'+b'a'*9000+b'"}\\n{"s":"end"}\\n'
  self.assertEqual(list(JSONLIterator(io.BytesIO(data),rel_seek=0.2)),[{'s':'end'}])
'''}
specs['boltons-table-text']={
 'source':'boltons-query-encoding','target':['tests/test_tableutils.py'],
 'problem':'https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md','corroboration':'https://github.com/mahmoud/boltons/blob/master/boltons/tableutils.py',
 'complexity':'Rendering must reconcile inferred width, short/non-string headers, ragged rows, header suppression and cell truncation without mutating stored data.',
 'issue':'''# Make Table.to_text handle empty and irregular tables

Table.to_text crashes or formats columns incorrectly for empty tables, non-string header cells, and rows wider than the header list. Render these tables robustly while keeping all cells and existing string conversion/truncation rules.

Compute each displayed column's width from that column's rendered data cells and, when included, its rendered header. Do not use the number of cells in a row as the text width. Missing header cells should be blank, and missing data cells should follow the existing None-filling behavior. Empty headers mean no header row or separator; a completely empty table renders ''. Header-only tables should render their headers and separator. with_headers=False must suppress headers without changing the data. Preserve the existing centered cells, ' | ' columns and '-|-' header separator, maxlen conversion, Unicode data, and table contents across repeated rendering. Change only existing implementation files; HTML changes and recursive tables are outside scope.
''',
 'public':'''import unittest
from boltons.tableutils import Table
class Cases(unittest.TestCase):
 def test_empty_and_header_only_tables(self):
  self.assertEqual(Table([]).to_text(),'')
  self.assertEqual(Table([],headers=['name']).to_text(),'name\\n----')
 def test_nonstring_headers(self):
  text=Table([[7,8]],headers=[None,42]).to_text()
  self.assertEqual([s.strip() for s in text.splitlines()[0].split(' | ')],['None','42'])
 def test_short_headers_do_not_drop_data(self):
  text=Table([[1,2,3],[4,5]],headers=['a']).to_text()
  self.assertEqual([s.strip() for s in text.splitlines()[0].split(' | ')],['a','',''])
  self.assertEqual([s.strip() for s in text.splitlines()[-1].split(' | ')],['4','5','None'])
''',
 'withheld':'''import copy,unittest
from boltons.tableutils import Table
class Cases(unittest.TestCase):
 def test_column_width_comes_from_that_column(self):
  t=Table([['abcdefghij','x'],['q','yyy']],headers=['A','B']);lines=t.to_text().splitlines()
  self.assertEqual([len(part) for part in lines[2].split(' | ')],[10,3])
  self.assertEqual([len(part) for part in lines[3].split(' | ')],[10,3])
 def test_empty_headers_and_ragged_data(self):
  text=Table([[1,2],[3]],headers=[]).to_text()
  self.assertEqual(len(text.splitlines()),2)
  self.assertEqual([s.strip() for s in text.splitlines()[-1].split(' | ')],['3','None'])
 def test_headers_can_be_suppressed_and_empty_data_is_safe(self):
  self.assertEqual(Table([],headers=['long']).to_text(with_headers=False),'')
  text=Table([[12,3]],headers=['a','b']).to_text(with_headers=False)
  self.assertEqual(text,'12 | 3');self.assertNotIn('-|-',text)
 def test_maxlen_unicode_and_nonstring_cells(self):
  t=Table([['中文字符更多',123456]],headers=['longheader',0]);text=t.to_text(maxlen=5)
  self.assertEqual([s.strip() for s in text.splitlines()[0].split(' | ')],['lo...','0'])
  self.assertEqual([s.strip() for s in text.splitlines()[-1].split(' | ')],['中文...','12...'])
 def test_repeated_rendering_keeps_table_and_headers(self):
  t=Table([[1,2,3],[4,5]],headers=['one']);before=copy.deepcopy((t.headers,t._data,t._width))
  first=t.to_text();self.assertEqual(t.to_text(),first);t.to_text(with_headers=False,maxlen=5)
  self.assertEqual((t.headers,t._data,t._width),before)
'''}

def replacement(source,relative,start,end,new):
 text=(source/'repo'/relative).read_text('utf-8');a=text.index(start);b=text.index(end,a)
 return {'path':relative,'old':text[a:b],'new':new,'expected_occurrences':1}

for task,s in specs.items():
 source=ROOT/'evaluation/multi_agent_20261025/public'/s['source'];base=json.loads((source/'manifest.json').read_bytes())
 if task=='click-resource-exceptions':
  edits=[{'path':'src/click/core.py','old':'        if self._depth == 0:\n            self.close()\n        pop_context()',
   'new':'        try:\n            if self._depth == 0:\n                self._close_with_exception_info(exc_type, exc_value, tb)\n        finally:\n            pop_context()','expected_occurrences':1},
   {'path':'src/click/core.py','old':'        self._exit_stack.close()\n        # In case the context is reused, create a new exit stack.\n        self._exit_stack = ExitStack()',
   'new':'        self._close_with_exception_info(None, None, None)\n\n    def _close_with_exception_info(self, exc_type, exc_value, tb):\n        try:\n            self._exit_stack.__exit__(exc_type, exc_value, tb)\n        finally:\n            self._exit_stack = ExitStack()','expected_occurrences':1}]
 elif task=='boltons-barrel-slices':
  edits=[replacement(source,'boltons/listutils.py','    def iter_slice(', '    __delslice__ = del_slice',
   '''    def iter_slice(self, start, stop, step=None):
        indices = range(*slice(start, stop, step).indices(len(self)))
        return (self[index] for index in indices)

    def del_slice(self, start, stop, step=None):
        values = list(self)
        del values[slice(start, stop, step)]
        self.lists[:] = [values]
        self._balance_list(0)

''')]
 elif task=='boltons-jsonl-seek':
  edits=[{'path':'boltons/jsonutils.py','old':'elif not -1.0 < rel_seek < 1.0:', 'new':'elif not -1.0 < rel_seek <= 1.0:','expected_occurrences':1},
   {'path':'boltons/jsonutils.py','old':'rel_seek = 1.0 - rel_seek','new':'rel_seek = 1.0 + rel_seek','expected_occurrences':1},
   replacement(source,'boltons/jsonutils.py','    def _align_to_newline(', '    def _init_rel_seek(',
   '''    def _align_to_newline(self):
        fo, bsize = self._file_obj, self._blocksize
        while True:
            start = fo.tell()
            block = fo.read(bsize)
            if not block:
                return
            newline = b'\\n' if isinstance(block, bytes) else '\\n'
            offset = block.find(newline)
            if offset >= 0:
                fo.seek(start + offset)
                return

''')]
 else:
  edits=[replacement(source,'boltons/tableutils.py','    def to_text(self, with_headers=True, maxlen=None):','        return \'\\n\'.join(lines)',
   '''    def to_text(self, with_headers=True, maxlen=None):
        headers = [to_text(h, maxlen=maxlen) for h in (self.headers or [])]
        data = [[to_text(cell, maxlen=maxlen) for cell in row] for row in self._data]
        show = bool(with_headers and headers)
        width = max([len(headers) if show else 0] + [len(row) for row in data])
        if not width:
            return ''
        headers += [''] * (width - len(headers))
        data = [row + [to_text(None, maxlen=maxlen)] * (width - len(row)) for row in data]
        widths = [max([len(row[i]) for row in data] + ([len(headers[i])] if show else [0])) for i in range(width)]
        lines = []
        if show:
            lines.append(' | '.join(h.center(widths[i]) for i, h in enumerate(headers)))
            lines.append('-|-'.join('-' * w for w in widths))
        lines.extend(' | '.join(cell.center(widths[i]) for i, cell in enumerate(row)) for row in data)
''')]
 public=DEST/'public'/task;authority=DEST/'evaluator'/task;public.mkdir(parents=True);authority.mkdir(parents=True)
 for n,h in base['source_files_sha256'].items():
  raw=(source/'repo'/n).read_bytes();assert hashlib.sha256(raw).hexdigest()==h
  p=public/'repo'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 (public/'checks').mkdir();(public/'issue.md').write_bytes(s['issue'].encode());(public/'checks/test_behavior.py').write_bytes(s['public'].encode())
 (authority/'test_behavior.py').write_bytes(s['withheld'].encode())
 (authority/'reference.json').write_bytes(canonical_bytes({'edits':edits,'scope':'Trusted developer qualification only; excluded from model inputs'}))
 (authority/'source.json').write_bytes(canonical_bytes({'problem_url':s['problem'],'corroboration':s['corroboration'],'complexity_rationale':s['complexity'],
  'classification':'Predeclared moderate interacting-behavior development tasks, not externally rated or unfamiliar repositories',
  'previous_project_model_use_of_this_behavior':False,'base_tag':base['base_tag'],'base_commit':base['base_commit'],'license':'BSD-3-Clause; original license retained'}))
 manifest={**base,'task_id':task,'problem_url':s['problem'],'upstream_target':s['target'],'full_target':s['target'],
  'agent_test_command':('PYTHONPATH=src ' if base.get('import_root')=='src' else '')+'python -B -m pytest '+' '.join(s['target'])+' -q -p no:cacheprovider',
  'task_files_sha256':{n:hashlib.sha256((public/n).read_bytes()).hexdigest() for n in ('issue.md','checks/test_behavior.py')}}
 (public/'manifest.json').write_bytes(canonical_bytes(manifest))
(DEST/'README.md').write_text('# Four moderate tasks improved single versus full roles\n\nFour unused interacting behaviors in Click and boltons. Original source bytes and BSD licenses retained. Three public and five retained test methods per task; evaluator/reference never enter model workspaces. Medium is an a-priori local classification, not official benchmark difficulty or training-unseen evidence. Eight single runs fixed before models; no outcome selection reruns.\n',encoding='utf-8')
print('Created four unchanged upstream baselines, 12 public and 20 retained methods; zero models')
