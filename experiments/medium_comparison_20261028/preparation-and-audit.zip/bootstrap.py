"""Capture pre-change state and reuse existing bounded preparation helpers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
old=ROOT/'temp/three_arm_20261028'
source=(old/'capture.py').read_text('utf-8').replace("'maximum_runs':6","'maximum_runs':8")
source=source.replace('那就按这个方案做，选两道新题，固定当前版本和条件，做原版、改良单Agent和完整多Agent三组比较。真实调用不用逐次问我，好坏结果都保留，旧成绩别改。','那就按这个方案做，选4道中等复杂度的新题，固定当前版本和条件，只比较改良单Agent和完整多Agent，共8次真实运行。真实调用不用逐次问我，好坏结果都保留，旧成绩别改。')
target=OUT/'capture.py';assert not target.exists();target.write_text(source,encoding='utf-8')
print('Baseline capture prepared, no model calls')
