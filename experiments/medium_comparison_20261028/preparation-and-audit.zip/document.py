"""Final report generated from the eight immutable outcomes and audit receipts."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
a=read(OUT/'audit.json');c=read(OUT/'fixed-conditions.json');arms=a['arms']
names={'improved':'改良单Agent','full':'完整多Agent'}
labels={'click-resource-exceptions':'Click资源退出异常','boltons-barrel-slices':'BarrelList切片与删除','boltons-jsonl-seek':'JSONL定位与结束边界','boltons-table-text':'Table不规则文本渲染'}
docname='64_评测_四道中等任务改良单Agent与完整组比较.md'
scores='、'.join(f"{names[v]}{arms[v]['resolved']}/4" for v in names)
bytask={t:{r['variant']:r for r in a['results'] if r['task']==t} for t in c['tasks']}
full_only=[labels[t] for t,p in bytask.items() if p['full']['resolved'] and not p['improved']['resolved']]
single_only=[labels[t] for t,p in bytask.items() if p['improved']['resolved'] and not p['full']['resolved']]
conclusion=('本批完整组修复通过数更多。' if arms['full']['resolved']>arms['improved']['resolved'] else
 '本批两组修复通过数相同。' if arms['full']['resolved']==arms['improved']['resolved'] else '本批改良单Agent修复通过数更多。')
text=f'''# 四道中等任务改良单Agent与完整组比较

日期：2026-10-28。按用户明确授权，固定63版，选择4道未用于本项目调试的相互约束行为问题，只比较改良单Agent与完整多Agent，每题每组一次，共8次真实运行。**独立补丁通过：{scores}；完整三角色成功{a['full_complete']}/4。** {conclusion}全部成功、失败、错误和费用保留，没有按结果补跑，旧成绩不改。

## 题目范围和复杂度

“中等”是结果产生前按相互影响的行为和状态预先分类，不是官方难度分、模型实测难度或大型跨文件开发。4题涉及同一模块中的多方法/多入口或多约束联动，比63的单一边界问题宽；不以补丁行数或必须修改多个文件强行规定解法。三题来自boltons、一题来自Click，仓库此前熟悉，具体行为未作为项目调试题；公开问题可能在模型训练中出现，不称训练未见或陌生仓库评测。

| 固定任务 | 相互约束 | 官方依据 |
| --- | --- | --- |
| Click资源退出异常 | Context退出/显式关闭/嵌套调用、原异常与traceback、LIFO及失败后清理和复用 | [Issue2447](https://github.com/pallets/click/issues/2447)、[PR3058](https://github.com/pallets/click/pull/3058) |
| BarrelList切片与删除 | iter_slice与读/删入口、跨内部段、正反/扩展步长、边界和后续变更 | [PR471](https://github.com/mahmoud/boltons/pull/471)、[PR472](https://github.com/mahmoud/boltons/pull/472) |
| JSONL定位与结束边界 | 构造参数归一、字节/文本换行、当前位置、正反迭代与EOF | [PR464](https://github.com/mahmoud/boltons/pull/464)、[官方变更记录](https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md) |
| Table不规则文本渲染 | 推导列宽、短/非字符串表头、不齐行、隐藏表头、截断与内容不变 | [官方变更记录](https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md)、[模块源码](https://github.com/mahmoud/boltons/blob/master/boltons/tableutils.py) |

原Click8.1.3和boltons25.0.0源码逐字节复用，原BSD-3-Clause许可保留，无人工注入缺陷。上游有维护和具体修复记录；复用已有公开投影、隔离资格与独立重放入口，不引入另一个评测框架、环境或依赖。题目范围明确排除新模块/联网服务/依赖安装和无关功能扩展，适配当前只接受已有实现文件修改的边界。

每题3项公开方法、5项保留方法；参考修复只用于开发侧资格检查。原始/参考均实际执行隔离子进程，网络阻断；原始公共3项全失败，参考公共3/保留5全部通过。兼容方法可以在原始版本通过，保留方法不是都必须红。

| 资格 | 原始公开/保留/上游 | 参考公开/保留/上游 |
| --- | --- | --- |
'''
for task in c['tasks']:
 q=a['qualification'][task]
 def values(version):return '、'.join(f"{q[version][k]['passed']}/{q[version][k]['tests_run']}" for k in ['public','withheld','upstream'])
 text+=f"| {labels[task]} | {values('baseline')} | {values('reference')} |\n"
text+=f'''
上游登记子集分别为23、2、2、3项，共30项/版本，不是两仓库全套。JSONL的无换行尾部测试使用有限读取次数的流，在原版无限循环时给出明确失败，不让资格检查挂死；不修改模型运行时限。BarrelList只删除内存序列元素，没有文件删除操作。

## 先固定的系统条件

源码基线`{a['source_base_commit']}`，即63交付提交。本轮只改[comparison_inputs.py](../scripts/comparison_inputs.py)的4题精确登记和[comparison_batch.py](../scripts/comparison_batch.py)的`medium_four`设计，复用已有两条分派分支。模型、提示、工具、上下文、读取控制、费用、时限和审查策略没有改动。

| 条件 | 改良单Agent | 完整多Agent |
| --- | --- | --- |
| 主流程 | 现有adaptive_history StatefulAgent | 文档、修复、首审，最多一次必要返工/末审 |
| 基础上下文 | 原1KB展示/12KB目标历史压缩、原文档案、有界任务状态 | 同一基础加原角色保护 |
| 附加能力 | 不开任务卡、文档/审查角色、检索、Skills/MCP | 原任务卡、文档/审查、只读Skills/MCP注册和修复收口 |
| 时限 | 300秒 | 初修300秒；父1800秒、文档120/首审120/返工180/末审90秒 |
| 模型/路由 | 原北邮优先、DeepSeek备用 | 同左，原父任务切换继承 |
| 评分机会 | 终态最终导出补丁 | 终态最终导出补丁，失败时最后合法封存候选 |
| 分母 | 固定4槽位，各一次 | 固定4槽位，各一次 |

温度0、16KB修复请求硬限、原32KB审查/6KB文档交接、权限/文件保护和共享记账保持。完整组总时间、提示、控制和返工机会更多，因此结果是两个现有系统的实际效果/成本比较；没有做总预算对齐，不能把差异单独归因于Agent数量。

任务1/3按改良→完整，任务2/4按完整→改良，串行交错，未随机化。全部8个身份在首次模型调用前登记，不按结果选题/重试/追加身份。输入冻结{a['frozen_inputs_verified']}份，计划SHA256 `{a['plan_sha256']}`。fixed-conditions与用户本次8槽位授权先保存；原正式worker空闲与无排队、批次锁、唯一claimed/禁止再派发及明确计费拒绝停止门控保持，不探测余额。

## 离线接线

复用已有23项服务生命周期/取消/来源检查通过；5组窄门控验证旧设计保持、四题公共ZIP字节和保留排除、8个脚本化分派/配置绑定、缺组或混入raw/活动评分/重复派发拒绝、8个失败仍留分母及新计费拒绝停止。0模型调用；其中合成失败仅用于门控，不是本轮真实模型成绩。没有新增测试文件或把62的432/301当作本轮新全回归。

题目、公共检查和登记上游给两组相同；保留和参考排除在模型工作副本、提示、快照之外。Bash没有OS沙箱，不能声称对恶意越级读取保密。

## 八次真实运行结果

| 任务 | 组别/新身份前缀 | 流程 | 独立补丁 | 公开/保留/上游 |
| --- | --- | --- | --- | --- |
'''
for r in a['results']:
 state=r['agent_exit'] if r['variant']=='improved' else f"{r['collaboration_result']}/{r['review_verdict']}"
 checks='；'.join(f"{k}{r['checks'][k]['passed']}/{r['checks'][k]['tests_run']}" for k in ['public','withheld','upstream']) if r.get('checks') else (r.get('evaluation_error') or '无合法候选')
 text+=f"| {labels[r['task']]} | {names[r['variant']]}/{r['run_id'][:8]} | {state} | {'通过' if r['resolved'] else '未解决'} | {checks} |\n"
text+='''
所有模型终态后才统一开始保留评分，在干净副本重放最终导出补丁或最后合法封存候选。无候选、失败、超时、服务错误和取消均在原8槽位分母。正常提交、独立补丁通过与完整协作成功分开报告；即使合法部分候选通过，也不把失败角色改成成功。失败工作目录diff仅供诊断，不补造或替代候选。

'''
text+=f"完整组单独通过的题：{'、'.join(full_only) or '无'}。改良单Agent单独通过的题：{'、'.join(single_only) or '无'}。\n\n"
for r in a['results']:
 text+=f"- {labels[r['task']]}，{names[r['variant']]}：{r['reason'] or '未附加原因说明，按下列退出状态判断'}"
 if r['variant']=='improved':text+=f"；退出{r['agent_exit']}，保护类型{r.get('limit_kind')}，正常提交{r['normal_submission']}。\n"
 else:
  text+=f"；文档{r.get('document_status')}，{r.get('document_handoff_bytes')}字节/{r.get('document_citations',0)}引用，完整三角色{r['complete_three_role']}。\n"
  reports=r.get('review_reports',[]);findings=sum(len(report.get('findings',[])) for report in reports)
  text+=f"  登记审查报告{len(reports)}份、发现{findings}条；角色状态："+'；'.join(f"{x['phase']}={x['status']}" for x in r['roles'])+'。\n'
 for trace,m in r['traces'].items():
  text+=f"  {trace}：{m['actions']}动作、{m['test_commands']}个含测试命令的Bash动作、{m['submission_commands']}个提交命令、{m['repair_control_rejections']}次修复控制拒绝、{m['format_corrections']}次格式纠正。\n"
text+='''
“登记发现”是审查模型的意见，不自动证明是真实缺陷或有效纠错。是否增加独立修复通过、是否正常返工和最终检查分别留证；没有额外用隐藏检查反馈指导模型。文档合法交接/工具注册也不等于内容有用或实际调用。详细意见、响应、角色轨迹和原输出均在归档。

本批实际未走到审查：完整组4次均RepairNoProgress，BarrelList文档另因document_repeated_evidence_limit失败后按原降级规则继续，其余3次文档合法提交information_not_found。改良单Agent的Click、BarrelList、JSONL分别221/225/229个Bash动作后TimeExceeded，未提交；表格17动作后context_bytes停止。

最终8个工作副本的实现diff均0字节：4个单Agent导出空补丁，4个完整组无合法封存候选。因此Final patch cannot replay是空补丁/未解决，不是有效候选被重放设施损坏；本批没有实际进入“合法最终补丁的保留方法执行”，保留资格验证与最终无候选评分分开。

改良组大量使用`cd "$(pwd)"`前缀、复合sed/grep、临时输出及Python打印源码；现有简单重复读守卫不能覆盖这些形式。例如Click同一复合读取重复137次。完整组更早返回读取/停滞纠正，4次初修分别66/24/22/21动作，但没有变成实现交付。表格单Agent确实尝试按固定行位置改写，工具回执显示写入前断言失败；同条复合命令继续执行检查并打印退出码，最后整体返回0，公开检查实际仍失败。以上来自原命令/回执和最终字节差异，不推测模型内部原因，也不在本批中途补修。

本批先暴露出执行闭环瓶颈，不能据此认定这些问题超出了模型的代码推理能力。后续优先离线核对“读到必要内容→形成实现变更→真实验证→提交”的接线，而不是继续提高付费任务难度；这只是后续建议，本批没有追加修复或真实调用。

## 费用与实际耗时

| 指标 | 改良单Agent四题 | 完整多Agent四题 |
| --- | --- | --- |
'''
for label,key in [('独立补丁通过','resolved'),('正常提交','normal_submissions'),('平台尝试','attempts'),('已知价格估算/元','known_price_estimate_cny'),('未知费用占位/元','unknown_placeholder_cny'),('实际运行累计/秒','elapsed_seconds')]:
 vals=[]
 for v in names:
  val=arms[v][key]
  if key=='resolved':val=f'{val}/4'
  elif key=='normal_submissions':val=f'{val}/4（初修）' if v=='full' else f'{val}/4'
  elif key=='known_price_estimate_cny':val=f'{val:.6f}'
  elif key=='elapsed_seconds':val=f'{val:.3f}'
  vals.append(str(val))
 text+=f"| {label} | {' | '.join(vals)} |\n"
text+=f'''
共{a['platform_attempts']}次平台尝试，已知估算{a['known_price_estimate_cny']:.6f}元，未知费用占位{a['unknown_placeholder_cny']:.2f}元；完整费用{'未知' if a['complete_cost_estimate_cny'] is None else a['complete_cost_estimate_cny']}，不把占位加到估算当确认扣费。耗时取原worker收尾metrics，包含本机准备/检查/收尾，排除队列等待和后续保留评分，不退回创建至结束计时。缺失运行计时：改良{arms['improved']['elapsed_unknown_runs']}、完整{arms['full']['elapsed_unknown_runs']}；若有缺失，上表只能表示已知部分。

计费停止记录`{a['billing_stop']}`。8个身份北邮首试均500，按原规则转DeepSeek备用，未出现明确余额不足/计费拒绝。新服务失败与备用切换均保留，具体平台类型/状态码见manifest；没有余额探测，不把连接错误或500猜作余额/认证问题。

{conclusion}这些是4道预设相互约束问题各一次的描述性结果，不代表真实中型工程整体表现、统计稳定率或角色数量的因果结论。不能只依据“approve次数多”或“调用工具多”判断收益，应同时看修复、协作是否完整，以及费用和时限机会的差异。

## 旧结果保护和交付

正式53条payload、原3177条共享请求、7941份旧experiments/evaluation文件逐项保持；共享请求现{a['shared_requests_after']}，{a['frozen_inputs_verified']}份冻结输入在终态评分后再次核对。原46/58/61/63比较和59/60/62开发复验分别保留，不混合分母或回填旧成绩；旧冻结因本轮登记源码变化已失配，不复用发起旧身份。

正式成果`experiments/medium_comparison_20261028/`保存8身份、成功/失败、角色报告/响应、合法候选/补丁、独立评分、资格、固定条件/授权、费用增量和原工具证据。全部ZIP成员与外层SHA256核对并递归扫描两份真实凭据和令牌模式；不上传正式数据库或整份共享账本。没有操作医疗、异机、依赖安装、8765服务或文件删除。

本批到此结束，不追加模型运行让结果更好看。若依据这些题继续修改策略，这些题即转为开发回归题；新的效果结论需另选题/冻结，不把本批已用题继续叫新题。
'''
target=ROOT/'Project'/docname;assert not target.exists();target.write_text(text,encoding='utf-8')
brief=f"2026-10-28最新：[64四题中等任务比较]({{prefix}}{docname})：按用户直接授权，63版四道未用相互约束行为（Click资源异常、boltons切片/JSONL定位/表格）预冻结684输入，改良单Agent/完整各一次共8身份，全部终态保留无选优重跑。补丁{scores}、完整协作{a['full_complete']}/4；{a['platform_attempts']}尝试已知估算{a['known_price_estimate_cny']:.6f}元/未知占位{a['unknown_placeholder_cny']:.2f}，完整费用未知；耗时用worker实际记录不含排队。23原服务+5组窄门控/题目资格通过，只加两处元数据登记，不改运行规则。正式53payload/原3177请求/7941旧文件保持，现{a['shared_requests_after']}。旧成绩不改，无面板重启/医疗/异机；中等为预设本地分类、熟悉两仓库3:1、总预算未对齐，非统计/角色数因果证明。"
def insert(path,marker,value):
 s=path.read_text('utf-8');assert marker in s and docname not in s
 path.write_text(s.replace(marker,marker+'\n\n'+value,1),encoding='utf-8')
insert(ROOT/'AGENTS.md','## 当前阶段','- '+brief.format(prefix='Project/'))
insert(ROOT.parent/'job/AGENTS.md','## 当前状态与导航','- '+brief.format(prefix='../shixi_project/Project/'))
for relative,prefix in [('Project/00_项目现状与快速接手.md',''),('README.md','Project/')]:
 p=ROOT/relative;s=p.read_text('utf-8');assert docname not in s;at=s.index('\n');p.write_text(s[:at+1]+'\n'+brief.format(prefix=prefix)+'\n'+s[at+1:],encoding='utf-8')
p=ROOT/'Project/项目开发流水账.md';s=p.read_text('utf-8');assert docname not in s;at=s.index('\n')
p.write_text(s[:at+1]+f'\n我固定63版，对资源异常、切片删除、JSONL定位、表格渲染四道相互约束新问题比较改良单Agent与完整组。8身份先登记各跑一次，补丁{scores}、完整协作{a["full_complete"]}/4。{conclusion}全部好坏结果保留，不回填旧成绩；中等难度是提前本地分类，两组总时间/返工机会仍不同。[详细证据]({docname})。\n'+s[at+1:],encoding='utf-8')
print(json.dumps({'document':str(target),'scores':scores},ensure_ascii=False))
