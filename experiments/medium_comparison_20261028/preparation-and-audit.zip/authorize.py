"""Bind the human's eight-run instruction to fixed inputs before any dispatch."""
import hashlib,json,sqlite3,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c64_1028'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
import comparison_batch as b
from task_service_store import policy
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT/'authorization.json').exists() and not (HOME/'dispatched.json').exists()
baseline=read(OUT/'baseline.json');checks=read(OUT/'offline-checks.json')
assert checks['groups_passed']==5 and checks['external_model_calls']==0
service=(OUT/'service-tests.txt').read_text('utf-8-sig');assert 'Ran 23 tests in ' in service and service.rstrip().endswith('OK')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 formal=dict(db.execute('SELECT id,payload FROM runs'))
assert formal==read(OUT/'formal-before.json') and len(formal)==53
assert read(ROOT/'data/deepseek_budget.json')==read(OUT/'ledger-before.json') and baseline['shared_requests']==3177
history=read(OUT/'history-before.json');assert len(history)==7941 and all(sha(ROOT/n)==h for n,h in history.items())
plan=b.verify(HOME);assert len(plan['slots'])==8
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline['source_commit']
plan.update(source_base_commit=baseline['source_commit'],
 source_delta_scope='Only two comparison metadata/dispatch files add the new packet and existing improved/full two-arm selection. No runtime model, prompt, protection, environment, time or pricing changes.',
 issue_novelty='Four unused interacting behaviors in two familiar repositories, three boltons and one Click; locally preclassified moderate, not external difficulty or training-unseen evidence.',
 order_limit='Tasks1/3 improved then full; Tasks2/4 full then improved. Serial, one repetition, alternating order, no randomization.',
 improved_configuration=policy('adaptive_history'),maximum_runs=8)
b.write(HOME/'plan.json',plan);digest=sha(HOME/'plan.json');b.write(HOME/'plan-sha256.json',{'sha256':digest});b.verify(HOME)
condition={k:plan[k] for k in ['source_base_commit','source_delta_scope','design','tasks','variants','slots','improved','full',
 'visibility','scoring','failure_policy','destinations','accounting','runtime_identity','confounds','order_limit','improved_configuration','issue_novelty']}
condition.update(complexity_qualification={t:read(ROOT/'evaluation/medium_comparison_20261028/evaluator'/t/'source.json')['complexity_rationale'] for t in plan['tasks']},plan_sha256=digest,frozen_inputs=len(plan['files_sha256']),offline_check_sha256=sha(OUT/'offline-checks.json'),
 service_test_sha256=sha(OUT/'service-tests.txt'),qualification_sha256=sha(HOME/'qualification.json'),
 maximum_runs=8,all_identities_created_before_first_model=True,selection_reruns=0,
 public_sources=['https://github.com/pallets/click/issues/2447','https://github.com/pallets/click/pull/3058','https://github.com/mahmoud/boltons/pull/471','https://github.com/mahmoud/boltons/pull/472','https://github.com/mahmoud/boltons/pull/464','https://github.com/mahmoud/boltons/pull/465','https://github.com/mahmoud/boltons/blob/master/CHANGELOG.md'])
b.write(OUT/'fixed-conditions.json',condition)
b.write(OUT/'authorization-record.json',{'human_instruction':baseline['authorization'],'plan_sha256':digest,'maximum_runs':8,
 'scope':'This exact eight-slot comparison only. No retries selected by outcome, no old identity resume.',
 'offline_check_groups':5,'existing_service_tests':23,'model_calls_before_dispatch':0})
(OUT/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','scripts/comparison_inputs.py','scripts/comparison_batch.py'],cwd=ROOT))
b.write(OUT/'authorization.json',{'approved':True,'plan_sha256':digest,'maximum_runs':8})
print(json.dumps({'authorized_slots':8,'plan_sha256':digest,'frozen_inputs':len(plan['files_sha256']),
 'formal_unchanged':53,'requests_unchanged':3177,'historical_files_unchanged':7941,'model_calls':0}))
