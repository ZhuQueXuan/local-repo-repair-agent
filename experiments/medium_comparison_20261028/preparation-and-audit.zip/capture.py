import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
assert not (OUT/'baseline.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:formal=dict(db.execute('SELECT id,payload FROM runs'))
ledger=json.loads((ROOT/'data/deepseek_budget.json').read_bytes())
history={p.relative_to(ROOT).as_posix():sha(p) for directory in ['experiments','evaluation'] for p in (ROOT/directory).rglob('*') if p.is_file()}
for name,value in [('formal-before.json',formal),('ledger-before.json',ledger),('history-before.json',history)]:
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
for name in ['comparison_batch.py','comparison_inputs.py']:(OUT/(name+'-before')).write_bytes((ROOT/'scripts'/name).read_bytes())
baseline={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'formal_payloads':len(formal),'shared_requests':len(ledger['requests']),'historical_files':len(history),'maximum_runs':8,
 'authorization':'那就按这个方案做，选4道中等复杂度的新题，固定当前版本和条件，只比较改良单Agent和完整多Agent，共8次真实运行。真实调用不用逐次问我，好坏结果都保留，旧成绩别改。'}
(OUT/'baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(baseline,ensure_ascii=False))
