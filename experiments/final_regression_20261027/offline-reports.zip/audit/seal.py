"""Archive selected offline reports only; scratch and whole live data stay local."""
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
DEST = ROOT/'experiments/final_regression_20261027'
audit = json.loads((OUT/'audit.json').read_bytes())
assert audit['complete']
assert not DEST.exists()
keys = [v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v]
assert len(keys) == 2
objects = 0
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def scan(raw, depth=0):
    global objects
    objects += 1
    assert depth <= 6 and not any(k in raw for k in keys), 'Credential detected; value withheld'
    assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw), 'Token pattern detected'
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if not n.endswith('/'): scan(z.read(n),depth+1)

entries = []
original = ROOT/'temp/regression'/audit['interrupted_driver']
for n in ['inventory.json','protected_before.json','native.log','adapter.log','native/upstream_results.json','native/upstream_junit.xml']:
    entries.append((original/n,'original-interrupted/'+n))
for label in ('adapter','project'):
    folder = ROOT/audit[label]['directory']
    names = ['inventory.json','protected_before.json','protected_after.json','summary.json',label+'.log']
    if label == 'adapter': names += ['adapter/upstream_results.json','adapter/upstream_junit.xml']
    entries.extend((folder/n,'completed-'+label+'/'+n) for n in names)
entries.append((ROOT/audit['adapter']['reference'],'reference/adapter-upstream_results.json'))
for n in ['baseline.json','audit.json','audit.py','seal.py']:
    entries.append((OUT/n,'audit/'+n))
members = {}
for p,n in entries:
    assert p.is_file() and n not in members
    raw = p.read_bytes(); scan(raw); members[n] = sha(raw)
DEST.mkdir()
with zipfile.ZipFile(DEST/'offline-reports.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,n in entries: z.writestr(n,p.read_bytes())
with zipfile.ZipFile(DEST/'offline-reports.zip') as z:
    assert all(sha(z.read(n)) == h for n,h in members.items())
scan((DEST/'offline-reports.zip').read_bytes())
write(DEST/'offline-reports.zip.sha256.json',members)
write(DEST/'manifest.json',dict(audit,archive_members=len(members),
      credential_scan={'keys_checked':2,'objects_including_nested':objects,'matches':0},
      source_changes=0,new_tests=0,formal_database_and_whole_ledger_uploaded=False,
      scope='Offline engineering regression only; not new real-model performance, browser or cross-machine acceptance. Six existing adapter failures retained.'))
write(DEST/'artifact_sha256.json',{n:sha((DEST/n).read_bytes()) for n in ['offline-reports.zip','offline-reports.zip.sha256.json','manifest.json']})
print(json.dumps({'members':len(members),'objects_scanned':objects,'credential_matches':0}))
