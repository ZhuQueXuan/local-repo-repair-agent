"""Stage 57 read-only conservation and completed regression audit."""
import hashlib
import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

baseline = read(OUT/'baseline.json')
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro', uri=True) as db:
    formal = dict(db.execute('SELECT id,payload FROM runs'))
assert formal == read(OUT/'formal-before.json') and len(formal) == 53
ledger = read(ROOT/'data/deepseek_budget.json')
assert ledger == read(OUT/'ledger-before.json') and len(ledger['requests']) == 2477
history = read(OUT/'historical-before.json')
assert len(history) == 82 and all(sha(ROOT/n) == h for n,h in history.items())
original = ROOT/'temp/regression/20261027_202844_58de5350'
protected = read(original/'protected_before.json')
changed = [n for n,h in protected.items() if not (ROOT/n).is_file() or sha(ROOT/n) != h]
assert not changed, changed
native = read(original/'native/upstream_results.json')
assert native['exit_code'] == 0 and native['counts'] == {'passed':301} and not native['guard_violations']
report = {'stage':57, 'source_commit':baseline['source_commit'], 'formal_payloads_unchanged':53,
          'shared_requests_unchanged':2477, 'new_model_attempts':0, 'historical_files_unchanged':82,
          'protected_files':len(protected), 'changed_protected_files':changed,
          'native':{'counts':native['counts'], 'deselected':len(native['deselected']), 'guard_violations':0},
          'interrupted_driver':'20261027_202844_58de5350',
          'interruption':'No remaining OS driver/pytest/unittest process; adapter log partial, project not started. Native result retained.'}
adapter_path = OUT/'adapter-path.txt'
project_path = OUT/'project-path.txt'
if adapter_path.exists():
    adapter_dir = ROOT/adapter_path.read_text('utf-8').strip()
    adapter = read(adapter_dir/'adapter/upstream_results.json')
    reference = read(ROOT/'temp/regression/20261027_025633_062e3945/adapter/upstream_results.json')
    failures = lambda d: sorted(r['nodeid'] for r in d['reports'] if r['outcome']=='failed')
    skips = lambda d: sorted(r['nodeid'] for r in d['reports'] if r['outcome']=='skipped')
    assert adapter['counts'] == reference['counts'] == {'passed':169,'failed':6,'skipped':1}
    assert failures(adapter) == failures(reference) and skips(adapter) == skips(reference)
    assert not adapter['guard_violations']
    summary = read(adapter_dir/'summary.json')
    assert not summary['changed_protected_files']
    report['adapter'] = {'directory':adapter_dir.relative_to(ROOT).as_posix(), 'counts':adapter['counts'],
                         'failed_nodeids':failures(adapter), 'skipped_nodeids':skips(adapter),
                         'same_failures_as_reference':True, 'guard_violations':0,
                         'reference':'temp/regression/20261027_025633_062e3945/adapter/upstream_results.json'}
if project_path.exists():
    project_dir = ROOT/project_path.read_text('utf-8').strip()
    summary = read(project_dir/'summary.json')
    assert not summary['changed_protected_files']
    project = summary['jobs'][0]
    assert project['scope'] == 'project' and project['exit_code'] == 0
    log = (project_dir/'project.log').read_text('utf-8', errors='replace')
    assert re.search(r'\nOK \(skipped=1\)\s*$', log)
    skipped_lines = [line for line in log.splitlines() if ' ... skipped ' in line]
    assert len(skipped_lines) == 1 and 'test_real_file_symlink_is_not_read' in skipped_lines[0]
    report['project'] = dict(project, directory=project_dir.relative_to(ROOT).as_posix(),
                            passed=project['tests_run']-project['skipped'], skipped_checks=skipped_lines,
                            seconds=float(re.search(r'Ran \d+ tests? in ([\d.]+)s',log)[1]))
report['complete'] = 'adapter' in report and 'project' in report
write(OUT/'audit.json', report)
print(json.dumps(report, ensure_ascii=False))
