import json
from pathlib import Path
OUT=Path(__file__).parent
for name in ('audit.json','new-request-receipts.json','ledger-after.json','diagnostics.json','fixed-conditions.json'):
 target=OUT/('initial-'+name);assert not target.exists();target.write_bytes((OUT/name).read_bytes())
print('Preserved both terminal failures and their exact original conditions before interface correction.')
