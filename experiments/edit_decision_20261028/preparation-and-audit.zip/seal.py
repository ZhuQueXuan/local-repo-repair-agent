"""Preserve both outcomes and every offline failure, without formal data/whole ledger."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
HOME=ROOT/'temp/comparison_batches/c67_1028';DEST=ROOT/'experiments/edit_decision_20261028'
def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
audit=read(OUT/'audit.json');assert audit['all_terminal'] and not DEST.exists()
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
 global scanned
 scanned+=1;assert depth<=7 and not any(k in raw for k in keys),'Credential detected; value withheld'
 assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(z.read(n),depth+1)
DEST.mkdir();outer={};counts={}
def pack(name,entries):
 members={}
 with zipfile.ZipFile(DEST/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p,n in entries:
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.lock' or p.name.endswith(('-wal','-shm')):continue
   assert not p.name.startswith('.env') and n not in members
   raw=p.read_bytes();scan(raw);members[n]=sha(raw);z.writestr(n,raw)
 with zipfile.ZipFile(DEST/name) as z:assert all(sha(z.read(n))==h for n,h in members.items())
 write(DEST/(name+'.sha256.json'),members);counts[name]=len(members)
 for suffix in ('','.sha256.json'):outer[name+suffix]=sha((DEST/(name+suffix)).read_bytes())
run_entries=[]
for prefix,home in [('initial',HOME),('actual-api-tools',ROOT/'temp/comparison_batches/c67b_1028')]:
 run_entries.extend((p,prefix+'/'+p.relative_to(home).as_posix()) for p in sorted(home.rglob('*')) if p.is_file())
 with sqlite3.connect((home/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
  rows=[json.loads(v) for v, in db.execute('SELECT payload FROM runs')]
 for row in rows:
  work=Path(row['workspace']) if row.get('workspace') else None
  if work is None:continue
  assert work.resolve().is_relative_to((ROOT/'temp').resolve())
  # Raw execution/state receipts live in the owned checkout, outside store/runs.
  for folder in ('temp/task-state','temp/tool-output'):
   run_entries.extend((p,'local-execution/'+row['id']+'/'+p.relative_to(work).as_posix())
    for p in sorted((work/folder).rglob('*')) if p.is_file())
pack('three-development-runs.zip',run_entries)
patch=subprocess.check_output(['git','diff','--binary','--','scripts'],cwd=ROOT)
(OUT/'source-change.patch').write_bytes(patch)
# git diff does not include the new module; preserve its exact frozen bytes separately.
entries=[(p,p.relative_to(OUT).as_posix()) for p in sorted(OUT.iterdir()) if p.is_file()
 and p.suffix in {'.py','.json','.log','.patch'} and 'ledger' not in p.name and p.name not in {
 'formal-before.json','ledger-before.json','ledger-after.json','history-before.json','commit-inventory.json'}]
entries.append((ROOT/'scripts/edit_decision.py','new-source/edit_decision.py'))
pack('preparation-and-audit.zip',entries)
folders=[Path(read(OUT/'fixed-conditions.json')['regression']).parent,ROOT/'temp/regression/20261028_151658_0913e651',
 Path(read(OUT/'tool-interface-fixed-conditions.json')['regression']).parent]
regression=[]
for prefix,folder in zip(('initial-full-fixed','initial-compatibility-failure','actual-api-tools-final-project'),folders):
 regression.extend((p,prefix+'/'+p.relative_to(folder).as_posix()) for p in sorted(folder.rglob('*')) if p.is_file()
  and p.suffix in {'.log','.json','.xml'} and p.name not in {'protected_before.json','protected_after.json'})
pack('offline-regression.zip',regression)
write(DEST/'manifest.json',dict(audit,archive_members=counts,
 credential_scan={'keys_checked':2,'objects_including_nested':scanned,'matches':0},
 formal_database_and_whole_shared_ledger_uploaded=False,source_patch='preparation-and-audit.zip/source-change.patch',
 new_source='preparation-and-audit.zip/new-source/edit_decision.py'))
outer['manifest.json']=sha((DEST/'manifest.json').read_bytes());write(DEST/'artifact_sha256.json',outer)
print(json.dumps({'archives':counts,'credential_scan_objects':scanned,'matches':0}))
