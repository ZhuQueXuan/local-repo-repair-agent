"""Preserve the post-live metadata correction as OFFLINE ONLY, no new run."""
import difflib,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'mini-swe-agent/src')]
from task_service_worker import freeze_inputs
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
log=(OUT/'range-correction-final-tests.log').read_text('utf-8-sig')
assert 'Ran 138 tests' in log and log.rstrip().endswith('OK')
initial=read(OUT/'tool-interface-fixed-conditions.json')
changed=[n for n,h in initial['inputs'].items() if sha(ROOT/n)!=h]
assert sorted(changed)==['scripts/edit_decision.py','scripts/test_collaboration_runtime.py'],changed
patch=[]
for n in changed:
 old=OUT/'tool-interface-snapshot/boltons-table-text/frozen_inputs'/n
 assert sha(old)==initial['inputs'][n]
 patch.extend(difflib.unified_diff(old.read_text('utf-8').splitlines(keepends=True),
  (ROOT/n).read_text('utf-8').splitlines(keepends=True),fromfile='paid-actual-tools/'+n,tofile='offline-range-metadata/'+n))
(OUT/'range-correction.patch').write_text(''.join(patch),encoding='utf-8')
target=OUT/'offline-final-snapshot';target.mkdir()
inputs=freeze_inputs('boltons-table-text',target)
inputs[Path(__file__).relative_to(ROOT).as_posix()]=sha(Path(__file__))
record={'kind':'Offline-only range correction after ALL THREE paid outcomes closed; zero new model calls or run identities.',
 'inputs':inputs,'changed_after_last_paid':changed,'targeted_checks':138,'new_model_calls':0,
 'reason':'Third model made three invalid evidence ranges, even with actual decision tools. Return exact legal bounded example, total lines/bytes and explicit zero evidence grant; caller must choose/resubmit. Same 512B, two-request and three-rejection limits.',
 'last_paid_outcome_unchanged':read(OUT/'tool-interface-audit.json')['results'][0]['run_id']}
(OUT/'offline-final-conditions.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'offline_only':True,'frozen_inputs':len(inputs),'changed':changed,'new_model_calls':0}))
