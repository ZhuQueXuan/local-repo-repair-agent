"""Read-only trajectory diagnosis; no old commands or model calls."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
cases=[('full','c66_1028','93dab55b592843a5b379e4d37d8fea96','repairing-trajectory.json'),
       ('improved','c66b_1028','b09fad091f634c6eb8dd86844f49629b','trajectory.json')]
records=[]
for variant,batch,identity,trace in cases:
 run=ROOT/'temp/comparison_batches'/batch/'store/runs'/identity
 j=read(run/trace);messages=j['messages']
 assistants=[(i,m) for i,m in enumerate(messages) if m['role']=='assistant' and m.get('tool_calls')]
 last_input=messages[:assistants[-1][0]]
 tool_indexes=[i for i,m in enumerate(last_input) if m['role']=='tool']
 retained_method=next((i for i in reversed(tool_indexes[-4:]) if 'cur_widths = [len(cur) for cur in text_data]' in last_input[i]['content'] and '[TRUNCATED:' not in last_input[i]['content']),None)
 tool_index=retained_method if retained_method is not None else tool_indexes[-1]
 latest_tool=last_input[tool_index]
 commands=[a['command'] for _,m in assistants for a in m.get('extra',{}).get('actions',[]) if 'command' in a]
 evidence={'run_id':identity,'variant':variant,'model_bash_actions':len(commands),
  'normal_submit_actions':sum('COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' in c for c in commands),
  'assistant_text_present':sum(bool(m.get('content','').strip()) for _,m in assistants),
  'last_input_tool_index':tool_index,'last_input_tool_truncated':'[TRUNCATED:' in latest_tool['content'] or 'remainder omitted' in latest_tool['content'],
  'last_input_contains_original_table_width_bug':'cur_widths = [len(cur) for cur in text_data]' in latest_tool['content'],
  'last_input_tool_content':latest_tool['content'],
  'scope':'Recorded tool data and declared projection metadata; cannot establish the model understood it or had a correct repair hypothesis.'}
 projections=run/'repair-context-projections.json'
 if projections.exists():
  projections_data=read(projections);groups=[]
  for entry in projections_data:
   if entry.get('mode')!='hard_guard_completed_projection':groups.append([entry])
   else:groups[-1].append(entry)
  complete=[]
  for i,m in enumerate(messages):
   if m.get('role')!='tool' or 'cur_widths = [len(cur) for cur in text_data]' not in m.get('content','') or '[TRUNCATED:' in m['content'] or 'remainder omitted' in m['content']:continue
   completed=sum(1 for j,_ in assistants if j<i)
   if completed>=len(groups):continue  # Final tool has no later model request.
   projection=groups[completed][-1]
   replaced=[r['message_index'] for r in projection.get('replaced_outputs',[])]
   complete.append({'tool_index':i,'next_request_ordinal':completed+1,'projection_mode':projection.get('mode'),
       'tool_omitted':i in replaced,'content':m['content']})
  evidence['complete_method_views_before_later_requests']=complete
  evidence['last_projection']=projections_data[-1]
  evidence['full_method_received_in_at_least_one_prepared_request']=any(not c['tool_omitted'] for c in complete)
  assert evidence['full_method_received_in_at_least_one_prepared_request']
 assert not evidence['normal_submit_actions']
 records.append(evidence)
result={'records':records,'model_calls':0,'old_actions_executed':0,
 'facts':['No implementation changes or submit in the selected failed runs (original terminal audit).',
  'Several complete Table method observations remain in the immediately following prepared request; later compaction can still remove older copies.',
  'Existing advisory state precedes recent exchanges; tool views can end with a concrete Next read command.',
  'No assistant text was recorded outside tool calls in these runs; internal reasoning is unavailable.'],
 'hypothesis_not_proven_cause':'The action interface and request order favor continued evidence collection without requiring a model-authored implementation decision. Exact editing and a last-position bounded decision may improve this transition; real acceptance is required.',
 'new_policy':'After the eight-action window, edit/precise evidence/abandon decision, atomic exact edit plus actual original validators, standalone submit only. Not an automatic patch or success guarantee.'}
(OUT/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(records),'full_method_available':records[0]['full_method_received_in_at_least_one_prepared_request'],
 'complete_retained_views':sum(not c['tool_omitted'] for c in records[0].get('complete_method_views_before_later_requests',[])),'model_calls':0}))
