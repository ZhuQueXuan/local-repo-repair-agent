"""Adapt the audited previous-stage once-only driver, before dispatch."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
old=ROOT/'temp/read_recovery_20261028'
text=(old/'live.py').read_text('utf-8')
text=text.replace('c66_1028','c67_1028').replace('development66-','development67-').replace('Stage66','Stage67')
text=text.replace("targeted-final.log","targeted-compat.log").replace('Ran 130 tests','Ran 137 tests')
text=text.replace('regression-driver.log','regression-final-driver.log')
text=text.replace(" replay=read(OUT/'replay.json');assert replay['all_checks_passed'] and replay['model_calls']==0", " analysis=read(OUT/'analysis.json');assert len(analysis['records'])==2")
text=text.replace("'replay':replay", "'offline_evidence':{'analysis':'analysis.json','targeted_tests':137,'new_tests':4}")
text=text.replace('Read-only output continuation with immutable hashes; once-per-origin/current-revision recovery of observations omitted from API view; context grep and compound pagination; real declared public reproduction before initial model run. Existing request/fee/time/security guards, eight-action advisory/24-action stop and role times unchanged.',
 'Initial evidence-to-edit checkpoint after eight actions without source/new-check progress; latest program message after task card, exact model-authored edit or at most two short evidence requests per revision, honest abandonment and three rejection stop. Actual registered checks automatically execute after any source edit; current passing revision permits one final diff and actual standalone model submission. Shared compact instructions, unchanged raw group, request/fee/time/security and role bounds; review revisions retain existing protocol. No seeded patch or automatic submit.')
(OUT/'live.py').write_text(text,encoding='utf-8')
text=(old/'compare_adapter.py').read_text('utf-8').replace('regression-driver.log','regression-final-driver.log')
(OUT/'compare_adapter.py').write_text(text,encoding='utf-8')
text=(old/'audit.py').read_text('utf-8').replace('c66_1028','c67_1028').replace('4104','4177').replace('8447','8455').replace("'stage':66","'stage':67")
needle="  if (work/'temp/task-state/state.json').is_file():entry['terminal_task_state']=read(work/'temp/task-state/state.json')"
replacement=needle+"\n  decisions=[e for e in events if e.get('decision_event')]\n  entry['decision_events']=decisions\n  requests=work/'temp/task-state/decision-requests.jsonl'\n  entry['last_decision_requests']=[json.loads(l) for l in requests.read_text('utf-8').splitlines()] if requests.is_file() else []"
assert needle in text;text=text.replace(needle,replacement)
(OUT/'audit.py').write_text(text,encoding='utf-8')
print('Prepared once-only driver, adapter comparison and outcome audit; zero models called.')
