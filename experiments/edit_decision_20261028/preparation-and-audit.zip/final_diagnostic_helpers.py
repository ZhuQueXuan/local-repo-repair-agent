from pathlib import Path
OUT=Path(__file__).parent
text=(OUT/'diagnose.py').read_text('utf-8').replace('c67_1028','c67b_1028')
text=text.replace("OUT/'diagnostics.json'", "OUT/'tool-interface-diagnostics.json'")
(OUT/'tool_interface_diagnose.py').write_text(text,encoding='utf-8')
text=(OUT/'monitor.py').read_text('utf-8').replace('c67_1028','c67b_1028')
(OUT/'tool_interface_monitor.py').write_text(text,encoding='utf-8')
