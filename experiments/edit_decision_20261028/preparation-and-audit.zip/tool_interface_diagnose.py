"""Read original action/error evidence after each role; no model or scores."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c67b_1028'
records=[]
for s in json.loads((HOME/'slots.json').read_bytes()):
 run=HOME/'store/runs'/s['run_id'];record=s|{'trajectories':{}}
 for p in sorted(run.glob('*trajectory.json')):
  data=json.loads(p.read_bytes());messages=data.get('messages',[])
  actions=[a.get('command',a.get('tool')) for m in messages for a in m.get('extra',{}).get('actions',[])]
  record['trajectories'][p.name]={'action_count':len(actions),'all_model_actions':actions,
   'last_tool_outputs':[m.get('content','')[-1800:] for m in messages if m.get('role')=='tool'][-4:],
   'end_info':{k:data.get('info',{}).get(k) for k in ('exit_status','submission','reason')}}
 records.append(record)
(OUT/'tool-interface-diagnostics.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(records,ensure_ascii=False,indent=2))
