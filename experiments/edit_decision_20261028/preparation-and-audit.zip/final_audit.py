"""Combine preserved failures and the separately frozen actual-tool acceptance."""
from decimal import Decimal
import hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
first=read(OUT/'initial-audit.json');second=read(OUT/'tool-interface-audit.json')
assert first['all_terminal'] and second['all_terminal'] and first['slots']==2 and second['slots']==1
results=[r|{'version':'initial_virtual_commands'} for r in first['results']]+[r|{'version':'actual_api_tools'} for r in second['results']]
assert len({r['run_id'] for r in results})==3
plan1=read(ROOT/'temp/comparison_batches/c67_1028/plan.json');plan2=read(ROOT/'temp/comparison_batches/c67b_1028/plan.json')
changed=[n for n,h in plan1['inputs'].items() if sha(ROOT/n)!=h]
assert sorted(changed)==sorted('scripts/'+n+'.py' for n in ['edit_decision','run_task_batch','task_service_worker','collaboration_live','collaboration_runtime','test_collaboration_runtime']),changed
for n in changed:
 assert sha(OUT/'snapshots/boltons-table-text/frozen_inputs'/n)==plan1['inputs'][n]
postlive=read(OUT/'offline-final-conditions.json')
changed_after_paid=[n for n,h in plan2['inputs'].items() if sha(ROOT/n)!=h]
assert sorted(changed_after_paid)==['scripts/edit_decision.py','scripts/test_collaboration_runtime.py']
for n in changed_after_paid:
 assert sha(OUT/'tool-interface-snapshot/boltons-table-text/frozen_inputs'/n)==plan2['inputs'][n]
assert all(sha(ROOT/n)==h for n,h in postlive['inputs'].items())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
before=read(OUT/'ledger-before.json');after=read(ROOT/'data/deepseek_budget.json')
assert len(before['requests'])==4177 and all(after['requests'][k]==v for k,v in before['requests'].items())
assert {k:v for k,v in before.items() if k!='requests'}=={k:v for k,v in after.items() if k!='requests'}
history=read(OUT/'history-before.json');assert len(history)==8455 and all(sha(ROOT/n)==h for n,h in history.items())
new={k:v for k,v in after['requests'].items() if k not in before['requests']}
known=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']=='settled'),Decimal(0))
unknown=sum((Decimal(v['amount_cny']) for v in new.values() if v['status']!='settled'),Decimal(0))
assert len(new)==sum(r['attempts'] for r in results)
assert abs(float(known)-sum(r['known_price_estimate_cny'] for r in results))<0.000003
diagnostics=read(OUT/'initial-diagnostics.json')+read(OUT/'tool-interface-diagnostics.json');assert len(diagnostics)==3
write(OUT/'diagnostics.json',diagnostics)
audit={'stage':67,'slots':3,'all_terminal':True,'results':results,
 'initial_results':{'slots':2,'resolved':sum(r['resolved'] for r in first['results']),'normal_submissions':sum(v['normal_submissions'] for v in first['arms'].values())},
 'corrected_results':{'slots':1,'resolved':sum(r['resolved'] for r in second['results']),'normal_submissions':sum(v['normal_submissions'] for v in second['arms'].values()),'full_complete':second['full_complete']},
 'resolved':sum(r['resolved'] for r in results),'normal_submissions':sum(v['normal_submissions'] for v in first['arms'].values())+sum(v['normal_submissions'] for v in second['arms'].values()),
 'full_complete':first['full_complete']+second['full_complete'],'selection_reruns':0,'maximum_total_stage_runs':3,
 'source_base_commit':first['source_base_commit'],'initial_plan_sha256':sha(ROOT/'temp/comparison_batches/c67_1028/plan.json'),
 'corrected_plan_sha256':sha(ROOT/'temp/comparison_batches/c67b_1028/plan.json'),
 'initial_frozen_inputs':len(plan1['inputs']),'initial_inputs_changed_after_terminal':changed,
 'changed_initial_inputs_preserved_in_original_snapshot':True,'current_frozen_inputs_verified':len(postlive['inputs']),
 'last_paid_inputs':len(plan2['inputs']),'changed_after_last_paid':changed_after_paid,
 'post_live_correction_model_calls':0,'post_live_correction_real_effect':'NOT VERIFIED',
 'extra_acceptance_reason':plan2['reason'],'platform_attempts':len(new),'known_price_estimate_cny':float(known),
 'unknown_placeholder_cny':float(unknown),'complete_cost_estimate_cny':None if unknown else float(known),
 'formal_payloads_unchanged':53,'shared_requests_before':4177,'shared_requests_after':len(after['requests']),
 'historical_files_unchanged':8455,'actual_worker_seconds':round(sum(r['elapsed_seconds'] for r in results),3),
 'balance_probed':False,'scope':'Two predeclared old-task development acceptances retained; one new full identity after the concrete printed-JSON virtual-tool failure and offline actual API-tool correction. Not a new benchmark, matched comparison, stable rate, or causal effect. No more paid attempts this stage.'}
write(OUT/'audit.json',audit);write(OUT/'new-request-receipts.json',new);write(OUT/'ledger-after.json',after)
print(json.dumps({k:audit[k] for k in ('slots','resolved','normal_submissions','full_complete','platform_attempts','known_price_estimate_cny','unknown_placeholder_cny','shared_requests_after')}))
