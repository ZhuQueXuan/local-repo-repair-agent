"""Exact changed-path allowlist, evidence hashes and recursive credential scan."""
import hashlib,io,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def paths(args):return [v.decode() for v in subprocess.check_output(['git',*args],cwd=ROOT).split(b'\0') if v]
names=sorted(set(paths(['diff','--name-only','-z','HEAD'])+paths(['ls-files','--others','--exclude-standard','-z'])))
allowed={'AGENTS.md','README.md','Project/00_项目现状与快速接手.md','Project/项目开发流水账.md',
 'Project/67_修复与验收_证据到修改的决策闭环.md'}
allowed.update('scripts/'+n+'.py' for n in ['collaboration_live','collaboration_runtime','run_task_batch','edit_decision',
 'task_service_worker','task_state','test_collaboration_runtime','tool_output_budget'])
assert len(names)==21 and all(n in allowed or n.startswith('experiments/edit_decision_20261028/') for n in names),names
keys=[v.encode() for k,v in dotenv_values(ROOT/'.env',interpolate=False).items() if 'KEY' in k and v];assert len(keys)==2
scanned=0
def scan(raw,depth=0):
 global scanned
 scanned+=1;assert depth<=7 and not any(k in raw for k in keys),'Credential detected; value withheld'
 assert not re.search(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9_-]{25,})\b',raw),'Token pattern detected'
 if raw.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(z.read(n),depth+1)
inventory={}
for n in names:
 p=ROOT/n;assert p.is_file() and not p.is_symlink();raw=p.read_bytes();scan(raw);inventory[n]=sha(raw)
scan((ROOT.parent/'job/AGENTS.md').read_bytes())
with sqlite3.connect((ROOT/'data/task_service/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 assert dict(db.execute('SELECT id,payload FROM runs'))==read(OUT/'formal-before.json')
ledger=read(ROOT/'data/deepseek_budget.json');assert ledger==read(OUT/'ledger-after.json')
history=read(OUT/'history-before.json');assert len(history)==8455 and all(sha((ROOT/n).read_bytes())==h for n,h in history.items())
plan=read(OUT/'offline-final-conditions.json')
assert all(sha((ROOT/n).read_bytes())==h for n,h in plan['inputs'].items())
dest=ROOT/'experiments/edit_decision_20261028'
for n,h in read(dest/'artifact_sha256.json').items():assert sha((dest/n).read_bytes())==h
for name in ['three-development-runs.zip','preparation-and-audit.zip','offline-regression.zip']:
 with zipfile.ZipFile(dest/name) as z:
  hashes=read(dest/(name+'.sha256.json'));assert set(hashes)==set(z.namelist())
  assert all(sha(z.read(n))==h for n,h in hashes.items())
(OUT/'commit-pathspec.bin').write_bytes(b'\0'.join(n.encode() for n in names)+b'\0')
(OUT/'commit-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf-8')
record={'files':len(names),'objects_scanned':scanned,'credential_matches':0,'formal_payloads_unchanged':53,
 'shared_requests_after':len(ledger['requests']),'historical_files_unchanged':len(history),'frozen_inputs_verified':len(plan['inputs'])}
(OUT/'commit-scan.json').write_text(json.dumps(record),encoding='utf-8');print(json.dumps(record))
