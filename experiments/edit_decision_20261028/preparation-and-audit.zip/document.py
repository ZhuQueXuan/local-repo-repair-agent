"""Write outcome-specific documentation only after both fixed slots terminate."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
a=read(OUT/'audit.json');initial=read(OUT/'fixed-conditions.json');plan=read(OUT/'tool-interface-fixed-conditions.json')
assert a['all_terminal'] and a['slots']==3
summary=read(Path(plan['regression']));project=next(j for j in summary['jobs'] if j['scope']=='project')
passed=project['tests_run']-project['skipped'];name='67_修复与验收_证据到修改的决策闭环.md'
lines=[]
for r in a['results']:
 checks=r.get('checks',{})
 checktext='；'.join(f"{k} {v['passed']}/{v['tests_run']}" for k,v in checks.items()) or '无可评分补丁'
 lines.append(f"| {r['task']} / {r['variant']} | `{r['run_id']}` | {r['status']} / {r.get('agent_exit') or r.get('repair_result')} | {checktext} | {r.get('collaboration_result') or '单Agent'} |")
body=f'''# 67：证据到实际修改、验证和提交

2026-10-28。按用户授权，暂停加题，先核对旧轨迹和离线验证，再做两次固定的旧题开发验收；首批接口失败补修后，另固定一次完整组验收，本轮共3身份，全部终态保留。基线 `{plan['base']}`，首批输入 {len(initial['inputs'])} 项、接口补修后 {len(plan['inputs'])} 项，各自在真实执行前固定，不更改旧评分。

本轮真实验收仍未打通：3身份均未提交、独立补丁0/3。程序的编辑—真实检查—实际提交路径有离线串联证据，真实仅Click执行过1次修改，不能说模型闭环已经修好。最后参数纠错补修只有离线结果，不再付费追成功。

## 已核实的问题与推测的边界

66的两份轨迹都在24个模型Bash动作后无修改、无提交。表格题有8个完整方法观察，被保留到紧接着的准备请求里；不能把所有停滞归为“模型从未收到关键代码”。但模型文本为空，内部判断不可见，不能据此声称它已理解原因、知道正确补丁，或每一轮都有完整上下文。旧上下文压缩会缩短近期观察，这仍是可能的干扰因素。

流程中能直接确认的缺口是：原阶段建议放在较早的状态消息里，随后又有源码续页的Next提示和任务卡；8次无进展后仍可继续通过不易识别的命令读文件。系统没有要求模型作出一份可执行、可校验的修改决定，重复读取只会在24次后停止。资料恢复解决“能否取回”，没有独自解决“何时开始修改”。这是一种有轨迹依据的工程解释，不是模型内部心理的因果证明。

## 本次改动

1. 初修停滞8动作后，当前程序决策放在整个请求的最后，任务卡之后；预算预留这条消息。普通Shell探索关闭，模型选择提出修改、申请最多两次短证据，或明确放弃。三次连续不合法决定仍失败停止。
2. 决策阶段把实际API工具集收窄成 `repair_edit`、`repair_locate`、`repair_need_evidence`、`repair_abandon`，不再提供bash；正常诊断和提交仍用bash。工具调用经同一受控执行器解释，不把参数当Shell执行。编辑必须由模型提供路径、唯一旧文本、新文本、当前源码版本和简短假设；版本/权限/语法不符原样拒绝，程序不猜补丁。只允许修改登记过的实现文件，无新增、删除或改测试的能力。
3. 精确替换落盘后运行原来登记的两项检查，保存实际子进程退出码、结果和原输出路径。模型在早期使用普通Shell修改实现，也走这个检查闭环。仅打印成功标志不能当通过，也不能当提交。
4. 两项检查均通过且属于当前修改版本后，只接受一次可选diff与模型独立的提交命令。程序不会代交。复核和保留检查仍独立决定补丁是否合格，局部检查通过不等于最终验收成功。
5. 单Agent与完整组初修使用同一段更短的说明，减少重复规则。raw原版不启用；审查返工明确停用初修虚拟命令，继续原意见回应协议。16KB请求、原角色期限、费用记录及权限边界保持。

核心文件：`scripts/edit_decision.py`（决定、版本校验、精确替换与补充证据）；`scripts/run_task_batch.py`（实际API工具集、执行、真实检查、提交标志与请求留证）；`scripts/task_state.py`（持久状态）；`scripts/task_service_worker.py`、`scripts/collaboration_live.py`、`scripts/collaboration_runtime.py`（两入口、任务卡后决策和返工切换）；`scripts/tool_output_budget.py`（实际动作类型）；原 `scripts/test_collaboration_runtime.py` 增加5项必要回归，未另起测试项目。

开源复用评估继续采用现有MIT Mini SWE Agent。对照[SWE-agent精确编辑接口](https://github.com/SWE-agent/SWE-agent/blob/main/tools/edit_anthropic/bin/str_replace_editor)及[Aider编辑块](https://github.com/Aider-AI/aider/blob/main/aider/coders/editblock_coder.py)的既有接口思路，实现登记文件内的精确替换。没有搬入这些框架或复制其实现，不新增依赖、模糊匹配、多文件补丁或迁移底座；当前局部问题无需承担额外集成和许可改造成本。该选型不构成效果证明。

## 离线结果

首批137项、实际工具补修后138项定向通过，包括真实本机写入、两项子进程检查、脚本模拟模型提交与独立流程的串联；失败修改、陈旧版本、越界/测试写入、语法错误、证据配额、重复JSON、输出伪提交和明确放弃均有检查。新增工具回归核验真正发给API的工具集不含bash，并将真实工具调用从解析、执行一直连到原观察格式器，防止只测字符串约定。所有离线回复都是脚本夹具，模型调用0，不能当真实模型成功。

初次124项有1个最小旧夹具字段兼容错误，修正后134项通过。第一次集中项目回归又发现旧五阶段夹具“普通Shell先改再直接交”没有走新检查，失败原日志保留；补齐普通Shell修改后的真实检查，再137项通过。首批集中结果上游原样301、项目443通过/1原权限跳过；适配169通过、6项旧失败、1项原跳过，与57逐个nodeid/phase相同。实际工具补修首次138项的测试夹具漏设原观察模板，失败日志保留；修正夹具后138全通过，再重跑整个项目，{passed}通过、{project['skipped']}项原权限跳过。上游/适配沿用首批结果，其源码、底层环境和配置本次补修未变；不能把所有轮次都称作通过。

## 三次真实开发验收及接口补修

先固定资源异常改良单Agent、表格完整组两身份；原路由、温度、输出上限、任务公开信息和时限保持，不塞入修补答案。两次终态后才运行保留评分。初批均失败：Click确实执行1次模型编辑和2项真实检查，但传入异常参数后未同步修正被调函数，两项检查都失败；接着猜行号、读到无关位置，最终修改块匹配0次而停止。Table已构造旧/新代码，却3次执行Python打印JSON，既没有写文件，也把单文件git哈希错当程序全源码版本；发出的最后程序决策确实到达API，不能以“提示没有发出”解释。

这次真实失败促成两项接口修正：把编辑/证据变成实际工具，决策时移除bash，统一系统说明；提供有界字面符号定位，和短行读取共用两次证据配额，提示复制当前程序版本而非git对象哈希。没有自动执行模型打印的JSON、替它改参数、扩大配额或生成补丁。离线验证后，只新增1次完整Table身份来验收实际接口，事先承诺无论结果都不再追加本批付费。首批423输入中的6个源码变更均保留最初字节快照，后批独立冻结；不是同一条件重跑。

第三次确实通过实际 `repair_need_evidence` 工具进入执行器，但模型分别请求560—600（文件共583行）、520—583及520—560，后两段超512内容字节。三次被拒后按原规则停止，没有修改、检查或审查。新工具接口已实际调用，不等于模型采用了编辑动作。

真实终态后仅离线补两处源码/测试：范围错误返回实际行数、字节上限和一个按原512B/80行约束计算的合法请求示例；不发源码、不消耗证据许可，不自动缩行执行，仍由模型选择是否重新请求。对同一失败模式验证了示例可真实读取、内容逐字对应、配额保持；首轮测试把Windows原始CRLF和归一化文本比较而失败，改为逐原始字节验证后138项定向通过，失败日志保持。末次付费285输入中的2文件变更保留付费时原字节；当前另有285离线冻结输入，新增真实调用0，不能回填第三次失败或宣称模型真实纠正成功。

| 已用开发题 / 系统 | 身份 | 原终态 | 独立检查 | 协作终态 |
| --- | --- | --- | --- | --- |
{chr(10).join(lines)}

首批2身份正常提交0/2、独立补丁0/2。接口补修后唯一完整组身份：初修正常提交{a['corrected_results']['normal_submissions']}/1、独立补丁{a['corrected_results']['resolved']}/1、完整三角色{a['corrected_results']['full_complete']}/1。三身份合计正常提交 {a['normal_submissions']}/3、独立补丁 {a['resolved']}/3。这些版本不同，不能把合计比例称为当前版本成功率。具体动作、拒绝、修改、实际检查和最后程序决策见 `manifest.json` 每个身份的原始计数与回执；自动检查次数不是模型主动验证次数。

平台尝试 {a['platform_attempts']} 次，已知价格部分估算 {a['known_price_estimate_cny']:.6f} 元，未知占位 {a['unknown_placeholder_cny']:.2f} 元，完整费用 {'未知' if a['complete_cost_estimate_cny'] is None else a['complete_cost_estimate_cny']}。正式53条payload、旧4177请求与8455旧成果文件逐项保持；共享账本新增后 {a['shared_requests_after']} 条。无余额探测、面板重启、医疗或异机操作。

这只是已用题的分版本开发验收；不是同题公平对照、因果消融、稳定成功率或多Agent收益证明。新机制收紧了动作选择并代执行声明过的检查，属于系统行为变化；后续若比较效果，必须重新固定条件并明示这项自动检查成本。当前尚未验证模型能稳定选择实际编辑，检查失败后的证据定位/再次修改，以及通过后真实提交，不能用离线夹具替代。应继续暂停扩题；本批关闭，不追加付费重跑。

## 使用与证据

现有任务入口启用adaptive_history进度功能时自动获得此初修流程，不需要用户填写JSON。模型负责选择编辑或证据请求；用户仍按原方式提交任务。运行中的8765面板本次没有重启，不声称其进程已加载新版。

归档：`experiments/edit_decision_20261028/manifest.json`、`three-development-runs.zip`（三次完整原轨迹、实际本机输出和冻结输入）、`preparation-and-audit.zip`（分析、离线各轮失败/通过、准备与审计脚本、补丁及新模块）、`offline-regression.zip`（三轮集中回归）。每个ZIP的成员哈希和外层哈希分别保留，上传前递归检查两套真实密钥与常见令牌。完整正式库和共享账本不放入归档。此前46—66的失败、成绩及快照均保持。
'''
body=body.replace('`scripts/edit_decision.py`','[edit_decision.py：工具与决策](../scripts/edit_decision.py#L19)')
body=body.replace('`scripts/run_task_batch.py`','[run_task_batch.py：实际检查](../scripts/run_task_batch.py#L215)')
body=body.replace('`scripts/test_collaboration_runtime.py`','[test_collaboration_runtime.py：实际工具回归](../scripts/test_collaboration_runtime.py#L192)')
(ROOT/'Project'/name).write_text(body,encoding='utf-8')
nav=(f"2026-10-28最新：[67证据到修改闭环]({name})：补最后程序决策、模型精确编辑、两项实际检查与真实提交；首批423输入2次旧题失败（一次改错、一次仅打印JSON），全部保留。实际编辑/定位/证据/放弃工具后138定向、项目{passed}通过+1原跳过；首批上游301、适配169/6旧失败/1原跳过逐名保持。另冻{len(plan['inputs'])}输入完整组仍三次非法读取而失败：3身份0提交/0修复，真实闭环未打通。最后范围错误补合法小段示例，138离线通过/0新真实调用，付费2变更源另留原快照。共{a['platform_attempts']}尝试已知{a['known_price_estimate_cny']:.6f}元/未知占位{a['unknown_placeholder_cny']:.2f}，完整费用未知；53正式payload/原4177请求/8455旧文件保持，现{a['shared_requests_after']}。旧成绩不改、不再付费追成功，无面板重启/医疗/异机。")
def insert(path,paragraph):
 text=path.read_text('utf-8');assert '[67证据到修改闭环]' not in text
 first,rest=text.split('\n',1);path.write_text(first+'\n\n'+paragraph+'\n'+rest,encoding='utf-8')
insert(ROOT/'Project/00_项目现状与快速接手.md',nav)
insert(ROOT/'README.md',nav.replace('](','](Project/'))
p=ROOT/'AGENTS.md';text=p.read_text('utf-8');assert '[67证据到修改闭环]' not in text
text=text.replace('## 当前阶段\n','## 当前阶段\n\n- '+nav.replace('](','](Project/')+'\n',1);p.write_text(text,encoding='utf-8')
insert(ROOT/'Project/项目开发流水账.md',f"我核对旧轨迹后把重点从恢复证据转到执行决定，补上模型精确编辑、实际检查和真实提交。首批Click改错后无法定位、Table仅打印修改JSON；改成实际工具并138定向/项目{passed}通过后，最后唯一完整组仍三次请求非法范围而停止。三身份0提交/0修复，真实闭环还没修好。我保留全部失败，离线补上合法小段参数示例，138项通过，没有继续付费或回填旧成绩。下一步仍应优先离线处理模型的证据选择到执行决定，而不是继续加题。[67证据到修改闭环]({name})。")
insert(ROOT.parent/'job/AGENTS.md',nav.replace('](','](../shixi_project/Project/'))
print(json.dumps({'document':name,'navigation':5,'all_terminal':True}))
