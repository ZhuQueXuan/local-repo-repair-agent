"""Compact read-only progress; never evaluates withheld tests or calls a model."""
from collections import Counter
import json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;HOME=ROOT/'temp/comparison_batches/c67_1028'
with sqlite3.connect((HOME/'store/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 rows=[json.loads(v) for v, in db.execute('SELECT payload FROM runs')]
for row in rows:
 work=Path(row['workspace']) if row.get('workspace') else None
 record={k:row.get(k) for k in ('id','task','status','stage','reason','agent_exit')}
 if work:
  path=work/'temp/task-state/events.jsonl'
  events=[json.loads(l) for l in path.read_text('utf-8').splitlines()] if path.exists() else []
  record['decisions']=dict(Counter(e.get('decision_event') for e in events if e.get('decision_event')))
  record['observations']=sum(e['kind']=='executed' for e in events)
  path=work/'temp/task-state/progress.jsonl'
  if path.exists():
   values=[json.loads(l) for l in path.read_text('utf-8').splitlines()]
   record['progress']={k:values[-1].get(k) for k in ('phase','current_validation','actions_without_source_or_new_validation')} if values else None
 print(json.dumps(record,ensure_ascii=False))
