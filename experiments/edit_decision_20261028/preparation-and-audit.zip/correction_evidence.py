"""Compare the closed first freeze with the corrected implementation."""
import difflib,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((OUT/'initial-fixed-conditions.json').read_bytes())
changed=[n for n,h in plan['inputs'].items() if sha(ROOT/n)!=h]
assert len(changed)==6 and all(n.startswith('scripts/') for n in changed)
patch=[]
for n in changed:
 old=OUT/'snapshots/boltons-table-text/frozen_inputs'/n;assert sha(old)==plan['inputs'][n]
 patch.extend(difflib.unified_diff(old.read_text('utf-8').splitlines(keepends=True),
  (ROOT/n).read_text('utf-8').splitlines(keepends=True),fromfile='initial/'+n,tofile='actual-api-tools/'+n))
(OUT/'tool-interface-correction.patch').write_text(''.join(patch),encoding='utf-8')
(OUT/'tool-interface-correction.json').write_text(json.dumps({'changed':changed,
 'patch_sha256':sha(OUT/'tool-interface-correction.patch'),'first_terminal_before_correction':True},indent=2),encoding='utf-8')
print(json.dumps({'changed_inputs':len(changed),'old_frozen_bytes_preserved':True,'model_calls':0}))
